using System;
using System.Linq;
using System.Threading.Tasks;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class PlayerListTests
{
    private const string Context = "17cdbdc380e94f11aff50fef43950e552";

    public static Task SearchMatchesNamesAndIdsWithoutChangingRows()
    {
        var accent = Row(11, "Éric", 30);
        var other = Row(204, "Alice", 10);
        var input = new[] { accent, other };
        var byName = PlayerListPolicy.Arrange(input, " ERIC ", PlayerListSort.Distance);
        Check(byName.Count == 1 && ReferenceEquals(byName[0], accent), "Search lost the French name or replaced its identity.");
        var byId = PlayerListPolicy.Arrange(input, "204", PlayerListSort.Name);
        Check(byId.Count == 1 && ReferenceEquals(byId[0], other), "ID search did not match the supplied row.");
        Check(PlayerListPolicy.Arrange(input, "inconnu", PlayerListSort.Distance).Count == 0, "Unmatched players survived filtering.");
        Check(ReferenceEquals(input[0], accent) && ReferenceEquals(input[1], other), "Filtering mutated the capture order.");
        return Task.CompletedTask;
    }

    public static Task InteractionHoldsExistingOrderButRemovesAbsentPlayers()
    {
        var first = Row(1, "Premier", 90);
        var second = Row(2, "Second", 5);
        var newcomer = Row(3, "Nouveau", 1);
        var old = new[] { first.Identity, Row(99, "Absent", 0).Identity, second.Identity };
        var result = PlayerListPolicy.Arrange(new[] { newcomer, second, first }, "", PlayerListSort.Distance, old, holdOrder: true);
        Check(result.Select(row => row.Identity.EntityId).SequenceEqual(new[] { 1, 2, 3 }),
            "An update moved an existing row under the pointer, retained an absent row or inserted a newcomer above it.");
        var released = PlayerListPolicy.Arrange(new[] { first, newcomer, second }, "", PlayerListSort.Distance,
            result.Select(row => row.Identity).ToArray(), holdOrder: false);
        Check(released.Select(row => row.Identity.EntityId).SequenceEqual(new[] { 3, 2, 1 }), "Releasing the list did not resume the requested sort.");
        return Task.CompletedTask;
    }

    public static Task ReusedIdsDoNotInheritHeldPositions()
    {
        var original = Row(7, "Même nom", 10);
        var stable = Row(8, "Stable", 20);
        var replacement = original with { Identity = new PlayerIdentity(Context, 777, 7), DistanceMeters = 1 };
        var result = PlayerListPolicy.Arrange(new[] { replacement, stable }, "", PlayerListSort.Distance,
            new[] { original.Identity, stable.Identity }, holdOrder: true);
        Check(result.Count == 2 && result[0].Identity == stable.Identity && result[1].Identity == replacement.Identity,
            "A different instance inherited the old row position from its reused game ID or name.");
        Check(!result.Any(row => row.Identity == original.Identity), "The prior identity remained in the current list.");
        return Task.CompletedTask;
    }

    public static Task SortsHaveDeterministicTiesAndUnknownHealthLast()
    {
        var unknown = Row(1, "Même", 2) with { Health = null };
        var high = Row(2, "Même", 2) with { Health = 120 };
        var low = Row(3, "Même", 2) with { Health = 5 };
        var input = new[] { low, unknown, high };
        Check(PlayerListPolicy.Arrange(input, "", PlayerListSort.Health).Select(row => row.Identity.EntityId)
            .SequenceEqual(new[] { 3, 2, 1 }), "Health sorting treated an unavailable value as zero or a known value as unavailable.");
        foreach (var sort in new[] { PlayerListSort.Distance, PlayerListSort.Name })
        {
            var one = PlayerListPolicy.Arrange(input, "", sort).Select(row => row.Identity).ToArray();
            var two = PlayerListPolicy.Arrange(input.Reverse().ToArray(), "", sort).Select(row => row.Identity).ToArray();
            Check(one.SequenceEqual(two) && one.Select(identity => identity.EntityId).SequenceEqual(new[] { 1, 2, 3 }),
                "Equal values produced an unstable order between captures.");
        }
        return Task.CompletedTask;
    }

    public static Task LegacyDuplicatesStayVisibleAndReadOnly()
    {
        var first = Row(5, "Legacy A", 20) with { Identity = new PlayerIdentity("", 0, 5) };
        var second = first with { Name = "Legacy B", DistanceMeters = 40 };
        var result = PlayerListPolicy.Arrange(new[] { second, first }, "legacy", PlayerListSort.Name);
        Check(result.Count == 2 && result.All(row => !row.CanAnnotate) && result[0].Name == "Legacy A" && result[1].Name == "Legacy B",
            "Duplicate legacy IDs were silently dropped or promoted to a valid session identity.");
        return Task.CompletedTask;
    }

    private static PlayerRow Row(int id, string name, double distance) => new()
    {
        Identity = new PlayerIdentity(Context, id + 10, id), Name = name, DistanceMeters = distance
    };

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
