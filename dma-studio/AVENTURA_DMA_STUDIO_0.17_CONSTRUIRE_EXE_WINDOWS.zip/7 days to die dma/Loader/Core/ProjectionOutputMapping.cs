#nullable enable
using System;

namespace SevenDaysEsp;

// Maps the complete source image to a display surface in physical pixels.
// Camera projection and the source viewport have already been validated by
// ProjectionMath. This mapping does not infer a fuser's scaling/cropping mode,
// change camera matrices, or turn an old camera capture into a fresh one.
public sealed class ProjectionOutputMapping
{
    public const string Fit = "fit";
    public const string Stretch = "stretch";
    public const string Fill = "fill";

    public int SourceWidth { get; }
    public int SourceHeight { get; }
    public int OutputWidth { get; }
    public int OutputHeight { get; }
    public string Mode { get; }
    public double ScaleX { get; }
    public double ScaleY { get; }
    public double OffsetX { get; }
    public double OffsetY { get; }

    // ImageViewport can extend outside the output in Fill mode. ClipViewport
    // is only the mapped camera viewport intersected with the output surface;
    // a camera sub-viewport must never be enlarged to occupy the whole output.
    public ProjectionViewport ImageViewport { get; }
    public ProjectionViewport ClipViewport { get; }
    public bool HasVisibleViewport => ClipViewport.Width > 0 && ClipViewport.Height > 0;

    private ProjectionOutputMapping(int sourceWidth, int sourceHeight, int outputWidth, int outputHeight,
        string mode, double scaleX, double scaleY, double offsetX, double offsetY,
        ProjectionViewport sourceViewport)
    {
        SourceWidth = sourceWidth; SourceHeight = sourceHeight;
        OutputWidth = outputWidth; OutputHeight = outputHeight; Mode = mode;
        ScaleX = scaleX; ScaleY = scaleY; OffsetX = offsetX; OffsetY = offsetY;
        ImageViewport = new(offsetX, offsetY, sourceWidth * scaleX, sourceHeight * scaleY);
        double left = Math.Max(0, sourceViewport.X * scaleX + offsetX);
        double top = Math.Max(0, sourceViewport.Y * scaleY + offsetY);
        double right = Math.Min(outputWidth, sourceViewport.Right * scaleX + offsetX);
        double bottom = Math.Min(outputHeight, sourceViewport.Bottom * scaleY + offsetY);
        ClipViewport = right > left && bottom > top
            ? new(left, top, right - left, bottom - top)
            : new(0, 0, 0, 0);
    }

    public static bool IsKnownMode(string? mode) => mode == Fit || mode == Stretch || mode == Fill;

    public static bool TryCreate(int sourceWidth, int sourceHeight, int outputWidth, int outputHeight,
        ProjectionViewport sourceViewport, string? mode, out ProjectionOutputMapping? mapping, out string reason)
    {
        mapping = null;
        reason = "";
        if (!ValidDimension(sourceWidth) || !ValidDimension(sourceHeight) ||
            !ValidDimension(outputWidth) || !ValidDimension(outputHeight))
            return Fail("Dimensions source ou sortie absentes ou hors limites.", out reason);
        if (!IsKnownMode(mode))
            return Fail("Mode d'adaptation de l'image inconnu.", out reason);
        if (!ValidViewport(sourceViewport, sourceWidth, sourceHeight))
            return Fail("Viewport caméra absent ou hors de l'image source.", out reason);

        double scaleX = (double)outputWidth / sourceWidth;
        double scaleY = (double)outputHeight / sourceHeight;
        double offsetX = 0, offsetY = 0;
        if (mode != Stretch)
        {
            double scale = mode == Fit ? Math.Min(scaleX, scaleY) : Math.Max(scaleX, scaleY);
            scaleX = scaleY = scale;
            offsetX = (outputWidth - sourceWidth * scale) / 2;
            offsetY = (outputHeight - sourceHeight * scale) / 2;
            // Keep round-off from inventing a tiny crop in Fit, or a tiny
            // letterbox margin in Fill when one dimension matches exactly.
            offsetX = mode == Fit ? Math.Max(0, offsetX) : Math.Min(0, offsetX);
            offsetY = mode == Fit ? Math.Max(0, offsetY) : Math.Min(0, offsetY);
        }
        if (!double.IsFinite(scaleX) || !double.IsFinite(scaleY) || scaleX <= 0 || scaleY <= 0 ||
            !double.IsFinite(offsetX) || !double.IsFinite(offsetY))
            return Fail("Transformation de sortie non finie ou invalide.", out reason);

        mapping = new(sourceWidth, sourceHeight, outputWidth, outputHeight,
            mode!, scaleX, scaleY, offsetX, offsetY, sourceViewport);
        return true;
    }

    // Coordinates can lie outside the OUTPUT in Fill mode. Preserve these
    // coordinates and clip the drawing instead of clamping a rectangle's
    // edges, which would draw a false outline at a crop boundary.
    public bool TryMapPoint(ProjectionPoint source, out ProjectionPoint output)
    {
        output = default;
        if (!ValidSourcePoint(source)) return false;
        double x = source.X * ScaleX + OffsetX;
        double y = source.Y * ScaleY + OffsetY;
        if (!double.IsFinite(x) || !double.IsFinite(y)) return false;
        output = new(x, y);
        return true;
    }

    public bool TryMapBox(ProjectionBox source, out ProjectionBox output)
    {
        output = default;
        if (source.Right <= source.Left || source.Bottom <= source.Top ||
            !TryMapPoint(new(source.Left, source.Top), out var topLeft) ||
            !TryMapPoint(new(source.Right, source.Bottom), out var bottomRight)) return false;
        output = new(topLeft.X, topLeft.Y, bottomRight.X, bottomRight.Y);
        return true;
    }

    public bool IsMarkerVisible(ProjectedMarker? marker)
    {
        if (marker == null || !HasVisibleViewport) return false;
        if (marker.Anchor is { } anchor && TryMapPoint(anchor, out var point) &&
            point.X >= ClipViewport.X && point.X <= ClipViewport.Right &&
            point.Y >= ClipViewport.Y && point.Y <= ClipViewport.Bottom) return true;
        return marker.Bounds is { } bounds && TryMapBox(bounds, out var box) &&
            box.Right > ClipViewport.X && box.Left < ClipViewport.Right &&
            box.Bottom > ClipViewport.Y && box.Top < ClipViewport.Bottom;
    }

    private bool ValidSourcePoint(ProjectionPoint point) =>
        double.IsFinite(point.X) && double.IsFinite(point.Y) &&
        point.X >= 0 && point.Y >= 0 && point.X <= SourceWidth && point.Y <= SourceHeight;

    private static bool ValidDimension(int value) => value >= 1 && value <= ProjectionMath.MaximumOutputDimension;

    private static bool ValidViewport(ProjectionViewport viewport, int width, int height) =>
        double.IsFinite(viewport.X) && double.IsFinite(viewport.Y) &&
        double.IsFinite(viewport.Width) && double.IsFinite(viewport.Height) &&
        viewport.X >= 0 && viewport.Y >= 0 && viewport.Width > 0 && viewport.Height > 0 &&
        viewport.Right <= width && viewport.Bottom <= height;

    private static bool Fail(string message, out string reason) { reason = message; return false; }
}
