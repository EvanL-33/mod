using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using SevenDaysLoader.Services;

namespace SevenDaysLoader.UI;

internal sealed class PlayerPanel : Expander
{
    private static readonly CultureInfo French = CultureInfo.GetCultureInfo("fr-FR");
    private static readonly string[] Palette = { "#66DEF2", "#FF9A52", "#9BF0A3", "#F881AA", "#C6A0FF", "#FFE27A", "#FFFFFF" };
    private readonly ILoaderController controller;
    private readonly ObservableCollection<PlayerListRow> rows = new();
    private readonly ListView list = new();
    private readonly TextBox search = new() { MaxLength = 128, Margin = new Thickness(0, 0, 8, 0), MinWidth = 85 };
    private readonly ComboBox sort = new() { ItemsSource = new[] { "Distance", "Nom", "Vie croissante" }, SelectedIndex = 0, Width = 130 };
    private readonly TextBlock state = FixedText(19, 11, Theme.Muted);
    private readonly TextBlock selectedName = FixedText(21, 13, Theme.Foreground);
    private readonly TextBlock selectedDetails = FixedText(19, 11, Theme.Muted);
    private readonly TextBlock message = FixedText(35, 11, Theme.Muted, wrap: true);
    private readonly List<Button> selectedButtons = new();
    private readonly Button pin;
    private readonly Button mark;
    private readonly Button hide;
    private readonly Button clearAll;
    private bool updating;
    private bool detailsRequested;
    private long nextRefresh;
    private long observedRevision = -1;
    private long lastInteraction;
    private long messageVersion;
    private PlayerIdentity? desiredSelection;
    private string observedColor = "";

    internal PlayerPanel(ILoaderController controller)
    {
        this.controller = controller;
        Header = "Joueurs détectés · liste et marquages";
        Foreground = Theme.Foreground;
        Margin = new Thickness(0, 4, 0, 15);
        IsExpanded = false;
        var body = new StackPanel { Margin = new Thickness(0, 10, 0, 0) };
        body.Children.Add(Theme.Text("Rechercher un nom ou un ID", 11, Theme.Muted));
        var find = new DockPanel { Margin = new Thickness(0, 0, 0, 7) };
        DockPanel.SetDock(sort, Dock.Right);
        find.Children.Add(sort);
        find.Children.Add(search);
        body.Children.Add(find);
        System.Windows.Automation.AutomationProperties.SetName(search, "Rechercher un joueur par nom ou ID");
        System.Windows.Automation.AutomationProperties.SetName(sort, "Trier les joueurs détectés");
        sort.ToolTip = "Le tri se fige pendant l’utilisation de la liste pour éviter de changer de joueur sous le pointeur.";
        body.Children.Add(state);

        var view = new GridView { AllowsColumnReorder = false };
        var nameColumn = Column("Joueur", "Name", 145);
        view.Columns.Add(nameColumn);
        view.Columns.Add(Column("Distance", "Distance", 69));
        view.Columns.Add(Column("PV", "Health", 68));
        view.Columns.Add(Column("Repères", "Flags", 94));
        var headerStyle = new Style(typeof(GridViewColumnHeader));
        headerStyle.Setters.Add(new Setter(Control.BackgroundProperty, Theme.Raised));
        headerStyle.Setters.Add(new Setter(Control.ForegroundProperty, Theme.Muted));
        headerStyle.Setters.Add(new Setter(Control.BorderBrushProperty, Theme.Line));
        headerStyle.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(5, 6, 5, 6)));
        headerStyle.Setters.Add(new Setter(Control.FontSizeProperty, 10.5));
        headerStyle.Setters.Add(new Setter(Control.HorizontalContentAlignmentProperty, HorizontalAlignment.Left));
        view.ColumnHeaderContainerStyle = headerStyle;
        list.View = view;
        list.ItemsSource = rows;
        list.SelectionMode = SelectionMode.Single;
        list.Height = 233;
        list.Background = Theme.Background;
        list.Foreground = Theme.Foreground;
        list.BorderBrush = Theme.Line;
        list.BorderThickness = new Thickness(1);
        list.Margin = new Thickness(0, 4, 0, 8);
        list.FontSize = 11.5;
        System.Windows.Automation.AutomationProperties.SetName(list, "Joueurs détectés dans la capture récente");
        ScrollViewer.SetHorizontalScrollBarVisibility(list, ScrollBarVisibility.Auto);
        ScrollViewer.SetVerticalScrollBarVisibility(list, ScrollBarVisibility.Visible);
        ScrollViewer.SetCanContentScroll(list, true);
        VirtualizingPanel.SetIsVirtualizing(list, true);
        VirtualizingPanel.SetVirtualizationMode(list, VirtualizationMode.Recycling);
        var itemStyle = new Style(typeof(ListViewItem));
        itemStyle.Setters.Add(new Setter(FrameworkElement.HeightProperty, 31.0));
        itemStyle.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(3, 0, 3, 0)));
        itemStyle.Setters.Add(new Setter(Control.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch));
        itemStyle.Setters.Add(new Setter(Control.VerticalContentAlignmentProperty, VerticalAlignment.Center));
        itemStyle.Setters.Add(new Setter(Control.ForegroundProperty, new Binding("Color")));
        itemStyle.Setters.Add(new Setter(FrameworkElement.ToolTipProperty, new Binding("Description")));
        var selected = new Trigger { Property = Selector.IsSelectedProperty, Value = true };
        selected.Setters.Add(new Setter(Control.FontWeightProperty, FontWeights.SemiBold));
        itemStyle.Triggers.Add(selected);
        list.ItemContainerStyle = itemStyle;
        list.SizeChanged += (_, _) => nameColumn.Width = Math.Max(100, list.ActualWidth - 69 - 68 - 94 - 28);
        body.Children.Add(list);
        selectedName.FontWeight = FontWeights.SemiBold;
        body.Children.Add(selectedName);
        body.Children.Add(selectedDetails);

        var actions = new WrapPanel { Margin = new Thickness(0, 5, 0, 0) };
        pin = SelectionButton("Épingler", row => controller.Players.Pin(row.Visual.Pinned ? null : row.Identity));
        mark = SelectionButton("Marquer", row => controller.Players.SetMarked(row.Identity, !row.Visual.Marked));
        hide = SelectionButton("Masquer ESP", row => controller.Players.SetHidden(row.Identity, !row.Visual.Hidden));
        actions.Children.Add(pin);
        actions.Children.Add(mark);
        actions.Children.Add(hide);
        actions.Children.Add(SelectionButton("Effacer ses marques", row => controller.Players.Clear(row.Identity)));
        body.Children.Add(actions);

        body.Children.Add(Theme.Text("Couleur individuelle", 11, Theme.Muted));
        var colors = new WrapPanel();
        foreach (string color in Palette)
        {
            var button = SelectionButton("", row => ApplyColor(row, color));
            button.Width = 25; button.Height = 25; button.MinHeight = 0;
            button.Padding = new Thickness(0); button.Margin = new Thickness(0, 0, 5, 5);
            button.Background = Theme.Brush(color);
            button.ToolTip = color;
            System.Windows.Automation.AutomationProperties.SetName(button, "Couleur du joueur " + color);
            colors.Children.Add(button);
        }
        var custom = Theme.Button("…", ChooseColor);
        custom.Width = 29; custom.Height = 25; custom.MinHeight = 0; custom.Padding = new Thickness(0);
        custom.Margin = new Thickness(0, 0, 5, 5);
        custom.ToolTip = "Couleur personnalisée pour le joueur sélectionné";
        System.Windows.Automation.AutomationProperties.SetName(custom, "Choisir une couleur individuelle");
        selectedButtons.Add(custom);
        colors.Children.Add(custom);
        var defaultColor = SelectionButton("Couleur du profil", row => controller.Players.SetColor(row.Identity, null));
        defaultColor.MinHeight = 25; defaultColor.Padding = new Thickness(7, 3, 7, 3); defaultColor.Margin = new Thickness(0, 0, 0, 5);
        colors.Children.Add(defaultColor);
        body.Children.Add(colors);
        var tools = new WrapPanel();
        clearAll = Theme.Button("Effacer toutes les marques", () =>
        {
            controller.Players.ClearAll();
            desiredSelection = null;
            ShowMessage("Marquages de cette session effacés.");
            Refresh(force: true);
        });
        clearAll.Padding = new Thickness(9, 5, 9, 5); clearAll.MinHeight = 28; clearAll.FontSize = 11;
        tools.Children.Add(clearAll);
        body.Children.Add(tools);
        body.Children.Add(message);
        body.Children.Add(Theme.Text("La liste concerne les joueurs détectés dans les captures récentes. Une absence ne signifie pas une déconnexion. Les marques sont locales à cette session ; elles ne sont jamais réattribuées à partir d’un nom ou d’un ID réutilisé.", 10, Theme.Muted));
        Content = body;

        search.TextChanged += (_, _) => { if (!updating) Refresh(force: true, explicitOrder: true); };
        sort.SelectionChanged += (_, _) => { if (!updating) Refresh(force: true, explicitOrder: true); };
        list.SelectionChanged += (_, _) =>
        {
            if (updating) return;
            if (list.SelectedItem is PlayerListRow row)
            {
                desiredSelection = row.Row.Identity;
                if (row.Row.CanAnnotate && !controller.Players.Select(row.Row.Identity) &&
                    !controller.Players.TryGetVisual(row.Row.Identity, out _))
                    ShowMessage("Ce joueur n’est plus présent dans la capture courante.", error: true);
                else if (!row.Row.CanAnnotate)
                    ShowMessage("Cette source ne fournit pas d’identité de session : liste en lecture seule.");
            }
            else { desiredSelection = null; controller.Players.Select(null); }
            Refresh(force: true);
        };
        list.PreviewMouseWheel += (_, _) => lastInteraction = Environment.TickCount64;
        list.PreviewMouseDown += (_, _) => lastInteraction = Environment.TickCount64;
        list.PreviewKeyDown += (_, _) => lastInteraction = Environment.TickCount64;
        Loaded += (_, _) => { UpdateDetailsRequest(); Refresh(force: true); };
        Unloaded += (_, _) => SetDetailsRequested(false);
        IsVisibleChanged += (_, _) => { UpdateDetailsRequest(); if (IsVisible) Refresh(force: true); };
        Expanded += (_, _) => { UpdateDetailsRequest(); Refresh(force: true); };
        Collapsed += (_, _) => SetDetailsRequested(false);
        UpdateSelection();
    }

    internal void Refresh() => Refresh(force: false);

    private void Refresh(bool force, bool explicitOrder = false)
    {
        if (updating || !IsLoaded || !IsVisible || !IsExpanded) return;
        long now = Environment.TickCount64;
        if (!force && now < nextRefresh) return;
        nextRefresh = now + 250;
        var snapshot = controller.Players.ReadSnapshot();
        string profileColor = controller.Settings.PlayerEsp.Color;
        if (!force && observedRevision == snapshot.Revision && observedColor == profileColor) return;
        // A legacy row may stay selected for reading, using its display slot.
        // It never becomes an annotatable identity and is removed immediately
        // when the current capture no longer contains that slot.
        var legacySelection = list.SelectedItem is PlayerListRow { Row.CanAnnotate: false } selectedLegacy ? selectedLegacy : null;
        observedRevision = snapshot.Revision;
        observedColor = profileColor;
        bool holding = !explicitOrder && (list.IsMouseOver || list.IsKeyboardFocusWithin || list.IsMouseCaptureWithin ||
            sort.IsDropDownOpen || now - lastInteraction < 750);
        var ordered = PlayerListPolicy.Arrange(snapshot.Rows, search.Text, (PlayerListSort)Math.Max(0, sort.SelectedIndex),
            rows.Select(row => row.Row.Identity).ToArray(), holding);
        var occurrences = new Dictionary<PlayerIdentity, int>();
        var keyed = ordered.Select(row =>
        {
            occurrences.TryGetValue(row.Identity, out int occurrence);
            occurrences[row.Identity] = occurrence + 1;
            return (Row: row, Key: (row.Identity, occurrence));
        }).ToArray();
        var wanted = keyed.Select(item => item.Key).ToHashSet();
        var previous = rows.ToDictionary(row => row.Key);
        var remembered = desiredSelection is { IsValid: true } ? desiredSelection : null;
        // A selection made in another open menu remains the same identity in
        // this view. A filtered-out player stays selected in the session.
        var sharedSelection = snapshot.Rows.FirstOrDefault(row => row.Visual.Selected);
        if (snapshot.HasCurrentData) remembered = sharedSelection?.Identity;
        var scroll = FindScrollViewer(list);
        double? offset = scroll?.VerticalOffset;
        updating = true;
        try
        {
            for (int i = rows.Count - 1; i >= 0; i--)
                if (!wanted.Contains(rows[i].Key)) rows.RemoveAt(i);
            for (int i = 0; i < keyed.Length; i++)
            {
                var source = keyed[i].Row;
                if (!previous.TryGetValue(keyed[i].Key, out var item)) item = new PlayerListRow(source, keyed[i].Key, profileColor);
                else item.Update(source, profileColor);
                if (i < rows.Count && ReferenceEquals(rows[i], item)) continue;
                int old = rows.IndexOf(item);
                if (old < 0) rows.Insert(i, item);
                else if (old != i) rows.Move(old, i);
            }
            list.SelectedItem = remembered.HasValue ? rows.FirstOrDefault(row => row.Row.Identity == remembered.Value)
                : legacySelection != null ? rows.FirstOrDefault(row => row.Key == legacySelection.Key) : null;
            desiredSelection = remembered;
            if (snapshot.HasCurrentData && remembered.HasValue && snapshot.Rows.All(row => row.Identity != remembered.Value))
                desiredSelection = null;
            if (offset.HasValue && scroll != null && Math.Abs(scroll.VerticalOffset - offset.Value) > 0.01)
                scroll.ScrollToVerticalOffset(offset.Value);
            state.Text = !snapshot.HasCurrentData ? "Joueurs indisponibles · attente d’une capture récente."
                : ordered.Count.ToString(French) + " affiché(s) / " + snapshot.Rows.Count.ToString(French) + " détecté(s)" +
                    (holding ? " · ordre conservé" : "");
            state.ToolTip = state.Text;
            clearAll.IsEnabled = snapshot.HasCurrentData && snapshot.Rows.Any(row => row.Visual.Selected || row.Visual.Pinned ||
                row.Visual.Marked || row.Visual.Hidden || row.Visual.Color != null);
            UpdateSelection();
        }
        finally { updating = false; }
    }

    private void UpdateSelection()
    {
        var row = (list.SelectedItem as PlayerListRow)?.Row;
        foreach (var button in selectedButtons) button.IsEnabled = row?.CanAnnotate == true;
        selectedName.Text = row == null ? "Sélectionne un joueur dans la liste." :
            (row.CanAnnotate ? "" : "Lecture seule · ") + (row.Name.Length == 0 ? "Joueur " + row.Identity.EntityId : row.Name);
        selectedName.ToolTip = selectedName.Text;
        selectedDetails.Text = row == null ? "Les actions concernent uniquement cette instance du joueur."
            : "ID " + row.Identity.EntityId + " · " + FormatDistance(row.DistanceMeters) + " · Δ hauteur " +
                row.HeightMeters.ToString("+0.0;-0.0;0.0", French) + " m · " + FormatHealth(row.Health, row.MaxHealth) + " PV";
        selectedDetails.ToolTip = selectedDetails.Text;
        pin.Content = row?.Visual.Pinned == true ? "Désépingler" : "Épingler";
        mark.Content = row?.Visual.Marked == true ? "Retirer la marque" : "Marquer";
        hide.Content = row?.Visual.Hidden == true ? "Réafficher ESP" : "Masquer ESP";
        if (row?.Visual.Color != null && controller.Settings.OutputMode == "fuser" &&
            string.Equals(row.Visual.Color, controller.Settings.FuserKeyColor, StringComparison.OrdinalIgnoreCase))
            ShowMessage("Cette couleur correspond au fond du fuser ; choisis une autre couleur.", error: true);
    }

    private Button SelectionButton(string text, Func<PlayerRow, bool> action)
    {
        var button = Theme.Button(text, () =>
        {
            if ((list.SelectedItem as PlayerListRow)?.Row is not { CanAnnotate: true } row) return;
            long priorMessage = messageVersion;
            if (!action(row))
            {
                if (messageVersion == priorMessage)
                {
                    bool current = controller.Players.TryGetVisual(row.Identity, out _);
                    ShowMessage(current ? "Ce réglage était déjà appliqué." : "Action non appliquée : le joueur ou ses données ne sont plus disponibles.", error: !current);
                }
            }
            else ShowMessage("Réglage individuel appliqué à cette session.");
            Refresh(force: true);
        });
        button.Padding = new Thickness(8, 6, 8, 6); button.MinHeight = 29;
        button.FontSize = 11; button.Margin = new Thickness(0, 0, 6, 6);
        selectedButtons.Add(button);
        return button;
    }

    private bool ApplyColor(PlayerRow row, string color)
    {
        if (controller.Settings.OutputMode == "fuser" && string.Equals(color, controller.Settings.FuserKeyColor, StringComparison.OrdinalIgnoreCase))
        {
            ShowMessage("Cette couleur est le fond transparent du fuser. Choisis une couleur différente.", error: true);
            return false;
        }
        return controller.Players.SetColor(row.Identity, color);
    }

    private void ChooseColor()
    {
        if ((list.SelectedItem as PlayerListRow)?.Row is not { CanAnnotate: true } row) return;
        using var dialog = new System.Windows.Forms.ColorDialog
        {
            FullOpen = true, AnyColor = true,
            Color = System.Drawing.ColorTranslator.FromHtml(row.Visual.Color ?? controller.Settings.PlayerEsp.Color)
        };
        var window = Window.GetWindow(this);
        var result = window == null ? dialog.ShowDialog() : dialog.ShowDialog(new ColorDialogOwner(new System.Windows.Interop.WindowInteropHelper(window).Handle));
        if (result != System.Windows.Forms.DialogResult.OK) return;
        string color = "#" + dialog.Color.R.ToString("X2") + dialog.Color.G.ToString("X2") + dialog.Color.B.ToString("X2");
        long priorMessage = messageVersion;
        if (ApplyColor(row, color)) ShowMessage("Couleur individuelle appliquée.");
        else if (messageVersion == priorMessage)
        {
            bool current = controller.Players.TryGetVisual(row.Identity, out _);
            ShowMessage(current ? "Cette couleur était déjà appliquée." : "La couleur n’a pas été appliquée : le joueur n’est plus disponible.", error: !current);
        }
        Refresh(force: true);
    }

    private void UpdateDetailsRequest() => SetDetailsRequested(IsLoaded && IsVisible && IsExpanded);

    private void SetDetailsRequested(bool value)
    {
        if (detailsRequested == value) return;
        detailsRequested = value;
        controller.SetPlayerDetailsVisible(this, value);
    }

    private void ShowMessage(string text, bool error = false)
    {
        messageVersion++;
        message.Text = text;
        message.ToolTip = text;
        message.Foreground = error ? Theme.Orange : Theme.Muted;
    }

    private static GridViewColumn Column(string title, string property, double width)
    {
        var text = new FrameworkElementFactory(typeof(TextBlock));
        text.SetBinding(TextBlock.TextProperty, new Binding(property));
        text.SetValue(TextBlock.TextTrimmingProperty, TextTrimming.CharacterEllipsis);
        text.SetValue(TextBlock.TextWrappingProperty, TextWrapping.NoWrap);
        text.SetValue(FrameworkElement.VerticalAlignmentProperty, VerticalAlignment.Center);
        return new GridViewColumn { Header = title, Width = width, CellTemplate = new DataTemplate { VisualTree = text } };
    }

    private static TextBlock FixedText(double height, double size, Brush color, bool wrap = false) => new()
    {
        Height = height, MinHeight = height, MaxHeight = height, FontSize = size, Foreground = color,
        TextWrapping = wrap ? TextWrapping.Wrap : TextWrapping.NoWrap, TextTrimming = TextTrimming.CharacterEllipsis,
        Margin = new Thickness(0, 0, 0, 3), ClipToBounds = true
    };

    private static string FormatDistance(double value) => double.IsFinite(value) && value >= 0 ? value.ToString("0", French) + " m" : "—";
    private static string FormatHealth(int? health, int? maximum) => health is >= 0
        ? health.Value.ToString(French) + (maximum is > 0 ? "/" + maximum.Value.ToString(French) : "") : "—";

    private static ScrollViewer? FindScrollViewer(DependencyObject parent)
    {
        for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
        {
            var child = VisualTreeHelper.GetChild(parent, i);
            if (child is ScrollViewer scroll) return scroll;
            var result = FindScrollViewer(child);
            if (result != null) return result;
        }
        return null;
    }

    private sealed class ColorDialogOwner : System.Windows.Forms.IWin32Window
    {
        public IntPtr Handle { get; }
        internal ColorDialogOwner(IntPtr handle) => Handle = handle;
    }

    private sealed class PlayerListRow : INotifyPropertyChanged
    {
        internal PlayerRow Row { get; private set; }
        internal (PlayerIdentity Identity, int Occurrence) Key { get; }
        public string Name { get; private set; } = "";
        public string Distance { get; private set; } = "";
        public string Health { get; private set; } = "";
        public string Flags { get; private set; } = "";
        public string Description { get; private set; } = "";
        public Brush Color { get; private set; } = Theme.Foreground;
        private string colorValue = "";
        public event PropertyChangedEventHandler? PropertyChanged;

        internal PlayerListRow(PlayerRow row, (PlayerIdentity Identity, int Occurrence) key, string profileColor)
        {
            Row = row; Key = key;
            Update(row, profileColor);
        }

        internal void Update(PlayerRow row, string profileColor)
        {
            Row = row;
            Change(nameof(Name), Name, row.Name.Length == 0 ? "Joueur " + row.Identity.EntityId : row.Name, value => Name = value);
            Change(nameof(Distance), Distance, FormatDistance(row.DistanceMeters), value => Distance = value);
            Change(nameof(Health), Health, FormatHealth(row.Health, row.MaxHealth), value => Health = value);
            string flags = string.Join(" · ", new[] { row.Visual.Pinned ? "Épinglé" : "", row.Visual.Marked ? "Marqué" : "",
                row.Visual.Hidden ? "Masqué" : "", !row.CanAnnotate ? "Lecture seule" : "" }.Where(value => value.Length > 0));
            Change(nameof(Flags), Flags, flags, value => Flags = value);
            Change(nameof(Description), Description, Name + " · ID " + row.Identity.EntityId + " · " + Distance + " · " + Health + " PV" +
                (flags.Length > 0 ? " · " + flags : ""), value => Description = value);
            string currentColor = row.Visual.Hidden ? "#AAB6C8" : row.Visual.Color ?? profileColor;
            if (!string.Equals(colorValue, currentColor, StringComparison.Ordinal))
            {
                colorValue = currentColor; Color = Theme.Brush(currentColor);
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Color)));
            }
        }

        private void Change(string property, string oldValue, string newValue, Action<string> set)
        {
            if (oldValue == newValue) return;
            set(newValue);
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
        }
    }
}
