using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using SevenDaysEsp;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class CreativeMenuToggleTests
{
    private const string Version = "V 3.4.0 (b10)";

    public static Task ToggleInvertsFreshMemoryAndOnlyReplacesCreativeReference()
    {
        var f = new CreativeMenuAccessTests.Fixture();
        byte[] defaults = f.Memory.Read(f.Declarations + 0x20, 293 * 40);
        byte[] values = f.Memory.Read(f.Values + 0x20, 316 * 8);
        // The first current value is a separate box; it must remain immutable.
        ulong own = f.NewBoolean(false);
        f.Memory.U64(f.TargetSlot, own);
        var enabled = f.ReaderAccess.ApplyToggle(f.Context, 77);
        Check(enabled.Success && enabled.Code == "CONFIRME" && enabled.WriteAttempted && enabled.ObservedEnabled == true,
            enabled.Message);
        Check(f.Memory.Read(own + 16, 1)[0] == 0 && f.Memory.ReadU64(f.TargetSlot) == f.True,
            "Toggle changed a Boolean box instead of replacing the single rooted reference.");
        var disabled = f.ReaderAccess.ApplyToggle(f.Context, 77);
        Check(disabled.Success && disabled.Code == "CONFIRME" && disabled.WriteAttempted && disabled.ObservedEnabled == false,
            disabled.Message);
        Check(f.Writer.Writes.Count == 2 && f.Writer.Writes.All(w => w.Slot == f.TargetSlot) &&
            f.Writer.Writes[0].Value == f.True && f.Writer.Writes[1].Value == f.False,
            "Each explicit toggle must perform exactly one write to the creative slot.");
        Check(defaults.SequenceEqual(f.Memory.Read(f.Declarations + 0x20, defaults.Length)) &&
            values.SequenceEqual(f.Memory.Read(f.Values + 0x20, values.Length)) &&
            f.Memory.Read(f.False + 16, 1)[0] == 0 && f.Memory.Read(f.True + 16, 1)[0] == 1,
            "A toggle mutated shared defaults, other preferences, or boxed Boolean contents.");
        return Task.CompletedTask;
    }

    public static Task ToggleIgnoresThePreviouslyDisplayedState()
    {
        var f = new CreativeMenuAccessTests.Fixture();
        var session = Session(f);
        var query = session.Begin(1, null);
        var observation = Execute(query, f, () => f.Apply(null));
        Check(session.Accept(1, observation) && session.State.ObservedEnabled == false, "Initial read did not reach the UI.");
        // The game changes the preference after the UI's last confirmed read.
        f.Memory.U64(f.TargetSlot, f.True);
        var request = session.BeginToggle(1);
        Check(request.Toggle && request.DesiredEnabled == null, "The UI converted toggle into an absolute desired value.");
        Expect<InvalidOperationException>(() => session.BeginToggle(1));
        var result = Execute(request, f, () => f.ReaderAccess.ApplyToggle(f.Context, 77));
        Check(result.Toggle && result.DesiredEnabled == null && result.ObservedEnabled == false &&
            result.WriteAttempted && CreativeMenuProtocol.IsValidResult(result) && session.Accept(1, result),
            "Toggle inverted the old UI value instead of the current memory value.");
        Check(f.Writer.Writes.Count == 1 && f.Writer.Writes[0].Value == f.False && session.State.ObservedEnabled == false,
            "The fresh-memory toggle was not confirmed once.");
        return Task.CompletedTask;
    }

    public static Task ConcurrentChangesRefuseToggleWithoutRetry()
    {
        var betweenPasses = new CreativeMenuAccessTests.Fixture();
        int graphPasses = 0;
        betweenPasses.Memory.BeforeRead = (address, count) =>
        {
            if (address == betweenPasses.PrefsClass && count == 0x60 && ++graphPasses == 2)
                betweenPasses.Memory.U64(betweenPasses.TargetSlot, betweenPasses.True);
        };
        var first = betweenPasses.ReaderAccess.ApplyToggle(betweenPasses.Context, 77);
        Check(graphPasses >= 2 && !first.Success && !first.WriteAttempted && first.ObservedEnabled == null &&
            betweenPasses.Writer.Writes.Count == 0 && betweenPasses.Memory.ReadU64(betweenPasses.TargetSlot) == betweenPasses.True,
            "Toggle recalculated its target or wrote after a concurrent graph change: passes=" + graphPasses +
            ", writes=" + betweenPasses.Writer.Writes.Count + ", status=" + first.Code + ", detail=" + first.Message);

        var beforeNative = new CreativeMenuAccessTests.Fixture();
        beforeNative.Writer.BeforeWrite = () => beforeNative.Memory.U64(beforeNative.TargetSlot, beforeNative.True);
        var second = beforeNative.ReaderAccess.ApplyToggle(beforeNative.Context, 77);
        Check(!second.Success && !second.WriteAttempted && second.ObservedEnabled == null && beforeNative.Writer.Writes.Count == 0,
            "Toggle bypassed the last expected-reference comparison or retried a concurrent change.");
        return Task.CompletedTask;
    }

    public static Task TogglePreservesGraphAndCancellationGuards()
    {
        foreach (Action<CreativeMenuAccessTests.Fixture> invalidate in new Action<CreativeMenuAccessTests.Fixture>[]
        {
            f => f.Memory.U64(f.Sandbox + 0x20 + 47 * 8, f.False),
            f => f.Memory.U64(f.TargetSlot, 0),
            f => f.Memory.Byte(f.False + 16, 2),
            f => f.Memory.U64(f.Memory.ReadU64(f.False) + 0x10, f.Memory.Allocate(32)),
            f => f.World.ReplaceWorld(),
            f => f.Writer.ProcessId = 78
        })
        {
            var f = new CreativeMenuAccessTests.Fixture(); invalidate(f);
            var result = f.ReaderAccess.ApplyToggle(f.Context, 77);
            Check(!result.Success && !result.WriteAttempted && result.ObservedEnabled == null && f.Writer.Writes.Count == 0,
                "Toggle weakened a graph, sandbox, domain, world, or PID guard: " + result.Message);
        }
        var profile = new CreativeMenuAccessTests.Fixture();
        var unknown = profile.Access(new GameVersionReport { Status = "VERSION_JEU_LUE", DisplayVersion = "V 3.5.0 (b1)" });
        Check(!unknown.ApplyToggle(profile.Context, 77).Success && profile.Writer.Writes.Count == 0,
            "Toggle wrote under an unknown game profile.");
        foreach (bool afterWrite in new[] { false, true })
        {
            var f = new CreativeMenuAccessTests.Fixture();
            using var cancelled = new CancellationTokenSource();
            if (afterWrite) f.Writer.AfterWrite = cancelled.Cancel;
            else f.Writer.BeforeWrite = cancelled.Cancel;
            var result = f.ReaderAccess.ApplyToggle(f.Context, 77, cancelled.Token);
            Check(!result.Success && result.ObservedEnabled == null && result.WriteAttempted == afterWrite &&
                f.Writer.Writes.Count == (afterWrite ? 1 : 0), "Toggle ignored cancellation or retried an uncertain result.");
        }
        return Task.CompletedTask;
    }

    public static Task UncertainToggleNeverRetriesOrConfirmsAValue()
    {
        foreach (bool interruptReadback in new[] { false, true })
        {
            var f = new CreativeMenuAccessTests.Fixture();
            if (interruptReadback)
                f.Writer.AfterWrite = () => f.Memory.BeforeRead = (address, _) =>
                { if (address == f.PrefsClass) throw new IOException("Synthetic toggle readback failure."); };
            else f.Writer.RejectNative = true;
            var request = Request(f); int calls = 0;
            var result = Execute(request, f, () => { calls++; return f.ReaderAccess.ApplyToggle(f.Context, 77); });
            Check(calls == 1 && f.Writer.Writes.Count == 1 && result.Toggle && result.WriteAttempted &&
                result.ObservedEnabled == null && CreativeMenuProtocol.IsValidResult(result),
                "An uncertain toggle was repeated or published as a confirmed value.");
        }
        return Task.CompletedTask;
    }

    public static Task ToggleProtocolRejectsAmbiguityAndFalseConfirmations()
    {
        var f = new CreativeMenuAccessTests.Fixture();
        var toggle = Request(f);
        CreativeMenuProtocol.ValidateRequest(toggle);
        foreach (bool desired in new[] { false, true })
        {
            var mixed = toggle.Copy(); mixed.DesiredEnabled = desired;
            Expect<InvalidDataException>(() => CreativeMenuProtocol.ValidateRequest(mixed));
            var set = mixed.Copy(); set.Toggle = false; CreativeMenuProtocol.ValidateRequest(set);
        }
        var query = toggle.Copy(); query.Toggle = false; CreativeMenuProtocol.ValidateRequest(query);
        foreach (bool observed in new[] { false, true })
        {
            Check(CreativeMenuProtocol.IsValidResult(Result(toggle, observed)), "A confirmed toggle outcome was rejected.");
            foreach (Action<CreativeMenuResult> corrupt in new Action<CreativeMenuResult>[]
            {
                r => r.Toggle = false, r => r.DesiredEnabled = observed,
                r => r.WriteAttempted = false, r => r.ObservedEnabled = null,
                r => r.Code = "ETAT_LU", r => r.Code = "DEJA_APPLIQUE",
                r => r.Code = "CREATIF_ETAT_INDETERMINE"
            })
            {
                var malformed = Result(toggle, observed); corrupt(malformed);
                Check(!CreativeMenuProtocol.IsValidResult(malformed), "An ambiguous or false toggle confirmation passed the protocol.");
            }
        }
        var uncertain = Result(toggle, null); uncertain.Code = "CREATIF_ETAT_INDETERMINE";
        Check(CreativeMenuProtocol.IsValidResult(uncertain), "A one-shot uncertain toggle could not be reported.");
        return Task.CompletedTask;
    }

    public static Task ToggleSessionCorrelatesOperationAndDoesNotReplayOnReset()
    {
        var f = new CreativeMenuAccessTests.Fixture(); var session = Session(f);
        var request = session.BeginToggle(1);
        var wrongOperation = Result(request, null);
        wrongOperation.Code = "CREATIF_REFUSE"; wrongOperation.Toggle = false; wrongOperation.WriteAttempted = false;
        Check(CreativeMenuProtocol.IsValidResult(wrongOperation) && !session.Accept(1, wrongOperation) && session.State.IsBusy,
            "A read-only result consumed a pending toggle.");
        Check(session.Accept(1, Result(request, true)) && !session.State.IsBusy && session.State.ObservedEnabled == true,
            "A matching toggle result did not confirm its actual value.");
        var pending = session.BeginToggle(1);
        session.Reset(2);
        session.ObserveContext(2, 77, Sample(f), true);
        Check(!session.State.IsBusy && session.State.ObservedEnabled == null &&
            !session.Accept(1, Result(pending, false)) && !session.Accept(2, Result(pending, false)) && f.Writer.Writes.Count == 0,
            "Reconnect restored, replayed, or accepted a previous toggle.");
        return Task.CompletedTask;
    }

    public static Task QueuedToggleExpiresWithoutExecution()
    {
        var f = new CreativeMenuAccessTests.Fixture();
        long clock = Stopwatch.GetTimestamp();
        var session = new CreativeMenuSession(() => clock, () => DateTime.UtcNow);
        session.Reset(1); session.ObserveContext(1, 77, Sample(f), true);
        var pending = session.BeginToggle(1);
        clock += Stopwatch.Frequency * 10;
        Check(!session.State.IsBusy && session.State.Code == "DELAI_DEPASSE" && !session.Accept(1, Result(pending, true)),
            "An expired toggle remained queued or a late result revived it.");
        pending.RequestedTimestamp = Stopwatch.GetTimestamp() - Stopwatch.Frequency * 11;
        int calls = 0;
        var result = Execute(pending, f, () => { calls++; return f.ReaderAccess.ApplyToggle(f.Context, 77); });
        Check(calls == 0 && result.Code == "EXPIRE" && result.Toggle && !result.WriteAttempted && result.ObservedEnabled == null &&
            CreativeMenuProtocol.IsValidResult(result) && f.Writer.Writes.Count == 0,
            "An expired toggle reached memory or lost its operation correlation.");
        return Task.CompletedTask;
    }

    private static CreativeMenuSession Session(CreativeMenuAccessTests.Fixture f)
    {
        var session = new CreativeMenuSession(); session.Reset(1); session.ObserveContext(1, 77, Sample(f), true); return session;
    }

    private static FeedSample Sample(CreativeMenuAccessTests.Fixture f) => new(new LiveEntitySnapshot
    { Status = "ENTITES_LUES", PlayerContextId = f.Context, LocalId = 1, LocalPosition = new LivePosition() }, 0);

    private static CreativeMenuRequest Request(CreativeMenuAccessTests.Fixture f) => new()
    {
        Sequence = 1, RequestId = Guid.NewGuid().ToString("N"), ExpectedProcessId = 77,
        ExpectedPlayerContextId = f.Context, Toggle = true, RequestedTimestamp = Stopwatch.GetTimestamp()
    };

    private static CreativeMenuResult Result(CreativeMenuRequest request, bool? observed) => new()
    {
        Sequence = request.Sequence, RequestId = request.RequestId, ProcessId = request.ExpectedProcessId,
        PlayerContextId = request.ExpectedPlayerContextId, DesiredEnabled = request.DesiredEnabled, Toggle = request.Toggle,
        ObservedEnabled = observed, WriteAttempted = true, Code = "CONFIRME", Message = "État relu."
    };

    private static CreativeMenuResult Execute(CreativeMenuRequest request, CreativeMenuAccessTests.Fixture f,
        Func<CreativeMenuAccessResult> apply) => CreativeMenuExecutor.Execute(request, 77, Sample(f).Snapshot, 0,
            Version, () => f.Writer.ProcessId == 77, apply);

    private static void Check(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }

    private static void Expect<T>(Action action) where T : Exception
    {
        try { action(); } catch (T) { return; }
        throw new InvalidOperationException("Expected " + typeof(T).Name + ".");
    }
}
