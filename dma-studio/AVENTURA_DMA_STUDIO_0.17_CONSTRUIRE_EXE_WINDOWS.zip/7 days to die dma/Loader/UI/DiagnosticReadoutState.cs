using System;

namespace SevenDaysLoader.UI;

// Presentation state only. This class never keeps or makes an ESP frame fresh.
// It remembers source dimensions explicitly as a historical observation, while
// limiting updates of the diagnostic readout so it can be read and selected.
internal sealed class DiagnosticReadoutState
{
    internal const int RefreshMilliseconds = 1000;
    private string sessionKey = "";
    private uint processId;
    private bool hasSession;
    private long lastPublication;
    private bool published;

    internal int LastSourceWidth { get; private set; }
    internal int LastSourceHeight { get; private set; }
    internal bool HasSource => LastSourceWidth > 0 && LastSourceHeight > 0;

    internal void ObserveSource(string reportPath, uint currentProcessId, int? width, int? height)
    {
        ArgumentNullException.ThrowIfNull(reportPath);
        if (!hasSession || sessionKey != reportPath || processId != currentProcessId)
        {
            sessionKey = reportPath;
            processId = currentProcessId;
            hasSession = true;
            LastSourceWidth = LastSourceHeight = 0;
        }
        if (width is > 0 and <= 32768 && height is > 0 and <= 32768)
        {
            LastSourceWidth = width.Value;
            LastSourceHeight = height.Value;
        }
    }

    internal bool ShouldPublish(long nowMilliseconds, bool frozen, bool reading, bool force = false)
    {
        // Explicit refresh captures one readout even while Figer remains checked.
        // Pointer/selection protection affects the UI only, not data acquisition.
        if (!force && (frozen || (reading && published))) return false;
        if (!force && published && nowMilliseconds >= lastPublication &&
            nowMilliseconds - lastPublication < RefreshMilliseconds) return false;
        published = true;
        lastPublication = nowMilliseconds;
        return true;
    }

    internal static string ProjectionAtReadout(string lastDisplayStatus, bool hasFreshCamera)
    {
        ArgumentNullException.ThrowIfNull(lastDisplayStatus);
        // Even after refreshing the overlay first, a frame may expire before
        // the diagnostic takes its readout. Do not freeze a stale active claim.
        return !hasFreshCamera && lastDisplayStatus.StartsWith("ESP actif", StringComparison.Ordinal)
            ? "ESP suspendu : aucune caméra fraîche dans ce relevé."
            : lastDisplayStatus;
    }
}
