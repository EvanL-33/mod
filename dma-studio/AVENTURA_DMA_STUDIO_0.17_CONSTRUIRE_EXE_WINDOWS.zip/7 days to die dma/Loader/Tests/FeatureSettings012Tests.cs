using System;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class FeatureSettings012Tests
{
    public static Task OldSettingsKeepProfilesAndQuietDisplayDefaults()
    {
        var settings = JsonSerializer.Deserialize<LoaderSettings>("""
            {"EspProfilesVersion":1,"MenuKey":"F10","ToggleKey":"F6","PlayerEsp":{"MaxDistance":720,"Color":"#ABCDEF","Enabled":false},"ZombieEsp":{"MaxDistance":135,"ShowHealth":false}}
            """, Wire.Json)!;
        SettingsStore.Normalize(settings);
        Check(!settings.PlayerEsp.Enabled && settings.PlayerEsp.MaxDistance == 720 && settings.PlayerEsp.Color == "#ABCDEF", "Old player profile changed.");
        Check(settings.ZombieEsp.MaxDistance == 135 && !settings.ZombieEsp.ShowHealth, "Old zombie profile changed.");
        Check(!settings.RadarIndependentRange && !settings.ShowRadarCounts && !settings.PlayerFeatures.ShowDistanceTrend, "Migration enabled new display features.");
        Check(!settings.PlayerEsp.Rules.HeightFilterEnabled && !settings.PlayerEsp.Rules.ShowHeightIndicator && settings.PlayerEsp.Rules.ColorMode == "none", "Migration enabled display rules.");
        Check(settings.MenuKey == "F10" && settings.CreativeMenuKey == "" && settings.AutoReconnectGame, "Creative key took over an existing shortcut or lost recovery default.");
        return Task.CompletedTask;
    }

    public static Task SeparateRulesAndNewOptionsRoundtripWithoutCreativeState()
    {
        string directory = Path.Combine(Path.GetTempPath(), "7dtd-settings012-" + Guid.NewGuid().ToString("N"));
        try
        {
            var store = new SettingsStore(directory);
            var settings = store.Load();
            settings.PlayerEsp.Rules.HeightFilterEnabled = true;
            settings.PlayerEsp.Rules.MaxHeightDifferenceMeters = 17;
            settings.PlayerEsp.Rules.ColorMode = "health";
            settings.ZombieEsp.Rules.ColorMode = "distance";
            settings.ZombieEsp.Rules.DistanceNearMeters = 9;
            settings.RadarIndependentRange = true; settings.RadarRangeMeters = 125; settings.ShowRadarCounts = true;
            settings.PlayerFeatures.ShowDistanceTrend = true;
            settings.AutoReconnectGame = false; settings.CreativeMenuKey = "F11";
            store.Save(settings);
            var loaded = store.Load();
            Check(loaded.PlayerEsp.Rules.HeightFilterEnabled && loaded.PlayerEsp.Rules.MaxHeightDifferenceMeters == 17 && loaded.PlayerEsp.Rules.ColorMode == "health", "Player rules did not roundtrip.");
            Check(!loaded.ZombieEsp.Rules.HeightFilterEnabled && loaded.ZombieEsp.Rules.ColorMode == "distance" && loaded.ZombieEsp.Rules.DistanceNearMeters == 9, "Zombie rules were coupled to players.");
            Check(loaded.RadarIndependentRange && loaded.RadarRangeMeters == 125 && loaded.ShowRadarCounts && loaded.PlayerFeatures.ShowDistanceTrend, "Radar/trend preferences were lost.");
            Check(!loaded.AutoReconnectGame && loaded.CreativeMenuKey == "F11", "Recovery/hotkey preferences were reset.");
            string json = File.ReadAllText(store.FilePath);
            Check(!json.Contains("desiredEnabled", StringComparison.OrdinalIgnoreCase) && !json.Contains("observedEnabled", StringComparison.OrdinalIgnoreCase), "A creative state was persisted.");
        }
        finally { if (Directory.Exists(directory)) Directory.Delete(directory, true); }
        return Task.CompletedTask;
    }

    public static Task InvalidAndSharedRulesNormalizeToIndependentBoundedValues()
    {
        var shared = new EntityDisplayRulesSettings
        {
            MaxHeightDifferenceMeters = -8, ColorMode = "bogus", HealthLowPercent = 150,
            HealthHighPercent = -5, DistanceNearMeters = 9000, DistanceFarMeters = -3,
            LowColor = "bad", MiddleColor = null!, HighColor = "#aabbcc"
        };
        var settings = new LoaderSettings { EspProfilesVersion = 1, RadarRangeMeters = -1 };
        settings.PlayerEsp.Rules = shared;
        settings.ZombieEsp.Rules = shared;
        SettingsStore.Normalize(settings);
        Check(settings.RadarRangeMeters == 25 && shared.MaxHeightDifferenceMeters == 1 && shared.ColorMode == "none", "Bounds/mode were not normalized.");
        Check(shared.HealthLowPercent == 99 && shared.HealthHighPercent == 100 && shared.DistanceNearMeters == 4999 && shared.DistanceFarMeters == 5000, "Thresholds remain contradictory.");
        Check(shared.IsValid(out _) && shared.HighColor == "#AABBCC", "Palette remains invalid.");
        Check(!ReferenceEquals(settings.PlayerEsp.Rules, settings.ZombieEsp.Rules), "Category rules share mutable state.");
        settings.ZombieEsp.Rules = null!;
        SettingsStore.Normalize(settings);
        Check(settings.ZombieEsp.Rules.IsValid(out _), "Null rules were not restored.");
        return Task.CompletedTask;
    }

    public static Task NewPresetRulesAreDeepCopiedWithoutConnectionOrKeyChanges()
    {
        var settings = new LoaderSettings { EspProfilesVersion = 1, RadarIndependentRange = true, RadarRangeMeters = 75, ShowRadarCounts = true };
        settings.PlayerEsp.Rules.ShowHeightIndicator = true;
        settings.PlayerEsp.Rules.ColorMode = "health";
        settings.ZombieEsp.Rules.ColorMode = "distance";
        var preset = EspPresetOptions.Capture(settings);
        settings.PlayerEsp.Rules.HealthLowPercent = 20;
        Check(preset.PlayerEsp.Rules.HealthLowPercent == 30, "Preset aliases live rules.");
        var copy = preset.Copy();
        copy.ZombieEsp.Rules.DistanceNearMeters = 15;
        Check(preset.ZombieEsp.Rules.DistanceNearMeters == 25, "Preset copies share rules.");
        var target = new LoaderSettings { CreativeMenuKey = "F11", AutoReconnectGame = false, Mode = "display" };
        preset.ApplyTo(target);
        Check(target.RadarIndependentRange && target.RadarRangeMeters == 75 && target.ShowRadarCounts && target.PlayerEsp.Rules.ShowHeightIndicator, "New preset settings were not applied.");
        Check(target.CreativeMenuKey == "F11" && !target.AutoReconnectGame && target.Mode == "display", "Preset changed connection or command bindings.");
        target.PlayerEsp.Rules.LowColor = "#FFFFFF";
        Check(preset.PlayerEsp.Rules.LowColor != target.PlayerEsp.Rules.LowColor, "Applying preset aliased its rules.");
        return Task.CompletedTask;
    }

    public static Task OldPresetsRemainImportableAndInvalidNewRulesAreAtomic()
    {
        const string old = """
            {"EspEnabled":true,"ShowProjectedEsp":true,"ShowRadar":true,"ShowHud":true,"RadarSize":300,"RadarOpacity":0.88,"PlayerEsp":{"Color":"#66DEF2"},"ZombieEsp":{"Color":"#FF9A52"}}
            """;
        var preset = JsonSerializer.Deserialize<EspPresetOptions>(old, Wire.Json)!;
        preset.Validate();
        Check(!preset.RadarIndependentRange && preset.RadarRangeMeters == 300 && preset.PlayerEsp.Rules.ColorMode == "none", "Legacy preset defaults changed.");
        var target = new LoaderSettings();
        string before = JsonSerializer.Serialize(target, Wire.Json);
        preset.PlayerEsp.Rules.HealthHighPercent = 10;
        bool rejected = false;
        try { preset.ApplyTo(target); } catch (InvalidDataException) { rejected = true; }
        Check(rejected && JsonSerializer.Serialize(target, Wire.Json) == before, "Invalid rules partially applied a preset.");
        preset.PlayerEsp.Rules.HealthHighPercent = 70;
        preset.RadarRangeMeters = 5001;
        rejected = false;
        try { preset.ApplyTo(target); } catch (InvalidDataException) { rejected = true; }
        Check(rejected && JsonSerializer.Serialize(target, Wire.Json) == before, "Invalid radar range partially applied a preset.");
        return Task.CompletedTask;
    }

    public static Task CreativeShortcutCannotStealOtherBindings()
    {
        foreach (string key in new[] { "Insert", "F6", "F7", "F8", "F9" })
        {
            var settings = new LoaderSettings { CreativeMenuKey = key };
            SettingsStore.Normalize(settings);
            Check(settings.CreativeMenuKey == "" && settings.MenuKey == "Insert" && settings.ToggleKey == "F6" &&
                settings.PlayersKey == "F7" && settings.ZombiesKey == "F8" && settings.RadarKey == "F9", "Creative shortcut took over " + key);
        }
        var defaults = new LoaderSettings();
        SettingsStore.Normalize(defaults);
        Check(defaults.CreativeMenuKey == "F10", "Free default shortcut was not kept.");
        defaults.CreativeMenuKey = "";
        SettingsStore.Normalize(defaults);
        Check(defaults.CreativeMenuKey == "", "Explicitly disabled creative shortcut was reset.");
        return Task.CompletedTask;
    }

    private static void Check(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
}
