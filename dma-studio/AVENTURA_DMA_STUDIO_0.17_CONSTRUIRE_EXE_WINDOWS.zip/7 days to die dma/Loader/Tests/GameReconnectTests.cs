using System;
using System.Threading;
using System.Threading.Tasks;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class GameReconnectTests
{
    public static Task OnlyConfirmedProcessLossCanRecoverAutomatically()
    {
        var settings = new LoaderSettings();
        var loss = new LoaderStatus { Stage = GameReconnectCoordinator.ProcessLostStage, IsReader = true };
        Check(GameReconnectCoordinator.CanRecover(loss, settings), "Process loss should permit recovery.");
        foreach (string stage in new[] { "ERREUR_LECTURE", "ERREUR_CONNEXION", "ERREUR_CONTROLE", "LECTEUR_ARRETE", "ARRETE", "LIAISON_PERDUE", "LECTURE_NON_VALIDEE" })
            Check(!GameReconnectCoordinator.CanRecover(loss with { Stage = stage }, settings), "Unrelated error caused recovery: " + stage);
        settings.AutoReconnectGame = false;
        Check(!GameReconnectCoordinator.CanRecover(loss, settings), "Disabled recovery remained active.");
        settings.AutoReconnectGame = true;
        settings.Mode = "display";
        Check(!GameReconnectCoordinator.CanRecover(loss, settings), "Remote display started a DMA reader.");
        settings.Mode = "reader";
        Check(!GameReconnectCoordinator.CanRecover(loss with { IsReader = false }, settings), "A remote status recovered locally.");
        return Task.CompletedTask;
    }

    public static async Task EndNotificationsCoalesceAndCannotReplayAnOldGeneration()
    {
        var release = Signal();
        var recovery = new GameReconnectCoordinator(_ => release.Task);
        int calls = 0, failures = 0;
        Task Connect(CancellationToken _) { Interlocked.Increment(ref calls); return Task.CompletedTask; }
        Check(recovery.TrySchedule(10, Connect, _ => failures++), "First recovery was not queued.");
        Check(!recovery.TrySchedule(10, Connect, _ => failures++), "Duplicate Ended created another task.");
        Check(!recovery.TrySchedule(11, Connect, _ => failures++), "Concurrent generation created another task.");
        Check(calls == 0, "Recovery bypassed the delay.");
        release.SetResult();
        await recovery.Completion;
        Check(calls == 1 && failures == 0, "Recovery did not execute exactly once.");
        Check(!recovery.TrySchedule(10, Connect, _ => failures++) && !recovery.TrySchedule(9, Connect, _ => failures++), "An old generation was replayed.");
        Check(recovery.TrySchedule(12, Connect, _ => failures++), "A new reader generation could not recover.");
        await recovery.Completion;
        Check(calls == 2, "The new generation did not recover once.");
    }

    public static async Task StopBeforeDelayPreventsTheRestartEvenWithAnUncooperativeDelay()
    {
        var entered = Signal();
        var release = Signal();
        var recovery = new GameReconnectCoordinator(_ => { entered.TrySetResult(); return release.Task; });
        int calls = 0, failures = 0;
        recovery.TrySchedule(1, _ => { calls++; return Task.CompletedTask; }, _ => failures++);
        Task pending = recovery.Completion;
        await entered.Task;
        recovery.Cancel();
        release.SetResult();
        await pending;
        Check(calls == 0 && failures == 0, "A cancelled delayed recovery started or reported a false error.");
    }

    public static async Task CancellationReachesAnInProgressStartup()
    {
        var entered = Signal();
        var cancelled = Signal();
        var recovery = new GameReconnectCoordinator(_ => Task.CompletedTask);
        int completed = 0, failures = 0;
        recovery.TrySchedule(2, async token =>
        {
            using var registration = token.Register(() => cancelled.TrySetResult());
            entered.TrySetResult();
            await Task.Delay(Timeout.Infinite, token);
            completed++;
        }, _ => failures++);
        Task pending = recovery.Completion;
        await entered.Task;
        recovery.Cancel();
        await cancelled.Task;
        await pending;
        Check(completed == 0 && failures == 0, "Startup continued or cancellation became an error.");
    }

    public static async Task ACancelledTaskCannotClearTheFollowingRecovery()
    {
        var firstEntered = Signal();
        var firstRelease = Signal();
        var secondEntered = Signal();
        var secondRelease = Signal();
        int delayCalls = 0, starts = 0;
        var recovery = new GameReconnectCoordinator(_ =>
        {
            if (Interlocked.Increment(ref delayCalls) == 1) { firstEntered.TrySetResult(); return firstRelease.Task; }
            secondEntered.TrySetResult(); return secondRelease.Task;
        });
        Task Connect(CancellationToken _) { starts++; return Task.CompletedTask; }
        recovery.TrySchedule(20, Connect, _ => throw new Exception("Unexpected error."));
        Task first = recovery.Completion;
        await firstEntered.Task;
        recovery.Cancel();
        Check(recovery.TrySchedule(22, Connect, _ => throw new Exception("Unexpected error.")), "New recovery blocked by cancelled task.");
        Task second = recovery.Completion;
        await secondEntered.Task;
        firstRelease.SetResult();
        await first;
        Check(!recovery.TrySchedule(23, Connect, _ => { }), "Old cleanup cleared the new pending task.");
        secondRelease.SetResult();
        await second;
        Check(starts == 1, "The cancelled generation ran or the new one was lost.");
    }

    public static async Task StartupFailureIsReportedOnceWithoutAutomaticRetry()
    {
        var recovery = new GameReconnectCoordinator(_ => Task.CompletedTask);
        int calls = 0, failures = 0;
        Exception? reported = null;
        var expected = new InvalidOperationException("SDK unavailable");
        recovery.TrySchedule(30, _ => { calls++; throw expected; }, error => { reported = error; failures++; });
        await recovery.Completion;
        Check(calls == 1 && failures == 1 && ReferenceEquals(reported, expected), "Failure was lost or retried.");
        Check(!recovery.TrySchedule(30, _ => { calls++; return Task.CompletedTask; }, _ => failures++), "Failed startup generation retried.");
    }

    private static TaskCompletionSource Signal() => new(TaskCreationOptions.RunContinuationsAsynchronously);
    private static void Check(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
}
