using System;
using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using SevenDaysEsp;

namespace SevenDaysLoader.Services;

// Preferences and explicit creative-menu intents share the local worker pipe.
// The monitor only deposits intents; hardware access remains on the capture loop.
public sealed class WorkerControl
{
    public const string ReadOptionsKind = "read-options";
    public const string StopKind = "stop";
    public const string CreativeMenuKind = "creative-menu";
    public const string CreativeResultKind = "creative-result";
    public const string PlayerDmaStatKind = "player-dma-stat";
    public const string PlayerDmaStatResultKind = "player-dma-stat-result";
    public const string PlayerControlKind = "player-control";
    public const string PlayerControlStateKind = "player-control-state";
    public const string PlayerControlSubmissionKind = "player-control-submission";
    public string Kind { get; set; } = "";
    public LiveReadOptions? ReadOptions { get; set; }
    public CreativeMenuRequest? CreativeMenu { get; set; }
    public PlayerControlRequest? PlayerControl { get; set; }
    public PlayerDmaStatRequest? PlayerDmaStat { get; set; }
}

internal static class ReadOptionsValue
{
    internal static bool Equal(LiveReadOptions? left, LiveReadOptions? right) =>
        left != null && right != null && left.PlayerNames == right.PlayerNames &&
        left.PlayerHealth == right.PlayerHealth && left.ZombieNames == right.ZombieNames &&
        left.ZombieHealth == right.ZombieHealth &&
        left.PlayerMovement == right.PlayerMovement &&
        left.PlayerFacing == right.PlayerFacing &&
        left.PlayerHeldItem == right.PlayerHeldItem &&
        left.ZombieAttackTarget == right.ZombieAttackTarget &&
        left.WorldBloodMoon == right.WorldBloodMoon;
}

// Exactly one pending value: UI activity can replace preferences, never queue
// an unbounded history. No mutable options supplied by a caller are retained.
internal sealed class PendingReadOptions
{
    private readonly object gate = new();
    private LiveReadOptions? pending;
    private LiveReadOptions? latest;

    internal bool HasPending { get { lock (gate) return pending != null; } }

    internal bool Replace(LiveReadOptions value)
    {
        lock (gate)
        {
            if (ReadOptionsValue.Equal(latest, value)) return false;
            latest = value.Copy();
            pending = latest.Copy();
            return true;
        }
    }

    internal LiveReadOptions? Take()
    {
        lock (gate)
        {
            var result = pending;
            pending = null;
            return result;
        }
    }

    internal LiveReadOptions TakeInitial(LiveReadOptions fallback)
    {
        lock (gate)
        {
            var result = (pending ?? fallback).Copy();
            pending = null;
            latest = result.Copy();
            return result;
        }
    }

    internal void Clear()
    {
        lock (gate) { pending = null; latest = null; }
    }
}

internal sealed record WorkerReadOptionsSnapshot(long Revision, LiveReadOptions Options);

// The pipe updates this mailbox while hardware capture runs independently.
// The capture loop takes one version between complete captures, never mid-read.
internal sealed class WorkerReadOptionsState
{
    private readonly object gate = new();
    private LiveReadOptions requested;
    private long revision = 1;
    private string? controlFailure;
    private CreativeMenuRequest? creativeRequest;
    private long lastCreativeSequence;
    private string lastCreativeRequestId = "";
    private PlayerDmaStatRequest? statRequest;
    private long lastStatSequence;
    private string lastStatRequestId = "";
    private PlayerControlRequest? playerRequest;
    private long lastPlayerSequence;
    private string lastPlayerRequestId = "";

    internal WorkerReadOptionsState(LiveReadOptions? initial) => requested = (initial ?? new LiveReadOptions()).Copy();
    internal string? ControlFailure { get { lock (gate) return controlFailure; } }
    internal bool HasCreativeRequest { get { lock (gate) return creativeRequest != null; } }

    internal bool TryQueueStatRequest(PlayerDmaStatRequest request)
    {
        PlayerDmaStatPolicy.Validate(request);
        var copy = request.Copy();
        lock (gate)
        {
            if (statRequest != null && PlayerDmaStatPolicy.IsExpired(statRequest, Stopwatch.GetTimestamp())) statRequest = null;
            if (statRequest != null || copy.Sequence <= lastStatSequence || copy.RequestId == lastStatRequestId) return false;
            statRequest = copy; lastStatSequence = copy.Sequence; lastStatRequestId = copy.RequestId;
            return true;
        }
    }
    internal PlayerDmaStatRequest? TakeStatRequest() { lock (gate) { var v = statRequest; statRequest = null; return v; } }
    internal void ClearStatRequest() { lock (gate) statRequest = null; }

    internal bool TryQueuePlayerRequest(PlayerControlRequest request)
    {
        PlayerControlPolicy.ValidateRequest(request);
        var copied = request.Copy();
        PlayerControlPolicy.ValidateRequest(copied);
        lock (gate)
        {
            if (playerRequest != null && PlayerControlPolicy.IsExpired(playerRequest, Stopwatch.GetTimestamp())) playerRequest = null;
            if (playerRequest != null || copied.Sequence <= lastPlayerSequence || copied.RequestId == lastPlayerRequestId) return false;
            playerRequest = copied; lastPlayerSequence = copied.Sequence; lastPlayerRequestId = copied.RequestId;
            return true;
        }
    }

    internal PlayerControlRequest? TakePlayerRequest()
    { lock (gate) { var next = playerRequest; playerRequest = null; return next; } }
    internal void ClearPlayerRequest() { lock (gate) playerRequest = null; }

    // Unlike read preferences, an unexpired intent is never replaced. Consuming
    // it does not reset the sequence, including after a failed hardware action.
    internal bool TryQueueCreativeRequest(CreativeMenuRequest request)
    {
        CreativeMenuProtocol.ValidateRequest(request);
        var copied = request.Copy();
        CreativeMenuProtocol.ValidateRequest(copied);
        lock (gate)
        {
            // Native calls can stall beyond the UI deadline. Once frames resume,
            // a new explicit action may arrive just before the capture loop takes
            // the old, already-expired intent. Discard that unusable intent here
            // rather than stopping the whole reader because the inbox is full.
            if (creativeRequest != null && CreativeMenuProtocol.IsExpired(creativeRequest, Stopwatch.GetTimestamp()))
                creativeRequest = null;
            if (creativeRequest != null || copied.Sequence <= lastCreativeSequence ||
                string.Equals(copied.RequestId, lastCreativeRequestId, StringComparison.Ordinal)) return false;
            creativeRequest = copied;
            lastCreativeSequence = copied.Sequence;
            lastCreativeRequestId = copied.RequestId;
            return true;
        }
    }

    internal CreativeMenuRequest? TakeCreativeRequest()
    {
        lock (gate)
        {
            var result = creativeRequest;
            creativeRequest = null;
            return result;
        }
    }

    internal void ClearCreativeRequest()
    {
        lock (gate) creativeRequest = null;
    }

    internal void Update(LiveReadOptions options)
    {
        lock (gate)
        {
            if (ReadOptionsValue.Equal(requested, options)) return;
            requested = options.Copy();
            ++revision;
        }
    }

    internal WorkerReadOptionsSnapshot Snapshot()
    {
        lock (gate) return new(revision, requested.Copy());
    }

    internal void Fail(string detail)
    {
        lock (gate) controlFailure ??= detail.Length <= 512 ? detail : detail[..512];
    }
}

internal static class WorkerControlLoop
{
    internal static async Task MonitorAsync(Stream pipe, WorkerReadOptionsState state, CancellationTokenSource cancelled)
    {
        try
        {
            while (!cancelled.IsCancellationRequested)
            {
                var command = await Wire.ReadAsync<WorkerControl>(pipe, cancelled.Token).ConfigureAwait(false);
                if (command.Kind == WorkerControl.StopKind && command.ReadOptions == null && command.CreativeMenu == null && command.PlayerControl == null && command.PlayerDmaStat == null) return;
                if (command.Kind == WorkerControl.ReadOptionsKind && command.ReadOptions != null && command.CreativeMenu == null && command.PlayerControl == null && command.PlayerDmaStat == null)
                    state.Update(command.ReadOptions);
                else if (command.Kind == WorkerControl.CreativeMenuKind && command.ReadOptions == null && command.CreativeMenu != null && command.PlayerControl == null && command.PlayerDmaStat == null)
                {
                    if (!state.TryQueueCreativeRequest(command.CreativeMenu))
                        throw new InvalidDataException("Demande de menu créatif dupliquée ou commande précédente encore en attente.");
                }
                else if (command.Kind == WorkerControl.PlayerControlKind && command.ReadOptions == null && command.CreativeMenu == null && command.PlayerControl != null && command.PlayerDmaStat == null)
                {
                    if (!state.TryQueuePlayerRequest(command.PlayerControl))
                        throw new InvalidDataException("Commande du personnage dupliquée ou précédente commande encore en attente.");
                }
                else if (command.Kind == WorkerControl.PlayerDmaStatKind && command.ReadOptions == null &&
                    command.CreativeMenu == null && command.PlayerControl == null && command.PlayerDmaStat != null)
                {
                    if (!state.TryQueueStatRequest(command.PlayerDmaStat))
                        throw new InvalidDataException("Demande de statistique dupliquée ou précédente encore en attente.");
                }
                else throw new InvalidDataException("Commande de contrôle inconnue ou incomplète.");
            }
        }
        catch (OperationCanceledException) when (cancelled.IsCancellationRequested) { }
        catch (Exception e) when (e is IOException || e is InvalidDataException || e is JsonException || e is ObjectDisposedException)
        {
            if (!cancelled.IsCancellationRequested)
                state.Fail("Liaison de contrôle interrompue : " + e.GetBaseException().Message);
        }
        finally { state.ClearCreativeRequest(); state.ClearPlayerRequest(); state.ClearStatRequest(); cancelled.Cancel(); }
    }
}
