using System;
using System.IO;
using System.Threading;

namespace SevenDaysEsp
{
    public enum PlayerStatTarget : byte
    {
        Health = 1, Stamina = 2, Food = 3, Water = 4, SkillPoints = 5, Level = 6
    }

    public sealed class LocalPlayerStatResult
    {
        public bool Success { get; set; }
        public bool WriteAttempted { get; set; }
        public float? Value { get; set; }
        public float? Maximum { get; set; }
        public string Code { get; set; } = "NON_CONFIRME";
        public string Message { get; set; } = "Lecture non confirmée.";
    }

    // This is intentionally not a game-mod mailbox: all reads and writes are
    // obtained from the local game's actual Mono objects, over MemProcFS DMA.
    // No game code is called or injected. No server-side effect is asserted.
    public sealed partial class LiveEntityReader
    {
        private RuntimeClass progressionStatClass;
        private int progressionPointerOffset = -1;

        private sealed class ScalarGraph
        {
            internal ulong Address, Owner, Object;
            internal byte[] Expected;
            internal float Value, Maximum;
            internal bool Integer;
            internal PlayerStatTarget Kind;
        }

        // Called within ExecuteInValidatedContext, not in the rendering loop.
        public LocalPlayerStatResult AccessLocalStat(LiveMenuContext context, PlayerStatTarget kind,
            float? desiredValue, CancellationToken cancellationToken = default(CancellationToken))
        {
            var result = new LocalPlayerStatResult();
            try
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (context == null) throw new IOException("Contexte de partie absent.");
                if (kind < PlayerStatTarget.Health || kind > PlayerStatTarget.Level ||
                    (desiredValue.HasValue && (!Finite(desiredValue.Value) || desiredValue < 0 || desiredValue >
                        (kind == PlayerStatTarget.SkillPoints ? 9999f : 10000f))))
                    throw new IOException("Statistique ou valeur demandée hors limites.");
                if (kind == PlayerStatTarget.Level && desiredValue.HasValue)
                    throw new IOException("Le niveau est disponible en lecture seule.");
                context.Validate();
                ScalarGraph initial = ResolveStatGraph(context, kind);
                result.Value = initial.Value;
                result.Maximum = initial.Maximum;
                if (!desiredValue.HasValue)
                {
                    result.Success = true; result.Code = "LECTURE_CONFIRMEE";
                    result.Message = "Valeur lue dans la mémoire du client (pas une preuve d'état serveur).";
                    return result;
                }
                float target = desiredValue.Value;
                if (initial.Integer)
                {
                    if (target != (float)Math.Truncate(target))
                        throw new IOException("Les points de compétence demandent un entier.");
                }
                else if (target > initial.Maximum)
                    throw new IOException("La valeur dépasse le maximum courant du personnage.");
                byte[] replacement = initial.Integer ? BitConverter.GetBytes(checked((int)target)) : BitConverter.GetBytes(target);
                if (SameBytes(initial.Expected, replacement))
                {
                    result.Success = true; result.Code = "DEJA_APPLIQUE";
                    result.Message = "Valeur déjà présente localement ; aucune écriture DMA.";
                    return result;
                }
                var writer = memory as IPlayerStatMemoryWriter;
                if (writer == null) throw new IOException("Ce lecteur DMA ne prend pas en charge l'écriture des statistiques.");
                if (writer.ProcessId == 0) throw new IOException("Processus DMA non confirmé.");
                // Validate the complete typed object chain again before allowing
                // a single scalar write. An object replaced by the game cannot
                // be written through a cached address.
                Action validate = delegate
                {
                    context.Validate();
                    ScalarGraph check = ResolveStatGraph(context, kind);
                    if (check.Address != initial.Address || check.Object != initial.Object || check.Owner != initial.Owner ||
                        check.Integer != initial.Integer || (check.Value != initial.Value && check.Value != target) ||
                        check.Maximum != initial.Maximum)
                        throw new IOException("La statistique ou le personnage a changé pendant la validation.");
                };
                var lease = new PlayerStatWriteLease(initial.Address, context.LocalPlayerAddress);
                var written = writer.WritePlayerStatScalar(writer.ProcessId, lease,
                    initial.Expected, replacement, validate, cancellationToken);
                result.WriteAttempted = written != null && written.Attempted;
                if (written == null) throw new IOException("Écriture DMA sans réponse.");
                if (!written.Confirmed)
                {
                    result.Value = null; result.Maximum = null;
                    throw new IOException(written.Message ?? "Le résultat de l'écriture DMA est inconnu.");
                }
                // Do not claim server acceptance, even if an immediate readback
                // confirms the target value in client memory.
                context.Validate();
                ScalarGraph after = ResolveStatGraph(context, kind);
                if (after.Address != initial.Address || after.Object != initial.Object || after.Owner != initial.Owner ||
                    after.Value != target)
                    throw new IOException("La statistique a changé après l'écriture ; résultat non confirmé.");
                result.Success = true; result.Code = "ECRITURE_LOCALE_CONFIRMEE";
                result.Value = after.Value; result.Maximum = after.Maximum;
                result.Message = "Écriture DMA relue sur le client. Le serveur peut rétablir cette valeur.";
            }
            catch (Exception e) when (e is IOException || e is ArgumentException || e is OverflowException || e is InvalidOperationException)
            {
                result.Success = false;
                result.Code = result.WriteAttempted ? "ECRITURE_NON_CONFIRMEE" : "LECTURE_NON_CONFIRMEE";
                result.Message = e.GetBaseException().Message;
                if (result.WriteAttempted) { result.Value = null; result.Maximum = null; }
            }
            return result;
        }

        private ScalarGraph ResolveStatGraph(LiveMenuContext context, PlayerStatTarget kind)
        {
            context.Validate();
            if (kind == PlayerStatTarget.SkillPoints || kind == PlayerStatTarget.Level)
            {
                if (progressionStatClass == null || progressionPointerOffset < 0)
                    throw new IOException("Type Progression non confirmé pour ce profil du jeu.");
                byte[] entity = ReadObject(context.LocalPlayerAddress, gameClasses["EntityPlayerLocal"], context.Domain);
                ulong progression = BufferPointer(entity, progressionPointerOffset);
                OptionalLayout layout = GetOptionalLayout(progressionStatClass);
                RuntimeField ownerField = RequiredOptionalField(layout, "parent", 0x12, 8);
                RuntimeField pointsField = RequiredOptionalField(layout, "SkillPoints", 0x08, 4);
                RuntimeField levelField = RequiredOptionalField(layout, "Level", 0x08, 4);
                if (ownerField.TypeData != gameClasses["EntityAlive"].Address)
                    throw new IOException("Propriétaire de Progression non reconnu.");
                DistinctOptionalFields(ownerField, pointsField, levelField);
                byte[] data = ReadObject(progression, progressionStatClass, context.Domain);
                if (BitConverter.ToUInt64(data, ownerField.Offset) != context.LocalPlayerAddress)
                    throw new IOException("Progression rattachée à un autre personnage.");
                int level = BitConverter.ToInt32(data, levelField.Offset);
                int points = BitConverter.ToInt32(data, pointsField.Offset);
                if (level < 1 || level > 300 || points < 0 || points > 9999)
                    throw new IOException("Progression courante incohérente.");
                bool readLevel = kind == PlayerStatTarget.Level;
                int scalar = readLevel ? level : points;
                return new ScalarGraph { Address = Add(progression, readLevel ? levelField.Offset : pointsField.Offset), Owner = context.LocalPlayerAddress,
                    Object = progression, Expected = BitConverter.GetBytes(scalar), Value = scalar,
                    Maximum = readLevel ? 300f : 9999f, Integer = true, Kind = kind };
            }

            if (statsClass == null || statsPointerOffset < 0)
                throw new IOException("EntityStats non confirmé pour cette partie.");
            byte[] local = ReadObject(context.LocalPlayerAddress, gameClasses["EntityPlayerLocal"], context.Domain);
            ulong stats = BufferPointer(local, statsPointerOffset);
            OptionalLayout entityStatsLayout = GetOptionalLayout(statsClass);
            RuntimeField owner = RequiredOptionalField(entityStatsLayout, "m_entity", 0x12, 8);
            string statName = kind.ToString();
            RuntimeField statField = RequiredOptionalField(entityStatsLayout, statName, 0x12, 8);
            if (owner.TypeData != gameClasses["EntityAlive"].Address)
                throw new IOException("Propriétaire EntityStats invalide.");
            DistinctOptionalFields(owner, statField);
            byte[] statsData = ReadObject(stats, statsClass, context.Domain);
            if (BitConverter.ToUInt64(statsData, owner.Offset) != context.LocalPlayerAddress)
                throw new IOException("Statistiques rattachées à un autre personnage.");
            RuntimeClass statClass = GetClass(statField.TypeData);
            if (statClass.Kind != 1 || statClass.Name != "Stat" || statClass.Namespace != "" || statClass.Image != gameImage)
                throw new IOException("Type de statistique inconnu.");
            OptionalLayout statLayout = GetOptionalLayout(statClass);
            RuntimeField valueField = RequiredOptionalField(statLayout, "m_value", 0x0C, 4);
            RuntimeField baseField = RequiredOptionalField(statLayout, "m_baseMax", 0x0C, 4);
            RuntimeField bonusField = RequiredOptionalField(statLayout, "m_maxModifier", 0x0C, 4);
            RuntimeField entityField = RequiredOptionalField(statLayout, "Entity", 0x12, 8);
            if (entityField.TypeData != gameClasses["EntityAlive"].Address)
                throw new IOException("Propriétaire de Stat invalide.");
            DistinctOptionalFields(valueField, baseField, bonusField, entityField);
            ulong stat = BufferPointer(statsData, statField.Offset);
            byte[] data = ReadObject(stat, statClass, context.Domain);
            if (BitConverter.ToUInt64(data, entityField.Offset) != context.LocalPlayerAddress)
                throw new IOException("Statistique d'un autre joueur.");
            float val = BitConverter.ToSingle(data, valueField.Offset);
            float rawMax = BitConverter.ToSingle(data, baseField.Offset);
            float bonus = BitConverter.ToSingle(data, bonusField.Offset);
            float max = rawMax + bonus;
            if (!Finite(val) || !Finite(rawMax) || !Finite(bonus) || !Finite(max) ||
                max < 1 || max > 10000f || val < 0 || val > 10000f)
                throw new IOException("Statistique hors limites raisonnables.");
            return new ScalarGraph { Address = Add(stat, valueField.Offset), Owner = context.LocalPlayerAddress,
                Object = stat, Expected = BitConverter.GetBytes(val), Value = val, Maximum = max, Kind = kind };
        }
    }
}
