using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace SevenDaysDmaControl
{
    // These are the only remotely writable/readable bridge objects. Their sizes and addresses
    // remain stable for the process lifetime. The loader never writes any action/game object.
    public static class ControlBridge
    {
        public static readonly byte[] RequestBuffer = new byte[ControlProtocol.RequestSize];
        public static readonly byte[] StateBuffer = new byte[ControlProtocol.StateSize];
        private static readonly GCHandle RequestPin = GCHandle.Alloc(RequestBuffer, GCHandleType.Pinned);
        private static readonly GCHandle StatePin = GCHandle.Alloc(StateBuffer, GCHandleType.Pinned);
        private static readonly Stopwatch Clock = Stopwatch.StartNew();
        private static readonly Guid SessionId = Guid.NewGuid();
        private static ControlMailbox _mailbox;

        internal static void Initialize()
        {
            if (_mailbox != null) return;
            // Touch the pinned handles to keep this invariant explicit even under optimization.
            if (!RequestPin.IsAllocated || !StatePin.IsAllocated) throw new InvalidOperationException("Mailbox pinning failed.");
            _mailbox = new ControlMailbox(new GameActions(), SessionId, RequestBuffer, StateBuffer, () => Clock.ElapsedMilliseconds);
        }
        internal static void Update()
        {
            if (_mailbox != null) _mailbox.Tick();
        }
        internal static void ShutdownWorld()
        {
            if (_mailbox != null) _mailbox.ReleaseForWorldShutdown();
        }
    }

    public sealed class ControlMod : IModApi
    {
        private static bool _registered;
        public void InitMod(Mod mod)
        {
            if (_registered) return;
            ControlBridge.Initialize();
            ModEvents.UnityUpdate.RegisterHandler(OnUnityUpdate);
            ModEvents.WorldShuttingDown.RegisterHandler(OnWorldShuttingDown);
            ModEvents.GameShutdown.RegisterHandler(OnGameShutdown);
            _registered = true;
        }
        private static void OnUnityUpdate(ref ModEvents.SUnityUpdateData data) { ControlBridge.Update(); }
        private static void OnWorldShuttingDown(ref ModEvents.SWorldShuttingDownData data) { ControlBridge.ShutdownWorld(); }
        private static void OnGameShutdown(ref ModEvents.SGameShutdownData data) { ControlBridge.ShutdownWorld(); }
    }
}
