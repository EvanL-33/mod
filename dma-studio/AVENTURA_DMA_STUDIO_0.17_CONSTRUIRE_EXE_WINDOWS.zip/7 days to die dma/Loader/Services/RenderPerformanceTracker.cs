using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace SevenDaysLoader.Services;

// A token binds a WPF publication to a previously accepted sample. It carries
// only numeric identity/timing data, never an entity list or a camera matrix.
public readonly record struct RenderPerformanceToken(int Generation, long CaptureId,
    long ReceivedTimestamp, double InitialAgeMs);

public sealed record RenderPerformanceSnapshot
{
    public int Generation { get; init; }
    public double WindowSeconds { get; init; } = RenderPerformanceTracker.WindowMilliseconds / 1000.0;
    public int AcceptedCaptures { get; init; }
    public int FreshCameras { get; init; }
    public int DrawnCaptures { get; init; }
    public int ExpiredWithoutDraw { get; init; }
    public int Interruptions { get; init; }
    public double AcceptedPerSecond => AcceptedCaptures / WindowSeconds;
    public double FreshCamerasPerSecond => FreshCameras / WindowSeconds;
    public double DrawnCapturesPerSecond => DrawnCaptures / WindowSeconds;
    public double? LastAgeAtDrawMs { get; init; }
    public double? AgeAtDrawP50Ms { get; init; }
    public double? AgeAtDrawP95Ms { get; init; }
    public double? ReceiveToDrawP50Ms { get; init; }
    public double? ReceiveToDrawP95Ms { get; init; }
    public bool CameraAvailable { get; init; }
    public bool IsWindowTruncated { get; init; }
    public int BufferedCaptures { get; init; }
    public int BufferedAliases { get; init; }
    public int CaptureCapacity { get; init; }
}

// Recent, bounded telemetry. This observes existing validity decisions and a
// completed WPF render receipt; it cannot make a camera valid or extend its TTL.
// Rates describe a fixed trailing ten-second interval, including startup time.
// Drawing commands are not GPU frames or proof of physical fuser presentation.
public sealed class RenderPerformanceTracker
{
    public const int WindowMilliseconds = 10_000;
    public const int DefaultCapacity = 2048;
    private readonly object gate = new();
    private readonly Func<long> timestamp;
    private readonly int capacity;
    private readonly int aliasCapacity;
    private readonly Queue<Capture> captures = new();
    private readonly Dictionary<CaptureIdentity, Capture> identities = new();
    private readonly Dictionary<long, Capture> captureIds = new();
    private readonly Queue<Alias> aliasOrder = new();
    private readonly Dictionary<SampleStamp, Alias> aliases = new();
    private readonly Queue<DrawObservation> draws = new();
    private readonly Queue<long> expirations = new();
    private readonly Queue<long> interruptions = new();
    private int generation;
    private long nextCaptureId;
    private long lastTimestamp;
    private long? lastCapacityDrop;
    private bool cameraAvailable;
    private long currentCameraDeadline;

    // An injected clock uses Stopwatch timestamp units. All elapsed values use
    // that clock; UTC capture time is an identity component, never a stopwatch.
    public RenderPerformanceTracker(Func<long>? getTimestamp = null, int capacity = DefaultCapacity)
    {
        if (capacity < 4 || capacity > 8192) throw new ArgumentOutOfRangeException(nameof(capacity));
        timestamp = getTimestamp ?? Stopwatch.GetTimestamp;
        this.capacity = capacity;
        aliasCapacity = capacity * 2;
        lastTimestamp = timestamp();
    }

    public void Reset(int newGeneration)
    {
        lock (gate)
        {
            if (newGeneration < generation) return;
            generation = newGeneration;
            captures.Clear(); identities.Clear(); captureIds.Clear();
            aliasOrder.Clear(); aliases.Clear(); draws.Clear(); expirations.Clear(); interruptions.Clear();
            lastCapacityDrop = null;
            cameraAvailable = false;
            currentCameraDeadline = 0;
            // Keep the monotonic fence and unique token counter even when an
            // explicit reset repeats a generation number.
            ReadTime();
        }
    }

    // True means a new accepted capture was counted. A retransmission can gain
    // an alias for its publication without counting or rejuvenating the capture.
    public bool ObserveReceived(FeedSample sample, int expectedGeneration)
    {
        lock (gate)
        {
            if (expectedGeneration != generation) return false;
            long now = ReadTime();
            Advance(now);
            if (sample == null || !FeedSample.IsValid(sample.Snapshot) ||
                !TryAge(sample.ReceivedTimestamp, sample.InitialAgeMs, now, out double age) || age >= FeedSample.LifetimeMs ||
                sample.Snapshot.CapturedUtc.Ticks == 0)
            {
                MarkUnavailable(now);
                return false;
            }
            var source = sample.Snapshot;
            var identity = new CaptureIdentity(source.CapturedUtc.Ticks, source.LocalId);
            int cameraEpoch = source.Camera?.CameraEpoch ?? 0;
            long cameraSequence = source.Camera?.Sequence ?? 0;
            var stamp = new SampleStamp(sample.ReceivedTimestamp, sample.InitialAgeMs);
            if (identities.TryGetValue(identity, out var previous))
            {
                // Conflicting metadata must not attach a new camera to an old
                // identity or revive a capture that was already invalidated.
                if (previous.CameraEpoch == cameraEpoch && previous.CameraSequence == cameraSequence &&
                    previous.FreshCamera && !previous.Invalidated && !previous.Expired && age < FeedSample.ProjectionLifetimeMs)
                    RegisterAlias(stamp, previous, now);
                return false;
            }

            bool freshCamera = age < FeedSample.ProjectionLifetimeMs && sample.TryGetProjectionView(out _, out _);
            var capture = new Capture(identity, ++nextCaptureId, now, stamp, freshCamera,
                cameraEpoch, cameraSequence, ProjectionDeadline(stamp));
            captures.Enqueue(capture);
            identities.Add(identity, capture);
            captureIds.Add(capture.Id, capture);
            while (captures.Count > capacity)
            {
                RemoveCapture(captures.Dequeue());
                lastCapacityDrop = now;
            }
            if (freshCamera)
            {
                cameraAvailable = true;
                currentCameraDeadline = capture.Deadline;
                RegisterAlias(stamp, capture, now);
            }
            else MarkUnavailable(now);
            return true;
        }
    }

    public void ObserveUnavailable(int expectedGeneration)
    {
        lock (gate)
        {
            if (expectedGeneration != generation) return;
            long now = ReadTime();
            Advance(now);
            MarkUnavailable(now);
        }
    }

    public bool TryGetDrawToken(long receivedTimestamp, double initialAgeMs, out RenderPerformanceToken token)
    {
        lock (gate)
        {
            token = default;
            long now = ReadTime();
            Advance(now);
            var stamp = new SampleStamp(receivedTimestamp, initialAgeMs);
            if (!TryResolve(stamp, now, out var capture)) return false;
            token = new RenderPerformanceToken(generation, capture.Id, receivedTimestamp, initialAgeMs);
            return true;
        }
    }

    // Call only after creating a successful RenderReceipt, including valid empty
    // geometry. Repeated redraws and retransmissions count at most once.
    public bool ObserveDraw(RenderPerformanceToken token)
    {
        lock (gate)
        {
            if (token.Generation != generation || token.CaptureId <= 0) return false;
            long now = ReadTime();
            Advance(now);
            var stamp = new SampleStamp(token.ReceivedTimestamp, token.InitialAgeMs);
            if (!TryResolve(stamp, now, out var capture) || capture.Id != token.CaptureId || capture.Drawn) return false;
            if (!TryAge(capture.Source.Timestamp, capture.Source.InitialAgeMs, now, out double originalAge) ||
                !TryAge(stamp.Timestamp, stamp.InitialAgeMs, now, out double publicationAge)) return false;
            double age = Math.Max(originalAge, publicationAge);
            if (age >= FeedSample.ProjectionLifetimeMs) return false;
            capture.Drawn = true;
            draws.Enqueue(new DrawObservation(now, age, ElapsedMs(capture.Source.Timestamp, now)));
            TrimCapacity(draws, now);
            return true;
        }
    }

    public RenderPerformanceSnapshot ReadSnapshot()
    {
        lock (gate)
        {
            long now = ReadTime();
            Advance(now);
            var observations = draws.ToArray();
            var ages = observations.Select(item => item.AgeMs).OrderBy(value => value).ToArray();
            var delays = observations.Select(item => item.ReceiveToDrawMs).OrderBy(value => value).ToArray();
            return new RenderPerformanceSnapshot
            {
                Generation = generation, WindowSeconds = WindowMilliseconds / 1000.0,
                AcceptedCaptures = captures.Count, FreshCameras = captures.Count(item => item.FreshCamera),
                DrawnCaptures = observations.Length, ExpiredWithoutDraw = expirations.Count,
                Interruptions = interruptions.Count, CameraAvailable = cameraAvailable,
                LastAgeAtDrawMs = observations.Length == 0 ? null : observations[^1].AgeMs,
                AgeAtDrawP50Ms = Percentile(ages, .50), AgeAtDrawP95Ms = Percentile(ages, .95),
                ReceiveToDrawP50Ms = Percentile(delays, .50), ReceiveToDrawP95Ms = Percentile(delays, .95),
                IsWindowTruncated = lastCapacityDrop.HasValue && ElapsedMs(lastCapacityDrop.Value, now) < WindowMilliseconds,
                BufferedCaptures = captures.Count, BufferedAliases = aliases.Count, CaptureCapacity = capacity
            };
        }
    }

    private bool TryResolve(SampleStamp stamp, long now, out Capture capture)
    {
        capture = null!;
        if (!TryAge(stamp.Timestamp, stamp.InitialAgeMs, now, out double age) || age >= FeedSample.ProjectionLifetimeMs ||
            !aliases.TryGetValue(stamp, out var alias) || alias.CaptureId <= 0 ||
            !captureIds.TryGetValue(alias.CaptureId, out var found) || !found.FreshCamera || found.Invalidated || found.Expired ||
            !TryAge(found.Source.Timestamp, found.Source.InitialAgeMs, now, out double originalAge) ||
            originalAge >= FeedSample.ProjectionLifetimeMs) return false;
        capture = found;
        return true;
    }

    private void RegisterAlias(SampleStamp stamp, Capture capture, long now)
    {
        if (aliases.TryGetValue(stamp, out var existing))
        {
            if (existing.CaptureId != capture.Id) existing.CaptureId = 0; // Ambiguous stamp: never guess.
            return;
        }
        var alias = new Alias(stamp, capture.Id, now);
        aliases.Add(stamp, alias);
        aliasOrder.Enqueue(alias);
        while (aliasOrder.Count > aliasCapacity)
        {
            aliases.Remove(aliasOrder.Dequeue().Stamp);
            lastCapacityDrop = now;
        }
    }

    private void MarkUnavailable(long now)
    {
        if (cameraAvailable)
        {
            interruptions.Enqueue(now);
            TrimCapacity(interruptions, now);
            cameraAvailable = false;
        }
        foreach (var capture in captures) capture.Invalidated = true;
        // Undrawn cameras still reach their original 250 ms deadline. They are
        // observations without drawing, not an inferred count of packet loss.
    }

    private void Advance(long now)
    {
        List<long>? due = null;
        foreach (var capture in captures)
        {
            if (!capture.FreshCamera || capture.Drawn || capture.Expired || now < capture.Deadline) continue;
            capture.Expired = true;
            (due ??= new List<long>()).Add(capture.Deadline);
        }
        if (due != null)
        {
            due.Sort();
            foreach (long deadline in due) expirations.Enqueue(deadline);
            TrimCapacity(expirations, now);
        }
        if (cameraAvailable && now >= currentCameraDeadline)
        {
            cameraAvailable = false;
            interruptions.Enqueue(currentCameraDeadline);
            TrimCapacity(interruptions, now);
        }
        while (captures.TryPeek(out var capture) && ElapsedMs(capture.ObservedAt, now) >= WindowMilliseconds)
            RemoveCapture(captures.Dequeue());
        while (aliasOrder.TryPeek(out var alias) && ElapsedMs(alias.ObservedAt, now) >= WindowMilliseconds)
            aliases.Remove(aliasOrder.Dequeue().Stamp);
        while (draws.TryPeek(out var draw) && ElapsedMs(draw.Timestamp, now) >= WindowMilliseconds) draws.Dequeue();
        PruneEvents(expirations, now);
        PruneEvents(interruptions, now);
    }

    private void RemoveCapture(Capture capture)
    {
        identities.Remove(capture.Identity);
        captureIds.Remove(capture.Id);
    }

    private void TrimCapacity<T>(Queue<T> queue, long now)
    {
        while (queue.Count > capacity)
        {
            queue.Dequeue();
            lastCapacityDrop = now;
        }
    }

    private static void PruneEvents(Queue<long> queue, long now)
    {
        while (queue.TryPeek(out long time) && ElapsedMs(time, now) >= WindowMilliseconds) queue.Dequeue();
    }

    private long ReadTime()
    {
        long now = timestamp();
        if (now > lastTimestamp) lastTimestamp = now;
        return lastTimestamp; // A faulty/test clock cannot rejuvenate a sample.
    }

    private static bool TryAge(long received, double initialAge, long now, out double age)
    {
        age = double.NaN;
        if (received <= 0 || received > now || !double.IsFinite(initialAge) || initialAge < 0) return false;
        age = initialAge + ElapsedMs(received, now);
        return double.IsFinite(age) && age >= 0;
    }

    private static long ProjectionDeadline(SampleStamp stamp)
    {
        double remaining = Math.Max(0, FeedSample.ProjectionLifetimeMs - stamp.InitialAgeMs);
        long ticks = (long)Math.Ceiling(remaining * Stopwatch.Frequency / 1000.0);
        return stamp.Timestamp <= long.MaxValue - ticks ? stamp.Timestamp + ticks : long.MaxValue;
    }

    private static double ElapsedMs(long start, long end) => Stopwatch.GetElapsedTime(start, end).TotalMilliseconds;

    // Nearest-rank empirical percentiles; no interpolation invents an unobserved
    // latency. Empty windows have no value, rather than a misleading zero.
    private static double? Percentile(double[] ordered, double fraction) => ordered.Length == 0 ? null :
        ordered[Math.Clamp((int)Math.Ceiling(ordered.Length * fraction) - 1, 0, ordered.Length - 1)];

    private readonly record struct CaptureIdentity(long CapturedUtcTicks, int LocalId);
    private readonly record struct SampleStamp(long Timestamp, double InitialAgeMs);
    private readonly record struct DrawObservation(long Timestamp, double AgeMs, double ReceiveToDrawMs);

    private sealed class Capture
    {
        internal readonly CaptureIdentity Identity;
        internal readonly long Id, ObservedAt, Deadline;
        internal readonly SampleStamp Source;
        internal readonly bool FreshCamera;
        internal readonly int CameraEpoch;
        internal readonly long CameraSequence;
        internal bool Drawn, Expired, Invalidated;
        internal Capture(CaptureIdentity identity, long id, long observedAt, SampleStamp source, bool freshCamera,
            int cameraEpoch, long cameraSequence, long deadline)
        {
            Identity = identity; Id = id; ObservedAt = observedAt; Source = source; FreshCamera = freshCamera;
            CameraEpoch = cameraEpoch; CameraSequence = cameraSequence; Deadline = deadline;
        }
    }

    private sealed class Alias
    {
        internal readonly SampleStamp Stamp;
        internal readonly long ObservedAt;
        internal long CaptureId;
        internal Alias(SampleStamp stamp, long captureId, long observedAt)
        { Stamp = stamp; CaptureId = captureId; ObservedAt = observedAt; }
    }
}
