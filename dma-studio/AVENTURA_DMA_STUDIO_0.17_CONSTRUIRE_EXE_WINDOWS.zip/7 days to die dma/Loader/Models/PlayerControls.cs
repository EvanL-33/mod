using System;
using System.Diagnostics;
using System.IO;
using SevenDaysDmaControl;

namespace SevenDaysLoader;

// Explicit, short-lived user intent. These commands are never stored in settings,
// included in display sharing or replayed by automatic reconnection.
public sealed class PlayerControlRequest
{
    public long Sequence { get; set; }
    public string RequestId { get; set; } = "";
    public uint ExpectedProcessId { get; set; }
    public string ExpectedPlayerContextId { get; set; } = "";
    public Guid ExpectedModuleSessionId { get; set; }
    public Guid ExpectedModuleContextId { get; set; }
    public int ExpectedPlayerId { get; set; }
    public ControlOperation Operation { get; set; }
    public bool Enabled { get; set; }
    public float Value { get; set; }
    public float PositionX { get; set; }
    public float PositionY { get; set; }
    public float PositionZ { get; set; }
    public long RequestedTimestamp { get; set; }
    public PlayerControlRequest Copy() => (PlayerControlRequest)MemberwiseClone();
}

// Local parent/worker pipe DTOs deliberately use properties. The shared game
// protocol is binary; its public fields are not silently lost by JSON serialization.
public sealed class PlayerControlObservation
{
    public uint ProcessId { get; set; }
    public string PlayerContextId { get; set; } = "";
    public long CapturedTimestamp { get; set; }
    public double ObservedAgeMs { get; set; }
    public bool Available { get; set; }
    public bool Fresh { get; set; }
    public string Code { get; set; } = "MODULE_ABSENT";
    public string Message { get; set; } = "Module du jeu non détecté.";
    public byte[]? SnapshotRecord { get; set; }
    public ulong PendingRequestId { get; set; }
    public double ProbeDurationMs { get; set; }
    public int ReadCalls { get; set; }
    public int ReadBytes { get; set; }
}

public sealed class PlayerControlSubmission
{
    public long Sequence { get; set; }
    public string RequestId { get; set; } = "";
    public uint ProcessId { get; set; }
    public string PlayerContextId { get; set; } = "";
    public bool Accepted { get; set; }
    public bool WriteAttempted { get; set; }
    public bool CommitAttempted { get; set; }
    public ulong ModuleRequestId { get; set; }
    public string Code { get; set; } = "REFUSE";
    public string Message { get; set; } = "Commande non transmise.";
}

public sealed record PlayerControlState
{
    public bool Available { get; init; }
    public bool IsBusy { get; init; }
    public string Code { get; init; } = "MODULE_ABSENT";
    public string Message { get; init; } = "Installe le module sur le PC du jeu, puis charge une partie.";
    public ControlSnapshot? Snapshot { get; init; }
    public DateTime? ObservedUtc { get; init; }
    public uint ProcessId { get; init; }
    public string PlayerContextId { get; init; } = "";
    public bool CanRequest => Available && !IsBusy;
    public bool Supports(ControlOperation operation) => CanRequest && Snapshot != null &&
        (Snapshot.Observation.SupportedOperations & ControlProtocol.OperationMask(operation)) != 0;
}

public static class PlayerControlPolicy
{
    public const int RequestLifetimeMs = 3000;
    public const int StateLifetimeMs = 1000;
    public const int ResultLifetimeMs = 40000;

    public static void ValidateRequest(PlayerControlRequest? value)
    {
        if (value == null || value.Sequence <= 0 || !CreativeMenuProtocol.IsGuidN(value.RequestId) ||
            value.ExpectedProcessId == 0 || !CreativeMenuProtocol.IsGuidN(value.ExpectedPlayerContextId) ||
            value.ExpectedModuleSessionId == Guid.Empty || value.ExpectedModuleContextId == Guid.Empty ||
            value.ExpectedPlayerId < 0 || value.RequestedTimestamp <= 0 ||
            !ControlProtocol.IsKnownOperation(value.Operation) || !float.IsFinite(value.Value) ||
            !ValidCoordinate(value.PositionX) || !ValidCoordinate(value.PositionY) || !ValidCoordinate(value.PositionZ))
            throw new InvalidDataException("Commande du personnage incomplète ou invalide.");
        if (value.Operation == ControlOperation.SetSpeed && (value.Value < 0.1f || value.Value > 15f))
            throw new InvalidDataException("Le multiplicateur de vitesse doit être compris entre 0,1 et 15.");
        if (value.Operation == ControlOperation.SetNightBrightness && (value.Value < 0 || value.Value > 1))
            throw new InvalidDataException("L’éclaircissement doit être compris entre 0 et 100 %.");
        if (value.Operation == ControlOperation.Teleport && (value.PositionY < 1 || value.PositionY > 254))
            throw new InvalidDataException("L’altitude Y de la destination doit être comprise entre 1 et 254.");
    }

    public static bool ValidCoordinate(float value) => float.IsFinite(value) && Math.Abs(value) <= 1_000_000;
    public static bool IsExpired(PlayerControlRequest value, long now) => value.RequestedTimestamp <= 0 ||
        now < value.RequestedTimestamp || Stopwatch.GetElapsedTime(value.RequestedTimestamp, now).TotalMilliseconds >= RequestLifetimeMs;

    public static bool TryReadSnapshot(PlayerControlObservation? packet, long now, out ControlSnapshot? snapshot, out double age)
    {
        snapshot = null;
        age = double.PositiveInfinity;
        if (packet == null || packet.ProcessId == 0 || !CreativeMenuProtocol.IsGuidN(packet.PlayerContextId) ||
            packet.CapturedTimestamp <= 0 || packet.CapturedTimestamp > now || !double.IsFinite(packet.ObservedAgeMs) ||
            packet.ObservedAgeMs < 0 || packet.SnapshotRecord?.Length != ControlProtocol.StateSize ||
            packet.Message == null || packet.Message.Length > 1024 || packet.Code == null || packet.Code.Length > 80)
            return false;
        if (!ControlProtocol.TryDecodeSnapshot(packet.SnapshotRecord, out var decoded, out _)) return false;
        var o = decoded.Observation;
        if (decoded.SessionId == Guid.Empty || o.GameTimestampMs < 0 ||
            (o.IsReady && (o.ContextId == Guid.Empty || o.PlayerId < 0)) ||
            !ValidCoordinate(o.PositionX) || !ValidCoordinate(o.PositionY) || !ValidCoordinate(o.PositionZ) ||
            !float.IsFinite(o.Speed) || !float.IsFinite(o.Brightness) ||
            (o.SupportedOperations & ~ControlProtocol.AllOperationsMask) != 0 ||
            (o.OwnedOperations & ~ControlProtocol.AllOperationsMask) != 0) return false;
        age = packet.ObservedAgeMs + Stopwatch.GetElapsedTime(packet.CapturedTimestamp, now).TotalMilliseconds;
        snapshot = decoded;
        return true;
    }
}
