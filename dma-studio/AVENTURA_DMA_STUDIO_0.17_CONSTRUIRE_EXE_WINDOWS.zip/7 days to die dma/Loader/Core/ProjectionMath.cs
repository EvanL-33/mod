#nullable enable
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace SevenDaysEsp;

// The producer must identify the camera and its matrix convention. These helpers
// check mathematical inputs; they do not discover or authenticate a camera.
public enum ProjectionDepthRange
{
    MinusOneToOne,
    ZeroToOne
}

public readonly record struct ProjectionViewport(double X, double Y, double Width, double Height)
{
    public double Right => X + Width;
    public double Bottom => Y + Height;
}

public readonly record struct ProjectionPoint(double X, double Y);

public readonly record struct ProjectionBox(double Left, double Top, double Right, double Bottom)
{
    public double Width => Right - Left;
    public double Height => Bottom - Top;
}

// A copied, immutable mathematical view. Matrix storage is row-major and vectors
// are columns: clip = M * (worldPosition - RenderOrigin, 1). The viewport uses
// source-output pixels with a top-left origin. No implicit transpose/Y flip exists.
public sealed class ProjectionView
{
    internal readonly double[] Matrix;
    internal readonly double OriginX, OriginY, OriginZ;
    public int SourceWidth { get; }
    public int SourceHeight { get; }
    public ProjectionViewport Viewport { get; }
    public ProjectionDepthRange DepthRange { get; }

    internal ProjectionView(float[] matrix, LivePosition origin, int width, int height,
        ProjectionViewport viewport, ProjectionDepthRange depthRange)
    {
        Matrix = Array.ConvertAll(matrix, x => (double)x);
        OriginX = origin.X; OriginY = origin.Y; OriginZ = origin.Z;
        SourceWidth = width; SourceHeight = height;
        Viewport = viewport; DepthRange = depthRange;
    }
}

// Construct this only after the producer has confirmed that the bounds belong to
// this entity and the same capture/coordinate space. IsValidated is a local gate,
// not a trust flag to copy from network input. Values are copied on construction.
public sealed class ProjectionEntityBounds
{
    public int EntityId { get; }
    public bool IsValidated { get; }
    public double MinX { get; }
    public double MinY { get; }
    public double MinZ { get; }
    public double MaxX { get; }
    public double MaxY { get; }
    public double MaxZ { get; }

    public ProjectionEntityBounds(int entityId, LivePosition? minimum, LivePosition? maximum, bool isValidated)
    {
        EntityId = entityId; IsValidated = isValidated;
        MinX = minimum?.X ?? double.NaN; MinY = minimum?.Y ?? double.NaN; MinZ = minimum?.Z ?? double.NaN;
        MaxX = maximum?.X ?? double.NaN; MaxY = maximum?.Y ?? double.NaN; MaxZ = maximum?.Z ?? double.NaN;
    }
}

public sealed record ProjectedMarker(int EntityId, string Kind, string Name, double DistanceMeters,
    ProjectionPoint? Anchor, ProjectionBox? Bounds, int? Health = null, int? MaxHealth = null,
    long IdentityToken = 0, double HeightMeters = double.NaN,
    bool? IsRunning = null, bool? IsCrouching = null, bool? IsJumping = null,
    int? HeldItemTypeId = null, double? FacingLocalDegrees = null, bool? ZombieTargetsLocal = null);

// Directions are separate from marker geometry. They must never become a fake
// box or a point pinned to the edge of the picture.
public sealed record ProjectedPlayerDirection(int EntityId, string Name, double DistanceMeters,
    long IdentityToken, OffscreenDirection Direction, double HeightMeters = double.NaN,
    int? Health = null, int? MaxHealth = null);

public sealed class ProjectedFrame
{
    public int SourceWidth { get; }
    public int SourceHeight { get; }
    public ProjectionViewport Viewport { get; }
    public IReadOnlyList<ProjectedMarker> Markers { get; }
    public string PlayerContextId { get; }
    public IReadOnlyList<ProjectedPlayerDirection> PlayerDirections { get; }

    internal ProjectedFrame(ProjectionView view, List<ProjectedMarker> markers,
        List<ProjectedPlayerDirection>? playerDirections = null, string? playerContextId = null)
    {
        SourceWidth = view.SourceWidth; SourceHeight = view.SourceHeight;
        Viewport = view.Viewport;
        Markers = new ReadOnlyCollection<ProjectedMarker>(markers.ToArray());
        PlayerContextId = playerContextId ?? string.Empty;
        PlayerDirections = new ReadOnlyCollection<ProjectedPlayerDirection>(
            (playerDirections ?? new List<ProjectedPlayerDirection>()).ToArray());
    }
}

public static class ProjectionMath
{
    public const int MaximumEntities = 4096;
    public const int MaximumOutputDimension = 32768;
    public const double MaximumCoordinate = 1_000_000;
    // Defensive numerical bounds, not camera/FOV heuristics. Arithmetic below is
    // double precision, including subtraction before matrix multiplication.
    private const double MaximumMatrixCoefficient = 1_000_000_000_000;
    private const double MinimumW = 0.0000001;
    private const double ClipTolerance = 0.000001;

    public static bool TryCreateView(float[]? rowMajorMatrix, LivePosition? renderOrigin,
        int sourceWidth, int sourceHeight, ProjectionViewport viewport, ProjectionDepthRange depthRange,
        out ProjectionView? view, out string reason)
    {
        view = null;
        reason = "";
        if (rowMajorMatrix == null || rowMajorMatrix.Length != 16 ||
            rowMajorMatrix.Any(v => !float.IsFinite(v) || Math.Abs((double)v) > MaximumMatrixCoefficient))
            return Fail("Matrice absente, non finie ou hors limites.", out reason);
        for (int row = 0; row < 4; row++)
            if (Enumerable.Range(row * 4, 4).All(i => rowMajorMatrix[i] == 0))
                return Fail("La matrice possède une ligne entièrement nulle.", out reason);
        if (!ValidPosition(renderOrigin))
            return Fail("Origine de projection absente ou hors limites.", out reason);
        if (sourceWidth < 1 || sourceHeight < 1 || sourceWidth > MaximumOutputDimension || sourceHeight > MaximumOutputDimension ||
            !ValidViewport(viewport, sourceWidth, sourceHeight))
            return Fail("Viewport absent ou hors de l'image source.", out reason);
        if (depthRange != ProjectionDepthRange.MinusOneToOne && depthRange != ProjectionDepthRange.ZeroToOne)
            return Fail("Convention de profondeur inconnue.", out reason);
        view = new ProjectionView(rowMajorMatrix, renderOrigin!, sourceWidth, sourceHeight, viewport, depthRange);
        return true;
    }

    public static bool TryProjectPoint(ProjectionView? view, LivePosition? worldPosition, out ProjectionPoint point)
    {
        point = default;
        if (view == null || !ValidPosition(worldPosition)) return false;
        Vertex clip = Transform(view, worldPosition!.X, worldPosition.Y, worldPosition.Z);
        if (!Finite(clip) || clip.W < MinimumW) return false;
        for (int plane = 1; plane < 7; plane++)
            if (!Inside(clip, Distance(clip, plane, view.DepthRange), plane)) return false;
        return ToPixel(view, clip, out point);
    }

    public static bool TryBuildFrame(ProjectionView? view, LivePosition? localPosition, int localId,
        IReadOnlyList<LiveEntity>? entities, IReadOnlyDictionary<int, ProjectionEntityBounds>? bounds,
        out ProjectedFrame? frame, out string reason, string? playerContextId = null)
    {
        frame = null;
        reason = "";
        if (view == null || !ValidPosition(localPosition) || localId < 0 || entities == null || entities.Count > MaximumEntities)
            return Fail("Capture d'entités absente ou hors limites.", out reason);
        var markers = new List<ProjectedMarker>();
        var playerDirections = new List<ProjectedPlayerDirection>();
        var ids = new HashSet<int>();
        foreach (LiveEntity entity in entities)
        {
            if (entity == null || entity.EntityId < 0 || entity.EntityId == localId || !ids.Add(entity.EntityId) ||
                (entity.Kind != "player" && entity.Kind != "zombie") || !ValidPosition(entity.Position) || entity.Name?.Length > 128)
                return Fail("Une entité de la capture est invalide ou répétée.", out reason);
            ProjectionPoint? anchor = TryProjectPoint(view, entity.Position, out var projected) ? projected : null;
            ProjectionBox? rectangle = null;
            if (bounds != null && bounds.TryGetValue(entity.EntityId, out var inputBounds) &&
                inputBounds != null && inputBounds.EntityId == entity.EntityId &&
                TryProjectBounds(view, inputBounds, out var projectedBounds)) rectangle = projectedBounds;
            double dx = (double)entity.Position.X - localPosition!.X;
            double dy = (double)entity.Position.Y - localPosition.Y;
            double dz = (double)entity.Position.Z - localPosition.Z;
            double distance = Math.Sqrt(dx * dx + dy * dy + dz * dz);
            string name = new string((entity.Name ?? "").Where(c => !char.IsControl(c)).Take(64).ToArray());
            // Optional metadata cannot invalidate otherwise usable positions.
            // Missing/invalid values remain unknown; zero current HP is real.
            int? health = entity.Health is >= 0 ? entity.Health : null;
            int? maxHealth = entity.MaxHealth is > 0 ? entity.MaxHealth : null;
            // Include source-visible players too: Fill can crop them off the
            // selected output. Actual output visibility is decided by the renderer.
            if (entity.Kind == "player" && OffscreenProjection.TryCreateDirection(view, entity.Position, out var direction))
                playerDirections.Add(new(entity.EntityId, name, distance, entity.IdentityToken, direction, dy, health, maxHealth));
            if (anchor == null && rectangle == null) continue;
            markers.Add(new ProjectedMarker(entity.EntityId, entity.Kind, name, distance, anchor, rectangle, health, maxHealth,
                entity.IdentityToken, dy, entity.IsRunning, entity.IsCrouching, entity.IsJumping,
                entity.HeldItemTypeId, entity.Kind == "player" ?
                    PvpSenseMath.AngleToLocal(entity.BodyYawDegrees, entity.Position, localPosition) : null,
                entity.ZombieTargetsLocal));
        }
        frame = new ProjectedFrame(view, markers, playerDirections, playerContextId);
        return true;
    }

    public static bool TryProjectBounds(ProjectionView? view, ProjectionEntityBounds? bounds, out ProjectionBox box)
    {
        box = default;
        if (view == null || bounds == null || !ValidBounds(bounds)) return false;
        var vertices = new Vertex[8];
        for (int i = 0; i < vertices.Length; i++)
        {
            vertices[i] = Transform(view,
                (i & 1) == 0 ? bounds.MinX : bounds.MaxX,
                (i & 2) == 0 ? bounds.MinY : bounds.MaxY,
                (i & 4) == 0 ? bounds.MinZ : bounds.MaxZ);
            if (!Finite(vertices[i])) return false;
        }
        var faces = new List<List<Vertex>>
        {
            Face(vertices, 0, 1, 3, 2), Face(vertices, 4, 6, 7, 5),
            Face(vertices, 0, 4, 5, 1), Face(vertices, 2, 3, 7, 6),
            Face(vertices, 0, 2, 6, 4), Face(vertices, 1, 5, 7, 3)
        };
        // Clip the solid, including the new cap on each plane. Clipping just its
        // original edges would miss a box containing the camera/whole frustum.
        for (int plane = 0; plane < 7; plane++)
        {
            faces = ClipSolid(view, faces, plane);
            if (faces.Count == 0) return false;
        }
        double left = double.PositiveInfinity, top = double.PositiveInfinity;
        double right = double.NegativeInfinity, bottom = double.NegativeInfinity;
        foreach (var face in faces)
        foreach (var vertex in face)
        {
            if (!ToPixel(view, vertex, out var point)) return false;
            left = Math.Min(left, point.X); right = Math.Max(right, point.X);
            top = Math.Min(top, point.Y); bottom = Math.Max(bottom, point.Y);
        }
        if (!double.IsFinite(left) || !double.IsFinite(top) || !double.IsFinite(right) || !double.IsFinite(bottom) ||
            right - left <= 0.000001 || bottom - top <= 0.000001) return false;
        box = new ProjectionBox(left, top, right, bottom);
        return true;
    }

    private static bool ValidBounds(ProjectionEntityBounds b) => b.IsValidated && b.EntityId >= 0 &&
        ValidCoordinate(b.MinX) && ValidCoordinate(b.MinY) && ValidCoordinate(b.MinZ) &&
        ValidCoordinate(b.MaxX) && ValidCoordinate(b.MaxY) && ValidCoordinate(b.MaxZ) &&
        b.MinX < b.MaxX && b.MinY < b.MaxY && b.MinZ < b.MaxZ;

    private static bool ValidPosition(LivePosition? p) => p != null &&
        ValidCoordinate(p.X) && ValidCoordinate(p.Y) && ValidCoordinate(p.Z);
    private static bool ValidCoordinate(double value) => double.IsFinite(value) && Math.Abs(value) <= MaximumCoordinate;
    private static bool ValidViewport(ProjectionViewport r, int width, int height) =>
        double.IsFinite(r.X) && double.IsFinite(r.Y) && double.IsFinite(r.Width) && double.IsFinite(r.Height) &&
        r.X >= 0 && r.Y >= 0 && r.Width > 0 && r.Height > 0 && r.Right <= width && r.Bottom <= height;
    private static bool Fail(string value, out string reason) { reason = value; return false; }

    private readonly record struct Vertex(double X, double Y, double Z, double W, double PX, double PY, double PZ);

    private static Vertex Transform(ProjectionView view, double worldX, double worldY, double worldZ)
    {
        double x = worldX - view.OriginX, y = worldY - view.OriginY, z = worldZ - view.OriginZ;
        var m = view.Matrix;
        return new Vertex(m[0] * x + m[1] * y + m[2] * z + m[3],
            m[4] * x + m[5] * y + m[6] * z + m[7],
            m[8] * x + m[9] * y + m[10] * z + m[11],
            m[12] * x + m[13] * y + m[14] * z + m[15], x, y, z);
    }

    private static bool Finite(Vertex p) => double.IsFinite(p.X) && double.IsFinite(p.Y) &&
        double.IsFinite(p.Z) && double.IsFinite(p.W);

    private static bool ToPixel(ProjectionView view, Vertex clip, out ProjectionPoint point)
    {
        point = default;
        if (!Finite(clip) || clip.W <= 0) return false;
        double x = clip.X / clip.W, y = clip.Y / clip.W;
        if (!double.IsFinite(x) || !double.IsFinite(y)) return false;
        // Any excess here is solely the tolerance accepted by clipping. Never
        // call ToPixel on an unclipped off-screen point to pin it to an edge.
        x = Math.Clamp(x, -1, 1); y = Math.Clamp(y, -1, 1);
        var r = view.Viewport;
        point = new ProjectionPoint(r.X + (x + 1) * r.Width / 2, r.Y + (1 - y) * r.Height / 2);
        return true;
    }

    private static List<Vertex> Face(Vertex[] vertices, params int[] indexes) => indexes.Select(i => vertices[i]).ToList();

    // Planes: positive w; left; right; bottom; top; near; far. Reversed-Z still
    // uses its supplied clip interval: no attempt is made to guess its near side.
    private static double Distance(Vertex p, int plane, ProjectionDepthRange depth) => plane switch
    {
        0 => p.W - MinimumW,
        1 => p.X + p.W,
        2 => p.W - p.X,
        3 => p.Y + p.W,
        4 => p.W - p.Y,
        5 => depth == ProjectionDepthRange.MinusOneToOne ? p.Z + p.W : p.Z,
        6 => p.W - p.Z,
        _ => double.NegativeInfinity
    };

    private static bool Inside(Vertex vertex, double distance, int plane) =>
        distance >= (plane == 0 ? 0 : -ClipTolerance * Math.Abs(vertex.W));

    private static List<List<Vertex>> ClipSolid(ProjectionView view, List<List<Vertex>> faces, int plane)
    {
        var result = new List<List<Vertex>>();
        var cap = new List<Vertex>();
        foreach (var face in faces)
        {
            var output = new List<Vertex>();
            Vertex previous = face[^1];
            double previousDistance = Distance(previous, plane, view.DepthRange);
            bool previousInside = Inside(previous, previousDistance, plane);
            foreach (var current in face)
            {
                double currentDistance = Distance(current, plane, view.DepthRange);
                bool currentInside = Inside(current, currentDistance, plane);
                if (currentInside != previousInside)
                {
                    double denominator = previousDistance - currentDistance;
                    if (!double.IsFinite(denominator) || denominator == 0) return new List<List<Vertex>>();
                    Vertex intersection = Lerp(previous, current, Math.Clamp(previousDistance / denominator, 0, 1));
                    if (!Finite(intersection)) return new List<List<Vertex>>();
                    AddDistinct(output, intersection);
                    AddDistinct(cap, intersection);
                }
                if (currentInside) AddDistinct(output, current);
                previous = current; previousDistance = currentDistance; previousInside = currentInside;
            }
            if (output.Count >= 3) result.Add(output);
        }
        if (cap.Count >= 3)
        {
            // Sort intersections in their original (pre-projection) plane. The
            // largest normal component identifies a nondegenerate 2-D basis.
            var m = view.Matrix;
            double nx = Normal(m, 0, plane, view.DepthRange);
            double ny = Normal(m, 1, plane, view.DepthRange);
            double nz = Normal(m, 2, plane, view.DepthRange);
            int drop = Math.Abs(nx) >= Math.Abs(ny) && Math.Abs(nx) >= Math.Abs(nz) ? 0 :
                Math.Abs(ny) >= Math.Abs(nz) ? 1 : 2;
            double centerU = cap.Average(v => AxisU(v, drop)), centerV = cap.Average(v => AxisV(v, drop));
            cap.Sort((a, b) => Math.Atan2(AxisV(a, drop) - centerV, AxisU(a, drop) - centerU)
                .CompareTo(Math.Atan2(AxisV(b, drop) - centerV, AxisU(b, drop) - centerU)));
            result.Add(cap);
        }
        return result;
    }

    private static double Normal(double[] m, int axis, int plane, ProjectionDepthRange depth) => plane switch
    {
        0 => m[12 + axis],
        1 => m[axis] + m[12 + axis],
        2 => m[12 + axis] - m[axis],
        3 => m[4 + axis] + m[12 + axis],
        4 => m[12 + axis] - m[4 + axis],
        5 => depth == ProjectionDepthRange.MinusOneToOne ? m[8 + axis] + m[12 + axis] : m[8 + axis],
        6 => m[12 + axis] - m[8 + axis],
        _ => 0
    };

    private static double AxisU(Vertex v, int drop) => drop == 0 ? v.PY : v.PX;
    private static double AxisV(Vertex v, int drop) => drop == 2 ? v.PY : v.PZ;
    private static Vertex Lerp(Vertex a, Vertex b, double t) => new(
        a.X + (b.X - a.X) * t, a.Y + (b.Y - a.Y) * t, a.Z + (b.Z - a.Z) * t,
        a.W + (b.W - a.W) * t, a.PX + (b.PX - a.PX) * t, a.PY + (b.PY - a.PY) * t, a.PZ + (b.PZ - a.PZ) * t);
    private static void AddDistinct(List<Vertex> vertices, Vertex point)
    {
        if (!vertices.Any(v => Math.Abs(v.PX - point.PX) < 0.0000001 &&
            Math.Abs(v.PY - point.PY) < 0.0000001 && Math.Abs(v.PZ - point.PZ) < 0.0000001)) vertices.Add(point);
    }
}
