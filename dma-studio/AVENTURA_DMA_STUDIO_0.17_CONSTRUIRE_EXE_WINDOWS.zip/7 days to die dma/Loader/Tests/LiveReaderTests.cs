using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using SevenDaysEsp;

// Exercises the production reader against a deterministic, fully traversable
// Mono object graph. No reader rules or Capture implementation are copied here.
// These objects are test data, not measured addresses/offsets for a game build.
internal static class LiveReaderTests
{
    public static Task HealthUsesEffectiveStatValuesAndCurrentMetadata()
    {
        var f = new Fixture(); f.EnableHealth();
        f.SetHealth(f.PlayerHealth, 55.9f, 100, 25);
        f.SetHealth(f.ZombieHealth, 42.9f, 80, -20);
        var reader = f.Reader(); var result = reader.Capture(); AssertValid(result, reader, f);
        Check(result.Entities[0].Health == 55 && result.Entities[0].MaxHealth == 125,
            "The player effective health ceiling or integer truncation did not follow the game fields.");
        Check(result.Entities[1].Health == 42 && result.Entities[1].MaxHealth == 60,
            "The zombie health did not use metadata offsets and the negative maximum modifier.");
        Check(result.Diagnostics.HealthAvailable == 2 && result.Diagnostics.HealthUnavailable == 0,
            "Health diagnostics did not describe the published entities.");
        f.SetHealth(f.ZombieHealth, 999, 80, -20);
        result = reader.Capture(); Check(result.Entities[1].Health == 60, "Over-limit raw health was not clamped as Stat.Value does.");
        f.SetHealth(f.ZombieHealth, -25, 80, -20);
        result = reader.Capture(); Check(result.Entities[1].Health == 0, "Negative raw health was not clamped to zero.");
        return Task.CompletedTask;
    }

    public static Task UnavailableHealthPreservesEntitiesAndCamera()
    {
        foreach (Action<Fixture> corrupt in new Action<Fixture>[]
        {
            f => f.Metadata.Classes.RemoveAll(c => c.Name == "EntityStats"),
            f => f.Metadata.Classes.Find(c => c.Name == "EntityStats")!.Fields.Find(x => x.Name == "Health")!.Type = "System.Object",
            f => f.Memory.U64(f.Zombie + 0x58, 0),
            f => f.Memory.U64(f.ZombieStats + Fixture.StatsOwnerOffset, f.OtherPlayer),
            f => f.Memory.U64(f.ZombieHealth + Fixture.StatOwnerOffset, f.Local),
            f => f.Memory.U64(f.ZombieStats + Fixture.StatsHealthOffset, f.OtherPlayer),
            f => f.Memory.U64(f.ZombieHealthTable + 0x10, f.Domain + 16),
            f => f.SetHealth(f.ZombieHealth, float.NaN, 100, 0),
            f => f.SetHealth(f.ZombieHealth, 20, float.PositiveInfinity, 0),
            f => f.SetHealth(f.ZombieHealth, 20, 100, float.NaN),
            f => f.SetHealth(f.ZombieHealth, 20, 100, -100),
            f => f.SetHealth(f.ZombieHealth, 20, 1000000000, 1000000000)
        })
        {
            var f = new Fixture(); f.EnableHealth(); corrupt(f);
            var reader = f.Reader(); var camera = CameraFrame(); reader.CameraCapture = (_, _, _) => camera;
            var result = reader.Capture(); AssertValid(result, reader, f);
            Check(result.Entities[1].Health == null && result.Entities[1].MaxHealth == null,
                "Unverified health was published or a default value was invented.");
            Check(ReferenceEquals(result.Camera, camera), "Unavailable health prevented camera acquisition.");
        }
        return Task.CompletedTask;
    }

    public static Task ChangingHealthGraphDiscardsOnlyOptionalValues()
    {
        var f = new Fixture(); f.EnableHealth(); var reader = f.Reader();
        int reads = 0;
        f.Memory.BeforeRead = (address, count) =>
        {
            if (address == f.ZombieHealth && count == Fixture.StatSize && ++reads == 2)
                f.SetHealth(f.ZombieHealth, 7, 100, 0);
        };
        var result = reader.Capture(); AssertValid(result, reader, f);
        Check(result.Entities[1].Health == null && result.Entities[1].MaxHealth == null,
            "A changing health value was published as a coherent pair.");
        f.Memory.BeforeRead = null;
        result = reader.Capture(); Check(result.Entities[1].Health == 7, "Health did not recover on the next coherent capture.");
        int entityReads = 0;
        f.Memory.BeforeRead = (address, count) =>
        {
            if (address == f.Zombie && count == Fixture.EntitySize && ++entityReads == 2)
                f.Memory.U64(f.Zombie + 0x58, f.PlayerStats);
        };
        result = reader.Capture(); AssertValid(result, reader, f);
        Check(result.Entities[1].Health == null, "A replaced entityStats reference kept values from the previous object.");
        return Task.CompletedTask;
    }

    public static Task ZombieNamesUseCurrentNameThenValidatedClassRegistry()
    {
        var f = new Fixture(); f.EnableNames();
        // The fixture also uses a negative class key, as EntityClass.FromString
        // uses signed String.GetHashCode, independently of positive entity IDs.
        // The game's default can be a non-null String.Empty. A pointer alone
        // must not prevent fallback to the concrete zombie class name.
        f.Memory.U64(f.Zombie + 0x50, f.ManagedString(""));
        var reader = f.Reader(); var result = reader.Capture();
        AssertValid(result, reader, f, expectedZombieName: "zombieArlene");
        Check(result.Entities[1].NameSource == "entityClassName" && result.Diagnostics.ClassNames == 1,
            "A technical zombie class name was not distinguished from an entity's current name.");
        f.Memory.U64(f.Zombie + 0x50, f.ManagedString("Arlene personnalisée"));
        result = reader.Capture(); AssertValid(result, reader, f, expectedZombieName: "Arlene personnalisée");
        Check(result.Entities[1].NameSource == "entityName" && result.Diagnostics.EntityNames == 1,
            "The current entity name was replaced by a class fallback.");
        f.Memory.U64(f.Zombie + 0x50, f.ManagedString("bad\nname"));
        result = reader.Capture(); AssertValid(result, reader, f, expectedZombieName: "zombieArlene");
        Check(result.Entities[1].NameSource == "entityClassName", "An invalid entity name prevented a valid class fallback.");
        return Task.CompletedTask;
    }

    public static Task InvalidClassRegistryNeverRemovesEntities()
    {
        foreach (Action<Fixture> corrupt in new Action<Fixture>[]
        {
            f => f.Metadata.Classes.RemoveAll(c => c.Name == "EntityClass"),
            f => f.Memory.I32(f.RegistryDictionary + 0x18, 8193),
            f => f.Memory.U64(f.RegistryEntryValue, f.Local),
            f => f.Memory.U64(f.RegistryClassObject + 0x18, f.ManagedString(new string('x', 129))),
            f => f.Memory.U64(f.RegistryClassObject + 0x18, f.ManagedString("bad\rname")),
            f => f.Memory.U64(f.RegistryClassObject + 0x18, 8),
            f => f.Memory.I32(f.RegistryArrayClass + 0x90, 4)
        })
        {
            var f = new Fixture(); f.EnableNames(); corrupt(f); var reader = f.Reader();
            var result = reader.Capture(); AssertValid(result, reader, f);
            Check(result.Entities[1].NameSource == "fallback", "An unverified class name was displayed.");
        }
        var moving = new Fixture(); moving.EnableNames(); var active = moving.Reader();
        int fullDictionaryReads = 0;
        moving.Memory.BeforeRead = (address, count) =>
        {
            if (address == moving.RegistryDictionary && count == 0x28 && ++fullDictionaryReads == 3)
                moving.Memory.I32(moving.RegistryDictionary + 0x1C, 9);
        };
        var changed = active.Capture(); AssertValid(changed, active, moving);
        Check(changed.Entities[1].NameSource == "fallback", "Names survived a late dictionary version change.");
        return Task.CompletedTask;
    }

    public static Task OptionalDetailBudgetsLeaveCameraAndWorldAvailable()
    {
        var f = new Fixture(); f.EnableHealth(); var reader = f.Reader(); bool delayed = false;
        var camera = CameraFrame(); reader.CameraCapture = (_, _, _) => camera;
        f.Memory.BeforeRead = (address, count) =>
        {
            if (address == f.PlayerHealth && !delayed) { delayed = true; System.Threading.Thread.Sleep(60); }
        };
        var result = reader.Capture(); AssertValid(result, reader, f);
        Check(delayed && result.Diagnostics.OptionalDetailsBudgetReached, "The delayed optional read did not reach its own budget.");
        Check(result.Entities.TrueForAll(e => e.Health == null) && ReferenceEquals(result.Camera, camera),
            "An optional budget failure removed a valid world/camera or invented health.");
        Check(result.Diagnostics.OptionalDetailsReadCalls <= 512 && result.Diagnostics.OptionalDetailsReadBytes <= 262144,
            "Optional hardware work exceeded its explicit call/byte limits.");
        var many = new Fixture(); many.EnableNames(4000); var manyReader = many.Reader();
        int maxRead = 0;
        many.Memory.BeforeRead = (_, count) => maxRead = Math.Max(maxRead, count);
        var large = manyReader.Capture(); AssertValid(large, manyReader, many, expectedZombieName: "zombieArlene");
        Check(maxRead <= 65536 && large.Diagnostics.OptionalDetailsReadBytes > 65536,
            "A valid registry larger than one read was not split into bounded chunks.");
        return Task.CompletedTask;
    }

    public static Task CollisionBoundsUseCurrentMetadata()
    {
        var fixture = new Fixture();
        fixture.MoveOrigin(4096, 0, -2048);
        var reader = fixture.Reader();
        LiveEntitySnapshot snapshot = reader.Capture();
        AssertValid(snapshot, reader, fixture);
        LiveBounds player = snapshot.Entities[0].Bounds ?? throw new InvalidOperationException("Player collision bounds were not captured.");
        LiveBounds zombie = snapshot.Entities[1].Bounds ?? throw new InvalidOperationException("Zombie collision bounds were not captured.");
        Check(player.Center.X == 110 && player.Center.Y == 31 && player.Center.Z == -20 &&
            player.Extents.X == 0.4f && player.Extents.Y == 1 && player.Extents.Z == 0.4f,
            "Collision bounds were not read from the current field metadata.");
        Check(zombie.Center.X == 90 && zombie.Center.Y == 26 && zombie.Center.Z == -15,
            "Collision bounds must remain in game-world coordinates.");
        Check(snapshot.RenderOrigin.X == 4096 && snapshot.RenderOrigin.Y == 0 && snapshot.RenderOrigin.Z == -2048,
            "The capture did not publish its validated floating origin.");
        Check(snapshot.Camera == null, "A reader without a camera callback invented a camera frame.");
        return Task.CompletedTask;
    }

    public static Task UnavailableBoundsPreserveRadar()
    {
        foreach (Action<Fixture> change in new Action<Fixture>[]
        {
            f => f.Metadata.Classes.Find(c => c.Name == "Entity")!.Fields.RemoveAll(p => p.Name == "boundingBox"),
            f => f.BoundsField.Type = "UnityEngine.Vector3",
            f => f.BoundsField.TypeCode = "0x08",
            f => f.BoundsField.IsStatic = true,
            f => f.BoundsField.IsLiteral = true,
            f => f.BoundsField.Issue = "Synthetic unvalidated field",
            f => f.BoundsField.Offset = Fixture.EntitySize,
            f => f.BoundsField.Offset = Fixture.BoundsOffset + 1
        })
        {
            var fixture = new Fixture();
            change(fixture);
            var reader = fixture.Reader();
            LiveEntitySnapshot snapshot = reader.Capture();
            AssertValid(snapshot, reader, fixture);
            Check(snapshot.Entities[0].Bounds == null && snapshot.Entities[1].Bounds == null,
                "Missing or unvalidated optional metadata must not produce collision bounds.");
        }
        foreach (Action<Fixture> change in new Action<Fixture>[]
        {
            f => f.Memory.Vector(f.Zombie + Fixture.BoundsOffset, float.NaN, 26, -15),
            f => f.Memory.Vector(f.Zombie + Fixture.BoundsOffset, float.PositiveInfinity, 26, -15),
            f => f.Memory.Vector(f.Zombie + Fixture.BoundsOffset, 10000001, 26, -15),
            f => f.Memory.Vector(f.Zombie + Fixture.BoundsOffset + 12, 0.4f, float.NaN, 0.4f),
            f => f.Memory.Vector(f.Zombie + Fixture.BoundsOffset + 12, 0.4f, float.NegativeInfinity, 0.4f),
            f => f.Memory.Vector(f.Zombie + Fixture.BoundsOffset + 12, 0.4f, -1, 0.4f),
            f => f.Memory.Vector(f.Zombie + Fixture.BoundsOffset + 12, 0.4f, 0, 0.4f),
            f => f.Memory.Vector(f.Zombie + Fixture.BoundsOffset + 12, 0.4f, 1000000, 0.4f)
        })
        {
            var fixture = new Fixture();
            change(fixture);
            var reader = fixture.Reader();
            LiveEntitySnapshot snapshot = reader.Capture();
            AssertValid(snapshot, reader, fixture);
            Check(snapshot.Entities[0].Bounds != null && snapshot.Entities[1].Bounds == null,
                "A malformed volume must only remove that entity's optional bounds.");
        }
        return Task.CompletedTask;
    }

    public static Task CameraCaptureUsesCurrentGraph()
    {
        var fixture = new Fixture();
        fixture.MoveOrigin(256, 0, -512);
        var reader = fixture.Reader();
        int playerReads = 0, zombieReads = 0, cameraCalls = 0;
        fixture.Memory.BeforeRead = (address, count) =>
        {
            if (address == fixture.OtherPlayer) playerReads++;
            if (address == fixture.Zombie) zombieReads++;
        };
        LiveCameraFrame frame = CameraFrame();
        reader.CameraCapture = (local, domain, origin) =>
        {
            cameraCalls++;
            Check(local == fixture.Local && domain == fixture.Domain, "Camera callback received the wrong graph identity.");
            Check(playerReads >= 2 && zombieReads >= 2, "Camera callback ran before complete entity reads.");
            Check(origin.X == 256 && origin.Y == 0 && origin.Z == -512, "Camera callback did not receive the captured origin.");
            origin.X = -9999; // The callback must not own the published origin value.
            return frame;
        };
        LiveEntitySnapshot snapshot = reader.Capture();
        AssertValid(snapshot, reader, fixture);
        Check(cameraCalls == 1 && ReferenceEquals(snapshot.Camera, frame), "The successful capture lost its camera frame.");
        Check(snapshot.RenderOrigin.X == 256 && snapshot.RenderOrigin.Z == -512,
            "Callback mutation contaminated the validated render origin.");
        Check(frame.Format == "SevenDaysEsp.CameraFrame/1", "Camera frame format default changed.");
        return Task.CompletedTask;
    }

    public static Task CameraFailurePreservesRadar()
    {
        var fixture = new Fixture();
        var reader = fixture.Reader();
        reader.CameraCapture = (local, domain, origin) => CameraFrame();
        Check(reader.Capture().Camera != null, "The initial camera fixture was not published.");
        foreach (Exception failure in new Exception[] { new IOException("Synthetic camera read failure"), new InvalidOperationException("Synthetic unsupported camera") })
        {
            reader.CameraCapture = (local, domain, origin) => throw failure;
            LiveEntitySnapshot snapshot = reader.Capture();
            AssertValid(snapshot, reader, fixture);
            Check(snapshot.Camera == null && snapshot.RenderOrigin != null && snapshot.Warnings.Count != 0,
                "Camera failure must clear the camera while preserving a validated radar/origin.");
        }
        reader.CameraCapture = (local, domain, origin) => null!;
        LiveEntitySnapshot absent = reader.Capture();
        AssertValid(absent, reader, fixture);
        Check(absent.Camera == null, "A camera-less sample retained an earlier camera frame.");
        reader.CameraCapture = null!;
        LiveEntitySnapshot disabled = reader.Capture();
        AssertValid(disabled, reader, fixture);
        Check(disabled.Camera == null, "Disabling acquisition retained an earlier camera frame.");
        return Task.CompletedTask;
    }

    public static Task RejectedGraphClearsCameraAndOrigin()
    {
        foreach (Action<Fixture> change in new Action<Fixture>[]
        {
            f => f.MoveOrigin(256, 0, 0),
            f => f.Memory.U64(f.Manager + Fixture.ManagerWorldOffset, 0),
            f => f.SetFlags(1, 0)
        })
        {
            var fixture = new Fixture();
            var reader = fixture.Reader();
            bool called = false;
            reader.CameraCapture = (local, domain, origin) =>
            {
                called = true;
                change(fixture);
                return CameraFrame();
            };
            LiveEntitySnapshot snapshot = reader.Capture();
            Check(called, "The late mutation did not execute through the real camera hook.");
            AssertNoPublishedPositions(snapshot, reader, "graph changed after camera acquisition");
        }
        var confirming = new Fixture();
        confirming.SetFlags(1, 0);
        var pendingReader = confirming.Reader();
        pendingReader.CameraCapture = (local, domain, origin) => CameraFrame();
        AssertPendingConfirmation(pendingReader.Capture(), pendingReader, "camera while first world confirmation is pending", 1);
        AssertPendingConfirmation(pendingReader.Capture(), pendingReader, "camera while second world confirmation is pending", 2);
        Check(pendingReader.Capture().Camera != null, "Confirmed graph did not release the camera frame.");
        return Task.CompletedTask;
    }

    private static LiveCameraFrame CameraFrame() => new()
    {
        ProfileId = "synthetic-capture-contract", ViewProjection = new float[]
        { 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 },
        SourceWidth = 1920, SourceHeight = 1080, ViewportWidth = 1920, ViewportHeight = 1080,
        ClipDepth = "MinusOneToOne", Sequence = 1, CameraEpoch = 1, ReadDurationMs = 1
    };

    public static Task ValidGraph()
    {
        var fixture = new Fixture();
        var reader = fixture.Reader();
        LiveEntitySnapshot snapshot = reader.Capture();
        AssertValid(snapshot, reader, fixture);
        Check(snapshot.Diagnostics.Stage == "TERMINE", "Successful graph did not finish its diagnostic.");
        Check(snapshot.Diagnostics.GameHasStartedRaw == 1 && snapshot.Diagnostics.WorldCreatedRaw == 1,
            "Initial flags were not recorded.");
        Check(snapshot.Diagnostics.GameHasStartedAfterRaw == 1 && snapshot.Diagnostics.WorldCreatedAfterRaw == 1,
            "Final flags were not recorded.");
        Check(snapshot.Diagnostics.WorldValidated && snapshot.Diagnostics.LocalValidated && snapshot.Diagnostics.LocalActive,
            "Valid world/local objects were not diagnosed.");
        Check(snapshot.Diagnostics.LocalReferencesMatch == true && snapshot.Diagnostics.LocalIdMatches == true,
            "Matching local references or ID were not diagnosed.");
        Check(snapshot.Diagnostics.EntityCount == 3 && snapshot.Diagnostics.CollectionValidated && snapshot.Diagnostics.GraphValidated,
            "The full collection/stability path was not validated.");
        Check(snapshot.Diagnostics.ReadinessPolicy == "INDICATEURS_ET_GRAPHE" && snapshot.Diagnostics.StableGraphCaptures == 0 &&
            snapshot.Diagnostics.RequiredStableGraphCaptures == 0, "The true/true path must remain immediately available.");
        return Task.CompletedTask;
    }

    public static Task GameNotStartedDiagnosesOnly()
    {
        foreach (var flags in new (byte started, byte created)[] { (0, 1), (0, 0) })
        {
            var fixture = new Fixture();
            fixture.SetFlags(flags.started, flags.created);
            var reader = fixture.Reader();
            for (int capture = 0; capture < 4; capture++)
            {
                LiveEntitySnapshot snapshot = reader.Capture();
                AssertNoPublishedPositions(snapshot, reader, $"flags {flags.started}/{flags.created}, capture {capture + 1}");
                Check(snapshot.Diagnostics.Code == "PARTIE_NON_DEMARREE" && snapshot.Diagnostics.StableGraphCaptures == 0,
                    "A game not started must reset confirmation and identify its blocking cause.");
                Check(snapshot.Diagnostics.Stage == "INDICATEURS_PARTIE", "A game not started reported a different blocking stage.");
                Check(snapshot.Diagnostics.GameHasStartedRaw == flags.started && snapshot.Diagnostics.WorldCreatedRaw == flags.created,
                    "A false first flag prevented recording the second flag.");
                Check(snapshot.Diagnostics.GameHasStartedAfterRaw == flags.started && snapshot.Diagnostics.WorldCreatedAfterRaw == flags.created,
                    "Stable false flags were not re-read.");
                Check(snapshot.Diagnostics.GraphValidated && snapshot.Diagnostics.CollectionValidated && snapshot.Diagnostics.EntityCount == 3,
                    "False flags prevented the diagnostic traversal of an otherwise valid graph.");
                Check(snapshot.Diagnostics.CandidatePlayersCount == 1 && snapshot.Diagnostics.CandidateZombiesCount == 1,
                    "Diagnostic candidates do not reflect the independently validated graph.");
            }
        }
        return Task.CompletedTask;
    }

    public static Task WorldCreatedZeroNeedsRepeatedValidGraph()
    {
        var fixture = new Fixture();
        fixture.SetFlags(1, 0);
        var reader = fixture.Reader();
        AssertPendingConfirmation(reader.Capture(), reader, "first coherent capture", 1);
        AssertPendingConfirmation(reader.Capture(), reader, "second coherent capture", 2);
        LiveEntitySnapshot third = reader.Capture();
        AssertValid(third, reader, fixture);
        Check(third.Diagnostics.ReadinessPolicy == "PARTIE_DEMARREE_ET_GRAPHE_CONFIRME" &&
            third.Diagnostics.StableGraphCaptures == 3 && third.Diagnostics.RequiredStableGraphCaptures == 3,
            "The third coherent 1/0 capture must identify the confirmed-graph policy.");
        LiveEntitySnapshot fourth = reader.Capture();
        AssertValid(fourth, reader, fixture);
        Check(fourth.Diagnostics.StableGraphCaptures == 3, "Confirmation count must remain bounded after readiness is reached.");
        return Task.CompletedTask;
    }

    public static Task RejectedCaptureResetsConfirmation()
    {
        var fixture = new Fixture();
        fixture.SetFlags(1, 0);
        var reader = fixture.Reader();
        AssertPendingConfirmation(reader.Capture(), reader, "first confirmation before missing world");
        AssertPendingConfirmation(reader.Capture(), reader, "second confirmation before missing world");
        fixture.Memory.U64(fixture.Manager + Fixture.ManagerWorldOffset, 0);
        AssertNoPublishedPositions(reader.Capture(), reader, "missing world interrupts confirmation");
        fixture.Memory.U64(fixture.Manager + Fixture.ManagerWorldOffset, fixture.World);
        AssertPendingConfirmation(reader.Capture(), reader, "first confirmation after restoring world");
        AssertPendingConfirmation(reader.Capture(), reader, "second confirmation after restoring world");
        AssertValid(reader.Capture(), reader, fixture);

        fixture.SetFlags(0, 0);
        AssertNoPublishedPositions(reader.Capture(), reader, "game stopped after confirmed display");
        fixture.SetFlags(1, 0);
        AssertPendingConfirmation(reader.Capture(), reader, "first confirmation after game restarts");
        AssertPendingConfirmation(reader.Capture(), reader, "second confirmation after game restarts");
        AssertValid(reader.Capture(), reader, fixture);
        return Task.CompletedTask;
    }

    public static Task IdentityChangesResetConfirmation()
    {
        foreach (var mutation in new (string name, Action<Fixture> apply, int localId)[]
        {
            ("local ID at the same addresses", f => f.SetLocalId(21), 21),
            ("world object", f => f.ReplaceWorld(), 11),
            ("local player object", f => f.ReplaceLocalPlayer(), 11)
        })
        {
            var fixture = new Fixture();
            fixture.SetFlags(1, 0);
            var reader = fixture.Reader();
            AssertPendingConfirmation(reader.Capture(), reader, "first confirmation before replacing " + mutation.name);
            AssertPendingConfirmation(reader.Capture(), reader, "second confirmation before replacing " + mutation.name);
            mutation.apply(fixture);
            AssertPendingConfirmation(reader.Capture(), reader, "changed " + mutation.name + " begins its own confirmation");
            AssertPendingConfirmation(reader.Capture(), reader, "changed " + mutation.name + " has only two confirmations");
            AssertValid(reader.Capture(), reader, fixture, mutation.localId);
        }
        return Task.CompletedTask;
    }

    public static async Task ConfirmationRequiresRecentCaptures()
    {
        var fixture = new Fixture();
        fixture.SetFlags(1, 0);
        var reader = fixture.Reader();
        AssertPendingConfirmation(reader.Capture(), reader, "first confirmation before expiry");
        AssertPendingConfirmation(reader.Capture(), reader, "second confirmation before expiry");
        await Task.Delay(5100);
        AssertPendingConfirmation(reader.Capture(), reader, "expired confirmation must restart");
        AssertPendingConfirmation(reader.Capture(), reader, "only two recent captures since expiry");
        AssertValid(reader.Capture(), reader, fixture);
    }

    public static Task CollectionAndMovementDoNotResetConfirmation()
    {
        var fixture = new Fixture();
        fixture.SetFlags(1, 0);
        var reader = fixture.Reader();
        AssertPendingConfirmation(reader.Capture(), reader, "first confirmation before movement", 1);
        fixture.ReplaceCollection();
        fixture.MoveOrigin(200, 0, 200);
        fixture.Memory.Vector(fixture.Local + 0x1C, 101, 25, -20);
        AssertPendingConfirmation(reader.Capture(), reader, "new collection and movement retain the same scene identity", 2);
        fixture.Memory.Vector(fixture.Local + 0x1C, 100, 25, -20);
        AssertValid(reader.Capture(), reader, fixture);
        return Task.CompletedTask;
    }

    public static Task TrueWorldFlagDoesNotReuseFallbackConfirmation()
    {
        var fixture = new Fixture();
        fixture.SetFlags(1, 0);
        var reader = fixture.Reader();
        AssertPendingConfirmation(reader.Capture(), reader, "first fallback confirmation before normal path");
        AssertPendingConfirmation(reader.Capture(), reader, "second fallback confirmation before normal path");
        fixture.SetFlags(1, 1);
        AssertValid(reader.Capture(), reader, fixture);
        fixture.SetFlags(1, 0);
        AssertPendingConfirmation(reader.Capture(), reader, "normal path must not retain two fallback confirmations");
        AssertPendingConfirmation(reader.Capture(), reader, "only two fallback confirmations after normal path");
        AssertValid(reader.Capture(), reader, fixture);
        return Task.CompletedTask;
    }

    public static Task InvalidFlagsReject()
    {
        foreach (var flags in new (byte started, byte created)[] { (2, 1), (1, 255), (0, 2), (255, 0) })
        {
            var fixture = new Fixture();
            fixture.SetFlags(flags.started, flags.created);
            var reader = fixture.Reader();
            LiveEntitySnapshot snapshot = reader.Capture();
            AssertNoPublishedPositions(snapshot, reader, $"invalid flags {flags.started}/{flags.created}");
            Check(snapshot.Diagnostics.Code == "INDICATEUR_INVALIDE", "A non-boolean value was not distinguished from false.");
            Check(snapshot.Diagnostics.GameHasStartedRaw == flags.started && snapshot.Diagnostics.WorldCreatedRaw == flags.created,
                "Both raw flags must be visible even when one is invalid.");
            Check(!snapshot.Diagnostics.GraphValidated, "A graph with an invalid game-state flag was marked validated.");
        }
        return Task.CompletedTask;
    }

    public static Task InvalidReferencesReject()
    {
        RejectMutation("null world", f => f.Memory.U64(f.Manager + Fixture.ManagerWorldOffset, 0),
            s => Check(s.Diagnostics.Code == "MONDE_ABSENT" && s.Diagnostics.WorldReference == "NULLE", "Null world was not identified."));
        RejectMutation("null manager local", f => f.Memory.U64(f.Manager + Fixture.ManagerLocalOffset, 0),
            s => Check(s.Diagnostics.Code == "JOUEUR_LOCAL_ABSENT" && s.Diagnostics.ManagerLocalReference == "NULLE", "Null manager local was not identified."));
        RejectMutation("null world local", f => f.Memory.U64(f.World + Fixture.WorldLocalOffset, 0),
            s => Check(s.Diagnostics.WorldLocalReference == "NULLE", "Null world local was not recorded."));
        RejectMutation("different world local", f => f.Memory.U64(f.World + Fixture.WorldLocalOffset, f.OtherPlayer),
            s => Check(s.Diagnostics.Code == "JOUEUR_LOCAL_DIFFERENT" && s.Diagnostics.LocalReferencesMatch == false,
                "Mismatched local references were not identified."));
        RejectMutation("world pointer out of range", f => f.Memory.U64(f.Manager + Fixture.ManagerWorldOffset, 7),
            s => Check(s.Diagnostics.WorldReference == "HORS_PLAGE", "Out-of-range world pointer was not identified."));
        RejectMutation("local belongs to another world", f => f.Memory.U64(f.Local + Fixture.EntityWorldOffset, f.Manager));
        RejectMutation("local ID differs from manager", f => f.Memory.I32(f.Manager + Fixture.ManagerIdOffset, 987),
            s => Check(s.Diagnostics.LocalIdMatches == false, "Mismatched local ID was not identified."));
        RejectMutation("world has unexpected class", f => f.Memory.U64(f.World, f.LocalVtable));
        RejectMutation("local has unexpected Mono domain", f => f.Memory.U64(f.LocalVtable + 0x10, f.Memory.Allocate(32)));
        return Task.CompletedTask;
    }

    public static Task InactiveLocalReject()
    {
        foreach (ulong offset in new ulong[] { 0x28, 0x29, 0x2A, 0x2B })
        {
            RejectMutation("removed local at field " + offset, f => f.Memory.Byte(f.Local + offset, 1),
                s => Check(!s.Diagnostics.LocalActive, "A dead/despawned/unloading local player was diagnosed as active."));
        }
        RejectMutation("player is not local-player class", f => f.Memory.U64(f.Local, f.OtherPlayerVtable));
        return Task.CompletedTask;
    }

    public static Task InvalidCollectionReject()
    {
        RejectMutation("entity count above capture bound", f => f.Memory.I32(f.List + 0x18, 4097));
        RejectMutation("entity count above capacity", f => f.Memory.U32(f.Array + 0x18, 2));
        RejectMutation("array declares different element class", f => f.Memory.U64(f.ArrayClass, f.Classes["EntityPlayer"]));
        return Task.CompletedTask;
    }

    public static Task StateResetAndRecovery()
    {
        var fixture = new Fixture();
        var reader = fixture.Reader();
        LiveEntitySnapshot successful = reader.Capture();
        AssertValid(successful, reader, fixture);

        fixture.SetFlags(0, 1);
        AssertNoPublishedPositions(reader.Capture(), reader, "valid capture followed by false flag");
        Check(successful.Entities.Count == 2 && successful.LocalPosition != null,
            "A new capture mutated an already-returned snapshot.");

        fixture.SetFlags(1, 1);
        AssertValid(reader.Capture(), reader, fixture);
        fixture.Memory.U64(fixture.Manager + Fixture.ManagerWorldOffset, 0);
        AssertNoPublishedPositions(reader.Capture(), reader, "valid capture followed by null world");

        fixture.Memory.U64(fixture.Manager + Fixture.ManagerWorldOffset, fixture.World);
        AssertValid(reader.Capture(), reader, fixture);
        return Task.CompletedTask;
    }

    public static Task FlagsChangingDuringCaptureReject()
    {
        foreach (var flags in new (byte initialStarted, byte initialCreated, byte finalStarted, byte finalCreated)[]
        {
            (1, 1, 1, 0), (1, 0, 1, 1), (1, 1, 1, 2), (1, 0, 0, 0)
        })
        {
            var fixture = new Fixture();
            fixture.SetFlags(flags.initialStarted, flags.initialCreated);
            var reader = fixture.Reader();
            int managerReads = 0;
            fixture.Memory.BeforeRead = (address, count) =>
            {
                if (address == fixture.Manager && count == Fixture.ManagerSize && ++managerReads == 2)
                    fixture.SetFlags(flags.finalStarted, flags.finalCreated);
            };
            LiveEntitySnapshot snapshot = reader.Capture();
            AssertNoPublishedPositions(snapshot, reader, "game flags changed during capture");
            Check(managerReads >= 2, "The stability read of the manager was not exercised.");
            Check(snapshot.Diagnostics.GameHasStartedRaw == flags.initialStarted && snapshot.Diagnostics.WorldCreatedRaw == flags.initialCreated,
                "Final values overwrote the initial diagnostic values.");
            Check(snapshot.Diagnostics.GameHasStartedAfterRaw == flags.finalStarted && snapshot.Diagnostics.WorldCreatedAfterRaw == flags.finalCreated,
                "The changed final flag was not diagnosed.");
        }
        return Task.CompletedTask;
    }

    private static void RejectMutation(string scenario, Action<Fixture> mutate, Action<LiveEntitySnapshot>? inspect = null)
    {
        var fixture = new Fixture();
        mutate(fixture);
        var reader = fixture.Reader();
        LiveEntitySnapshot snapshot = reader.Capture();
        AssertNoPublishedPositions(snapshot, reader, scenario);
        Check(!snapshot.Diagnostics.GraphValidated, scenario + ": an invalid graph was validated.");
        inspect?.Invoke(snapshot);
    }

    private static void AssertNoPublishedPositions(LiveEntitySnapshot snapshot, LiveEntityReader reader, string scenario)
    {
        Check(snapshot.Status == "LECTURE_NON_VALIDEE", scenario + ": wrong rejection status: " + snapshot.Status + " / " + snapshot.Message);
        Check(snapshot.Entities.Count == 0 && snapshot.PlayersCount == 0 && snapshot.ZombiesCount == 0,
            scenario + ": unvalidated entity positions escaped the reader.");
        Check(snapshot.LocalPosition == null && snapshot.LocalId == -1 && reader.LocalPlayerAddress == 0,
            scenario + ": local player data escaped the reader.");
        Check(snapshot.Camera == null && snapshot.RenderOrigin == null,
            scenario + ": unvalidated camera/origin data escaped the reader.");
        Check(!snapshot.Diagnostics.CanPublish, scenario + ": rejected capture was marked publishable.");
    }

    private static void AssertPendingConfirmation(LiveEntitySnapshot snapshot, LiveEntityReader reader, string scenario, int expectedCount = 0)
    {
        AssertNoPublishedPositions(snapshot, reader, scenario);
        Check(snapshot.Diagnostics.Code == "CONFIRMATION_MONDE" && snapshot.Diagnostics.Stage == "CONFIRMATION_PARTIE",
            scenario + ": pending confirmation lost its exact diagnostic cause.");
        Check(snapshot.Diagnostics.RequiredStableGraphCaptures == 3 && snapshot.Diagnostics.StableGraphCaptures is 1 or 2,
            scenario + ": pending confirmation count is outside the expected bounds.");
        if (expectedCount != 0) Check(snapshot.Diagnostics.StableGraphCaptures == expectedCount, scenario + ": wrong confirmation count.");
        Check(snapshot.Diagnostics.GraphValidated && snapshot.Diagnostics.CollectionValidated,
            scenario + ": the full graph must be validated while waiting for confirmation.");
        Check(snapshot.Diagnostics.GameHasStartedRaw == 1 && snapshot.Diagnostics.WorldCreatedRaw == 0 &&
            snapshot.Diagnostics.GameHasStartedAfterRaw == 1 && snapshot.Diagnostics.WorldCreatedAfterRaw == 0,
            scenario + ": pending confirmation lost the stable observed 1/0 flags.");
        Check(snapshot.Diagnostics.CandidatePlayersCount == 1 && snapshot.Diagnostics.CandidateZombiesCount == 1,
            scenario + ": independently read candidates were not kept in the diagnostic counts.");
    }

    private static void AssertValid(LiveEntitySnapshot snapshot, LiveEntityReader reader, Fixture fixture, int localId = 11, string expectedZombieName = "Zombie 13")
    {
        Check(snapshot.Status == "ENTITES_LUES", "Valid test graph was rejected: " + snapshot.Message);
        Check(snapshot.Diagnostics.CanPublish, "A valid snapshot was not marked publishable.");
        Check(snapshot.LocalId == localId && reader.LocalPlayerAddress == fixture.Local, "Wrong local player selected.");
        Check(snapshot.LocalPosition != null && snapshot.LocalPosition.X == 100 && snapshot.LocalPosition.Y == 25 && snapshot.LocalPosition.Z == -20,
            "Local position was not read from the synthetic memory.");
        Check(snapshot.RenderOrigin != null, "Successful graph did not publish its validated render origin.");
        Check(snapshot.PlayersCount == 1 && snapshot.ZombiesCount == 1 && snapshot.Entities.Count == 2 && snapshot.RejectedEntities == 0,
            "The full entity list did not produce one player and one zombie.");
        LiveEntity player = snapshot.Entities[0], zombie = snapshot.Entities[1];
        Check(player.Kind == "player" && player.EntityId == 12 && player.Name == "Joueur 12" && player.Position.X == 110 && player.Position.Y == 30,
            "Player fields did not traverse the production classification/read path.");
        Check(zombie.Kind == "zombie" && zombie.EntityId == 13 && zombie.Name == expectedZombieName && zombie.Position.X == 90 && zombie.Position.Z == -15,
            "Zombie fields did not traverse the production classification/read path.");
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    internal sealed class Fixture
    {
        internal const int ManagerSize = 0x40;
        internal const int EntitySize = 0x60;
        internal const int BoundsOffset = 0x2C;
        internal const ulong ManagerWorldOffset = 0x20, ManagerLocalOffset = 0x28, ManagerIdOffset = 0x30;
        internal const ulong WorldLocalOffset = 0x18, EntityWorldOffset = 0x10;
        internal readonly FakeMemory Memory = new();
        internal readonly Dictionary<string, ulong> Classes = new(StringComparer.Ordinal);
        internal readonly MonoInspectionReport Metadata = new()
        {
            SelectedLayout = "Unity Mono x64 2022 (candidate)", Status = "METADONNEES_COLLECTEES"
        };
        internal ulong Manager, World, Local, OtherPlayer, Zombie, List, Array, ArrayClass;
        internal ulong LocalVtable, OtherPlayerVtable;
        internal const int StatSize = 0x40;
        internal const ulong StatsHealthOffset = 0x20, StatsOwnerOffset = 0x18;
        internal const ulong StatValueOffset = 0x28, StatBaseOffset = 0x30, StatModifierOffset = 0x2C, StatOwnerOffset = 0x10;
        internal ulong PlayerStats, ZombieStats, PlayerHealth, ZombieHealth, ZombieHealthTable;
        internal ulong RegistryDictionary, RegistryEntryValue, RegistryClassObject, RegistryArrayClass;
        private ulong stringClass;
        private readonly ulong domain, gameImage, coreImage;
        private readonly ulong originStatics;
        internal ulong Domain => domain;
        internal MonoFieldReport BoundsField => Metadata.Classes.Find(c => c.Name == "Entity")!.Fields.Find(f => f.Name == "boundingBox")!;

        internal Fixture()
        {
            domain = Memory.Allocate(32); gameImage = Memory.Allocate(32); coreImage = Memory.Allocate(32);
            GameClass("GameManager", ManagerSize);
            GameClass("World", 0x30);
            GameClass("Entity", 0x50);
            GameClass("EntityAlive", EntitySize, "Entity");
            GameClass("EntityPlayer", EntitySize, "EntityAlive");
            GameClass("EntityPlayerLocal", EntitySize, "EntityPlayer");
            GameClass("EntityZombie", EntitySize, "EntityAlive");
            GameClass("Origin", 0x20);
            Field("GameManager", "Instance", 0x10, "0x12", "GameManager", true);
            Field("GameManager", "m_World", (int)ManagerWorldOffset, "0x12", "World");
            Field("GameManager", "myEntityPlayerLocal", (int)ManagerLocalOffset, "0x12", "EntityPlayerLocal");
            Field("GameManager", "myPlayerId", (int)ManagerIdOffset, "0x08", "System.Int32");
            Field("GameManager", "GameHasStarted", 0x34, "0x02", "System.Boolean");
            Field("GameManager", "worldCreated", 0x35, "0x02", "System.Boolean");
            Field("World", "EntityAlives", 0x10, "0x15", "System.Collections.Generic.List`1<EntityAlive>");
            Field("World", "m_LocalPlayerEntity", (int)WorldLocalOffset, "0x12", "EntityPlayerLocal");
            Field("Entity", "world", (int)EntityWorldOffset, "0x12", "World");
            Field("Entity", "entityId", 0x18, "0x08", "System.Int32");
            Field("Entity", "position", 0x1C, "0x11", "UnityEngine.Vector3");
            Field("Entity", "bDead", 0x28, "0x02", "System.Boolean");
            Field("Entity", "IsDespawned", 0x29, "0x02", "System.Boolean");
            Field("Entity", "markedForUnload", 0x2A, "0x02", "System.Boolean");
            Field("Entity", "isUnloaded", 0x2B, "0x02", "System.Boolean");
            Field("Entity", "boundingBox", BoundsOffset, "0x11", "UnityEngine.Bounds");
            Field("EntityAlive", "entityName", 0x50, "0x0E", "System.String");
            Field("Origin", "position", 0x10, "0x11", "UnityEngine.Vector3", true);

            Manager = Object(Classes["GameManager"], ManagerSize);
            World = Object(Classes["World"], 0x30);
            Local = Entity("EntityPlayerLocal", 11, 100, 25, -20, out LocalVtable);
            OtherPlayer = Entity("EntityPlayer", 12, 110, 30, -20, out OtherPlayerVtable);
            Zombie = Entity("EntityZombie", 13, 90, 25, -15, out _);
            Memory.U64(Manager + ManagerWorldOffset, World);
            Memory.U64(Manager + ManagerLocalOffset, Local);
            Memory.I32(Manager + ManagerIdOffset, 11);
            Memory.U64(World + WorldLocalOffset, Local);
            SetFlags(1, 1);

            ulong managerStatics = StaticStorage(Classes["GameManager"]);
            Memory.U64(managerStatics + 0x10, Manager);
            originStatics = StaticStorage(Classes["Origin"]);
            Memory.Vector(originStatics + 0x10, 0, 0, 0);
            BuildList();
            Memory.U64(World + 0x10, List);
        }

        internal void EnableHealth()
        {
            GameClass("EntityStats", 0x30);
            GameClass("Stat", StatSize);
            Field("EntityAlive", "entityStats", 0x58, "0x12", "EntityStats");
            Field("EntityStats", "Health", (int)StatsHealthOffset, "0x12", "Stat");
            Field("EntityStats", "m_entity", (int)StatsOwnerOffset, "0x12", "EntityAlive");
            RuntimeFields(Classes["EntityStats"], new[]
            {
                ("Health", (int)StatsHealthOffset, (byte)0x12, Classes["Stat"]),
                ("m_entity", (int)StatsOwnerOffset, (byte)0x12, Classes["EntityAlive"])
            });
            RuntimeFields(Classes["Stat"], new[]
            {
                ("m_value", (int)StatValueOffset, (byte)0x0C, 0UL),
                ("m_baseMax", (int)StatBaseOffset, (byte)0x0C, 0UL),
                ("m_maxModifier", (int)StatModifierOffset, (byte)0x0C, 0UL),
                ("Entity", (int)StatOwnerOffset, (byte)0x12, Classes["EntityAlive"])
            });
            PlayerStats = Object(Classes["EntityStats"], 0x30); ZombieStats = Object(Classes["EntityStats"], 0x30);
            PlayerHealth = Object(Classes["Stat"], StatSize); ZombieHealth = Object(Classes["Stat"], StatSize);
            ZombieHealthTable = Memory.ReadU64(ZombieHealth);
            Memory.U64(OtherPlayer + 0x58, PlayerStats); Memory.U64(Zombie + 0x58, ZombieStats);
            Memory.U64(PlayerStats + StatsOwnerOffset, OtherPlayer); Memory.U64(ZombieStats + StatsOwnerOffset, Zombie);
            Memory.U64(PlayerStats + StatsHealthOffset, PlayerHealth); Memory.U64(ZombieStats + StatsHealthOffset, ZombieHealth);
            Memory.U64(PlayerHealth + StatOwnerOffset, OtherPlayer); Memory.U64(ZombieHealth + StatOwnerOffset, Zombie);
            SetHealth(PlayerHealth, 75, 100, 0); SetHealth(ZombieHealth, 42, 100, 0);
        }

        internal void SetHealth(ulong stat, float value, float maximum, float modifier)
        {
            Memory.Single(stat + StatValueOffset, value); Memory.Single(stat + StatBaseOffset, maximum);
            Memory.Single(stat + StatModifierOffset, modifier);
        }

        private void RuntimeFields(ulong type, (string Name, int Offset, byte Code, ulong Data)[] fields)
        {
            ulong array = Memory.Allocate(fields.Length * 32);
            Memory.U64(type + 0x98, array); Memory.I32(type + 0x100, fields.Length);
            for (int i = 0; i < fields.Length; i++)
            {
                var f = fields[i]; GenericField(array + (ulong)i * 32, type, f.Name, f.Offset, f.Code, f.Data);
            }
        }

        private ulong ClosedClass(string name, string ns, int size, ulong image,
            (string Name, int Offset, byte Code, ulong Data)[] fields, out ulong context)
        {
            ulong definition = Class(name, ns, 2, size, image);
            ulong actual = Class(name, ns, 3, size, image);
            ulong args = Memory.Allocate(24); context = Memory.Allocate(0x28);
            Memory.U32(args + 4, 2);
            Memory.U64(args + 8, MonoType(0x08, 0)); Memory.U64(args + 16, MonoType(0x12, Classes["EntityClass"]));
            Memory.U64(context, definition); Memory.U64(context + 8, args); Memory.U64(context + 0x20, actual);
            Memory.U64(actual + 0xF0, context); Memory.I32(definition + 0x100, fields.Length);
            RuntimeFields(actual, fields);
            return actual;
        }

        internal void EnableNames(int entriesCount = 2)
        {
            GameClass("EntityClass", 0x30);
            Field("Entity", "entityClass", 0x44, "0x08", "System.Int32");
            Field("EntityClass", "list", 0x10, "0x15", "DictionarySave`2<Int32,EntityClass>", true);
            Field("EntityClass", "entityClassName", 0x18, "0x0E", "System.String");
            Memory.I32(Zombie + 0x44, -73);
            RegistryClassObject = Object(Classes["EntityClass"], 0x30);
            Memory.U64(RegistryClassObject + 0x18, ManagedString("zombieArlene"));
            ulong entry = ClosedClass("Entry", "System.Collections.Generic", 0x28, coreImage, new[]
            {
                ("hashCode", 0x10, (byte)0x08, 0UL), ("next", 0x14, (byte)0x08, 0UL),
                ("key", 0x18, (byte)0x08, 0UL), ("value", 0x20, (byte)0x12, Classes["EntityClass"])
            }, out _);
            RegistryArrayClass = Class("Entry[]", "System.Collections.Generic", 5, 0x20, coreImage);
            Memory.U64(RegistryArrayClass, entry); Memory.Byte(RegistryArrayClass + 0x1A, 1); Memory.I32(RegistryArrayClass + 0x90, 24);
            ulong entries = Object(RegistryArrayClass, 0x20 + entriesCount * 24);
            Memory.U32(entries + 0x18, (uint)entriesCount);
            for (int i = 0; i < entriesCount; i++) Memory.I32(entries + 0x20 + (ulong)i * 24, -1);
            ulong record = entries + 0x20 + (ulong)(entriesCount - 1) * 24;
            Memory.I32(record, int.MaxValue & -73); Memory.I32(record + 4, -1); Memory.I32(record + 8, -73);
            RegistryEntryValue = record + 16; Memory.U64(RegistryEntryValue, RegistryClassObject);
            ulong dic = ClosedClass("Dictionary`2", "System.Collections.Generic", 0x28, coreImage, new[]
            {
                ("entries", 0x10, (byte)0x1D, entry), ("count", 0x18, (byte)0x08, 0UL), ("version", 0x1C, (byte)0x08, 0UL)
            }, out var dictionaryContext);
            RegistryDictionary = Object(dic, 0x28);
            Memory.U64(RegistryDictionary + 0x10, entries); Memory.I32(RegistryDictionary + 0x18, entriesCount); Memory.I32(RegistryDictionary + 0x1C, 7);
            ulong wrapper = ClosedClass("DictionarySave`2", "", 0x18, gameImage,
                new[] { ("dic", 0x10, (byte)0x15, dictionaryContext) }, out _);
            ulong wrapperObject = Object(wrapper, 0x18); Memory.U64(wrapperObject + 0x10, RegistryDictionary);
            ulong statics = StaticStorage(Classes["EntityClass"]); Memory.U64(statics + 0x10, wrapperObject);
        }

        internal ulong ManagedString(string value)
        {
            if (stringClass == 0) stringClass = Class("String", "System", 1, 0x18, coreImage);
            byte[] content = Encoding.Unicode.GetBytes(value);
            ulong result = Object(stringClass, 0x14 + content.Length);
            Memory.I32(result + 0x10, value.Length); Memory.WriteBytes(result + 0x14, content);
            return result;
        }

        internal LiveEntityReader Reader() => new(Memory, Metadata);
        internal void SetFlags(byte started, byte created)
        {
            Memory.Byte(Manager + 0x34, started); Memory.Byte(Manager + 0x35, created);
        }

        internal void SetLocalId(int value)
        {
            Memory.I32(Manager + ManagerIdOffset, value);
            Memory.I32(Local + 0x18, value);
        }

        internal void ReplaceWorld()
        {
            World = Object(Classes["World"], 0x30);
            Memory.U64(Manager + ManagerWorldOffset, World);
            Memory.U64(World + WorldLocalOffset, Local);
            Memory.U64(World + 0x10, List);
            foreach (ulong entity in new[] { Local, OtherPlayer, Zombie }) Memory.U64(entity + EntityWorldOffset, World);
        }

        internal void ReplaceLocalPlayer()
        {
            Local = Entity("EntityPlayerLocal", 11, 100, 25, -20, out LocalVtable);
            Memory.U64(Manager + ManagerLocalOffset, Local);
            Memory.U64(World + WorldLocalOffset, Local);
            Memory.U64(Array + 0x20, Local);
        }

        internal void ReplaceCollection()
        {
            BuildList();
            Memory.U64(World + 0x10, List);
        }

        internal void MoveOrigin(float x, float y, float z) => Memory.Vector(originStatics + 0x10, x, y, z);

        private void GameClass(string name, int size, string? parent = null)
        {
            ulong address = Class(name, "", 1, size, gameImage, parent == null ? 0 : Classes[parent]);
            Classes.Add(name, address);
            Metadata.Classes.Add(new MonoClassReport
            {
                Name = name, Namespace = "", Address = "0x" + address.ToString("X"), InstanceSize = size,
                FieldsComplete = true
            });
        }

        private void Field(string owner, string name, int offset, string code, string type, bool isStatic = false)
        {
            MonoClassReport report = Metadata.Classes.Find(c => c.Name == owner)!;
            report.Fields.Add(new MonoFieldReport
            {
                Name = name, Offset = offset, TypeCode = code, Type = type, IsStatic = isStatic
            });
            report.DeclaredFieldCount = report.Fields.Count;
        }

        private ulong Class(string name, string ns, byte kind, int size, ulong image, ulong parent = 0)
        {
            ulong address = Memory.Allocate(0x180);
            Memory.Byte(address + 0x1B, kind); Memory.I32(address + 0x1C, size);
            Memory.U64(address + 0x30, parent); Memory.U64(address + 0x40, image);
            Memory.U64(address + 0x48, Memory.CString(name)); Memory.U64(address + 0x50, Memory.CString(ns));
            return address;
        }

        private ulong Vtable(ulong type)
        {
            ulong table = Memory.Allocate(0x58);
            Memory.U64(table, type); Memory.U64(table + 0x10, domain);
            return table;
        }

        private ulong Object(ulong type, int size)
        {
            ulong instance = Memory.Allocate(size);
            Memory.U64(instance, Vtable(type));
            return instance;
        }

        private ulong Entity(string type, int id, float x, float y, float z, out ulong table)
        {
            ulong instance = Memory.Allocate(EntitySize);
            table = Vtable(Classes[type]);
            Memory.U64(instance, table); Memory.U64(instance + EntityWorldOffset, World);
            Memory.I32(instance + 0x18, id); Memory.Vector(instance + 0x1C, x, y, z);
            Memory.Vector(instance + BoundsOffset, x, y + 1, z);
            Memory.Vector(instance + BoundsOffset + 12, 0.4f, 1, 0.4f);
            return instance;
        }

        private ulong StaticStorage(ulong type)
        {
            ulong runtime = Memory.Allocate(0x20), table = Vtable(type), data = Memory.Allocate(0x40);
            Memory.U64(type + 0xD0, runtime); Memory.I32(type + 0x90, 0x40);
            Memory.U64(runtime + 8, table); // domain index 0, default max_domain == 0
            Memory.Byte(table + 0x2D, 1); Memory.U32(table + 0x30, 4); Memory.U64(table + 0x48, data);
            return data;
        }

        private void BuildList()
        {
            ulong definition = Class("List`1", "System.Collections.Generic", 2, 0x20, coreImage);
            ulong instantiated = Class("List`1", "System.Collections.Generic", 3, 0x20, coreImage);
            Memory.I32(definition + 0x100, 3);
            ulong arguments = Memory.Allocate(16), generic = Memory.Allocate(0x28);
            Memory.U32(arguments + 4, 1); Memory.U64(arguments + 8, MonoType(0x12, Classes["EntityAlive"]));
            Memory.U64(generic, definition); Memory.U64(generic + 8, arguments); Memory.U64(generic + 0x20, instantiated);
            Memory.U64(instantiated + 0xF0, generic);

            ulong fields = Memory.Allocate(3 * 32);
            Memory.U64(instantiated + 0x98, fields);
            GenericField(fields, instantiated, "_items", 0x10, 0x1D, Classes["EntityAlive"]);
            GenericField(fields + 32, instantiated, "_size", 0x18, 0x08, 0);
            GenericField(fields + 64, instantiated, "_version", 0x1C, 0x08, 0);

            ArrayClass = Class("EntityAlive[]", "", 5, 0x20, gameImage);
            Memory.U64(ArrayClass, Classes["EntityAlive"]);
            Memory.Byte(ArrayClass + 0x1A, 1); Memory.I32(ArrayClass + 0x90, 8);
            Array = Object(ArrayClass, 0x20 + 3 * 8);
            Memory.U32(Array + 0x18, 3);
            Memory.U64(Array + 0x20, Local); Memory.U64(Array + 0x28, OtherPlayer); Memory.U64(Array + 0x30, Zombie);
            List = Object(instantiated, 0x20);
            Memory.U64(List + 0x10, Array); Memory.I32(List + 0x18, 3); Memory.I32(List + 0x1C, 7);
        }

        private ulong MonoType(byte code, ulong typeData)
        {
            ulong type = Memory.Allocate(16);
            Memory.U64(type, typeData); Memory.Byte(type + 10, code);
            return type;
        }

        private void GenericField(ulong address, ulong parent, string name, int offset, byte code, ulong typeData)
        {
            Memory.U64(address, MonoType(code, typeData)); Memory.U64(address + 8, Memory.CString(name));
            Memory.U64(address + 16, parent); Memory.I32(address + 24, offset);
        }
    }

    internal sealed class FakeMemory : IMemoryReader
    {
        private const ulong BaseAddress = 0x100000;
        private readonly byte[] bytes = new byte[1024 * 1024];
        private int used;
        internal Action<ulong, int>? BeforeRead;

        internal ulong Allocate(int size)
        {
            int start = (used + 15) & ~15;
            used = checked(start + size);
            if (used > bytes.Length) throw new InvalidOperationException("Synthetic memory exhausted.");
            return BaseAddress + (ulong)start;
        }

        private Span<byte> At(ulong address, int count)
        {
            if (address < BaseAddress || address - BaseAddress > (ulong)used || count < 0 ||
                (ulong)count > (ulong)used - (address - BaseAddress))
                throw new IOException("Read outside the allocated test memory.");
            return bytes.AsSpan((int)(address - BaseAddress), count);
        }

        internal void Byte(ulong address, byte value) => At(address, 1)[0] = value;
        internal ulong ReadU64(ulong address) => BinaryPrimitives.ReadUInt64LittleEndian(At(address, 8));
        internal void Single(ulong address, float value) => I32(address, BitConverter.SingleToInt32Bits(value));
        internal void WriteBytes(ulong address, byte[] value) => value.CopyTo(At(address, value.Length));
        internal void I32(ulong address, int value) => BinaryPrimitives.WriteInt32LittleEndian(At(address, 4), value);
        internal void U32(ulong address, uint value) => BinaryPrimitives.WriteUInt32LittleEndian(At(address, 4), value);
        internal void U64(ulong address, ulong value) => BinaryPrimitives.WriteUInt64LittleEndian(At(address, 8), value);
        internal void Vector(ulong address, float x, float y, float z)
        {
            I32(address, BitConverter.SingleToInt32Bits(x));
            I32(address + 4, BitConverter.SingleToInt32Bits(y));
            I32(address + 8, BitConverter.SingleToInt32Bits(z));
        }

        internal ulong CString(string value)
        {
            ulong address = Allocate(256);
            byte[] encoded = Encoding.UTF8.GetBytes(value);
            encoded.CopyTo(At(address, encoded.Length));
            return address;
        }

        public byte[] Read(ulong address, int count)
        {
            BeforeRead?.Invoke(address, count);
            return At(address, count).ToArray();
        }

        public ulong ModuleBase(string name) => throw new NotSupportedException("Capture should use the supplied current metadata.");
        public ulong ExportAddress(string module, string symbol) => throw new NotSupportedException("No runtime execution/export lookup in this test.");
    }
}
