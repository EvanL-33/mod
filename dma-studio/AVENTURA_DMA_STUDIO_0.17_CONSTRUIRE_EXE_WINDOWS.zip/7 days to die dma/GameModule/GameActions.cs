using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Threading;
using UnityEngine;

namespace SevenDaysDmaControl
{
    // Compiled against the supplied V 3.4.0 (b10) assembly. All calls below run on
    // UnityUpdate. The DMA side only publishes requests to the bridge's mailbox.
    public sealed class GameActions : IGameActions
    {
        private const string ProfileHash = "cb54022ccc862aa673e0ee55dafe67d842b364c80df6916958d171e959656c58";
        private const float NightScale = 0.4f;
        private readonly string profileError;
        private readonly Stopwatch clock = Stopwatch.StartNew();
        private int threadId;
        private World world;
        private EntityPlayerLocal player;
        private PlayerMoveController controller;
        private Guid contextId;
        private int playerId;
        private bool wasReady;
        private bool contextSuspended;
        private string notice = "";
        private PendingTeleport pending;
        private readonly Owned<bool> fly = new Owned<bool>();
        private readonly Owned<bool> noclip = new Owned<bool>();
        private readonly Owned<bool> god = new Owned<bool>();
        private readonly Owned<float> speed = new Owned<float>();
        private readonly Owned<float> night = new Owned<float>();
        private WorldEnvironment nightEnvironment;
        private CameraOwnership camera;
        private SpectatorOwnership spectator;

        public GameActions()
        {
            try
            {
                string path = typeof(EntityPlayerLocal).Assembly.Location;
                using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var sha = SHA256.Create())
                {
                    string hash = BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
                    if (!string.Equals(hash, ProfileHash, StringComparison.Ordinal))
                        profileError = "Assembly-CSharp différente du profil V 3.4.0 (b10) analysé. Commandes indisponibles.";
                }
            }
            catch (Exception ex)
            {
                profileError = "Vérification du profil impossible : " + ex.GetType().Name + ".";
            }
        }

        public GameObservation Observe()
        {
            if (!OnGameThread()) return Unavailable(BridgeAvailability.Faulted, "Appel hors du thread du jeu.");
            if (profileError != null) return Unavailable(BridgeAvailability.Incompatible, profileError);
            try
            {
                GameManager manager = GameManager.Instance;
                World nextWorld = manager == null ? null : manager.World;
                EntityPlayerLocal nextPlayer = nextWorld == null ? null : nextWorld.GetPrimaryPlayer();
                PlayerMoveController nextController = nextPlayer == null ? null : nextPlayer.moveController;
                bool changed = !ReferenceEquals(nextWorld, world) || !ReferenceEquals(nextPlayer, player)
                    || !ReferenceEquals(nextController, controller)
                    || (nextPlayer != null && nextPlayer.entityId != playerId);
                if (changed)
                {
                    // Never write into objects from a previous world/player incarnation.
                    ForgetOwned(); pending = null; wasReady = false; contextSuspended = false;
                    world = nextWorld; player = nextPlayer; controller = nextController;
                    playerId = player == null ? 0 : player.entityId;
                    contextId = player == null ? Guid.Empty : Guid.NewGuid();
                    notice = "Nouveau contexte : aucune option réactivée automatiquement.";
                }
                if (world == null || player == null)
                    return Unavailable(BridgeAvailability.NoWorld, "En attente d'un monde et du joueur local.");
                if (!ReferenceEquals(player.world, world) || player.isEntityRemote
                    || player.IsFlyMode is null || player.IsGodMode is null || player.IsNoCollisionMode is null
                    || controller == null || !ReferenceEquals(controller.entityPlayerLocal, player)
                    || player.m_vp_FPController == null)
                    return Unavailable(BridgeAvailability.NoWorld, "Le joueur local ou son contrôleur n'est pas encore prêt.");

                bool dead = player.IsDead();
                bool teleportTransition = pending != null && pending.ContextId == contextId && !dead;
                bool ready = !dead && (player.Spawned || teleportTransition);
                if (!ready && wasReady && !contextSuspended)
                {
                    // No retries or state replay across death/ordinary respawn. Do not call
                    // movement/camera setters on a dying or unloaded character.
                    ForgetOwned(); pending = null; contextId = Guid.NewGuid(); contextSuspended = true;
                    notice = "Mort ou réapparition : demandes et états possédés abandonnés, sans réactivation.";
                }
                if (ready && contextSuspended)
                {
                    contextSuspended = false; contextId = Guid.NewGuid();
                    notice = "Joueur revenu : options à activer explicitement dans ce nouveau contexte.";
                }
                wasReady = ready;
                if (night.Active && !ReferenceEquals(world.m_WorldEnvironment, nightEnvironment))
                { night.Clear(); nightEnvironment = null; }
                var result = new GameObservation
                {
                    ContextId = contextId, PlayerId = playerId,
                    Availability = ready ? BridgeAvailability.Ready : BridgeAvailability.NoWorld,
                    PositionX = player.position.x, PositionY = player.position.y, PositionZ = player.position.z,
                    Speed = player.GodModeSpeedModifier, Brightness = ReadBrightness(),
                    Flags = ReadFlags(dead), OwnedOperations = OwnedMask(),
                    Message = ready ? notice : "Joueur mort ou en cours d'apparition."
                };
                return result;
            }
            catch (Exception ex)
            {
                return Unavailable(BridgeAvailability.Faulted, "Lecture locale interrompue : " + ex.GetType().Name + ".");
            }
        }

        public GameActionResult Execute(ControlRequest request, GameObservation current)
        {
            if (!OnGameThread()) return GameActionResult.Refused("Appel hors du thread du jeu.");
            if (request == null || current == null || !Matches(current) || request.ContextId != contextId
                || request.PlayerId != playerId)
                return GameActionResult.Refused("Le contexte du monde ou du joueur a changé.");
            if (profileError != null) return GameActionResult.Refused(profileError);
            if (request.TargetEntityId != 0 && request.TargetEntityId != playerId)
                return GameActionResult.Refused("Ces commandes concernent uniquement ton joueur local.");
            if (!current.IsReady || player == null || player.IsDead())
                return GameActionResult.Refused("Joueur local vivant requis.");
            try
            {
                if (request.Operation == ControlOperation.RestoreOwned)
                {
                    if (!player.Spawned || player.AttachedToEntity != null || player.m_vp_FPController == null)
                        return GameActionResult.Refused("Restauration non exécutée pendant une transition ou dans un véhicule. Les états courants restent affichés.");
                    return GameActionResult.Applied(RestoreOwnedCore());
                }
                if (pending != null) return GameActionResult.Refused("Téléportation en cours ; attendre sa fin.");
                if (!player.Spawned) return GameActionResult.Refused("Attendre la fin de l'apparition du joueur.");
                if (player.AttachedToEntity != null)
                    return GameActionResult.Refused("Quitte le véhicule ou l'entité attachée avant cette commande.");
                switch (request.Operation)
                {
                    case ControlOperation.SetFly: return SetFly(request.Enabled);
                    case ControlOperation.SetNoclip: return SetNoclip(request.Enabled);
                    case ControlOperation.SetSpeed: return SetSpeed(request.Value);
                    case ControlOperation.SetFreeCamera: return SetFreeCamera(request.Enabled);
                    case ControlOperation.SetNightBrightness: return SetNight(request.Value);
                    case ControlOperation.SetGod: return SetGod(request.Enabled);
                    case ControlOperation.Teleport: return StartTeleport(request);
                    case ControlOperation.SetSpectator: return SetSpectator(request.Enabled);
                    default: return GameActionResult.Refused("Commande inconnue.");
                }
            }
            catch (Exception ex)
            {
                return GameActionResult.Failed("La méthode du jeu a interrompu la commande : " + ex.GetType().Name
                    + ". L'état observé reste affiché ; aucune nouvelle tentative automatique.");
            }
        }

        public GameActionResult Poll(ulong requestId, GameObservation current)
        {
            if (!OnGameThread()) return GameActionResult.Refused("Appel hors du thread du jeu.");
            if (pending == null || pending.RequestId != requestId)
                return GameActionResult.Refused("Aucune transition correspondante n'est suivie.");
            if (current == null || !Matches(current) || pending.ContextId != contextId
                || player == null || player.IsDead())
            { pending = null; return GameActionResult.Refused("Téléportation interrompue par un changement de joueur ou de monde."); }
            if (clock.ElapsedMilliseconds - pending.StartedMs > 30000)
            {
                pending = null;
                return GameActionResult.Failed("Téléportation non confirmée après 30 s. Aucune annulation ni nouvelle tentative forcée.");
            }
            if (!player.Spawned)
            { pending.SawUnspawned = true; pending.StableReads = 0; return GameActionResult.Pending("Chargement et réapparition du joueur en cours."); }
            float distance = (player.position - pending.Target).sqrMagnitude;
            bool laterFrame = Time.frameCount != pending.StartedFrame;
            if (laterFrame && pending.SawUnspawned && clock.ElapsedMilliseconds - pending.StartedMs >= 250
                && ControlProtocol.IsFinite(distance) && distance <= 2.25f)
            {
                if (pending.LastStableFrame != Time.frameCount)
                { pending.LastStableFrame = Time.frameCount; pending.StableReads++; }
                if (pending.StableReads >= 2)
                {
                    pending = null;
                    return GameActionResult.Applied("Téléportation observée localement après réapparition et deux captures de position.");
                }
            }
            else pending.StableReads = 0;
            return GameActionResult.Pending("Attente de la position locale après la transition du jeu.");
        }

        public void Release(GameObservation current)
        {
            if (!OnGameThread()) return;
            if (current == null || !Matches(current) || player == null || world == null)
            { ForgetOwned(); pending = null; return; }
            try { RestoreOwnedCore(); }
            catch (Exception ex) { notice = "Restauration interrompue : " + ex.GetType().Name + "."; ForgetOwned(); pending = null; }
        }

        private GameActionResult SetFly(bool enabled)
        {
            if (!enabled && player.IsNoCollisionMode.Value)
            {
                noclip.Capture(player.IsNoCollisionMode.Value);
                try { player.IsNoCollisionMode.Value = false; } finally { noclip.Last = player.IsNoCollisionMode.Value; }
            }
            if (player.IsFlyMode.Value != enabled)
            {
                fly.Capture(player.IsFlyMode.Value);
                try { player.IsFlyMode.Value = enabled; } finally { fly.Last = player.IsFlyMode.Value; }
            }
            player.bEntityAliveFlagsChanged = true;
            return player.IsFlyMode.Value == enabled && (enabled || !player.IsNoCollisionMode.Value)
                ? GameActionResult.Applied(enabled ? "Vol observé localement." : "Vol et traversée désactivés localement.")
                : GameActionResult.Failed("La transition de vol n'a pas produit l'état demandé.");
        }

        private GameActionResult SetNoclip(bool enabled)
        {
            if (enabled && !player.IsFlyMode.Value)
            {
                fly.Capture(player.IsFlyMode.Value);
                try { player.IsFlyMode.Value = true; } finally { fly.Last = player.IsFlyMode.Value; }
            }
            if (player.IsNoCollisionMode.Value != enabled)
            {
                noclip.Capture(player.IsNoCollisionMode.Value);
                try { player.IsNoCollisionMode.Value = enabled; } finally { noclip.Last = player.IsNoCollisionMode.Value; }
            }
            player.bEntityAliveFlagsChanged = true;
            return player.IsNoCollisionMode.Value == enabled && (!enabled || player.IsFlyMode.Value)
                ? GameActionResult.Applied(enabled ? "Traversée et vol observés localement." : "Traversée désactivée localement ; position inchangée.")
                : GameActionResult.Failed("La transition de traversée n'a pas produit l'état demandé.");
        }

        private GameActionResult SetSpeed(float value)
        {
            if (!ControlProtocol.IsFinite(value) || value < 0.1f || value > 15f)
                return GameActionResult.Refused("Le multiplicateur doit être compris entre 0,1 et 15.");
            if (!player.GodModeSpeedModifier.Equals(value))
            {
                speed.Capture(player.GodModeSpeedModifier);
                player.GodModeSpeedModifier = value; speed.Last = player.GodModeSpeedModifier;
            }
            return player.GodModeSpeedModifier.Equals(value)
                ? GameActionResult.Applied("Multiplicateur local observé ; son effet dépend du mode de déplacement du jeu.")
                : GameActionResult.Failed("Multiplicateur local non confirmé.");
        }

        private GameActionResult SetGod(bool enabled)
        {
            if (player.IsGodMode.Value == enabled) return GameActionResult.Applied("État God demandé déjà observé localement.");
            if (!NativeGodAvailable()) return GameActionResult.Refused("L'action God native de ce joueur n'est pas disponible.");
            god.Capture(player.IsGodMode.Value); fly.Capture(player.IsFlyMode.Value); noclip.Capture(player.IsNoCollisionMode.Value);
            try { controller.toggleGodMode(); }
            finally { god.Last = player.IsGodMode.Value; fly.Last = player.IsFlyMode.Value; noclip.Last = player.IsNoCollisionMode.Value; }
            return player.IsGodMode.Value == enabled && player.IsFlyMode.Value == enabled && player.IsNoCollisionMode.Value == enabled
                ? GameActionResult.Applied("Action God native exécutée ; God, vol et traversée observés localement. Acceptation serveur non confirmée.")
                : GameActionResult.Failed("L'action God native n'a pas produit tous les états attendus.");
        }

        private GameActionResult SetFreeCamera(bool enabled)
        {
            CameraState before;
            if (!TryCamera(out before)) return GameActionResult.Refused("Caméra locale indisponible.");
            if (before.Parent != null && !ReferenceEquals(before.Parent, player.cameraContainerTransform))
                return GameActionResult.Refused("Quitte la lunette ou la caméra spéciale avant cette commande.");
            if ((enabled && before.Free) || (!enabled && before.IsNormal))
                return GameActionResult.Applied("État de caméra demandé déjà observé localement.");
            if (camera == null || !camera.Last.Same(before)) camera = new CameraOwnership { Baseline = before, Last = before };
            bool targetAttached = !enabled && player.bFirstPersonView;
            bool targetLocked = enabled;
            bool targetDetachedMove = enabled;
            // Normal third-person view also has a detached Transform. Preserve its
            // native camera state rather than forcibly attaching it as first-person.
            if (!enabled && camera.Baseline.IsNormal)
            {
                targetAttached = camera.Baseline.Parent != null;
                targetLocked = camera.Baseline.Locked;
                targetDetachedMove = camera.Baseline.DetachedMove;
            }
            try
            {
                if (enabled) player.ClearMovementInputs();
                player.SetCameraAttachedToPlayer(targetAttached, targetLocked);
                player.vp_FPCamera.Locked3rdPerson = targetLocked;
                player.movementInput.bDetachedCameraMove = targetDetachedMove;
            }
            finally { CameraState after; if (TryCamera(out after)) camera.Last = after; }
            CameraState observed;
            return TryCamera(out observed) && observed.Free == enabled
                && observed.Locked == targetLocked && observed.DetachedMove == targetDetachedMove
                && (targetAttached ? ReferenceEquals(observed.Parent, player.cameraContainerTransform) : observed.Parent == null)
                ? GameActionResult.Applied(enabled ? "Caméra libre locale détachée ; déplacement géré par le jeu." : "Vue normale du joueur local rétablie.")
                : GameActionResult.Failed("Transition de caméra non confirmée.");
        }

        private GameActionResult SetNight(float value)
        {
            if (!ControlProtocol.IsFinite(value) || value < 0f || value > 1f)
                return GameActionResult.Refused("L'éclaircissement doit être compris entre 0 et 1.");
            WorldEnvironment environment = world.m_WorldEnvironment;
            if (environment == null || !ReferenceEquals(environment.world, world) || !ReferenceEquals(environment.localPlayer, player))
                return GameActionResult.Refused("L'environnement visuel de ce joueur n'est pas prêt.");
            if (!ReferenceEquals(nightEnvironment, environment)) { night.Clear(); nightEnvironment = environment; }
            float desired = value * NightScale;
            if (!environment.nightVisionBrightness.Equals(desired))
            {
                night.Capture(environment.nightVisionBrightness);
                try { environment.SetNightVision(value); } finally { night.Last = environment.nightVisionBrightness; }
            }
            return environment.nightVisionBrightness.Equals(desired)
                ? GameActionResult.Applied("Éclaircissement nocturne local observé.")
                : GameActionResult.Failed("Éclaircissement local non confirmé.");
        }

        private GameActionResult SetSpectator(bool enabled)
        {
            if (player.emodel == null) return GameActionResult.Refused("Le modèle du joueur n'est pas prêt.");
            if (player.IsSpectator == enabled && player.isIgnoredByAI == enabled
                && (!enabled || !player.emodel.visible))
                return GameActionResult.Applied("État spectateur demandé déjà observé localement.");
            if (spectator == null || !spectator.Matches(player))
                spectator = new SpectatorOwnership(player);
            try { player.IsSpectator = enabled; }
            finally { spectator.Record(player); }
            return player.IsSpectator == enabled && player.isIgnoredByAI == enabled
                && (enabled ? !player.emodel.visible : player.emodel.visible == player.bModelVisible)
                ? GameActionResult.Applied("Transition spectateur native observée localement ; visibilité chez les autres joueurs non confirmée.")
                : GameActionResult.Failed("La transition complète du modèle spectateur n'est pas confirmée.");
        }

        private GameActionResult StartTeleport(ControlRequest request)
        {
            if (!ControlProtocol.IsFinite(request.PositionX) || !ControlProtocol.IsFinite(request.PositionY)
                || !ControlProtocol.IsFinite(request.PositionZ) || request.PositionY < 1f || request.PositionY > 254f)
                return GameActionResult.Refused("Coordonnées finies requises ; hauteur autorisée de 1 à 254.");
            CameraState cameraState;
            if (!TryCamera(out cameraState) || cameraState.Free || cameraState.Locked || cameraState.DetachedMove
                || (cameraState.Parent != null && !ReferenceEquals(cameraState.Parent, player.cameraContainerTransform)))
                return GameActionResult.Refused("Quitte la caméra libre, la caméra verrouillée et la lunette avant une téléportation.");
            if (player.emodel == null || player.emodel.IsRagdollOn)
                return GameActionResult.Refused("Attendre la fin de la chute ou de l'animation physique du joueur.");
            Vector3i min, max;
            if (!world.GetWorldExtent(out min, out max) || max.x <= min.x || max.z <= min.z)
                return GameActionResult.Refused("Limites du monde indisponibles ; destination non validée.");
            if (request.PositionX < min.x + 2 || request.PositionX >= max.x - 2
                || request.PositionZ < min.z + 2 || request.PositionZ >= max.z - 2)
                return GameActionResult.Refused("Destination située hors des limites utilisables du monde.");
            var target = new Vector3(request.PositionX, request.PositionY, request.PositionZ);
            pending = new PendingTeleport { RequestId = request.RequestId, ContextId = contextId,
                Target = target, StartedMs = clock.ElapsedMilliseconds, StartedFrame = Time.frameCount, LastStableFrame = -1 };
            try
            {
                player.TeleportToPosition(target, false, null);
                pending.SawUnspawned = !player.Spawned;
            }
            catch { pending = null; throw; }
            return GameActionResult.Pending("Téléportation personnelle demandée au jeu ; attente de sa réapparition et de la position finale.");
        }

        private string RestoreOwnedCore()
        {
            bool teleportWasPending = pending != null;
            pending = null; // Abandon observation only; no cancellation of a game coroutine.
            if (player == null || player.IsDead() || !player.Spawned || player.AttachedToEntity != null
                || player.m_vp_FPController == null || player.IsFlyMode is null
                || player.IsNoCollisionMode is null || player.IsGodMode is null)
            {
                ForgetOwned();
                return notice = "Contexte de restauration indisponible : propriété abandonnée sans écrire dans le joueur."
                    + (teleportWasPending ? " La téléportation déjà lancée reste gérée par le jeu." : "");
            }
            int restored = 0, preserved = 0;
            // The game's God action also changes Fly/Noclip. Invoke it only while the
            // complete group is still ours, then restore the captured movement baseline.
            bool canFly = fly.Matches(player.IsFlyMode.Value), canNoclip = noclip.Matches(player.IsNoCollisionMode.Value);
            bool canGod = god.Matches(player.IsGodMode.Value);
            // Do not turn off flight underneath a noclip state changed by the game.
            if (canFly && !fly.Baseline && player.IsNoCollisionMode.Value && (!canNoclip || noclip.Baseline))
                canFly = false;
            if (god.Active && !player.IsGodMode.Value.Equals(god.Baseline))
            {
                if (canGod && canFly && canNoclip && NativeGodAvailable())
                {
                    controller.toggleGodMode();
                    if (player.IsGodMode.Value.Equals(god.Baseline)) restored++; else preserved++;
                }
                else preserved++;
            }
            else if (god.Active) { if (canGod) restored++; else preserved++; }
            god.Clear();
            if (canNoclip && !noclip.Baseline) { player.IsNoCollisionMode.Value = false; }
            if (canFly) { player.IsFlyMode.Value = fly.Baseline; restored++; }
            else if (fly.Active) preserved++;
            if (canNoclip)
            {
                if (!noclip.Baseline || player.IsFlyMode.Value)
                { player.IsNoCollisionMode.Value = noclip.Baseline; restored++; }
                else preserved++;
            }
            else if (noclip.Active) preserved++;
            fly.Clear(); noclip.Clear(); player.bEntityAliveFlagsChanged = true;
            if (speed.Active)
            {
                if (speed.Matches(player.GodModeSpeedModifier)) { player.GodModeSpeedModifier = speed.Baseline; restored++; }
                else preserved++;
                speed.Clear();
            }
            if (night.Active)
            {
                if (ReferenceEquals(nightEnvironment, world.m_WorldEnvironment)
                    && ReferenceEquals(nightEnvironment.localPlayer, player) && night.Matches(nightEnvironment.nightVisionBrightness))
                { nightEnvironment.nightVisionBrightness = night.Baseline; restored++; }
                else preserved++;
                night.Clear(); nightEnvironment = null;
            }
            if (camera != null)
            {
                CameraState now;
                if (TryCamera(out now) && camera.Last.Same(now)
                    && (camera.Baseline.Parent == null || ReferenceEquals(camera.Baseline.Parent, player.cameraContainerTransform)))
                {
                    player.SetCameraAttachedToPlayer(camera.Baseline.Parent != null, camera.Baseline.Locked);
                    player.vp_FPCamera.Locked3rdPerson = camera.Baseline.Locked;
                    player.movementInput.bDetachedCameraMove = camera.Baseline.DetachedMove; restored++;
                }
                else preserved++;
                camera = null;
            }
            if (spectator != null)
            {
                if (spectator.Matches(player) && player.emodel != null)
                {
                    player.IsSpectator = spectator.BaselineSpectator;
                    player.isIgnoredByAI = spectator.BaselineIgnored;
                    player.SetVisible(spectator.BaselineVisible); restored++;
                }
                else preserved++;
                spectator = null;
            }
            return notice = "Restauration locale : " + restored + " état(s) restauré(s), " + preserved
                + " modification(s) externe(s) conservée(s)."
                + (teleportWasPending ? " La téléportation déjà lancée n'est pas annulée." : "");
        }

        private bool NativeGodAvailable()
        {
            return controller != null && ReferenceEquals(controller, player.moveController)
                && ReferenceEquals(controller.entityPlayerLocal, player) && ReferenceEquals(controller.gameManager, GameManager.Instance)
                && controller.toggleGodMode != null;
        }

        private bool TryCamera(out CameraState state)
        {
            state = null;
            if (player == null || player.cameraTransform == null || player.cameraContainerTransform == null
                || player.vp_FPCamera == null || player.movementInput == null) return false;
            if (!ReferenceEquals(player.vp_FPCamera.FPController, player.m_vp_FPController)
                || player.m_vp_FPController == null || !ReferenceEquals(player.m_vp_FPController.localPlayer, player)
                || player.vp_FPCamera.PositionOnDeath != Vector3.zero) return false;
            state = new CameraState { Transform = player.cameraTransform, Parent = player.cameraTransform.parent,
                Locked = player.vp_FPCamera.Locked3rdPerson, DetachedMove = player.movementInput.bDetachedCameraMove,
                FirstPerson = player.bFirstPersonView };
            return true;
        }

        private ControlFlags ReadFlags(bool dead)
        {
            ControlFlags flags = ControlFlags.None;
            if (player.IsFlyMode.Value) flags |= ControlFlags.Fly;
            if (player.IsNoCollisionMode.Value) flags |= ControlFlags.Noclip;
            if (player.IsGodMode.Value) flags |= ControlFlags.God;
            if (player.IsSpectator) flags |= ControlFlags.Spectator;
            if (player.bFirstPersonView) flags |= ControlFlags.FirstPerson;
            if (dead) flags |= ControlFlags.Dead;
            if (pending != null) flags |= ControlFlags.Teleporting;
            if (world.IsRemote()) flags |= ControlFlags.RemoteWorld;
            CameraState state; if (TryCamera(out state) && state.Free) flags |= ControlFlags.FreeCamera;
            return flags;
        }

        private float ReadBrightness()
        {
            WorldEnvironment environment = world.m_WorldEnvironment;
            return environment != null && ReferenceEquals(environment.localPlayer, player)
                ? environment.nightVisionBrightness / NightScale : 0f;
        }

        private uint OwnedMask()
        {
            uint mask = 0;
            if (fly.Active) mask |= ControlProtocol.OperationMask(ControlOperation.SetFly);
            if (noclip.Active) mask |= ControlProtocol.OperationMask(ControlOperation.SetNoclip);
            if (god.Active) mask |= ControlProtocol.OperationMask(ControlOperation.SetGod);
            if (speed.Active) mask |= ControlProtocol.OperationMask(ControlOperation.SetSpeed);
            if (night.Active) mask |= ControlProtocol.OperationMask(ControlOperation.SetNightBrightness);
            if (camera != null) mask |= ControlProtocol.OperationMask(ControlOperation.SetFreeCamera);
            if (spectator != null) mask |= ControlProtocol.OperationMask(ControlOperation.SetSpectator);
            return mask;
        }

        private void ForgetOwned()
        {
            fly.Clear(); noclip.Clear(); god.Clear(); speed.Clear(); night.Clear();
            nightEnvironment = null; camera = null; spectator = null;
        }

        private bool Matches(GameObservation current)
        {
            GameManager manager = GameManager.Instance;
            return profileError == null && current.ContextId != Guid.Empty && current.ContextId == contextId
                && current.PlayerId == playerId && world != null && player != null
                && manager != null && ReferenceEquals(manager.World, world)
                && ReferenceEquals(world.GetPrimaryPlayer(), player) && player.entityId == playerId
                && ReferenceEquals(player.moveController, controller);
        }

        private bool OnGameThread()
        {
            int id = Thread.CurrentThread.ManagedThreadId;
            if (threadId == 0) threadId = id;
            return id == threadId;
        }

        private GameObservation Unavailable(BridgeAvailability availability, string message)
        {
            return new GameObservation { ContextId = contextId, PlayerId = playerId, Availability = availability,
                SupportedOperations = profileError == null ? ControlProtocol.AllOperationsMask : 0,
                OwnedOperations = OwnedMask(), Message = message };
        }

        private sealed class Owned<T>
        {
            public bool Active;
            public T Baseline, Last;
            public void Capture(T current)
            {
                if (!Matches(current)) Baseline = current;
                Last = current; Active = true;
            }
            public bool Matches(T current) { return Active && EqualityComparer<T>.Default.Equals(current, Last); }
            public void Clear() { Active = false; Baseline = default(T); Last = default(T); }
        }

        private sealed class CameraState
        {
            public Transform Transform, Parent;
            public bool Locked, DetachedMove, FirstPerson;
            public bool Free { get { return Parent == null && Locked && DetachedMove; } }
            public bool IsNormal { get { return !Locked && !DetachedMove; } }
            public bool Same(CameraState other)
            {
                return other != null && ReferenceEquals(Transform, other.Transform) && ReferenceEquals(Parent, other.Parent)
                    && Locked == other.Locked && DetachedMove == other.DetachedMove && FirstPerson == other.FirstPerson;
            }
        }
        private sealed class CameraOwnership { public CameraState Baseline, Last; }
        private sealed class SpectatorOwnership
        {
            public readonly bool BaselineSpectator, BaselineIgnored;
            public readonly bool BaselineVisible;
            public readonly EModelBase Model;
            public bool LastSpectator, LastIgnored, LastVisible, LastNominalVisibility;
            public SpectatorOwnership(EntityPlayerLocal p)
            {
                BaselineSpectator = p.IsSpectator; BaselineIgnored = p.isIgnoredByAI;
                Model = p.emodel; BaselineVisible = Model.visible; Record(p);
            }
            public void Record(EntityPlayerLocal p)
            {
                LastSpectator = p.IsSpectator; LastIgnored = p.isIgnoredByAI;
                LastVisible = p.emodel != null && p.emodel.visible; LastNominalVisibility = p.bModelVisible;
            }
            public bool Matches(EntityPlayerLocal p)
            {
                return ReferenceEquals(Model, p.emodel) && p.emodel != null
                    && p.IsSpectator == LastSpectator && p.isIgnoredByAI == LastIgnored
                    && p.emodel.visible == LastVisible && p.bModelVisible == LastNominalVisibility;
            }
        }
        private sealed class PendingTeleport
        {
            public ulong RequestId;
            public Guid ContextId;
            public Vector3 Target;
            public long StartedMs;
            public int StartedFrame, LastStableFrame, StableReads;
            public bool SawUnspawned;
        }
    }
}
