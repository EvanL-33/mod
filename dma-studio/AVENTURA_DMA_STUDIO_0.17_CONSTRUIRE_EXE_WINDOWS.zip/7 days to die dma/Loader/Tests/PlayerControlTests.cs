using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using SevenDaysDmaControl;
using SevenDaysEsp;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class PlayerControlTests
{
    private sealed class Fixture
    {
        public long Now = Stopwatch.GetTimestamp();
        public readonly string Context = Guid.NewGuid().ToString("N");
        public readonly Guid Module = Guid.NewGuid(), Character = Guid.NewGuid();
        public readonly PlayerControlSession Session;
        public readonly FeedSample Feed;
        public Fixture()
        {
            Session = new PlayerControlSession(() => Now, () => new DateTime(2026, 11, 16, 12, 0, 0, DateTimeKind.Utc));
            Feed = new FeedSample(new LiveEntitySnapshot { Status = "ENTITES_LUES", PlayerContextId = Context,
                LocalId = 1, LocalPosition = new LivePosition(), PlayerCaptureSequence = 1 }, 0);
            Session.Reset(1); Session.ObserveContext(1, 123, Feed, true);
        }
        public PlayerControlObservation Packet(ulong requestId = 0, ControlStatus status = ControlStatus.None,
            ControlOperation operation = ControlOperation.None, ControlFlags flags = ControlFlags.FirstPerson)
        {
            var state = new ControlSnapshot
            {
                SessionId = Module, Sequence = 2, LastRequestId = requestId, LastOperation = operation,
                LastRequestContextId = requestId == 0 ? Guid.Empty : Character,
                LastStatus = status, LastMessage = "Observation de test", RequestHighWatermark = requestId,
                Observation = new GameObservation { ContextId = Character, PlayerId = 1, Availability = BridgeAvailability.Ready,
                    GameTimestampMs = 1000, PositionY = 65, Speed = 1, Flags = flags }
            };
            return new PlayerControlObservation { ProcessId = 123, PlayerContextId = Context, CapturedTimestamp = Now,
                Available = true, Fresh = true, Code = "MODULE_PRET", Message = "Prêt", SnapshotRecord = ControlProtocol.EncodeSnapshot(state, 2) };
        }
        public void Ready() => Check(Session.Observe(1, Packet()) && Session.State.CanRequest, "Fixture not ready.");
        public void Advance(double ms) => Now += (long)(Stopwatch.Frequency * ms / 1000);
        public static PlayerControlSubmission Submission(PlayerControlRequest request, ulong id = 7) => new()
        {
            Sequence = request.Sequence, RequestId = request.RequestId, ProcessId = request.ExpectedProcessId,
            PlayerContextId = request.ExpectedPlayerContextId, Accepted = true, WriteAttempted = true, CommitAttempted = true,
            ModuleRequestId = id, Code = "TRANSMIS", Message = "Transmis, exécution encore inconnue."
        };
    }

    public static Task RequiresFreshModuleAndCurrentLocalFeed()
    {
        var f = new Fixture(); Expect<InvalidOperationException>(() => f.Session.Begin(1, ControlOperation.SetFly, true));
        var stale = f.Packet(); stale.Fresh = false; f.Session.Observe(1, stale);
        Check(!f.Session.State.CanRequest, "Nonprogressing heartbeat became ready.");
        f.Ready();
        var snapshot = f.Session.State.Snapshot!; snapshot.Observation.Flags = ControlFlags.God;
        Check(f.Session.State.Snapshot!.Observation.Flags == ControlFlags.FirstPerson, "View mutated retained observation.");
        f.Advance(1000); Check(!f.Session.State.CanRequest, "Cached module state gained a lifetime.");
        f.Ready(); f.Session.ObserveContext(1, 123, null, true);
        Check(!f.Session.State.CanRequest, "Rejected entity frame still allowed a command.");
        return Task.CompletedTask;
    }

    public static Task TransmissionIsNotExecutionAndAckIsCorrelated()
    {
        var f = new Fixture(); f.Ready();
        var request = f.Session.Begin(1, ControlOperation.SetFly, true);
        Check(request.ExpectedModuleContextId == f.Character && request.ExpectedModuleSessionId == f.Module, "Intent missing module identities.");
        Check(f.Session.AcceptSubmission(1, Fixture.Submission(request)), "Valid submission rejected.");
        Check(f.Session.State.IsBusy && f.Session.State.Snapshot!.Observation.Flags == ControlFlags.FirstPerson,
            "Transmission falsely confirmed an enabled flag.");
        var wrong = f.Packet(8, ControlStatus.AppliedLocal, ControlOperation.SetFly, ControlFlags.Fly);
        f.Session.Observe(1, wrong); Check(f.Session.State.IsBusy, "Another request completed ours.");
        var pending = f.Packet(7, ControlStatus.Pending, ControlOperation.SetFly); pending.PendingRequestId = 7;
        f.Session.Observe(1, pending); Check(f.Session.State.IsBusy, "Pending result completed request.");
        var applied = f.Packet(7, ControlStatus.AppliedLocal, ControlOperation.SetFly, ControlFlags.Fly);
        f.Session.Observe(1, applied);
        Check(!f.Session.State.IsBusy && f.Session.State.Available && f.Session.State.Snapshot!.Observation.Flags == ControlFlags.Fly,
            "Matching observed execution not shown.");
        Check(f.Feed.IsFresh && f.Feed.Snapshot.PlayerContextId == f.Context, "Control result mutated ESP feed.");
        return Task.CompletedTask;
    }

    public static Task ContextGenerationAndCorruptionCannotReuseIntent()
    {
        var f = new Fixture(); f.Ready(); var request = f.Session.Begin(1, ControlOperation.SetGod, true);
        f.Session.AcceptSubmission(1, Fixture.Submission(request));
        var corrupt = f.Packet(); corrupt.SnapshotRecord![84] ^= 1; f.Session.Observe(1, corrupt);
        Check(!f.Session.State.Available, "Corrupted module state published.");
        f.Session.Reset(2); f.Session.ObserveContext(2, 123, f.Feed, true);
        Check(!f.Session.AcceptSubmission(1, Fixture.Submission(request)) && !f.Session.Observe(1, f.Packet(7, ControlStatus.AppliedLocal, ControlOperation.SetGod)),
            "Old generation result accepted.");
        f.Session.Observe(2, f.Packet()); Check(!f.Session.State.IsBusy, "Reset replayed pending command.");
        var next = f.Session.Begin(2, ControlOperation.SetFly, true); f.Session.AcceptSubmission(2, Fixture.Submission(next));
        var changed = f.Packet(); ControlProtocol.TryDecodeSnapshot(changed.SnapshotRecord!, out var state, out _);
        state.Observation.ContextId = Guid.NewGuid(); changed.SnapshotRecord = ControlProtocol.EncodeSnapshot(state, 4);
        f.Session.Observe(2, changed);
        Check(!f.Session.State.IsBusy && !f.Session.AcceptSubmission(2, Fixture.Submission(next)), "New character retained old intent.");
        return Task.CompletedTask;
    }

    public static Task CommandsHaveBoundedValuesAndNoImplicitReplay()
    {
        var f = new Fixture(); f.Ready();
        Expect<InvalidDataException>(() => f.Session.Begin(1, ControlOperation.SetSpeed, value: float.NaN));
        Expect<InvalidDataException>(() => f.Session.Begin(1, ControlOperation.SetSpeed, value: 15.1f));
        Expect<InvalidDataException>(() => f.Session.Begin(1, ControlOperation.Teleport, y: 0));
        var request = f.Session.Begin(1, ControlOperation.SetSpeed, value: 15);
        var copied = request.Copy(); copied.Value = 1;
        Check(request.Value == 15, "Intent retained mutable caller state.");
        f.Advance(3000); Check(PlayerControlPolicy.IsExpired(request, f.Now), "Boundary TTL accepted.");
        f.Advance(37000); Check(!f.Session.State.IsBusy && f.Session.State.Code == "DELAI_DEPASSE", "Unknown outcome did not expire.");
        Check(!f.Session.AcceptSubmission(1, Fixture.Submission(request)), "Late submission revived expired intent.");
        return Task.CompletedTask;
    }

    public static Task RefusalSurvivesOldAckAndContextChangeAfterReadGap()
    {
        var f = new Fixture(); f.Ready(); var first = f.Session.Begin(1, ControlOperation.SetFly, true);
        f.Session.AcceptSubmission(1, Fixture.Submission(first));
        var oldAck = f.Packet(7, ControlStatus.AppliedLocal, ControlOperation.SetFly, ControlFlags.Fly);
        f.Session.Observe(1, oldAck);
        var refused = f.Session.Begin(1, ControlOperation.SetGod, true);
        f.Session.AcceptSubmission(1, new PlayerControlSubmission { Sequence = refused.Sequence, RequestId = refused.RequestId,
            ProcessId = 123, PlayerContextId = f.Context, Code = "COMMANDE_REFUSEE", Message = "Refus récent avant commit." });
        f.Session.Observe(1, oldAck);
        Check(f.Session.State.Code == "COMMANDE_REFUSEE" && f.Session.State.Message == "Refus récent avant commit.",
            "An old successful acknowledgement hid the latest command refusal.");
        var pending = f.Session.Begin(1, ControlOperation.SetGod, true);
        var bad = f.Packet(); bad.SnapshotRecord![0] ^= 1; f.Session.Observe(1, bad);
        Check(f.Session.State.Snapshot == null && f.Session.State.IsBusy, "Invalid packet did not suspend observations.");
        var changed = f.Packet(); ControlProtocol.TryDecodeSnapshot(changed.SnapshotRecord!, out var snap, out _);
        snap.Observation.ContextId = Guid.NewGuid(); changed.SnapshotRecord = ControlProtocol.EncodeSnapshot(snap, 4);
        f.Session.Observe(1, changed);
        Check(!f.Session.State.IsBusy && !f.Session.AcceptSubmission(1, Fixture.Submission(pending)),
            "A read gap concealed the module context change.");
        // A retained result from the old world is identifiable, even to a new loader.
        f.Session.Reset(2); f.Session.ObserveContext(2, 123, f.Feed, true);
        snap.LastRequestContextId = f.Character; snap.LastRequestId = 8; snap.LastStatus = ControlStatus.AppliedLocal;
        snap.LastOperation = ControlOperation.SetGod; changed.SnapshotRecord = ControlProtocol.EncodeSnapshot(snap, 6);
        f.Session.Observe(2, changed);
        Check(f.Session.State.Code != "APPLIEDLOCAL", "Previous world's result appeared current after loader restart.");
        return Task.CompletedTask;
    }

    public static async Task WireKeepsBinaryStateAndInboxConsumesOnce()
    {
        var f = new Fixture(); f.Ready(); var request = f.Session.Begin(1, ControlOperation.SetSpectator, true);
        var inbox = new WorkerReadOptionsState(null);
        Check(inbox.TryQueuePlayerRequest(request), "Inbox rejected first command.");
        request.Enabled = false;
        var taken = inbox.TakePlayerRequest(); Check(taken?.Enabled == true && inbox.TakePlayerRequest() == null, "Inbox did not copy or consume once.");
        Check(!inbox.TryQueuePlayerRequest(taken!), "Inbox accepted replay.");
        using var stream = new MemoryStream();
        var packet = f.Packet();
        await Wire.WriteAsync(stream, new WorkerMessage { Kind = WorkerControl.PlayerControlStateKind, PlayerControlObservation = packet }, CancellationToken.None);
        stream.Position = 0;
        var roundtrip = await Wire.ReadAsync<WorkerMessage>(stream, CancellationToken.None);
        Check(PlayerControlPolicy.TryReadSnapshot(roundtrip.PlayerControlObservation, f.Now, out var decoded, out _) && decoded!.SessionId == f.Module &&
            decoded.Observation.ContextId == f.Character && decoded.Observation.PositionY == 65, "JSON silently lost binary state fields.");
    }

    public static Task ExecutorBindsIdentityExpiryAndNativeResult()
    {
        var f = new Fixture(); f.Ready(); var request = f.Session.Begin(1, ControlOperation.SetFly, true);
        int calls = 0;
        ControlSubmitResult Submit() { calls++; return new ControlSubmitResult { Accepted = true, WriteAttempted = true, CommitAttempted = true, RequestId = 9, Code = "TRANSMIS", Message = "Transmis" }; }
        var result = PlayerControlExecutor.Execute(request, 123, f.Feed.Snapshot, 10, () => true, Submit, CancellationToken.None);
        Check(calls == 1 && result.Accepted && result.ModuleRequestId == 9 && result.RequestId == request.RequestId, "Valid execution lost correlation.");
        request.ExpectedPlayerId = 2;
        var wrong = PlayerControlExecutor.Execute(request, 123, f.Feed.Snapshot, 10, () => true, Submit, CancellationToken.None);
        Check(!wrong.Accepted && calls == 1, "Another player reached DMA writer.");
        request.ExpectedPlayerId = 1; request.RequestedTimestamp = Stopwatch.GetTimestamp() - 4 * Stopwatch.Frequency;
        var expired = PlayerControlExecutor.Execute(request, 123, f.Feed.Snapshot, 10, () => true, Submit, CancellationToken.None);
        Check(!expired.Accepted && calls == 1, "Expired intent reached DMA writer.");
        request.RequestedTimestamp = Stopwatch.GetTimestamp();
        using var cancellation = new CancellationTokenSource(); cancellation.Cancel();
        var cancelled = PlayerControlExecutor.Execute(request, 123, f.Feed.Snapshot, 10, () => true, Submit, cancellation.Token);
        Check(cancelled.Code == "ANNULE" && calls == 1, "Cancellation performed a write.");
        return Task.CompletedTask;
    }

    public static async Task HostCannotQueueControlsBeforeStartup()
    {
        var f = new Fixture(); f.Ready(); var request = f.Session.Begin(1, ControlOperation.SetFly, true);
        await using var host = new WorkerHost();
        try { await host.SendPlayerControlAsync(request); throw new Exception("Unstarted worker accepted a command."); }
        catch (InvalidOperationException) { }
    }

    public static Task InstallerPreservesOldVersionAndRefusesForeignFiles()
    {
        string root = Path.Combine(Path.GetTempPath(), "dma-module-test-" + Guid.NewGuid().ToString("N"));
        string package = Path.Combine(root, "package"), mods = Path.Combine(root, "data", "Mods");
        try
        {
            Directory.CreateDirectory(package);
            var firstManifest = MakePackage(package, "first");
            Expect<ArgumentException>(() => GameModuleInstaller.InstallValidated(package, Path.Combine(root, "Managed"), firstManifest, () => { }));
            var first = GameModuleInstaller.InstallValidated(package, mods, firstManifest, () => { });
            Check(File.ReadAllText(Path.Combine(first.Directory, "SevenDaysDmaControl.dll")) == "first" && first.BackupDirectory == "", "Initial install failed.");
            var secondManifest = MakePackage(package, "second");
            Expect<InvalidOperationException>(() => GameModuleInstaller.InstallValidated(package, mods, secondManifest,
                () => throw new InvalidOperationException("game started")));
            Check(File.ReadAllText(Path.Combine(first.Directory, "SevenDaysDmaControl.dll")) == "first", "Interrupted install damaged old module.");
            Expect<IOException>(() => GameModuleInstaller.InstallValidated(package, mods, secondManifest, () =>
            {
                foreach (string stage in Directory.EnumerateDirectories(Path.GetDirectoryName(mods)!, ".dma7dtd-stage-*"))
                    Directory.Delete(stage, true);
            }));
            Check(File.ReadAllText(Path.Combine(first.Directory, "SevenDaysDmaControl.dll")) == "first",
                "Failed final move did not restore the backed up installation.");
            var second = GameModuleInstaller.InstallValidated(package, mods, secondManifest, () => { });
            Check(File.ReadAllText(Path.Combine(second.Directory, "SevenDaysDmaControl.dll")) == "second" &&
                File.ReadAllText(Path.Combine(second.BackupDirectory, "SevenDaysDmaControl.dll")) == "first", "Update lost backup.");
            File.WriteAllText(Path.Combine(second.Directory, "foreign.txt"), "keep");
            Expect<IOException>(() => GameModuleInstaller.InstallValidated(package, mods, secondManifest, () => { }));
            Check(File.Exists(Path.Combine(second.Directory, "foreign.txt")), "Installer removed foreign content.");
            File.Delete(Path.Combine(second.Directory, "foreign.txt"));
            File.WriteAllText(Path.Combine(second.Directory, "SevenDaysDmaControl.dll"), "external edit");
            Expect<InvalidDataException>(() => GameModuleInstaller.InstallValidated(package, mods, secondManifest, () => { }));
            Check(File.ReadAllText(Path.Combine(second.Directory, "SevenDaysDmaControl.dll")) == "external edit", "Installer overwrote changed DLL.");
        }
        finally { if (Directory.Exists(root)) Directory.Delete(root, true); }
        return Task.CompletedTask;
    }

    private static GameModulePackage MakePackage(string directory, string content)
    {
        File.WriteAllText(Path.Combine(directory, "SevenDaysDmaControl.dll"), content);
        File.WriteAllText(Path.Combine(directory, "ModInfo.xml"), "<xml/>");
        var result = new GameModulePackage { Format = GameModuleInstaller.PackageFormat, Version = "0.13.0", GameAssemblySha256 = GameModuleInstaller.GameAssemblyHash };
        foreach (string name in new[] { "SevenDaysDmaControl.dll", "ModInfo.xml" })
            result.Files[name] = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Path.Combine(directory, name)))).ToLowerInvariant();
        return result;
    }
    private static void Check(bool value, string message) { if (!value) throw new Exception(message); }
    private static void Expect<T>(Action action) where T : Exception
    { try { action(); } catch (T) { return; } throw new Exception("Expected " + typeof(T).Name); }
}
