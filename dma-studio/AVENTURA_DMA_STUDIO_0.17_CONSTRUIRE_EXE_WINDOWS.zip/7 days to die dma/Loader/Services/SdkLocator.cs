using System;
using System.Collections.Generic;
using System.IO;

namespace SevenDaysLoader.Services;

public static class SdkLocator
{
    public static string? Find(string? preferred, string? applicationDirectory = null, string? desktopDirectory = null)
    {
        applicationDirectory ??= AppContext.BaseDirectory;
        desktopDirectory ??= Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        var candidates = new List<string?> { preferred };
        if (!string.IsNullOrWhiteSpace(applicationDirectory))
        {
            candidates.Add(Path.Combine(applicationDirectory, "MemProcFS"));
            candidates.Add(Path.Combine(applicationDirectory, "MemProcFS_files_and_binaries-win_x64-latest"));
        }
        if (!string.IsNullOrWhiteSpace(desktopDirectory))
            candidates.Add(Path.Combine(desktopDirectory, "MemProcFS_files_and_binaries-win_x64-latest"));
        foreach (string? candidate in candidates)
        {
            if (string.IsNullOrWhiteSpace(candidate)) continue;
            try
            {
                string directory = Path.GetFullPath(candidate.Trim().Trim('"'));
                if (File.Exists(Path.Combine(directory, "vmm.dll")) && File.Exists(Path.Combine(directory, "leechcore.dll")))
                    return directory;
            }
            catch (Exception ex) when (ex is ArgumentException || ex is IOException || ex is NotSupportedException || ex is UnauthorizedAccessException) { }
        }
        return null;
    }
}
