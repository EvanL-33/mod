using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace SevenDaysEsp
{
    // Original read-only inspector. Layout evidence (not a compatibility promise):
    // https://github.com/Razchek/Unispect/blob/master/Unispect/targets/v2022.json
    // https://github.com/Razchek/Unispect/blob/master/Unispect/Classes/Structs/TypeDefinition.cs
    // https://github.com/Unity-Technologies/mono/blob/unity-2022.3-mbe/mono/metadata/class-private-definition.h
    // https://github.com/Unity-Technologies/mono/blob/unity-2022.3-mbe/mono/metadata/metadata-internals.h
    // https://github.com/Unity-Technologies/mono/blob/unity-2022.3-mbe/mono/utils/mono-internal-hash.h
    // There are no remote calls, memory writes, static-value reads, or object scans.

    public sealed class MonoInspectionReport
    {
        public string Format { get; set; }
        public string CreatedUtc { get; set; }
        public string Status { get; set; }
        public string Message { get; set; }
        public bool CanRunEsp { get { return false; } }
        public string MonoModule { get; set; }
        public string RootDomain { get; set; }
        public string RootExport { get; set; }
        public string RootExportBytes { get; set; }
        public string SelectedLayout { get; set; }
        public long ElapsedMilliseconds { get; set; }
        public long BytesRead { get; set; }
        public List<MonoModuleReport> Modules { get; set; }
        public List<MonoLayoutAttempt> LayoutAttempts { get; set; }
        public List<MonoClassReport> Classes { get; set; }
        public List<string> MissingClasses { get; set; }
        public List<string> Warnings { get; set; }

        public MonoInspectionReport()
        {
            Format = "SevenDaysEsp.MonoMetadata/1";
            CreatedUtc = DateTime.UtcNow.ToString("o");
            Modules = new List<MonoModuleReport>();
            LayoutAttempts = new List<MonoLayoutAttempt>();
            Classes = new List<MonoClassReport>();
            MissingClasses = new List<string>();
            Warnings = new List<string>();
        }
    }

    public sealed class MonoModuleReport
    {
        public string Name { get; set; }
        public string BaseAddress { get; set; }
        public uint PeTimeDateStamp { get; set; }
        public uint ImageSize { get; set; }
        public string Machine { get; set; }
        public string RuntimeBuildInfo { get; set; }
        public string Note { get; set; }
    }

    public sealed class MonoLayoutAttempt
    {
        public string Layout { get; set; }
        public string Status { get; set; }
        public string Detail { get; set; }
        public int AssemblyCount { get; set; }
        public int CacheEntriesReported { get; set; }
        public int ClassRecordsChecked { get; set; }
        public int MatchingClasses { get; set; }
    }

    public sealed class MonoClassReport
    {
        public string Name { get; set; }
        public string Namespace { get; set; }
        public string Address { get; set; }
        public string MetadataToken { get; set; }
        public string Parent { get; set; }
        public int InstanceSize { get; set; }
        public int DeclaredFieldCount { get; set; }
        public bool FieldsComplete { get; set; }
        public string Issue { get; set; }
        public List<MonoFieldReport> Fields { get; set; }

        public MonoClassReport() { Fields = new List<MonoFieldReport>(); }
    }

    public sealed class MonoFieldReport
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public string TypeCode { get; set; }
        public int Offset { get; set; }
        public string OffsetHex { get; set; }
        public bool IsStatic { get; set; }
        public bool IsLiteral { get; set; }
        public string Storage { get; set; }
        public string Issue { get; set; }
    }

    public sealed class MonoInspector
    {
        private sealed class Layout
        {
            public string Name;
            public uint DomainAssemblies;
            public uint ImageClassCache;
        }

        private sealed class Candidate
        {
            public Layout Layout;
            public MonoLayoutAttempt Attempt;
            public ulong Image;
            public readonly Dictionary<string, ulong> Classes = new Dictionary<string, ulong>(StringComparer.Ordinal);
        }

        private sealed class InspectionLimitException : IOException
        {
            public InspectionLimitException(string message) : base(message) { }
        }

        private static readonly string[] WantedClasses = {
            "GameManager", "World", "Entity", "EntityAlive", "EntityPlayer",
            "EntityPlayerLocal", "EntityEnemy", "EntityZombie", "Origin", "Constants", "VersionInformation",
            "EntityStats", "EntityClass", "GamePrefs", "Progression"
        };
        private static readonly Layout[] Layouts = {
            new Layout { Name = "Unity Mono x64 2022 (candidate)", DomainAssemblies = 0xA0, ImageClassCache = 0x4D0 }
        };

        private readonly IMemoryReader memory;
        private readonly int timeBudgetMs;
        private readonly Dictionary<ulong, byte[]> pages = new Dictionary<ulong, byte[]>();
        private readonly Dictionary<ulong, string> classNames = new Dictionary<ulong, string>();
        private readonly UTF8Encoding utf8 = new UTF8Encoding(false, true);
        private Stopwatch watch;
        private long bytesRead;
        private ulong monoBase;
        private uint monoSize;
        private const int MaxPages = 8192;
        private const int MaxAssemblies = 1024;
        private const int MaxClasses = 65536;
        private const int MaxBuckets = 131072;
        private const int MaxFields = 4096;

        public MonoInspector(IMemoryReader reader) : this(reader, 20000) { }
        public MonoInspector(IMemoryReader reader, int maximumMilliseconds)
        {
            if (reader == null) throw new ArgumentNullException("reader");
            if (maximumMilliseconds < 1000 || maximumMilliseconds > 120000)
                throw new ArgumentOutOfRangeException("maximumMilliseconds");
            memory = reader;
            timeBudgetMs = maximumMilliseconds;
        }

        public MonoInspectionReport Inspect()
        {
            MonoInspectionReport report = new MonoInspectionReport();
            pages.Clear();
            classNames.Clear();
            bytesRead = 0;
            monoBase = 0;
            monoSize = 0;
            watch = Stopwatch.StartNew();
            report.Warnings.Add("Ce rapport contient des metadonnees de classes, pas un profil ESP valide ni des positions d'entites.");
            report.Warnings.Add("Les horodatages PE identifient des binaires ; ils ne donnent pas la version exacte du jeu.");
            try
            {
                foreach (string name in new string[] { "7DaysToDie.exe", "UnityPlayer.dll", "mono-2.0-bdwgc.dll" })
                {
                    CheckBudget();
                    ulong address = memory.ModuleBase(name);
                    if (address == 0) continue;
                    try
                    {
                        MonoModuleReport module = ReadModule(name, address);
                        report.Modules.Add(module);
                        if (name == "mono-2.0-bdwgc.dll")
                        {
                            monoBase = address;
                            monoSize = module.ImageSize;
                            report.MonoModule = name;
                        }
                    }
                    catch (InspectionLimitException) { throw; }
                    catch (IOException e)
                    {
                        report.Warnings.Add(name + " : entete PE illisible ou incompatible : " + e.Message);
                    }
                }
                if (monoBase == 0 || monoSize == 0)
                    return Finish(report, "MONO_NON_PRIS_EN_CHARGE", "Le module Mono x64 attendu n'a pas ete identifie. Aucune structure de jeu n'a ete supposee.");

                TryRuntimeBuildInfo(report);
                ulong rootExport = memory.ExportAddress(report.MonoModule, "mono_get_root_domain");
                report.RootExport = Hex(rootExport);
                if (!InMono(rootExport, 16))
                    return Finish(report, "EXPORT_MONO_ABSENT", "L'export mono_get_root_domain est absent ou hors du module attendu.");
                report.RootExportBytes = BitConverter.ToString(Read(rootExport, 16)).Replace("-", " ");
                ulong root = ReadRootDomain(rootExport);
                report.RootDomain = Hex(root);
                List<Candidate> matches = new List<Candidate>();
                foreach (Layout layout in Layouts)
                {
                    Candidate candidate = new Candidate();
                    candidate.Layout = layout;
                    candidate.Attempt = new MonoLayoutAttempt { Layout = layout.Name };
                    report.LayoutAttempts.Add(candidate.Attempt);
                    try
                    {
                        InspectLayout(candidate, root);
                        candidate.Attempt.Status = "COHERENT";
                        candidate.Attempt.Detail = "Assembly-CSharp et les classes GameManager, World et Entity ont ete verifies.";
                        matches.Add(candidate);
                    }
                    catch (InspectionLimitException) { throw; }
                    catch (IOException e)
                    {
                        candidate.Attempt.Status = "REJETE_OU_ILLISIBLE";
                        candidate.Attempt.Detail = e.Message;
                    }
                }
                if (matches.Count == 0)
                    return Finish(report, "LAYOUT_NON_CONFIRME", "Le layout candidat Unity Mono 2022 n'a pas passe les verifications. Le runtime peut etre different ou les classes ne pas etre chargees.");
                if (matches.Count != 1)
                    return Finish(report, "LAYOUT_AMBIGU", "Plusieurs layouts semblent coherents. Aucun profil n'est choisi automatiquement.");

                Candidate chosen = matches[0];
                report.SelectedLayout = chosen.Layout.Name;
                bool complete = true;
                foreach (string className in WantedClasses)
                {
                    ulong address;
                    if (!chosen.Classes.TryGetValue(className, out address))
                    {
                        report.MissingClasses.Add(className);
                        complete = false;
                        continue;
                    }
                    MonoClassReport item = ReadSelectedClass(address, chosen.Image);
                    report.Classes.Add(item);
                    if (!item.FieldsComplete) complete = false;
                }
                return Finish(report, complete ? "METADONNEES_COLLECTEES" : "METADONNEES_PARTIELLES",
                    "Le layout de metadonnees est coherent avec les controles effectues. Il ne valide pas la lecture de la camera, des instances ou d'un ESP.");
            }
            catch (InspectionLimitException e)
            {
                return Finish(report, "LIMITE_INSPECTION", e.Message);
            }
            catch (IOException e)
            {
                return Finish(report, "LECTURE_NON_VALIDEE", e.Message);
            }
            catch (Exception e)
            {
                // Native load/argument errors are reported too, but no raw memory is emitted.
                return Finish(report, "ERREUR_INSPECTION", e.GetType().Name + ": " + e.Message);
            }
        }

        private MonoInspectionReport Finish(MonoInspectionReport report, string status, string message)
        {
            report.Status = status;
            report.Message = message;
            report.ElapsedMilliseconds = watch.ElapsedMilliseconds;
            report.BytesRead = bytesRead;
            return report;
        }

        private MonoModuleReport ReadModule(string name, ulong address)
        {
            RequirePointer(address);
            if (U16(address) != 0x5A4D) throw new IOException("Signature MZ absente.");
            uint peOffset = U32(Add(address, 0x3C));
            if (peOffset < 0x40 || peOffset > 0x100000) throw new IOException("Offset PE invalide.");
            ulong pe = Add(address, peOffset);
            if (U32(pe) != 0x00004550 || U16(Add(pe, 4)) != 0x8664 || U16(Add(pe, 24)) != 0x20B)
                throw new IOException("Image PE32+ AMD64 attendue.");
            ushort optionalSize = U16(Add(pe, 20));
            if (optionalSize < 112) throw new IOException("En-tete optionnel PE32+ incomplet.");
            uint imageSize = U32(Add(pe, 0x50));
            if (imageSize < 4096 || imageSize > 0x40000000)
                throw new IOException("Taille d'image hors limites.");
            uint headerSize = U32(Add(pe, 0x54));
            if (headerSize < peOffset + 24U + optionalSize || headerSize > imageSize)
                throw new IOException("Taille des en-tetes PE incoherente.");
            return new MonoModuleReport {
                Name = name, BaseAddress = Hex(address), PeTimeDateStamp = U32(Add(pe, 8)),
                ImageSize = imageSize, Machine = "AMD64", Note = "Identite PE en memoire ; version produit non deduite."
            };
        }

        private ulong ReadRootDomain(ulong address)
        {
            HashSet<ulong> visited = new HashSet<ulong>();
            for (int step = 0; step < 4; step++)
            {
                if (!InMono(address, 16) || !visited.Add(address))
                    throw new IOException("Trampoline mono_get_root_domain hors limites ou cyclique.");
                byte[] code = Read(address, 16);
                int p = HasEndbr(code) ? 4 : 0;
                if (code[p] == 0x48 && code[p + 1] == 0x8B && code[p + 2] == 0x05 && code[p + 7] == 0xC3)
                {
                    ulong slot = Relative(Add(address, (uint)(p + 7)), BitConverter.ToInt32(code, p + 3));
                    if (!InMono(slot, 8)) throw new IOException("Stockage du domaine racine hors du module Mono.");
                    ulong domain = U64(slot);
                    RequirePointer(domain);
                    return domain;
                }
                if (code[p] == 0xE9)
                {
                    address = Relative(Add(address, (uint)(p + 5)), BitConverter.ToInt32(code, p + 1));
                    continue;
                }
                if (code[p] == 0xFF && code[p + 1] == 0x25)
                {
                    ulong slot = Relative(Add(address, (uint)(p + 6)), BitConverter.ToInt32(code, p + 2));
                    if (!InMono(slot, 8)) throw new IOException("Trampoline indirect hors du module Mono.");
                    address = U64(slot);
                    continue;
                }
                throw new IOException("Forme native de mono_get_root_domain non prise en charge ; aucun code distant n'a ete execute.");
            }
            throw new IOException("Trop de trampolines pour mono_get_root_domain.");
        }

        private void TryRuntimeBuildInfo(MonoInspectionReport report)
        {
            // Only the simple, side-effect-free machine-code shape is interpreted.
            // No function pointer is ever invoked in the target or the reader process.
            try
            {
                ulong function = memory.ExportAddress(report.MonoModule, "mono_get_runtime_build_info");
                if (!InMono(function, 16)) return;
                byte[] code = Read(function, 16);
                int p = HasEndbr(code) ? 4 : 0;
                if (code[p] != 0x48 || code[p + 1] != 0x8D || code[p + 2] != 0x05 || code[p + 7] != 0xC3) return;
                ulong textAddress = Relative(Add(function, (uint)(p + 7)), BitConverter.ToInt32(code, p + 3));
                if (!InMono(textAddress, 1)) return;
                string build = CString(textAddress, 256, false);
                foreach (MonoModuleReport module in report.Modules)
                    if (module.Name == report.MonoModule) module.RuntimeBuildInfo = build;
            }
            catch (InspectionLimitException) { throw; }
            catch (IOException) { }
        }

        private void InspectLayout(Candidate candidate, ulong root)
        {
            ulong node = U64(Add(root, candidate.Layout.DomainAssemblies));
            HashSet<ulong> assemblyNodes = new HashSet<ulong>();
            int images = 0;
            while (node != 0)
            {
                RequirePointer(node);
                if (!assemblyNodes.Add(node) || assemblyNodes.Count > MaxAssemblies)
                    throw new IOException("Liste d'assemblies cyclique ou trop grande.");
                ulong assembly = U64(node);
                RequirePointer(assembly);
                string name = CString(U64(Add(assembly, 0x10)), 256, false);
                if (name == "Assembly-CSharp")
                {
                    candidate.Image = U64(Add(assembly, 0x60));
                    RequirePointer(candidate.Image);
                    images++;
                }
                node = U64(Add(node, 8));
            }
            candidate.Attempt.AssemblyCount = assemblyNodes.Count;
            if (images != 1) throw new IOException("Une unique assembly Assembly-CSharp n'a pas ete trouvee.");

            ulong cache = Add(candidate.Image, candidate.Layout.ImageClassCache);
            for (uint i = 0; i < 3; i++)
                if (!InMono(U64(Add(cache, i * 8)), 1))
                    throw new IOException("Fonctions du cache de classes incoherentes avec le module Mono.");
            int buckets = I32(Add(cache, 0x18));
            int entries = I32(Add(cache, 0x1C));
            ulong table = U64(Add(cache, 0x20));
            if (buckets <= 0 || buckets > MaxBuckets || entries < 3 || entries > MaxClasses)
                throw new IOException("Dimensions du cache de classes incompatibles.");
            RequirePointer(table);
            candidate.Attempt.CacheEntriesReported = entries;
            HashSet<ulong> classNodes = new HashSet<ulong>();
            for (uint bucket = 0; bucket < (uint)buckets; bucket++)
            {
                ulong klass = U64(Add(table, bucket * 8));
                while (klass != 0)
                {
                    if (!classNodes.Add(klass) || classNodes.Count > MaxClasses)
                        throw new IOException("Cache de classes cyclique, modifie ou trop grand.");
                    byte[] data = Read(klass, 0x110);
                    byte kind = data[0x1B];
                    uint token = BitConverter.ToUInt32(data, 0x58);
                    if ((kind != 1 && kind != 2) || (token & 0xFF000000) != 0x02000000 || (token & 0x00FFFFFF) == 0 ||
                        BitConverter.ToUInt64(data, 0x40) != candidate.Image)
                        throw new IOException("Identite d'une classe incoherente avec l'assembly cible.");
                    string name = CString(BitConverter.ToUInt64(data, 0x48), 512, false);
                    if (IsWanted(name))
                    {
                        string nameSpace = CString(BitConverter.ToUInt64(data, 0x50), 256, true);
                        // These game classes are expected in the global namespace.
                        if (nameSpace.Length == 0)
                        {
                            if (candidate.Classes.ContainsKey(name))
                                throw new IOException("Nom de classe cible ambigu : " + name);
                            candidate.Classes.Add(name, klass);
                        }
                    }
                    klass = BitConverter.ToUInt64(data, 0x108);
                }
            }
            candidate.Attempt.ClassRecordsChecked = classNodes.Count;
            candidate.Attempt.MatchingClasses = candidate.Classes.Count;
            if (classNodes.Count != entries)
                throw new IOException("Le nombre de classes a change ou la lecture du cache est incomplete. Relance une fois le chargement termine.");
            if (!candidate.Classes.ContainsKey("GameManager") || !candidate.Classes.ContainsKey("World") || !candidate.Classes.ContainsKey("Entity"))
                throw new IOException("Les trois classes de controle GameManager, World et Entity ne sont pas toutes presentes.");
            foreach (string key in new string[] { "GameManager", "World", "Entity" })
                ValidateSelectedClass(candidate.Classes[key], candidate.Image);
        }

        private void ValidateSelectedClass(ulong address, ulong image)
        {
            byte[] data = Read(address, 0x110);
            int instanceSize = BitConverter.ToInt32(data, 0x1C);
            int count = BitConverter.ToInt32(data, 0x100);
            if (BitConverter.ToUInt64(data, 0x40) != image || data[0x1B] != 1 ||
                instanceSize < 16 || instanceSize > 1048576 || count < 0 || count > MaxFields)
                throw new IOException("Structure d'une classe cible incompatible.");
            if (count > 0) RequirePointer(BitConverter.ToUInt64(data, 0x98));
        }

        private MonoClassReport ReadSelectedClass(ulong address, ulong image)
        {
            MonoClassReport item = new MonoClassReport { Address = Hex(address) };
            try
            {
                ValidateSelectedClass(address, image);
                byte[] data = Read(address, 0x110);
                item.Name = CString(BitConverter.ToUInt64(data, 0x48), 512, false);
                item.Namespace = CString(BitConverter.ToUInt64(data, 0x50), 256, true);
                item.MetadataToken = "0x" + BitConverter.ToUInt32(data, 0x58).ToString("X8");
                item.InstanceSize = BitConverter.ToInt32(data, 0x1C);
                item.DeclaredFieldCount = BitConverter.ToInt32(data, 0x100);
                ulong parent = BitConverter.ToUInt64(data, 0x30);
                item.Parent = parent == 0 ? null : ClassName(parent);
                ulong fields = BitConverter.ToUInt64(data, 0x98);
                HashSet<string> names = new HashSet<string>(StringComparer.Ordinal);
                bool allTypesResolved = true;
                for (uint index = 0; index < (uint)item.DeclaredFieldCount; index++)
                {
                    byte[] field = Read(Add(fields, index * 32), 32);
                    if (BitConverter.ToUInt64(field, 16) != address)
                        throw new IOException("Parent d'un champ incoherent.");
                    string fieldName = CString(BitConverter.ToUInt64(field, 8), 512, false);
                    if (!names.Add(fieldName)) throw new IOException("Noms de champs dupliques.");
                    ulong typePointer = BitConverter.ToUInt64(field, 0);
                    byte[] type = Read(typePointer, 16);
                    ushort flags = BitConverter.ToUInt16(type, 8);
                    int offset = BitConverter.ToInt32(field, 24);
                    bool isStatic = (flags & 0x10) != 0;
                    bool isLiteral = (flags & 0x40) != 0;
                    if (offset < -1 || offset > 1048576 || (!isStatic && (offset < 16 || offset >= item.InstanceSize)))
                        throw new IOException("Offset de champ hors limites.");
                    MonoFieldReport fieldReport = new MonoFieldReport {
                        Name = fieldName, Offset = offset,
                        OffsetHex = offset < 0 ? "-1" : "0x" + offset.ToString("X"),
                        IsStatic = isStatic, IsLiteral = isLiteral,
                        TypeCode = "0x" + type[10].ToString("X2"),
                        Storage = isLiteral ? "constante de metadonnees" : (isStatic ? (offset == -1 ? "statique special" : "stockage statique de classe") : "depuis le debut de l'objet")
                    };
                    try
                    {
                        fieldReport.Type = TypeName(typePointer, 0, new HashSet<ulong>());
                        if (fieldReport.Type.IndexOf("non resolu", StringComparison.Ordinal) >= 0 ||
                            fieldReport.Type.StartsWith("parametre generique", StringComparison.Ordinal))
                        {
                            fieldReport.Issue = "Description partielle du type ; les arguments, le rang ou le contexte generique restent a resoudre.";
                            allTypesResolved = false;
                        }
                    }
                    catch (InspectionLimitException) { throw; }
                    catch (IOException e)
                    {
                        fieldReport.Type = "non resolu";
                        fieldReport.Issue = e.Message;
                        allTypesResolved = false;
                    }
                    item.Fields.Add(fieldReport);
                }
                item.FieldsComplete = allTypesResolved;
                if (!allTypesResolved) item.Issue = "Certains types de champs n'ont pas ete resolus ; consulter Issue sur ces champs.";
            }
            catch (InspectionLimitException) { throw; }
            catch (IOException e)
            {
                item.FieldsComplete = false;
                item.Issue = e.Message;
            }
            return item;
        }

        private string TypeName(ulong address, int depth, HashSet<ulong> visited)
        {
            if (depth > 4 || !visited.Add(address)) throw new IOException("Type recursif ou trop profond.");
            byte[] type = Read(address, 16);
            ulong data = BitConverter.ToUInt64(type, 0);
            byte code = type[10];
            switch (code)
            {
                case 0x01: return "System.Void";
                case 0x02: return "System.Boolean";
                case 0x03: return "System.Char";
                case 0x04: return "System.SByte";
                case 0x05: return "System.Byte";
                case 0x06: return "System.Int16";
                case 0x07: return "System.UInt16";
                case 0x08: return "System.Int32";
                case 0x09: return "System.UInt32";
                case 0x0A: return "System.Int64";
                case 0x0B: return "System.UInt64";
                case 0x0C: return "System.Single";
                case 0x0D: return "System.Double";
                case 0x0E: return "System.String";
                case 0x0F: return TypeName(data, depth + 1, visited) + "*";
                case 0x10: return TypeName(data, depth + 1, visited) + "&";
                case 0x11: case 0x12: return ClassName(data);
                case 0x13: return "parametre generique de type";
                case 0x14: return ClassName(U64(data)) + "[rang non resolu]";
                case 0x15: return ClassName(U64(data)) + " [arguments generiques non resolus]";
                case 0x16: return "System.TypedReference";
                case 0x18: return "System.IntPtr";
                case 0x19: return "System.UIntPtr";
                case 0x1B: return "pointeur de fonction";
                case 0x1C: return "System.Object";
                case 0x1D: return ClassName(data) + "[]";
                case 0x1E: return "parametre generique de methode";
                default: throw new IOException("Code MonoType non pris en charge : 0x" + code.ToString("X2"));
            }
        }

        private string ClassName(ulong address)
        {
            string cached;
            if (classNames.TryGetValue(address, out cached)) return cached;
            byte[] data = Read(address, 0x60);
            int kind = data[0x1B];
            if (kind < 1 || kind > 6) throw new IOException("Genre de classe Mono non reconnu.");
            string name = CString(BitConverter.ToUInt64(data, 0x48), 512, false);
            string ns = CString(BitConverter.ToUInt64(data, 0x50), 256, true);
            cached = ns.Length == 0 ? name : ns + "." + name;
            if (classNames.Count > 8192) throw new InspectionLimitException("Limite de noms de types atteinte.");
            classNames.Add(address, cached);
            return cached;
        }

        private byte[] Read(ulong address, int count)
        {
            CheckBudget();
            RequirePointer(address);
            if (count < 1 || count > 1048576 || address > 0x00007FFFFFFFFFFFUL - (ulong)count)
                throw new IOException("Plage de lecture invalide.");
            byte[] result = new byte[count];
            int done = 0;
            while (done < count)
            {
                ulong current = address + (uint)done;
                ulong page = current & ~4095UL;
                byte[] data;
                if (!pages.TryGetValue(page, out data))
                {
                    CheckBudget();
                    if (pages.Count >= MaxPages) throw new InspectionLimitException("Budget de lecture de metadonnees atteint (32 Mio).");
                    data = memory.Read(page, 4096);
                    if (data == null || data.Length != 4096) throw new IOException("Lecture de page incomplete.");
                    bytesRead += 4096;
                    pages.Add(page, data);
                }
                int offset = (int)(current - page);
                int length = Math.Min(count - done, 4096 - offset);
                Buffer.BlockCopy(data, offset, result, done, length);
                done += length;
            }
            return result;
        }

        private string CString(ulong address, int maximumBytes, bool allowEmpty)
        {
            RequirePointer(address);
            List<byte> bytes = new List<byte>();
            for (int i = 0; i < maximumBytes; i++)
            {
                byte b = Read(Add(address, (uint)i), 1)[0];
                if (b == 0)
                {
                    if (bytes.Count == 0 && !allowEmpty) throw new IOException("Nom de metadonnee vide.");
                    string result;
                    try { result = utf8.GetString(bytes.ToArray()); }
                    catch (DecoderFallbackException) { throw new IOException("Nom de metadonnee UTF-8 invalide."); }
                    foreach (char c in result)
                        if (char.IsControl(c)) throw new IOException("Caractere de controle dans une metadonnee.");
                    return result;
                }
                bytes.Add(b);
            }
            throw new IOException("Nom de metadonnee sans terminaison dans la limite autorisee.");
        }

        private void CheckBudget()
        {
            if (watch != null && watch.ElapsedMilliseconds > timeBudgetMs)
                throw new InspectionLimitException("Budget de temps atteint. Ce budget est controle entre les appels natifs ; il ne peut pas interrompre un pilote bloque.");
        }

        private static bool HasEndbr(byte[] code)
        {
            return code[0] == 0xF3 && code[1] == 0x0F && code[2] == 0x1E && code[3] == 0xFA;
        }
        private static bool IsWanted(string name)
        {
            foreach (string item in WantedClasses) if (name == item) return true;
            return false;
        }
        private bool InMono(ulong address, uint count)
        {
            return monoBase != 0 && address >= monoBase && count <= monoSize && address - monoBase <= monoSize - count;
        }
        private static void RequirePointer(ulong value)
        {
            if (value < 0x10000 || value > 0x00007FFFFFFFFFFFUL) throw new IOException("Pointeur utilisateur x64 invalide.");
        }
        private static ulong Add(ulong value, uint offset)
        {
            if (value > ulong.MaxValue - offset) throw new IOException("Depassement d'adresse.");
            return value + offset;
        }
        private static ulong Relative(ulong nextInstruction, int displacement)
        {
            long result = checked((long)nextInstruction + displacement);
            if (result < 0) throw new IOException("Deplacement relatif invalide.");
            return (ulong)result;
        }
        private ushort U16(ulong address) { return BitConverter.ToUInt16(Read(address, 2), 0); }
        private uint U32(ulong address) { return BitConverter.ToUInt32(Read(address, 4), 0); }
        private int I32(ulong address) { return BitConverter.ToInt32(Read(address, 4), 0); }
        private ulong U64(ulong address) { return BitConverter.ToUInt64(Read(address, 8), 0); }
        private static string Hex(ulong address) { return "0x" + address.ToString("X16"); }
    }
}
