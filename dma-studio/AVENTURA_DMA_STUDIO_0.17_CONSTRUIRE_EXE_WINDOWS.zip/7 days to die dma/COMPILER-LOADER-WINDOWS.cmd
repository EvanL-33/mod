@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>&1
if errorlevel 1 (
  echo Il faut installer le SDK .NET 10 pour compiler les sources sur Windows.
  echo Aucun executable n'a ete modifie.
  pause
  exit /b 1
)
dotnet --version
if errorlevel 1 exit /b 1
REM Verifier d'abord les tests des services (aucun materiel DMA necessaire)
dotnet run --project "Loader\Tests\ServiceTests.csproj" --configuration Release
if errorlevel 1 (
  echo Tests des services en echec. Publication annulee.
  pause
  exit /b 1
)
dotnet run --project "Loader\Tests\Controller\ControllerTests.csproj" --configuration Release
if errorlevel 1 (
  echo Tests de controle en echec. Publication annulee.
  pause
  exit /b 1
)
dotnet publish "Loader\7DTD-Loader.csproj" -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
if errorlevel 1 (
  echo Erreur de compilation. Ne remplace pas l'ancien executable.
  pause
  exit /b 1
)
echo.
echo Executable compile dans : Loader\bin\Release\net10.0-windows\win-x64\publish\
echo Verifie son fonctionnement hors ligne avant de remplacer ton loader.
pause
endlocal
