using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using SevenDaysLoader.Services;

namespace SevenDaysLoader.UI;

// This is an actual horizontal map. It never turns positions into screen-space
// boxes without a validated camera matrix, and never generates example entities.
internal sealed class RadarControl : FrameworkElement
{
    private readonly ILoaderController controller;
    private readonly Dictionary<string, Brush> colors = new(StringComparer.OrdinalIgnoreCase);
    internal RadarControl(ILoaderController controller) { this.controller = controller; MinWidth = 180; MinHeight = 180; }

    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);
        double w = ActualWidth, h = ActualHeight;
        if (w < 80 || h < 80) return;
        var settings = controller.Settings;
        double mapHeight = Math.Max(80, h - (settings.ShowRadarCounts ? 56 : 0));
        double radius = Math.Max(20, Math.Min(w, mapHeight) / 2 - 30);
        var center = new Point(w / 2, mapHeight / 2);
        var sample = controller.CurrentFrame;
        var visuals = new PlayerVisualLookup(controller.Players.ReadSnapshot());
        var summary = RadarSummary.Create(settings, sample, visuals);
        int radarRange = summary.RangeMeters;
        var line = new Pen(Theme.Line, 1);
        dc.DrawRoundedRectangle(Theme.Background, null, new Rect(0, 0, w, h), 10, 10);
        for (int i = 1; i <= 4; i++) dc.DrawEllipse(null, line, center, radius * i / 4, radius * i / 4);
        dc.DrawLine(line, new Point(center.X - radius, center.Y), new Point(center.X + radius, center.Y));
        dc.DrawLine(line, new Point(center.X, center.Y - radius), new Point(center.X, center.Y + radius));
        DrawText(dc, "+Z", new Point(center.X - 8, center.Y - radius - 23), Theme.Muted, 11);
        DrawText(dc, "+X", new Point(center.X + radius + 5, center.Y - 8), Theme.Muted, 11);
        DrawText(dc, "−Z", new Point(center.X - 8, center.Y + radius + 6), Theme.Muted, 11);
        DrawText(dc, radarRange + " m", new Point(10, 8), Theme.Muted, 11);
        if (settings.ShowRadarCounts) DrawCounters(dc, summary, h - 56, w);
        if (!summary.HasCurrentData)
        {
            string message = !controller.Settings.EspEnabled ? "AFFICHAGE DÉSACTIVÉ" :
                !controller.Settings.ShowRadar ? "RADAR MASQUÉ" : "EN ATTENTE DE DONNÉES";
            var text = Format(message, Theme.Muted, 12);
            dc.DrawRoundedRectangle(Theme.Surface, line, new Rect(center.X - text.Width / 2 - 12, center.Y - 18, text.Width + 24, 36), 6, 6);
            dc.DrawText(text, new Point(center.X - text.Width / 2, center.Y - text.Height / 2));
            return;
        }
        // Far dots first; nearer labels are less likely to be obscured. Label only
        // the 16 nearest targets to keep a dense radar readable.
        var near = summary.Targets.Where(d => d.Profile.ShowNames || d.Profile.ShowDistances ||
            d.Profile.Rules?.ShowHeightIndicator == true ||
            (d.Entity.Kind == "player" ? PvpSenseLabels.WantsPlayerLabel(settings.PvpSense) :
                PvpSenseLabels.WantsZombieLabel(settings.PvpSense)))
            .OrderByDescending(d => PlayerVisualLookup.Priority(d.Visual)).ThenBy(d => d.DistanceMeters)
            .ThenBy(d => d.Entity.EntityId).Take(16).Select(d => d.Entity.EntityId).ToHashSet();
        foreach (var dot in summary.Targets.OrderBy(d => PlayerVisualLookup.Priority(d.Visual)).ThenByDescending(d => d.DistanceMeters))
        {
            var profile = dot.Profile;
            Point p = new(center.X + dot.X / radarRange * radius, center.Y - dot.Z / radarRange * radius);
            string? highlightedColor = dot.Visual.Color;
            if (dot.Entity.Kind == "player" && settings.AdminWatch?.PurpleEsp == true &&
                AdminWatchMatcher.IsListed(settings.AdminWatch, dot.Entity.Name) && string.IsNullOrEmpty(highlightedColor))
                highlightedColor = settings.AdminWatch.Color;
            Brush color = SafeBrush(EntityDisplayRules.ResolveColor(profile, dot.DistanceMeters,
                dot.Entity.Health, dot.Entity.MaxHealth, highlightedColor), dot.Entity.Kind == "player" ? Theme.Cyan : Theme.Orange);
            dc.DrawEllipse(color, new Pen(Theme.Background, 1), p, dot.Entity.Kind == "player" ? 4.5 : 3.5, dot.Entity.Kind == "player" ? 4.5 : 3.5);
            if (PlayerVisualLookup.Priority(dot.Visual) > 0)
                dc.DrawEllipse(null, new Pen(color, dot.Visual.Pinned ? 2 : 1), p, 7, 7);
            if (dot.Entity.Kind == "zombie" && settings.PvpSense.ShowZombieTarget &&
                dot.Entity.ZombieTargetsLocal == true)
                dc.DrawEllipse(null, new Pen(Theme.Orange, 2), p, 8, 8);
            if (!near.Contains(dot.Entity.EntityId)) continue;
            string label = profile.ShowNames ? CleanName(dot.Entity.Name) : "";
            if (label.Length > 0 && dot.Visual.Marked) label = "★ " + label;
            if (profile.ShowDistances) label += (label.Length > 0 ? " · " : "") + Math.Round(dot.DistanceMeters) + " m";
            if (profile.Rules?.ShowHeightIndicator == true)
            {
                string height = EntityDisplayRules.HeightIndicator(dot.HeightMeters);
                if (height.Length > 0) label += (label.Length > 0 ? " · " : "") + height;
            }
            if (dot.Entity.Kind == "player")
                label = PvpSenseLabels.Append(label, PvpSenseLabels.ForPlayer(settings.PvpSense,
                    dot.Entity.IsRunning, dot.Entity.IsCrouching, dot.Entity.IsJumping,
                    dot.Entity.HeldItemTypeId, PvpSenseMath.AngleToLocal(
                        dot.Entity.BodyYawDegrees, dot.Entity.Position, sample!.Snapshot.LocalPosition)));
            else if (dot.Entity.Kind == "zombie")
                label = PvpSenseLabels.Append(label,
                    PvpSenseLabels.ForZombie(settings.PvpSense, dot.Entity.ZombieTargetsLocal));
            if (label.Length == 0) continue;
            var text = Format(label, color, Math.Clamp(profile.FontSize - 2, 10, 18));
            double x = Math.Clamp(p.X + 7, 4, Math.Max(4, w - text.Width - 4));
            double y = Math.Clamp(p.Y - 8, 4, Math.Max(4, mapHeight - text.Height - 4));
            dc.DrawRoundedRectangle(Theme.Background, null, new Rect(x - 2, y, text.Width + 4, text.Height), 2, 2);
            dc.DrawText(text, new Point(x, y));
        }
        dc.DrawEllipse(Theme.Foreground, new Pen(Theme.Background, 2), center, 5, 5);
        dc.DrawLine(new Pen(Theme.Foreground, 2), new Point(center.X, center.Y - 7), new Point(center.X, center.Y + 7));
    }

    private void DrawCounters(DrawingContext dc, RadarSummary summary, double top, double width)
    {
        dc.DrawRoundedRectangle(Theme.Surface, null, new Rect(4, top, Math.Max(1, width - 8), 52), 6, 6);
        DrawText(dc, "Détections J / Z · horizontal", new Point(10, top + 3), Theme.Muted, 9);
        double column = Math.Max(1, (width - 16) / 3);
        for (int i = 0; i < summary.Bands.Count; i++)
        {
            var band = summary.Bands[i];
            int nominalEnd = i == 0 ? 25 : i == 1 ? 50 : 100;
            string range = band.FromMeters + "–" + (band.IsAvailable ? band.ToMeters : nominalEnd) + " m";
            string count = summary.HasCurrentData && band.IsAvailable ? band.Players + " / " + band.Zombies : "—";
            var heading = Format(range, Theme.Muted, 9);
            var value = Format(count, summary.HasCurrentData && band.IsAvailable ? Theme.Foreground : Theme.Muted, width < 230 ? 10 : 12);
            heading.MaxTextWidth = value.MaxTextWidth = Math.Max(1, column - 4);
            double middle = 8 + column * (i + .5);
            dc.DrawText(heading, new Point(middle - heading.Width / 2, top + 17));
            dc.DrawText(value, new Point(middle - value.Width / 2, top + 30));
        }
    }

    internal static string CleanName(string? name)
    {
        if (string.IsNullOrWhiteSpace(name)) return "Entité";
        var clean = new string(name.Where(c => !char.IsControl(c)).Take(32).ToArray());
        return clean;
    }
    private Brush SafeBrush(string value, Brush fallback)
    {
        if (string.IsNullOrEmpty(value)) return fallback;
        if (colors.TryGetValue(value, out var cached)) return cached;
        try
        {
            var brush = Theme.Brush(value);
            if (colors.Count >= 128) colors.Clear();
            colors[value] = brush;
            return brush;
        }
        catch (FormatException) { return fallback; }
        catch (ArgumentException) { return fallback; }
        catch (NotSupportedException) { return fallback; }
    }
    private FormattedText Format(string value, Brush brush, double size) => new(value, CultureInfo.GetCultureInfo("fr-FR"),
        FlowDirection.LeftToRight, new Typeface("Segoe UI"), size, brush, VisualTreeHelper.GetDpi(this).PixelsPerDip)
        {
            MaxTextWidth = Math.Max(1, ActualWidth - 16), MaxLineCount = 1, Trimming = TextTrimming.CharacterEllipsis
        };
    private void DrawText(DrawingContext dc, string text, Point position, Brush brush, double size) => dc.DrawText(Format(text, brush, size), position);
}
