using System;
using System.Reflection;
using System.Threading;
using SevenDaysDmaControl;
using UnityEngine;

internal static class GameActionsTests
{
    private static int assertions;
    private static int scenarios;
    private static void Main()
    {
        Run(ProfileIsRequired);
        Run(NativeModesRestore);
        Run(ExternalSpeedIsPreserved);
        Run(GodDoesNotOverwriteExternalMovement);
        Run(ThirdPersonCameraRestores);
        Run(PartialFreeCameraIsNotReportedApplied);
        Run(ScopeCameraIsRejected);
        Run(SpectatorExternalVisibilityIsPreserved);
        Run(SpectatorRestoresOriginalAiState);
        Run(ContextChangeDropsOwnership);
        Run(DeathDoesNotReplayModes);
        Run(TeleportNeedsObservedTransition);
        Run(TeleportDoesNotCrossWorlds);
        Run(InputsAreBounded);
        Console.WriteLine("PASS: " + scenarios + " GameActions scenarios, " + assertions + " assertions; game/Unity doubles only.");
    }
    private static void Run(Action action) { action(); scenarios++; }
    private static void Assert(bool condition, string message)
    { assertions++; if (!condition) throw new InvalidOperationException(message); }
    private static void Applied(GameActionResult result) { Assert(result.Status == ControlStatus.AppliedLocal, result.Message); }
    private static void Refused(GameActionResult result) { Assert(result.Status == ControlStatus.Refused, result.Message); }

    private static void ProfileIsRequired()
    {
        var f = new Fixture(false);
        Assert(f.Actions.Observe().Availability == BridgeAvailability.Incompatible, "Unknown assembly must be incompatible.");
    }
    private static void NativeModesRestore()
    {
        var f = new Fixture();
        Applied(f.Do(ControlOperation.SetFly, true)); Assert(f.Player.IsFlyMode.Value, "fly on");
        Applied(f.Do(ControlOperation.SetNoclip, true)); Assert(f.Player.IsFlyMode.Value && f.Player.IsNoCollisionMode.Value, "noclip dependency");
        Applied(f.Do(ControlOperation.SetSpeed, value: 3f));
        Applied(f.Do(ControlOperation.SetNightBrightness, value: 0.75f)); Assert(f.World.m_WorldEnvironment.NightCalls == 1, "native night setter");
        Applied(f.Do(ControlOperation.SetGod, true)); Assert(f.Player.NativeGodCalls == 1, "native God action");
        Applied(f.Do(ControlOperation.SetSpectator, true)); Assert(!f.Player.emodel.visible && f.Player.isIgnoredByAI, "native spectator effects");
        Applied(f.Do(ControlOperation.RestoreOwned));
        Assert(!f.Player.IsFlyMode.Value && !f.Player.IsNoCollisionMode.Value && !f.Player.IsGodMode.Value, "movement baseline");
        Assert(f.Player.NativeGodCalls == 2, "restore uses native God action");
        Assert(f.Player.GodModeSpeedModifier == 1f && f.World.m_WorldEnvironment.nightVisionBrightness == 0.08f, "scalar baselines");
        Assert(!f.Player.IsSpectator && f.Player.emodel.visible && !f.Player.isIgnoredByAI, "spectator baseline");
        Assert(f.Actions.Observe().OwnedOperations == 0, "ownership released");
    }
    private static void ExternalSpeedIsPreserved()
    {
        var f = new Fixture(); Applied(f.Do(ControlOperation.SetSpeed, value: 5f));
        f.Player.GodModeSpeedModifier = 7f;
        Applied(f.Do(ControlOperation.RestoreOwned));
        Assert(f.Player.GodModeSpeedModifier == 7f, "restore must preserve external speed");
        Applied(f.Do(ControlOperation.SetSpeed, value: 4f));
        Applied(f.Do(ControlOperation.RestoreOwned));
        Assert(f.Player.GodModeSpeedModifier == 7f, "new explicit action captures the latest external baseline");
    }
    private static void GodDoesNotOverwriteExternalMovement()
    {
        var f = new Fixture(); Applied(f.Do(ControlOperation.SetGod, true));
        f.Player.IsNoCollisionMode.Value = false;
        Applied(f.Do(ControlOperation.RestoreOwned));
        Assert(f.Player.NativeGodCalls == 1 && f.Player.IsGodMode.Value, "cannot call coupled God restoration after external group change");
        Assert(!f.Player.IsNoCollisionMode.Value, "external noclip is preserved");
    }
    private static void ThirdPersonCameraRestores()
    {
        var f = new Fixture(); f.Player.bFirstPersonView = false; f.Player.cameraTransform.parent = null;
        Applied(f.Do(ControlOperation.SetFreeCamera, true));
        Assert(f.Player.ClearMovementCalls == 1, "clear character input before free camera");
        Assert(f.Player.movementInput.bDetachedCameraMove && f.Player.vp_FPCamera.Locked3rdPerson, "free camera active");
        Applied(f.Do(ControlOperation.SetFreeCamera, false));
        Assert(!f.Player.LastCameraAttached && f.Player.cameraTransform.parent == null, "normal TPV remains detached");
        Assert(!f.Player.movementInput.bDetachedCameraMove && !f.Player.vp_FPCamera.Locked3rdPerson, "normal TPV flags restored");
        int calls = f.Player.CameraCalls; Applied(f.Do(ControlOperation.SetFreeCamera, false));
        Assert(f.Player.CameraCalls == calls, "already normal TPV is a no-op");
    }
    private static void ScopeCameraIsRejected()
    {
        var f = new Fixture(); f.Player.cameraTransform.parent = new Transform();
        Refused(f.Do(ControlOperation.SetFreeCamera, true));
        Assert(f.Player.CameraCalls == 0 && f.Player.ClearMovementCalls == 0, "scope not modified");
    }
    private static void PartialFreeCameraIsNotReportedApplied()
    {
        var f = new Fixture(); f.Player.cameraTransform.parent = null;
        f.Player.movementInput.bDetachedCameraMove = true;
        Assert((f.Actions.Observe().Flags & ControlFlags.FreeCamera) == 0, "unlocked detached camera is not complete free camera");
        Applied(f.Do(ControlOperation.SetFreeCamera, true));
        Assert(f.Player.CameraCalls == 1 && f.Player.vp_FPCamera.Locked3rdPerson, "partial free camera is repaired by native method");
    }
    private static void SpectatorExternalVisibilityIsPreserved()
    {
        var f = new Fixture(); Applied(f.Do(ControlOperation.SetSpectator, true));
        f.Player.emodel.visible = true;
        Applied(f.Do(ControlOperation.RestoreOwned));
        Assert(f.Player.NativeSpectatorCalls == 1 && f.Player.emodel.visible, "external visibility not overwritten by spectator restore");
    }
    private static void SpectatorRestoresOriginalAiState()
    {
        var f = new Fixture(); f.Player.isIgnoredByAI = true;
        Applied(f.Do(ControlOperation.SetSpectator, true)); Applied(f.Do(ControlOperation.RestoreOwned));
        Assert(!f.Player.IsSpectator && f.Player.isIgnoredByAI && f.Player.emodel.visible, "independent pre-existing ignore-AI state restored");
    }
    private static void ContextChangeDropsOwnership()
    {
        var f = new Fixture(); Applied(f.Do(ControlOperation.SetSpeed, value: 4f));
        var old = f.Actions.Observe(); var oldPlayer = f.Player;
        f.ResetWorld(); var current = f.Actions.Observe();
        Assert(current.ContextId != old.ContextId && current.OwnedOperations == 0, "new world gets fresh context");
        Assert(f.Player.GodModeSpeedModifier == 1f && oldPlayer.GodModeSpeedModifier == 4f, "old object never restored or replayed");
        var stale = new ControlRequest { ContextId = old.ContextId, PlayerId = old.PlayerId, Operation = ControlOperation.SetSpeed, Value = 8f };
        Refused(f.Actions.Execute(stale, current));
    }
    private static void DeathDoesNotReplayModes()
    {
        var f = new Fixture(); Applied(f.Do(ControlOperation.SetGod, true)); var before = f.Actions.Observe();
        f.Player.Dead = true; var dead = f.Actions.Observe();
        Assert(!dead.IsReady && dead.ContextId != before.ContextId && dead.OwnedOperations == 0, "death drops ownership");
        f.Player.Dead = false; f.Player.Spawned = false;
        f.Player.IsGodMode.Value = false; f.Player.IsFlyMode.Value = false; f.Player.IsNoCollisionMode.Value = false;
        f.Actions.Observe(); f.Player.Spawned = true; var after = f.Actions.Observe();
        Assert(after.IsReady && after.ContextId != dead.ContextId, "respawn has another fresh context");
        Assert(!f.Player.IsGodMode.Value && f.Player.NativeGodCalls == 1, "no automatic mode replay");
    }
    private static void TeleportNeedsObservedTransition()
    {
        var f = new Fixture(); var req = f.Request(ControlOperation.Teleport); req.PositionX = 20; req.PositionY = 65; req.PositionZ = 30;
        var result = f.Actions.Execute(req, f.Actions.Observe());
        Assert(result.Status == ControlStatus.Pending && f.Player.TeleportCalls == 1, "native TP queued once");
        var loading = f.Actions.Observe();
        Assert(loading.IsReady && (loading.Flags & ControlFlags.Teleporting) != 0, "own TP keeps polling context ready");
        Refused(f.Do(ControlOperation.RestoreOwned));
        Assert(f.Player.TeleportCalls == 1 && !f.Player.Spawned, "restore during loading never claims success or forces respawn");
        Assert(f.Actions.Poll(req.RequestId, loading).Status == ControlStatus.Pending, "not applied before spawn");
        f.Player.Spawned = true; Thread.Sleep(260); Time.frameCount++;
        Assert(f.Actions.Poll(req.RequestId, f.Actions.Observe()).Status == ControlStatus.Pending, "one observed frame is insufficient");
        Time.frameCount++; Applied(f.Actions.Poll(req.RequestId, f.Actions.Observe()));
        f.Actions.Release(f.Actions.Observe());
        Assert(f.Player.position == new Vector3(20, 65, 30) && f.Player.TeleportCalls == 1, "release never teleports back or retries");
    }
    private static void TeleportDoesNotCrossWorlds()
    {
        var f = new Fixture(); var req = f.Request(ControlOperation.Teleport); req.PositionY = 65;
        Assert(f.Actions.Execute(req, f.Actions.Observe()).Status == ControlStatus.Pending, "TP pending");
        f.ResetWorld(); var next = f.Actions.Observe();
        Refused(f.Actions.Poll(req.RequestId, next)); Assert(f.Player.TeleportCalls == 0, "no TP replay into next world");
    }
    private static void InputsAreBounded()
    {
        var f = new Fixture();
        Refused(f.Do(ControlOperation.SetSpeed, value: float.NaN)); Refused(f.Do(ControlOperation.SetSpeed, value: 15.01f));
        Applied(f.Do(ControlOperation.SetSpeed, value: 15f));
        Refused(f.Do(ControlOperation.SetNightBrightness, value: -0.1f));
        var req = f.Request(ControlOperation.SetGod); req.Enabled = true; req.TargetEntityId = 99;
        Refused(f.Actions.Execute(req, f.Actions.Observe())); Assert(f.Player.NativeGodCalls == 0, "other entity never targeted");
        req = f.Request(ControlOperation.Teleport); req.PositionY = 255; Refused(f.Actions.Execute(req, f.Actions.Observe()));
        req.PositionY = 60; req.PositionX = 4000; Refused(f.Actions.Execute(req, f.Actions.Observe()));
        Assert(f.Player.TeleportCalls == 0, "invalid destination does not reach game");
    }

    private sealed class Fixture
    {
        public GameActions Actions;
        public World World;
        public EntityPlayerLocal Player;
        private ulong requestId;
        public Fixture(bool useTestProfile = true)
        {
            ResetWorld(); Actions = new GameActions();
            // TEST ONLY: the fake assembly is deliberately rejected by production's
            // SHA guard. Substitute that guard solely to exercise ownership logic.
            if (useTestProfile) typeof(GameActions).GetField("profileError", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(Actions, null);
            Actions.Observe();
        }
        public void ResetWorld()
        {
            World = new World(); Player = new EntityPlayerLocal { world = World };
            GameManager.Instance = new GameManager { World = World };
            World.PrimaryPlayer = Player;
            World.m_WorldEnvironment = new WorldEnvironment { world = World, localPlayer = Player };
            Player.m_vp_FPController = new vp_FPController { localPlayer = Player };
            Player.vp_FPCamera = new vp_FPCamera { FPController = Player.m_vp_FPController };
            Player.cameraTransform.parent = Player.cameraContainerTransform;
            var currentPlayer = Player;
            Player.moveController = new PlayerMoveController { entityPlayerLocal = Player, gameManager = GameManager.Instance,
                toggleGodMode = () => { currentPlayer.NativeGodCalls++; bool enabled = !currentPlayer.IsGodMode.Value;
                    currentPlayer.IsGodMode.Value = enabled; currentPlayer.IsFlyMode.Value = enabled; currentPlayer.IsNoCollisionMode.Value = enabled; } };
            PlayerMoveController.Instance = Player.moveController;
        }
        public ControlRequest Request(ControlOperation operation)
        {
            var observed = Actions.Observe();
            return new ControlRequest { ContextId = observed.ContextId, PlayerId = observed.PlayerId,
                TargetEntityId = observed.PlayerId, RequestId = ++requestId, Operation = operation };
        }
        public GameActionResult Do(ControlOperation operation, bool enabled = false, float value = 0)
        {
            var request = Request(operation); request.Enabled = enabled; request.Value = value;
            return Actions.Execute(request, Actions.Observe());
        }
    }
}
