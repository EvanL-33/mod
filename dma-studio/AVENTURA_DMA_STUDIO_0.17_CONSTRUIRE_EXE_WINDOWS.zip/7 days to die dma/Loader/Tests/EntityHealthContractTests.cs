using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;
using SevenDaysEsp;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class EntityHealthContractTests
{
    internal static Task OptionalHealthRoundtrip()
    {
        var snapshot = Snapshot();
        snapshot.Entities[0].Health = 37;
        snapshot.Entities[0].MaxHealth = 125;
        string json = JsonSerializer.Serialize(snapshot, Wire.Json);
        var received = JsonSerializer.Deserialize<LiveEntitySnapshot>(json, Wire.Json)!;
        Check(FeedSample.IsValid(received) && received.Entities[0].Health == 37 && received.Entities[0].MaxHealth == 125,
            "A live wire roundtrip lost health, maximum health or valid positions.");
        var legacy = JsonSerializer.Deserialize<LiveEntity>("{\"Kind\":\"zombie\",\"EntityId\":2,\"Name\":\"zombieArlene\"}", Wire.Json)!;
        Check(legacy.Health == null && legacy.MaxHealth == null, "An older packet invented zero or full health.");
        var settings = JsonSerializer.Deserialize<LoaderSettings>("{\"ShowNames\":false}", Wire.Json)!;
        Check(settings.ShowHealth && !settings.ShowNames, "The new health preference changed the existing names preference.");
        settings.ShowHealth = false;
        Check(!JsonSerializer.Deserialize<LoaderSettings>(JsonSerializer.Serialize(settings, Wire.Json), Wire.Json)!.ShowHealth,
            "Disabling health was not preserved in the settings contract.");
        return Task.CompletedTask;
    }

    internal static Task ProjectionPreservesHealthAndUnknownValues()
    {
        var matrix = new float[] { 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1 };
        Check(ProjectionMath.TryCreateView(matrix, new LivePosition(), 1920, 1080,
            new ProjectionViewport(0, 0, 1920, 1080), ProjectionDepthRange.MinusOneToOne, out var view, out _), "Fixture view invalid.");
        foreach (var values in new (int? health, int? maximum, int? expectedHealth, int? expectedMaximum)[]
        {
            (37, 125, 37, 125), (0, 125, 0, 125), (null, null, null, null),
            (37, null, 37, null), (null, 125, null, 125), (150, 125, 150, 125),
            (-1, 125, null, 125), (37, 0, 37, null), (37, -10, 37, null)
        })
        {
            var snapshot = Snapshot();
            var entity = snapshot.Entities[0];
            entity.Health = values.health; entity.MaxHealth = values.maximum;
            Check(ProjectionMath.TryBuildFrame(view, snapshot.LocalPosition, snapshot.LocalId,
                snapshot.Entities, null, out var projected, out var reason), reason);
            Check(projected!.Markers.Count == 1 && projected.Markers[0].Health == values.expectedHealth &&
                projected.Markers[0].MaxHealth == values.expectedMaximum && projected.Markers[0].Name == "zombieArlene",
                "Projection invented, discarded or confused optional health data.");
            entity.Health = 999;
            Check(projected.Markers[0].Health == values.expectedHealth, "A later entity mutation changed a published immutable marker.");
        }
        return Task.CompletedTask;
    }

    private static LiveEntitySnapshot Snapshot() => new()
    {
        Status = "ENTITES_LUES", LocalId = 1, LocalPosition = new LivePosition(),
        Entities = new List<LiveEntity>
        {
            new() { Kind = "zombie", EntityId = 2, Name = "zombieArlene", Position = new LivePosition { Z = .5f } }
        }
    };

    private static void Check(bool value, string message)
    { if (!value) throw new InvalidOperationException(message); }
}
