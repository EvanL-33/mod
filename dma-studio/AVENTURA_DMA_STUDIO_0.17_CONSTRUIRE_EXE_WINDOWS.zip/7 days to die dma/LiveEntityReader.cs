// Read-only live entity reader for the metadata layout observed on the user's game.
// Game field offsets are obtained from the current MonoInspectionReport, never from
// an old JSON report. Native Mono ABI evidence:
// https://github.com/Unity-Technologies/mono/blob/unity-2022.3-mbe/mono/metadata/class-private-definition.h
// https://github.com/Unity-Technologies/mono/blob/unity-2022.3-mbe/mono/metadata/class-accessors.c
// https://github.com/Unity-Technologies/mono/blob/unity-2022.3-mbe/mono/metadata/class-init.c
// https://github.com/Unity-Technologies/mono/blob/unity-2022.3-mbe/mono/metadata/object-internals.h
// List field names, not offsets:
// https://github.com/Unity-Technologies/mono/blob/unity-2022.3-mbe/mcs/class/referencesource/mscorlib/system/collections/generic/list.cs
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;

namespace SevenDaysEsp
{
    // Optional presentation details only. Position, identity, world and camera
    // checks are independent of these preferences and always remain enabled.
    public sealed class LiveReadOptions
    {
        public bool PlayerNames { get; set; }
        public bool PlayerHealth { get; set; }
        public bool ZombieNames { get; set; }
        public bool ZombieHealth { get; set; }
        public bool PlayerMovement { get; set; }
        public bool PlayerFacing { get; set; }
        public bool PlayerHeldItem { get; set; }
        public bool ZombieAttackTarget { get; set; }
        public bool WorldBloodMoon { get; set; }

        public LiveReadOptions()
        {
            PlayerNames = PlayerHealth = ZombieNames = ZombieHealth = true;
        }

        public LiveReadOptions Copy()
        {
            return new LiveReadOptions { PlayerNames = PlayerNames, PlayerHealth = PlayerHealth,
                ZombieNames = ZombieNames, ZombieHealth = ZombieHealth,
                PlayerMovement = PlayerMovement, PlayerFacing = PlayerFacing,
                PlayerHeldItem = PlayerHeldItem, ZombieAttackTarget = ZombieAttackTarget,
                WorldBloodMoon = WorldBloodMoon };
        }
    }

    public sealed class LivePosition
    {
        public float X { get; set; }
        public float Y { get; set; }
        public float Z { get; set; }
    }

    // Entity.boundingBox is the game's world-space collision volume. It does
    // not describe the animated mesh silhouette or an inferred head height.
    public sealed class LiveBounds
    {
        public LivePosition Center { get; set; }
        public LivePosition Extents { get; set; }
    }

    public sealed class LiveCameraFrame
    {
        public string Format { get; set; }
        public string ProfileId { get; set; }
        // Canonical row-major P * V, multiplied by column(world - origin, 1).
        // Source viewport coordinates use pixels with their origin at top left.
        public float[] ViewProjection { get; set; }
        public int SourceWidth { get; set; }
        public int SourceHeight { get; set; }
        public float ViewportX { get; set; }
        public float ViewportY { get; set; }
        public float ViewportWidth { get; set; }
        public float ViewportHeight { get; set; }
        public string ClipDepth { get; set; }
        public long Sequence { get; set; }
        public int CameraEpoch { get; set; }
        public double ReadDurationMs { get; set; }

        public LiveCameraFrame() { Format = "SevenDaysEsp.CameraFrame/1"; }
    }

    public sealed class LiveEntity
    {
        public string Kind { get; set; }
        public int EntityId { get; set; }
        // Opaque continuity token for players only. Never a process address.
        // Zero means a legacy/unidentified entity and must not receive annotations.
        public long IdentityToken { get; set; }
        public string Name { get; set; }
        public string NameSource { get; set; }
        public int? Health { get; set; }
        public int? MaxHealth { get; set; }
        public LivePosition Position { get; set; }
        public LiveBounds Bounds { get; set; }
        public bool? IsRunning { get; set; }
        public bool? IsCrouching { get; set; }
        public bool? IsJumping { get; set; }
        // ItemValue.typeField; never interpreted as an actual weapon name.
        public int? HeldItemTypeId { get; set; }
        public float? BodyYawDegrees { get; set; }
        // True only when a confirmed zombie attackTarget pointer equals the
        // validated local entity. Null means unknown, not non-aggressive.
        public bool? ZombieTargetsLocal { get; set; }
    }

    // A bounded diagnostic only: no player names, IDs, positions or memory addresses.
    // GraphValidated describes structural/stability checks only. ReadinessPolicy
    // and CanPublish distinguish an observation from a confirmed running game.
    public sealed class LiveReadDiagnostics
    {
        public string Stage { get; set; }
        public string Code { get; set; }
        public string Detail { get; set; }
        public int? GameHasStartedRaw { get; set; }
        public int? WorldCreatedRaw { get; set; }
        public int? GameHasStartedAfterRaw { get; set; }
        public int? WorldCreatedAfterRaw { get; set; }
        public string WorldReference { get; set; }
        public string ManagerLocalReference { get; set; }
        public string WorldLocalReference { get; set; }
        public bool WorldValidated { get; set; }
        public bool LocalValidated { get; set; }
        public bool LocalActive { get; set; }
        public bool? LocalReferencesMatch { get; set; }
        public bool? LocalIdMatches { get; set; }
        public int? EntityCount { get; set; }
        public bool CollectionValidated { get; set; }
        public bool GraphValidated { get; set; }
        public string ReadinessPolicy { get; set; }
        public int StableGraphCaptures { get; set; }
        public int RequiredStableGraphCaptures { get; set; }
        public bool CanPublish { get; set; }
        public int CandidatePlayersCount { get; set; }
        public int CandidateZombiesCount { get; set; }
        public int HealthAvailable { get; set; }
        public int HealthUnavailable { get; set; }
        public int HealthSkipped { get; set; }
        public int NamesSkipped { get; set; }
        public LiveReadOptions AppliedReadOptions { get; set; }
        public int EntityNames { get; set; }
        public int ClassNames { get; set; }
        public int FallbackNames { get; set; }
        public int OptionalDetailsReadCalls { get; set; }
        public int OptionalDetailsReadBytes { get; set; }
        public double OptionalDetailsMilliseconds { get; set; }
        public bool OptionalDetailsBudgetReached { get; set; }

        public LiveReadDiagnostics()
        {
            Stage = "STOCKAGE_GAMEMANAGER";
            Code = "EN_COURS";
            Detail = String.Empty;
            ReadinessPolicy = "NON_CONFIRMEE";
            WorldReference = "NON_LUE";
            ManagerLocalReference = "NON_LUE";
            WorldLocalReference = "NON_LUE";
        }
    }

    public sealed class LiveEntitySnapshot
    {
        public DateTime CapturedUtc { get; set; }
        // Changes only after a fully accepted world/local-player context change.
        public string PlayerContextId { get; set; }
        public long PlayerCaptureSequence { get; set; }
        public LivePosition LocalPosition { get; set; }
        public LivePosition RenderOrigin { get; set; }
        public LiveCameraFrame Camera { get; set; }
        public int LocalId { get; set; }
        public List<LiveEntity> Entities { get; set; }
        public int PlayersCount { get; set; }
        public int ZombiesCount { get; set; }
        public int? WorldDay { get; set; }
        public int? WorldHour { get; set; }
        public bool? BloodMoonActive { get; set; }
        public int RejectedEntities { get; set; }
        public string Status { get; set; }
        public string Message { get; set; }
        public long ReadDurationMs { get; set; }
        public List<string> Warnings { get; set; }
        public LiveReadDiagnostics Diagnostics { get; set; }

        public LiveEntitySnapshot()
        {
            CapturedUtc = DateTime.UtcNow;
            LocalId = -1;
            Entities = new List<LiveEntity>();
            Warnings = new List<string>();
            Diagnostics = new LiveReadDiagnostics();
            Status = "LECTURE_EN_ATTENTE";
        }
    }

    // Valid only during ExecuteInValidatedContext's synchronous callback.
    // Never serialized in the ESP feed or retained as an address to restore later.
    public sealed class LiveMenuContext
    {
        public string ContextId { get; internal set; }
        public ulong Domain { get; internal set; }
        public ulong GameImage { get; internal set; }
        public ulong WorldAddress { get; internal set; }
        public ulong LocalPlayerAddress { get; internal set; }
        public int LocalPlayerId { get; internal set; }
        internal Action ValidateAction;
        public void Validate()
        {
            if (ValidateAction == null) throw new InvalidOperationException("Contexte de menu expire.");
            ValidateAction();
        }
    }

    public sealed partial class LiveEntityReader
    {
        private sealed class CaptureStateException : IOException
        {
            public string Code { get; private set; }
            public CaptureStateException(string code, string message) : base(message) { Code = code; }
        }

        private sealed class ConfirmationPendingException : IOException
        {
            public ConfirmationPendingException(int count) : base("Partie demarree, monde coherent : confirmation " +
                count.ToString(CultureInfo.InvariantCulture) + "/" + RequiredWorldConfirmations.ToString(CultureInfo.InvariantCulture) +
                " (worldCreated=0). Lecture automatique en cours.") { }
        }

        private sealed class ReadLimitException : IOException
        {
            public ReadLimitException() : base("Budget de capture atteint ; les anciennes positions sont retirees.") { }
        }

        private sealed class OptionalReadLimitException : IOException
        {
            public OptionalReadLimitException() : base("Budget des details optionnels atteint.") { }
        }

        private sealed class RuntimeClass
        {
            public ulong Address;
            public ulong Parent;
            public ulong Image;
            public int Size;
            public byte Kind;
            public string Name;
            public string Namespace;
        }

        private sealed class StaticStorage
        {
            public ulong ClassAddress;
            public ulong Runtime;
            public ulong RuntimeSlot;
            public ulong VTable;
            public ulong Domain;
            public ulong StaticSlot;
            public ulong Data;
            public int Size;
        }

        private sealed class RuntimeField
        {
            public string Name;
            public int Offset;
            public byte TypeCode;
            public ulong TypeData;
        }

        private sealed class ListLayout
        {
            public ulong ClassAddress;
            public int Size;
            public int ItemsOffset;
            public int CountOffset;
            public int VersionOffset;
        }

        private sealed class EntityState
        {
            public ulong VTable;
            public ulong ClassAddress;
            public int Id;
            public LivePosition Position;
            public LiveBounds Bounds;
            public ulong NamePointer;
            public ulong StatsPointer;
            public int EntityClassId = -1;
            public bool Removed;
        }

        private sealed class PlayerIdentityCandidate
        {
            public LiveEntity Entity;
            public ulong Address;
            public ulong ClassAddress;
        }

        private sealed class PlayerInstanceIdentity
        {
            public ulong Address;
            public ulong ClassAddress;
            public long Token;
        }

        private sealed class OptionalLayout
        {
            public RuntimeClass Type;
            public ulong FieldArray, GenericContext, Definition;
            public int FieldCount;
            public readonly Dictionary<string, RuntimeField> Fields = new Dictionary<string, RuntimeField>(StringComparer.Ordinal);
        }

        private sealed class NameRegistry
        {
            public StaticStorage Storage;
            public ulong Wrapper, WrapperTable, Dictionary, DictionaryTable, Entries, EntriesTable;
            public RuntimeClass WrapperType, DictionaryType;
            public int WrapperDictionaryOffset, EntriesOffset, CountOffset, VersionOffset, Count, Version;
            public readonly Dictionary<int, ulong> Objects = new Dictionary<int, ulong>();
        }

        private sealed class CachedClassName
        {
            public ulong Pointer;
            public string Name;
        }

        private readonly IMemoryReader memory;
        private readonly object captureLock = new object();
        private volatile LiveReadOptions readOptions = new LiveReadOptions();
        // Only the preceding accepted capture is retained; at most 4096 entries.
        // Rejected captures cannot replace this identity state.
        private Dictionary<int, PlayerInstanceIdentity> playerIdentities = new Dictionary<int, PlayerInstanceIdentity>();
        private ulong playerIdentityWorld, playerIdentityLocal, playerIdentityDomain;
        private int playerIdentityLocalId = -1;
        private string playerContextId;
        private long nextPlayerIdentityToken;
        private long nextPlayerCaptureSequence;
        private long lastValidatedCaptureTimestamp;
        private ulong lastValidatedManager;
        private readonly UTF8Encoding utf8 = new UTF8Encoding(false, true);
        private readonly UnicodeEncoding utf16 = new UnicodeEncoding(false, false, true);
        private readonly Dictionary<ulong, RuntimeClass> classCache = new Dictionary<ulong, RuntimeClass>();
        private readonly Dictionary<ulong, string> kindCache = new Dictionary<ulong, string>();
        private readonly Dictionary<ulong, ListLayout> listCache = new Dictionary<ulong, ListLayout>();
        private readonly Dictionary<string, RuntimeClass> gameClasses = new Dictionary<string, RuntimeClass>(StringComparer.Ordinal);
        private readonly Dictionary<string, int> fields = new Dictionary<string, int>(StringComparer.Ordinal);
        private readonly ulong gameImage;
        private readonly int entityReadSize;
        private readonly int boundsOffset = -1;
        private int statsPointerOffset = -1, entityClassOffset = -1;
        private RuntimeClass statsClass, classDefinitionClass;
        private int statsHealthOffset = -1, statsOwnerOffset = -1, classListOffset = -1, classNameOffset = -1;
        private readonly Dictionary<ulong, OptionalLayout> optionalLayouts = new Dictionary<ulong, OptionalLayout>();
        private readonly HashSet<ulong> validatedOptionalLayouts = new HashSet<ulong>();
        private readonly Dictionary<ulong, CachedClassName> classNames = new Dictionary<ulong, CachedClassName>();
        private readonly Stopwatch optionalClock = new Stopwatch();
        private bool readingOptional, optionalExhausted;
        private int optionalReadCalls, optionalReadBytes;
        private NameRegistry nameRegistry;
        private bool nameRegistryAttempted;
        private const int OptionalMilliseconds = 40;
        private const int OptionalCalls = 512;
        private const int OptionalBytes = 262144;
        private const int MaximumRegistryEntries = 8192;
        private Stopwatch clock;
        private int readCalls;
        private int readBytes;
        private bool initializing;
        private const int MaximumEntities = 4096;
        private const int MaximumReadCalls = 24000;
        private const int MaximumReadBytes = 16777216;
        private const int MaximumCaptureMilliseconds = 1500;
        private const int RequiredWorldConfirmations = 3;
        // Continuity of observations, not the lifetime of displayed positions.
        // A two-second threshold would starve the supported IntervalMs=2000 mode.
        private const double MaximumConfirmationGapMilliseconds = 5000;
        private ulong confirmationDomain;
        private ulong confirmationManager;
        private ulong confirmationWorld;
        private ulong confirmationLocal;
        private int confirmationLocalId = -1;
        private int confirmationCount;
        private long confirmationTimestamp;

        public ulong LocalPlayerAddress { get; private set; }
        // Publish a complete copy without waiting for a hardware read. Capture
        // takes its own copy once; a change cannot split one capture's policy.
        public LiveReadOptions ReadOptions
        {
            get { return readOptions.Copy(); }
            set { readOptions = value == null ? new LiveReadOptions() : value.Copy(); }
        }
        // Optional read-only camera acquisition, inside the entity capture's
        // final identity/origin checks. Projection validation belongs to the
        // consumer; this callback cannot make a rejected graph publishable.
        public Func<ulong, ulong, LivePosition, LiveCameraFrame> CameraCapture { get; set; }

        public LiveEntityReader(IMemoryReader reader, MonoInspectionReport currentMetadata)
        {
            if (reader == null) throw new ArgumentNullException("reader");
            if (currentMetadata == null || currentMetadata.SelectedLayout != "Unity Mono x64 2022 (candidate)" ||
                (currentMetadata.Status != "METADONNEES_COLLECTEES" && currentMetadata.Status != "METADONNEES_PARTIELLES"))
                throw new IOException("Relance l'analyse des metadonnees Mono avant la lecture des entites.");
            memory = reader;
            initializing = true;
            ResetBudget();
            string[] required = { "GameManager", "World", "Entity", "EntityAlive", "EntityPlayer", "EntityPlayerLocal", "EntityZombie", "Origin" };
            foreach (string name in required)
            {
                MonoClassReport item = ReportClass(currentMetadata, name);
                RuntimeClass type = GetClass(ParseAddress(item.Address));
                if (type.Kind != 1 || type.Name != name || type.Namespace != String.Empty || type.Size != item.InstanceSize)
                    throw new IOException("Les metadonnees ne correspondent plus a la classe " + name + ". Relance le lecteur.");
                if (gameClasses.Count == 0) gameImage = type.Image;
                if (type.Image != gameImage) throw new IOException("Les classes du jeu ne partagent pas la meme assembly.");
                gameClasses.Add(name, type);
            }
            Bind(currentMetadata, "GameManager", "Instance", "0x12", "GameManager", 8, true, false);
            Bind(currentMetadata, "GameManager", "m_World", "0x12", "World", 8, false, false);
            Bind(currentMetadata, "GameManager", "myEntityPlayerLocal", "0x12", "EntityPlayerLocal", 8, false, false);
            Bind(currentMetadata, "GameManager", "myPlayerId", "0x08", "System.Int32", 4, false, false);
            Bind(currentMetadata, "GameManager", "GameHasStarted", "0x02", "System.Boolean", 1, false, false);
            Bind(currentMetadata, "GameManager", "worldCreated", "0x02", "System.Boolean", 1, false, false);
            Bind(currentMetadata, "World", "EntityAlives", "0x15", "System.Collections.Generic.List`1", 8, false, true);
            Bind(currentMetadata, "World", "m_LocalPlayerEntity", "0x12", "EntityPlayerLocal", 8, false, false);
            Bind(currentMetadata, "Entity", "world", "0x12", "World", 8, false, false);
            Bind(currentMetadata, "Entity", "entityId", "0x08", "System.Int32", 4, false, false);
            Bind(currentMetadata, "Entity", "position", "0x11", "UnityEngine.Vector3", 12, false, false);
            Bind(currentMetadata, "Entity", "bDead", "0x02", "System.Boolean", 1, false, false);
            Bind(currentMetadata, "Entity", "IsDespawned", "0x02", "System.Boolean", 1, false, false);
            Bind(currentMetadata, "Entity", "markedForUnload", "0x02", "System.Boolean", 1, false, false);
            Bind(currentMetadata, "Entity", "isUnloaded", "0x02", "System.Boolean", 1, false, false);
            Bind(currentMetadata, "EntityAlive", "entityName", "0x0E", "System.String", 8, false, false);
            Bind(currentMetadata, "Origin", "position", "0x11", "UnityEngine.Vector3", 12, true, false);
            // Use the current report's field/type/offset; an older or incomplete
            // profile may still provide a working radar without collision boxes.
            try
            {
                Bind(currentMetadata, "Entity", "boundingBox", "0x11", "UnityEngine.Bounds", 24, false, false);
                boundsOffset = Offset("Entity", "boundingBox");
            }
            catch (IOException) { boundsOffset = -1; }
            InitializeOptionalDetails(currentMetadata);
            InitializePvpSense(currentMetadata);
            entityReadSize = Math.Max(gameClasses["Entity"].Size, Offset("EntityAlive", "entityName") + 8);
            if (statsPointerOffset >= 0) entityReadSize = Math.Max(entityReadSize, statsPointerOffset + 8);
            if (entityClassOffset >= 0) entityReadSize = Math.Max(entityReadSize, entityClassOffset + 4);
            if (entityReadSize > gameClasses["EntityAlive"].Size || entityReadSize > 65536)
                throw new IOException("Taille de lecture des entites incoherente.");
            if (Classify(gameClasses["EntityPlayer"].Address) != "player" || Classify(gameClasses["EntityZombie"].Address) != "zombie")
                throw new IOException("Hierarchie des classes joueurs/zombies non reconnue.");
            initializing = false;
        }

        public LiveEntitySnapshot Capture()
        {
            lock (captureLock)
            {
                LiveEntitySnapshot snapshot = new LiveEntitySnapshot();
                LiveReadDiagnostics diagnostic = snapshot.Diagnostics;
                LiveReadOptions captureOptions = readOptions.Copy();
                diagnostic.AppliedReadOptions = captureOptions.Copy();
                LocalPlayerAddress = 0;
                lastValidatedCaptureTimestamp = 0;
                long captureStarted = Stopwatch.GetTimestamp();
                ResetBudget();
                ResetOptionalBudget();
                try
                {
                    StaticStorage managerStorage = FindManagerStorage();
                    ulong instanceSlot = Add(managerStorage.Data, Offset("GameManager", "Instance"));
                    ulong manager = Pointer(instanceSlot);
                    diagnostic.Stage = "INSTANCE_GAMEMANAGER";
                    byte[] managerData = ReadObject(manager, gameClasses["GameManager"], managerStorage.Domain);

                    // Read both flags and all root reference values independently.
                    // Short-circuiting the old boolean gate hid the second flag and
                    // made an absent world indistinguishable from an unsupported flag.
                    diagnostic.Stage = "INDICATEURS_PARTIE";
                    diagnostic.GameHasStartedRaw = managerData[Offset("GameManager", "GameHasStarted")];
                    diagnostic.WorldCreatedRaw = managerData[Offset("GameManager", "worldCreated")];
                    ulong world = BitConverter.ToUInt64(managerData, Offset("GameManager", "m_World"));
                    ulong local = BitConverter.ToUInt64(managerData, Offset("GameManager", "myEntityPlayerLocal"));
                    diagnostic.WorldReference = ReferenceState(world);
                    diagnostic.ManagerLocalReference = ReferenceState(local);
                    if (diagnostic.GameHasStartedRaw > 1 || diagnostic.WorldCreatedRaw > 1)
                        throw new CaptureStateException("INDICATEUR_INVALIDE", "Octet de chargement incoherent : " + FlagSummary(diagnostic) + ".");
                    bool gameStarted = Boolean(managerData, Offset("GameManager", "GameHasStarted"));
                    bool worldCreated = Boolean(managerData, Offset("GameManager", "worldCreated"));

                    // Diagnose the bounded graph even while the game is loading.
                    // Publication still requires GameHasStarted=1 and stable flags.
                    // The observed V 3.4.0 (b10) worldCreated=0 case additionally
                    // requires consecutive complete observations of the same scene.
                    diagnostic.Stage = "MONDE";
                    if (world == 0)
                        throw new CaptureStateException("MONDE_ABSENT", "Le jeu est detecte, mais la reference du monde est nulle. Attente automatique de la partie.");
                    RequirePointer(world);
                    byte[] worldData = ReadObject(world, gameClasses["World"], managerStorage.Domain);
                    diagnostic.WorldValidated = true;
                    ulong worldLocal = BitConverter.ToUInt64(worldData, Offset("World", "m_LocalPlayerEntity"));
                    diagnostic.WorldLocalReference = ReferenceState(worldLocal);

                    diagnostic.Stage = "REFERENCES_JOUEUR_LOCAL";
                    if (local == 0 || worldLocal == 0)
                        throw new CaptureStateException("JOUEUR_LOCAL_ABSENT", "Le monde est accessible, mais une reference du joueur local est nulle. Attente automatique de son apparition.");
                    RequirePointer(local);
                    RequirePointer(worldLocal);
                    diagnostic.LocalReferencesMatch = worldLocal == local;
                    if (worldLocal != local)
                        throw new CaptureStateException("JOUEUR_LOCAL_DIFFERENT", "Les deux references du joueur local ne correspondent pas ; nouvelle lecture automatique.");

                    diagnostic.Stage = "ORIGINE_DU_MONDE";
                    StaticStorage originStorage = GetStorageForDomain(gameClasses["Origin"], managerStorage.Domain);
                    CheckOffset(Offset("Origin", "position"), originStorage.Size, 12, false);
                    ulong originSlot = Add(originStorage.Data, Offset("Origin", "position"));
                    byte[] originBefore = Read(originSlot, 12);
                    LivePosition renderOrigin = Position(originBefore, 0);

                    diagnostic.Stage = "JOUEUR_LOCAL";
                    EntityState localBefore = ReadEntityState(local, world, managerStorage.Domain);
                    diagnostic.LocalValidated = HasAncestor(localBefore.ClassAddress, gameClasses["EntityPlayerLocal"].Address);
                    if (!diagnostic.LocalValidated)
                        throw new CaptureStateException("TYPE_JOUEUR_LOCAL_INVALIDE", "La classe du joueur local ne correspond pas au profil attendu.");
                    diagnostic.LocalActive = !localBefore.Removed;
                    if (!diagnostic.LocalActive)
                        throw new CaptureStateException("JOUEUR_LOCAL_INACTIF", "Le joueur local porte un indicateur de mort ou de retrait. Attente automatique de son retour.");
                    diagnostic.LocalIdMatches = BitConverter.ToInt32(managerData, Offset("GameManager", "myPlayerId")) == localBefore.Id;
                    if (diagnostic.LocalIdMatches != true)
                        throw new CaptureStateException("IDENTIFIANT_LOCAL_DIFFERENT", "L'identifiant du joueur local ne correspond pas a celui du gestionnaire ; nouvelle lecture automatique.");

                    diagnostic.Stage = "COLLECTION_ENTITES";
                    ulong list = BufferPointer(worldData, Offset("World", "EntityAlives"));
                    ulong listVtable = Pointer(list);
                    ulong listClass = ValidateVTable(listVtable, managerStorage.Domain);
                    ListLayout layout = GetListLayout(listClass);
                    byte[] listBefore = Read(list, layout.Size);
                    if (BitConverter.ToUInt64(listBefore, 0) != listVtable) throw new IOException("La liste des entites a change.");
                    int count = BitConverter.ToInt32(listBefore, layout.CountOffset);
                    diagnostic.EntityCount = count;
                    int version = BitConverter.ToInt32(listBefore, layout.VersionOffset);
                    if (count < 0 || count > MaximumEntities) throw new IOException("Nombre d'entites hors limite du lecteur (maximum 4096).");
                    ulong items = BufferPointer(listBefore, layout.ItemsOffset);
                    byte[] arrayHeader = Read(items, 0x20);
                    ulong arrayVtable = BufferPointer(arrayHeader, 0);
                    ulong arrayClass = ValidateVTable(arrayVtable, managerStorage.Domain);
                    RuntimeClass arrayType = GetClass(arrayClass);
                    byte[] arrayClassData = Read(arrayClass, 0x98);
                    if (arrayType.Kind != 5 || arrayClassData[0x1A] != 1 ||
                        BitConverter.ToUInt64(arrayClassData, 0) != gameClasses["EntityAlive"].Address ||
                        BitConverter.ToInt32(arrayClassData, 0x90) != 8 || BitConverter.ToUInt64(arrayHeader, 0x10) != 0)
                        throw new IOException("Le stockage de la liste n'est pas un tableau de references EntityAlive reconnu.");
                    // Mono's ordinary array length is uint32; upper alignment bytes are not read as length.
                    uint capacity = BitConverter.ToUInt32(arrayHeader, 0x18);
                    if (capacity > 1048576 || count > capacity) throw new IOException("Capacite du tableau d'entites incoherente.");
                    byte[] entries = count == 0 ? new byte[0] : Read(items + 0x20UL, count * 8);
                    diagnostic.CollectionValidated = true;
                    diagnostic.Stage = "LECTURE_ENTITES";
                    HashSet<ulong> seenPointers = new HashSet<ulong>();
                    HashSet<int> seenIds = new HashSet<int>();
                    int missingNames = 0;
                    List<PlayerIdentityCandidate> playerCandidates = new List<PlayerIdentityCandidate>();
                    for (int index = 0; index < count; index++)
                    {
                        ulong entity = BitConverter.ToUInt64(entries, index * 8);
                        if (entity == local) continue;
                        try
                        {
                            RequirePointer(entity);
                            if (!seenPointers.Add(entity)) throw new IOException("Reference d'entite dupliquee.");
                            EntityState state = ReadEntityState(entity, world, managerStorage.Domain);
                            if (state.Id == localBefore.Id || state.Removed) continue;
                            string kind = Classify(state.ClassAddress);
                            if (kind == null) continue;
                            if (!seenIds.Add(state.Id)) throw new IOException("Identifiant d'entite duplique.");
                            string displayName = null, nameSource = "fallback";
                            int? health = null, maxHealth = null;
                            bool readNames = kind == "player" ? captureOptions.PlayerNames : captureOptions.ZombieNames;
                            bool readHealth = kind == "player" ? captureOptions.PlayerHealth : captureOptions.ZombieHealth;
                            if ((readNames || readHealth) && !optionalExhausted)
                            {
                                readingOptional = true;
                                optionalClock.Start();
                                try
                                {
                                    if (readHealth)
                                    {
                                        try { ReadHealth(entity, state, managerStorage.Domain, out health, out maxHealth); }
                                        catch (ReadLimitException) { throw; }
                                        catch (IOException) { health = null; maxHealth = null; }
                                    }
                                    if (readNames && state.NamePointer != 0)
                                    {
                                        try { displayName = ReadName(state.NamePointer, managerStorage.Domain); }
                                        catch (ReadLimitException) { throw; }
                                        catch (IOException) { missingNames++; }
                                    }
                                    if (!String.IsNullOrWhiteSpace(displayName)) nameSource = "entityName";
                                    else if (readNames && kind == "zombie" && entityClassOffset >= 0)
                                    {
                                        try { displayName = ReadClassName(state.EntityClassId, managerStorage.Domain); }
                                        catch (ReadLimitException) { throw; }
                                        catch (IOException) { missingNames++; }
                                        if (!String.IsNullOrWhiteSpace(displayName)) nameSource = "entityClassName";
                                    }
                                }
                                finally { optionalClock.Stop(); readingOptional = false; }
                            }
                            // Extra PvP observations consume the optional-read budget.
                            // They never determine whether this entity exists.
                            var pvpDetails = new LiveEntity();
                            bool wantsPvp = kind == "player" ?
                                captureOptions.PlayerMovement || captureOptions.PlayerFacing || captureOptions.PlayerHeldItem :
                                captureOptions.ZombieAttackTarget;
                            if (wantsPvp && !optionalExhausted)
                            {
                                readingOptional = true;
                                optionalClock.Start();
                                try { ReadPvpEntity(entity, kind, local, managerStorage.Domain, captureOptions, pvpDetails); }
                                catch (ReadLimitException) { throw; }
                                catch (IOException) { /* optional data remains unknown */ }
                                finally { optionalClock.Stop(); readingOptional = false; }
                            }
                            EntityState after = ReadEntityState(entity, world, managerStorage.Domain);
                            if (after.VTable != state.VTable || after.Id != state.Id || after.ClassAddress != state.ClassAddress || after.Removed)
                                throw new IOException("L'entite a change pendant la capture.");
                            if (after.StatsPointer != state.StatsPointer) { health = null; maxHealth = null; }
                            if ((nameSource == "entityName" && after.NamePointer != state.NamePointer) ||
                                (nameSource == "entityClassName" && after.EntityClassId != state.EntityClassId))
                            { displayName = null; nameSource = "fallback"; }
                            if (String.IsNullOrWhiteSpace(displayName))
                            { displayName = (kind == "player" ? "Joueur " : "Zombie ") + state.Id.ToString(CultureInfo.InvariantCulture); nameSource = "fallback"; }
                            LiveEntity capturedEntity = new LiveEntity { Kind = kind, EntityId = state.Id, Name = displayName, NameSource = nameSource,
                                Health = health, MaxHealth = maxHealth, Position = state.Position, Bounds = state.Bounds,
                                IsRunning = pvpDetails.IsRunning, IsCrouching = pvpDetails.IsCrouching,
                                IsJumping = pvpDetails.IsJumping, HeldItemTypeId = pvpDetails.HeldItemTypeId,
                                BodyYawDegrees = pvpDetails.BodyYawDegrees, ZombieTargetsLocal = pvpDetails.ZombieTargetsLocal };
                            snapshot.Entities.Add(capturedEntity);
                            if (kind == "player") playerCandidates.Add(new PlayerIdentityCandidate
                                { Entity = capturedEntity, Address = entity, ClassAddress = state.ClassAddress });
                            if (!readHealth) diagnostic.HealthSkipped++;
                            else if (health.HasValue && maxHealth.HasValue) diagnostic.HealthAvailable++; else diagnostic.HealthUnavailable++;
                            if (!readNames) diagnostic.NamesSkipped++;
                            if (nameSource == "entityName") diagnostic.EntityNames++;
                            else if (nameSource == "entityClassName") diagnostic.ClassNames++;
                            else diagnostic.FallbackNames++;
                            if (kind == "player") snapshot.PlayersCount++; else snapshot.ZombiesCount++;
                        }
                        catch (ReadLimitException) { throw; }
                        catch (IOException) { snapshot.RejectedEntities++; }
                    }

                    FinalizeOptionalDetails(snapshot);
                    LiveCameraFrame camera = null;
                    Func<ulong, ulong, LivePosition, LiveCameraFrame> captureCamera = CameraCapture;
                    if (captureCamera != null)
                    {
                        diagnostic.Stage = "LECTURE_CAMERA";
                        try
                        {
                            // Keep the confirmed origin independent of callback
                            // mutation; the native reader receives its own value.
                            camera = captureCamera(local, managerStorage.Domain, new LivePosition
                            { X = renderOrigin.X, Y = renderOrigin.Y, Z = renderOrigin.Z });
                        }
                        catch (Exception cameraError)
                        {
                            snapshot.Warnings.Add("Camera indisponible pour cette capture : " + cameraError.Message);
                        }
                    }

                    diagnostic.CandidatePlayersCount = snapshot.PlayersCount;
                    diagnostic.CandidateZombiesCount = snapshot.ZombiesCount;
                    diagnostic.Stage = "COHERENCE_CAPTURE";
                    byte[] listAfter = Read(list, layout.Size);
                    if (BitConverter.ToUInt64(listAfter, 0) != listVtable ||
                        BitConverter.ToUInt64(listAfter, layout.ItemsOffset) != items ||
                        BitConverter.ToInt32(listAfter, layout.CountOffset) != count ||
                        BitConverter.ToInt32(listAfter, layout.VersionOffset) != version)
                        throw new IOException("La liste des entites a change pendant la capture ; nouvelle lecture au prochain passage.");
                    byte[] arrayAfter = Read(items, 0x20);
                    if (!SameBytes(arrayHeader, arrayAfter)) throw new IOException("Le tableau d'entites a change pendant la capture.");
                    EntityState localAfter = ReadEntityState(local, world, managerStorage.Domain);
                    if (localAfter.VTable != localBefore.VTable || localAfter.Id != localBefore.Id || localAfter.Removed)
                        throw new IOException("Le joueur local a change pendant la capture.");
                    byte[] managerAfter = ReadObject(manager, gameClasses["GameManager"], managerStorage.Domain);
                    byte[] worldAfter = ReadObject(world, gameClasses["World"], managerStorage.Domain);
                    diagnostic.GameHasStartedAfterRaw = managerAfter[Offset("GameManager", "GameHasStarted")];
                    diagnostic.WorldCreatedAfterRaw = managerAfter[Offset("GameManager", "worldCreated")];
                    if (diagnostic.GameHasStartedAfterRaw > 1 || diagnostic.WorldCreatedAfterRaw > 1)
                        throw new CaptureStateException("INDICATEUR_INVALIDE", "Un indicateur de chargement est devenu incoherent pendant la capture.");
                    if (diagnostic.GameHasStartedAfterRaw != diagnostic.GameHasStartedRaw || diagnostic.WorldCreatedAfterRaw != diagnostic.WorldCreatedRaw)
                        throw new CaptureStateException("INDICATEURS_MODIFIES", "Les indicateurs de partie ont change pendant la capture ; nouvelle lecture automatique.");
                    if (BufferPointer(managerAfter, Offset("GameManager", "m_World")) != world ||
                        BufferPointer(managerAfter, Offset("GameManager", "myEntityPlayerLocal")) != local ||
                        BufferPointer(worldAfter, Offset("World", "m_LocalPlayerEntity")) != local ||
                        BufferPointer(worldAfter, Offset("World", "EntityAlives")) != list ||
                        BitConverter.ToInt32(managerAfter, Offset("GameManager", "myPlayerId")) != localBefore.Id || Pointer(instanceSlot) != manager)
                        throw new IOException("La partie ou le monde a change pendant la capture.");
                    ValidateStorage(managerStorage);
                    ValidateStorage(originStorage);
                    if (!SameBytes(originBefore, Read(originSlot, 12)))
                        throw new IOException("L'origine du monde a change pendant la capture ; nouvelle lecture au prochain passage.");
                    diagnostic.GraphValidated = true;

                    diagnostic.Stage = "INDICATEURS_PARTIE";
                    if (!gameStarted)
                        throw new CaptureStateException("PARTIE_NON_DEMARREE", "Monde et joueur local coherents, mais GameHasStarted=0. Attente automatique du demarrage de la partie.");
                    if (worldCreated)
                    {
                        ResetWorldConfirmation();
                        diagnostic.ReadinessPolicy = "INDICATEURS_ET_GRAPHE";
                    }
                    else
                    {
                        // This is an empirical compatibility rule for the profiled
                        // game version, not a general claim about worldCreated.
                        diagnostic.Stage = "CONFIRMATION_PARTIE";
                        diagnostic.ReadinessPolicy = "PARTIE_DEMARREE_ET_GRAPHE_CONFIRME";
                        diagnostic.RequiredStableGraphCaptures = RequiredWorldConfirmations;
                        diagnostic.StableGraphCaptures = ConfirmWorld(managerStorage.Domain, manager, world,
                            local, localBefore.Id, captureStarted);
                        if (diagnostic.StableGraphCaptures < RequiredWorldConfirmations)
                            throw new ConfirmationPendingException(diagnostic.StableGraphCaptures);
                    }

                    // World metadata only becomes visible after both coherent
                    // world reads. It never controls readiness or ESP positions.
                    if (captureOptions.WorldBloodMoon)
                        ReadPvpWorld(worldData, worldAfter, snapshot);
                    snapshot.LocalPosition = localBefore.Position;
                    // Entity.SetPosition/updateTransform in the profiled assembly
                    // establish render coordinates = world - Origin.position.
                    snapshot.RenderOrigin = renderOrigin;
                    snapshot.Camera = camera;
                    snapshot.LocalId = localBefore.Id;
                    snapshot.Status = "ENTITES_LUES";
                    snapshot.Message = camera != null ? "Positions et camera DMA lues ; projection disponible pour cette capture." : "Positions DMA lues ; radar disponible, camera en attente pour cette capture.";
                    diagnostic.Stage = "TERMINE";
                    diagnostic.Code = "ENTITES_LUES";
                    diagnostic.CanPublish = true;
                    diagnostic.Detail = snapshot.Message;
                    LocalPlayerAddress = local;
                    if (snapshot.RejectedEntities > 0) snapshot.Warnings.Add("Certaines entites ont ete ecartees car leur lecture n'etait pas coherente.");
                    if (missingNames > 0) snapshot.Warnings.Add("Certains noms ne sont pas disponibles ; les identifiants servent de libelles.");
                    // No extra DMA read: these addresses/classes were validated above.
                    // Commit last, after the camera callback, final consistency/readiness
                    // checks and every other operation that can reject this capture.
                    CommitPlayerIdentities(snapshot, playerCandidates, world, local, localBefore.Id, managerStorage.Domain);
                    lastValidatedManager = manager;
                    lastValidatedCaptureTimestamp = captureStarted;
                }
                catch (Exception e)
                {
                    diagnostic.CandidatePlayersCount = snapshot.PlayersCount;
                    diagnostic.CandidateZombiesCount = snapshot.ZombiesCount;
                    // Only the deliberate 1/3 and 2/3 wait preserves progress.
                    // Every failed/incomplete/changed capture breaks the sequence.
                    bool confirming = e is ConfirmationPendingException;
                    if (!confirming)
                    {
                        ResetWorldConfirmation();
                        diagnostic.StableGraphCaptures = 0;
                    }
                    diagnostic.CanPublish = false;
                    CaptureStateException stateError = e as CaptureStateException;
                    diagnostic.Code = confirming ? "CONFIRMATION_MONDE" :
                        (e is ReadLimitException ? "LIMITE_LECTURE" :
                        (stateError == null ? "LECTURE_NON_VALIDEE" : stateError.Code));
                    diagnostic.Detail = e.Message;
                    snapshot.Entities.Clear();
                    snapshot.PlayersCount = 0;
                    snapshot.ZombiesCount = 0;
                    snapshot.LocalPosition = null;
                    snapshot.RenderOrigin = null;
                    snapshot.Camera = null;
                    snapshot.LocalId = -1;
                    snapshot.PlayerContextId = null;
                    snapshot.PlayerCaptureSequence = 0;
                    snapshot.Status = e is ReadLimitException ? "LIMITE_LECTURE" : "LECTURE_NON_VALIDEE";
                    snapshot.Message = "[" + diagnostic.Code + " / " + diagnostic.Stage + "] " + e.Message;
                    LocalPlayerAddress = 0;
                }
                snapshot.ReadDurationMs = clock.ElapsedMilliseconds;
                return snapshot;
            }
        }

        // The game still executes concurrently with DMA. This lock serializes our
        // reader and the explicit menu action only; validation is repeated on both
        // sides of the write and does not claim an atomic transaction with the game.
        public T ExecuteInValidatedContext<T>(string expectedContextId, Func<LiveMenuContext, T> operation)
        {
            if (operation == null) throw new ArgumentNullException("operation");
            lock (captureLock)
            {
                long captured = lastValidatedCaptureTimestamp;
                ulong manager = lastValidatedManager;
                ulong domain = playerIdentityDomain;
                ulong world = playerIdentityWorld;
                ulong local = playerIdentityLocal;
                int localId = playerIdentityLocalId;
                bool active = true;
                ResetBudget();
                LiveMenuContext context = new LiveMenuContext {
                    ContextId = expectedContextId, Domain = domain, GameImage = gameImage,
                    WorldAddress = world, LocalPlayerAddress = local, LocalPlayerId = localId
                };
                context.ValidateAction = delegate
                {
                    double age = captured == 0 ? Double.PositiveInfinity :
                        (Stopwatch.GetTimestamp() - captured) * 1000.0 / Stopwatch.Frequency;
                    if (!active || captured == 0 || age < 0 || age > 2000 ||
                        String.IsNullOrEmpty(expectedContextId) || playerContextId != expectedContextId ||
                        lastValidatedCaptureTimestamp != captured || LocalPlayerAddress != local || local == 0)
                        throw new IOException("CONTEXTE_MENU_EXPIRE : une capture valide et recente de cette partie est requise.");
                    StaticStorage storage = FindManagerStorage();
                    ulong slot = Add(storage.Data, Offset("GameManager", "Instance"));
                    if (storage.Domain != domain || Pointer(slot) != manager)
                        throw new IOException("CONTEXTE_MENU_MODIFIE : domaine ou gestionnaire de partie modifie.");
                    ValidateClassHeader(gameClasses["World"], Read(gameClasses["World"].Address, 0x60));
                    ValidateClassHeader(gameClasses["EntityPlayerLocal"], Read(gameClasses["EntityPlayerLocal"].Address, 0x60));
                    byte[] managerData = ReadObject(manager, gameClasses["GameManager"], domain);
                    byte[] worldData = ReadObject(world, gameClasses["World"], domain);
                    EntityState localData = ReadEntityState(local, world, domain);
                    if (!Boolean(managerData, Offset("GameManager", "GameHasStarted")) ||
                        managerData[Offset("GameManager", "worldCreated")] > 1 ||
                        BufferPointer(managerData, Offset("GameManager", "m_World")) != world ||
                        BufferPointer(managerData, Offset("GameManager", "myEntityPlayerLocal")) != local ||
                        BitConverter.ToInt32(managerData, Offset("GameManager", "myPlayerId")) != localId ||
                        BufferPointer(worldData, Offset("World", "m_LocalPlayerEntity")) != local ||
                        localData.Id != localId || localData.Removed ||
                        localData.ClassAddress != gameClasses["EntityPlayerLocal"].Address)
                        throw new IOException("CONTEXTE_MENU_MODIFIE : la partie ou le joueur local a change.");
                    ValidateStorage(storage);
                    if (Pointer(slot) != manager) throw new IOException("CONTEXTE_MENU_MODIFIE : gestionnaire remplace.");
                };
                try
                {
                    context.Validate();
                    return operation(context);
                }
                finally
                {
                    active = false;
                    context.ValidateAction = null;
                }
            }
        }

        private void CommitPlayerIdentities(LiveEntitySnapshot snapshot, List<PlayerIdentityCandidate> candidates,
            ulong world, ulong local, int localId, ulong domain)
        {
            bool sameContext = playerContextId != null && playerIdentityWorld == world &&
                playerIdentityLocal == local && playerIdentityLocalId == localId && playerIdentityDomain == domain;
            // The counter is not recycled in an existing context, including at overflow.
            if (nextPlayerIdentityToken > Int64.MaxValue - candidates.Count || nextPlayerCaptureSequence == Int64.MaxValue) sameContext = false;
            string context = sameContext ? playerContextId : Guid.NewGuid().ToString("N");
            long nextToken = nextPlayerIdentityToken > Int64.MaxValue - candidates.Count ? 0 : nextPlayerIdentityToken;
            Dictionary<int, PlayerInstanceIdentity> accepted = new Dictionary<int, PlayerInstanceIdentity>();
            foreach (PlayerIdentityCandidate candidate in candidates)
            {
                PlayerInstanceIdentity previous;
                long token = sameContext && playerIdentities.TryGetValue(candidate.Entity.EntityId, out previous) &&
                    previous.Address == candidate.Address && previous.ClassAddress == candidate.ClassAddress ?
                    previous.Token : ++nextToken;
                accepted.Add(candidate.Entity.EntityId, new PlayerInstanceIdentity
                    { Address = candidate.Address, ClassAddress = candidate.ClassAddress, Token = token });
            }
            // No old LiveEntity is retained or edited. Previously published snapshots
            // therefore keep their identities when an ID is recycled by the game.
            foreach (PlayerIdentityCandidate candidate in candidates)
                candidate.Entity.IdentityToken = accepted[candidate.Entity.EntityId].Token;
            snapshot.PlayerContextId = context;
            snapshot.PlayerCaptureSequence = nextPlayerCaptureSequence == Int64.MaxValue ? 1 : nextPlayerCaptureSequence + 1;
            playerIdentities = accepted;
            playerIdentityWorld = world;
            playerIdentityLocal = local;
            playerIdentityLocalId = localId;
            playerIdentityDomain = domain;
            playerContextId = context;
            nextPlayerIdentityToken = nextToken;
            nextPlayerCaptureSequence = snapshot.PlayerCaptureSequence;
        }

        private int ConfirmWorld(ulong domain, ulong manager, ulong world, ulong local, int localId, long timestamp)
        {
            bool continuous = confirmationCount > 0 && confirmationDomain == domain &&
                confirmationManager == manager && confirmationWorld == world && confirmationLocal == local &&
                confirmationLocalId == localId && timestamp >= confirmationTimestamp &&
                ((timestamp - confirmationTimestamp) * 1000.0 / Stopwatch.Frequency) <= MaximumConfirmationGapMilliseconds;
            confirmationCount = continuous ? Math.Min(RequiredWorldConfirmations, confirmationCount + 1) : 1;
            confirmationDomain = domain;
            confirmationManager = manager;
            confirmationWorld = world;
            confirmationLocal = local;
            confirmationLocalId = localId;
            confirmationTimestamp = timestamp;
            return confirmationCount;
        }

        private void ResetWorldConfirmation()
        {
            confirmationCount = 0;
            confirmationTimestamp = 0;
            confirmationDomain = 0;
            confirmationManager = 0;
            confirmationWorld = 0;
            confirmationLocal = 0;
            confirmationLocalId = -1;
        }

        private static string ReferenceState(ulong value)
        {
            if (value == 0) return "NULLE";
            return value >= 0x10000 && value <= 0x00007FFFFFFFFFFFUL ? "PRESENTE" : "HORS_PLAGE";
        }

        private static string FlagSummary(LiveReadDiagnostics diagnostic)
        {
            return "GameHasStarted=" + diagnostic.GameHasStartedRaw + ", worldCreated=" + diagnostic.WorldCreatedRaw;
        }

        private StaticStorage FindManagerStorage()
        {
            RuntimeClass type = gameClasses["GameManager"];
            byte[] header = Read(type.Address, 0xD8);
            ValidateClassHeader(type, header);
            ulong runtime = BufferPointer(header, 0xD0);
            int maxDomain = U16(runtime);
            if (maxDomain >= 32) throw new IOException("Nombre de domaines Mono hors limites.");
            StaticStorage selected = null;
            for (int index = 0; index <= maxDomain; index++)
            {
                ulong slot = runtime + 8UL + (ulong)index * 8UL;
                ulong table = U64(slot);
                if (table == 0) continue;
                StaticStorage candidate = Storage(type, header, runtime, slot, table);
                if (candidate == null) continue;
                CheckOffset(Offset("GameManager", "Instance"), candidate.Size, 8, false);
                ulong instance = U64(Add(candidate.Data, Offset("GameManager", "Instance")));
                if (instance == 0) continue;
                RequirePointer(instance);
                if (selected != null) throw new IOException("Plusieurs instances GameManager initialisees ; choix du monde ambigu.");
                selected = candidate;
            }
            if (selected == null) throw new CaptureStateException("GESTIONNAIRE_ABSENT", "Aucune instance de gestionnaire de partie trouvee. Attente automatique du chargement.");
            return selected;
        }

        private StaticStorage GetStorageForDomain(RuntimeClass type, ulong domain)
        {
            byte[] header = Read(type.Address, 0xD8);
            ValidateClassHeader(type, header);
            ulong runtime = BufferPointer(header, 0xD0);
            int maxDomain = U16(runtime);
            if (maxDomain >= 32) throw new IOException("Nombre de domaines Mono hors limites.");
            StaticStorage selected = null;
            for (int index = 0; index <= maxDomain; index++)
            {
                ulong slot = runtime + 8UL + (ulong)index * 8UL;
                ulong table = U64(slot);
                if (table == 0) continue;
                StaticStorage candidate = Storage(type, header, runtime, slot, table);
                if (candidate == null || candidate.Domain != domain) continue;
                if (selected != null) throw new IOException("Stockage statique Mono duplique.");
                selected = candidate;
            }
            if (selected == null) throw new IOException("L'origine du monde n'est pas initialisee dans le domaine de la partie.");
            return selected;
        }

        private StaticStorage Storage(RuntimeClass type, byte[] header, ulong runtime, ulong runtimeSlot, ulong table)
        {
            byte[] data = Read(table, 0x48);
            if (BitConverter.ToUInt64(data, 0) != type.Address) throw new IOException("La vtable statique ne correspond pas a la classe attendue.");
            if (data[0x2D] == 0) return null;
            uint flags = BitConverter.ToUInt32(data, 0x30);
            int slots = BitConverter.ToInt32(header, 0x5C);
            int size = BitConverter.ToInt32(header, 0x90);
            if (data[0x2D] != 1 || (flags & 2U) != 0 || (flags & 4U) == 0 || slots < 0 || slots > 4096 || size < 1 || size > 1048576)
                throw new IOException("Stockage statique Mono non reconnu.");
            ulong staticSlot = table + 0x48UL + (ulong)slots * 8UL;
            return new StaticStorage { ClassAddress = type.Address, Runtime = runtime, RuntimeSlot = runtimeSlot,
                VTable = table, Domain = BufferPointer(data, 0x10), StaticSlot = staticSlot, Data = Pointer(staticSlot), Size = size };
        }

        private void ValidateStorage(StaticStorage storage)
        {
            if (Pointer(storage.ClassAddress + 0xD0UL) != storage.Runtime || U64(storage.RuntimeSlot) != storage.VTable ||
                Pointer(storage.StaticSlot) != storage.Data || ValidateVTable(storage.VTable, storage.Domain) != storage.ClassAddress)
                throw new IOException("Le domaine Mono ou son stockage statique a change.");
        }

        private ListLayout GetListLayout(ulong address)
        {
            ListLayout cached;
            if (listCache.TryGetValue(address, out cached)) return cached;
            RuntimeClass type = GetClass(address);
            if (type.Kind != 3 || type.Name != "List`1" || type.Namespace != "System.Collections.Generic")
                throw new IOException("World.EntityAlives n'est pas une List<T> Mono reconnue.");
            ulong generic = Pointer(address + 0xF0UL);
            byte[] genericData = Read(generic, 0x28);
            ulong definition = BufferPointer(genericData, 0);
            RuntimeClass genericDefinition = GetClass(definition);
            if (genericDefinition.Kind != 2 || genericDefinition.Name != type.Name || genericDefinition.Namespace != type.Namespace ||
                genericDefinition.Image != type.Image || BitConverter.ToUInt64(genericData, 0x20) != address)
                throw new IOException("Definition generique de List<T> incoherente.");
            ulong arguments = BufferPointer(genericData, 8);
            byte[] argumentHeader = Read(arguments, 16);
            uint argumentFlags = BitConverter.ToUInt32(argumentHeader, 4);
            if ((argumentFlags & 0x3FFFFFU) != 1 || (argumentFlags & 0x400000U) != 0 || BitConverter.ToUInt64(genericData, 0x10) != 0)
                throw new IOException("La liste n'a pas exactement un argument generique ferme.");
            byte[] elementType = Read(BufferPointer(argumentHeader, 8), 16);
            if (elementType[10] != 0x12 || BitConverter.ToUInt64(elementType, 0) != gameClasses["EntityAlive"].Address)
                throw new IOException("La liste ne declare pas EntityAlive comme type d'element.");
            int count = I32(definition + 0x100UL);
            if (count < 3 || count > 128) throw new IOException("Nombre de champs de List<T> hors limites.");
            ulong fieldArray = Pointer(address + 0x98UL);
            RuntimeField items = null, size = null, version = null;
            for (int index = 0; index < count; index++)
            {
                byte[] raw = Read(fieldArray + (ulong)index * 32UL, 32);
                if (BitConverter.ToUInt64(raw, 16) != address) throw new IOException("Parent de champ List<T> incoherent.");
                string name = CString(BufferPointer(raw, 8));
                if (name != "_items" && name != "_size" && name != "_version") continue;
                byte[] fieldType = Read(BufferPointer(raw, 0), 16);
                ushort flags = BitConverter.ToUInt16(fieldType, 8);
                if ((flags & 0x50) != 0) throw new IOException("Champ de liste statique inattendu.");
                RuntimeField field = new RuntimeField { Name = name, Offset = BitConverter.ToInt32(raw, 24), TypeCode = fieldType[10], TypeData = BitConverter.ToUInt64(fieldType, 0) };
                if (name == "_items") { if (items != null) throw new IOException("Champ _items duplique."); items = field; }
                if (name == "_size") { if (size != null) throw new IOException("Champ _size duplique."); size = field; }
                if (name == "_version") { if (version != null) throw new IOException("Champ _version duplique."); version = field; }
            }
            if (items == null || size == null || version == null || items.TypeCode != 0x1D ||
                items.TypeData != gameClasses["EntityAlive"].Address || size.TypeCode != 0x08 || version.TypeCode != 0x08)
                throw new IOException("Champs _items/_size/_version de List<EntityAlive> non reconnus.");
            CheckOffset(items.Offset, type.Size, 8, true); CheckOffset(size.Offset, type.Size, 4, true); CheckOffset(version.Offset, type.Size, 4, true);
            if (Overlaps(items.Offset, 8, size.Offset, 4) || Overlaps(items.Offset, 8, version.Offset, 4) ||
                Overlaps(size.Offset, 4, version.Offset, 4))
                throw new IOException("Champs de liste superposes.");
            cached = new ListLayout { ClassAddress = address, Size = type.Size, ItemsOffset = items.Offset, CountOffset = size.Offset, VersionOffset = version.Offset };
            listCache.Add(address, cached);
            return cached;
        }

        private EntityState ReadEntityState(ulong instance, ulong world, ulong domain)
        {
            byte[] data = Read(instance, entityReadSize);
            ulong table = BufferPointer(data, 0);
            ulong klass = ValidateVTable(table, domain);
            RuntimeClass type = GetClass(klass);
            if (type.Size < entityReadSize || !HasAncestor(klass, gameClasses["EntityAlive"].Address))
                throw new IOException("L'objet ne correspond pas a une entite vivante du jeu.");
            if (BufferPointer(data, Offset("Entity", "world")) != world) throw new IOException("L'entite appartient a un autre monde.");
            int id = BitConverter.ToInt32(data, Offset("Entity", "entityId"));
            if (id < 0) throw new IOException("Identifiant d'entite invalide.");
            bool removed = Boolean(data, Offset("Entity", "bDead")) || Boolean(data, Offset("Entity", "IsDespawned")) ||
                Boolean(data, Offset("Entity", "markedForUnload")) || Boolean(data, Offset("Entity", "isUnloaded"));
            return new EntityState { VTable = table, ClassAddress = klass, Id = id,
                Position = Position(data, Offset("Entity", "position")), Bounds = ReadBounds(data),
                NamePointer = BitConverter.ToUInt64(data, Offset("EntityAlive", "entityName")),
                StatsPointer = statsPointerOffset >= 0 ? BitConverter.ToUInt64(data, statsPointerOffset) : 0,
                EntityClassId = entityClassOffset >= 0 ? BitConverter.ToInt32(data, entityClassOffset) : -1,
                Removed = removed };
        }

        private void InitializeOptionalDetails(MonoInspectionReport metadata)
        {
            try
            {
                statsClass = OptionalGameClass(metadata, "EntityStats");
                Bind(metadata, "EntityAlive", "entityStats", "0x12", "EntityStats", 8, false, false);
                Bind(metadata, "EntityStats", "Health", "0x12", "Stat", 8, false, false);
                Bind(metadata, "EntityStats", "m_entity", "0x12", "EntityAlive", 8, false, false);
                statsPointerOffset = Offset("EntityAlive", "entityStats");
                statsHealthOffset = Offset("EntityStats", "Health");
                statsOwnerOffset = Offset("EntityStats", "m_entity");
            }
            catch (ReadLimitException) { throw; }
            catch (IOException) { statsClass = null; statsPointerOffset = -1; }
            try
            {
                progressionStatClass = OptionalGameClass(metadata, "Progression");
                Bind(metadata, "EntityAlive", "Progression", "0x12", "Progression", 8, false, false);
                progressionPointerOffset = Offset("EntityAlive", "Progression");
            }
            catch (ReadLimitException) { throw; }
            catch (IOException) { progressionStatClass = null; progressionPointerOffset = -1; }
            try
            {
                classDefinitionClass = OptionalGameClass(metadata, "EntityClass");
                Bind(metadata, "Entity", "entityClass", "0x08", "System.Int32", 4, false, false);
                Bind(metadata, "EntityClass", "list", "0x15", "DictionarySave`2", 8, true, true);
                Bind(metadata, "EntityClass", "entityClassName", "0x0E", "System.String", 8, false, false);
                entityClassOffset = Offset("Entity", "entityClass");
                classListOffset = Offset("EntityClass", "list");
                classNameOffset = Offset("EntityClass", "entityClassName");
            }
            catch (ReadLimitException) { throw; }
            catch (IOException) { classDefinitionClass = null; entityClassOffset = -1; }
        }

        private RuntimeClass OptionalGameClass(MonoInspectionReport metadata, string name)
        {
            MonoClassReport report = ReportClass(metadata, name);
            RuntimeClass type = GetClass(ParseAddress(report.Address));
            if (type.Kind != 1 || type.Name != name || type.Namespace != String.Empty ||
                type.Image != gameImage || type.Size != report.InstanceSize || type.Size > 65536)
                throw new IOException("Classe optionnelle non confirmee : " + name + ".");
            gameClasses.Add(name, type);
            return type;
        }

        private void ResetOptionalBudget()
        {
            optionalClock.Reset(); readingOptional = false; optionalExhausted = false;
            optionalReadCalls = 0; optionalReadBytes = 0;
            validatedOptionalLayouts.Clear(); nameRegistry = null; nameRegistryAttempted = false;
        }

        private void CheckOptionalBudget(int count)
        {
            if (!readingOptional) return;
            if (optionalExhausted || optionalClock.ElapsedMilliseconds >= OptionalMilliseconds ||
                optionalReadCalls >= OptionalCalls || count < 0 || optionalReadBytes > OptionalBytes - count)
            { optionalExhausted = true; throw new OptionalReadLimitException(); }
        }

        // Names/health are optional. Their own budget must not turn a slow or
        // unknown auxiliary graph into an invalid world/camera capture.
        private void FinalizeOptionalDetails(LiveEntitySnapshot snapshot)
        {
            bool classNamesValid = true;
            if (nameRegistry != null)
            {
                readingOptional = true; optionalClock.Start();
                try { ValidateNameRegistry(nameRegistry); }
                catch (ReadLimitException) { throw; }
                catch (IOException) { classNamesValid = false; }
                finally { optionalClock.Stop(); readingOptional = false; }
            }
            if (!classNamesValid)
                foreach (LiveEntity entity in snapshot.Entities)
                    if (entity.NameSource == "entityClassName")
                    {
                        entity.Name = "Zombie " + entity.EntityId.ToString(CultureInfo.InvariantCulture);
                        entity.NameSource = "fallback";
                        snapshot.Diagnostics.ClassNames--; snapshot.Diagnostics.FallbackNames++;
                    }
            snapshot.Diagnostics.OptionalDetailsReadCalls = optionalReadCalls;
            snapshot.Diagnostics.OptionalDetailsReadBytes = optionalReadBytes;
            snapshot.Diagnostics.OptionalDetailsMilliseconds = optionalClock.Elapsed.TotalMilliseconds;
            snapshot.Diagnostics.OptionalDetailsBudgetReached = optionalExhausted;
        }

        private OptionalLayout GetOptionalLayout(RuntimeClass type)
        {
            OptionalLayout cached;
            if (optionalLayouts.TryGetValue(type.Address, out cached))
            {
                if (!validatedOptionalLayouts.Contains(type.Address))
                {
                    byte[] header = Read(type.Address, 0x110);
                    ValidateClassHeader(type, header);
                    if (BitConverter.ToUInt64(header, 0x98) != cached.FieldArray ||
                        (type.Kind == 1 && BitConverter.ToInt32(header, 0x100) != cached.FieldCount) ||
                        (type.Kind == 3 && (BitConverter.ToUInt64(header, 0xF0) != cached.GenericContext ||
                            I32(cached.Definition + 0x100UL) != cached.FieldCount)))
                        throw new IOException("Metadonnees de details modifiees pendant la session.");
                    validatedOptionalLayouts.Add(type.Address);
                }
                return cached;
            }
            if (optionalLayouts.Count >= 32 || type.Size < 16 || type.Size > 4096)
                throw new IOException("Type optionnel trop grand ou trop nombreux.");
            byte[] data = Read(type.Address, 0x110);
            ValidateClassHeader(type, data);
            int count;
            ulong generic = 0, definition = 0;
            if (type.Kind == 1) count = BitConverter.ToInt32(data, 0x100);
            else if (type.Kind == 3)
            {
                generic = BufferPointer(data, 0xF0);
                byte[] context = Read(generic, 0x28);
                definition = BufferPointer(context, 0);
                RuntimeClass open = GetClass(definition);
                if (open.Kind != 2 || open.Name != type.Name || open.Namespace != type.Namespace ||
                    open.Image != type.Image || BitConverter.ToUInt64(context, 0x20) != type.Address)
                    throw new IOException("Definition generique optionnelle incoherente.");
                count = I32(definition + 0x100UL);
            }
            else throw new IOException("Type optionnel non pris en charge.");
            if (count < 1 || count > 128) throw new IOException("Nombre de champs optionnels hors limites.");
            ulong fieldsAddress = BufferPointer(data, 0x98);
            byte[] all = Read(fieldsAddress, count * 32);
            var layout = new OptionalLayout { Type = type, FieldArray = fieldsAddress,
                GenericContext = generic, Definition = definition, FieldCount = count };
            for (int i = 0; i < count; i++)
            {
                int pos = i * 32;
                if (BitConverter.ToUInt64(all, pos + 16) != type.Address) throw new IOException("Parent de champ optionnel incoherent.");
                string name = CString(BufferPointer(all, pos + 8));
                byte[] fieldType = Read(BufferPointer(all, pos), 16);
                ushort attributes = BitConverter.ToUInt16(fieldType, 8);
                if ((attributes & 0x50) != 0) continue;
                if (layout.Fields.ContainsKey(name)) throw new IOException("Champ optionnel duplique.");
                layout.Fields.Add(name, new RuntimeField { Name = name, Offset = BitConverter.ToInt32(all, pos + 24),
                    TypeCode = fieldType[10], TypeData = BitConverter.ToUInt64(fieldType, 0) });
            }
            optionalLayouts.Add(type.Address, layout);
            validatedOptionalLayouts.Add(type.Address);
            return layout;
        }

        private static RuntimeField RequiredOptionalField(OptionalLayout layout, string name, byte code, int width)
        {
            RuntimeField field;
            if (!layout.Fields.TryGetValue(name, out field) || field.TypeCode != code)
                throw new IOException("Champ optionnel absent ou non reconnu : " + layout.Type.Name + "." + name);
            CheckOffset(field.Offset, layout.Type.Size, width, true);
            return field;
        }

        private static void DistinctOptionalFields(params RuntimeField[] fields)
        {
            for (int i = 0; i < fields.Length; i++)
                for (int j = i + 1; j < fields.Length; j++)
                {
                    int a = fields[i].TypeCode == 0x12 || fields[i].TypeCode == 0x15 || fields[i].TypeCode == 0x1D ? 8 : 4;
                    int b = fields[j].TypeCode == 0x12 || fields[j].TypeCode == 0x15 || fields[j].TypeCode == 0x1D ? 8 : 4;
                    if (Overlaps(fields[i].Offset, a, fields[j].Offset, b))
                        throw new IOException("Champs optionnels superposes.");
                }
        }

        private void ReadHealth(ulong instance, EntityState state, ulong domain, out int? health, out int? maximum)
        {
            health = null; maximum = null;
            if (statsClass == null || state.StatsPointer == 0) return;
            OptionalLayout statsLayout = GetOptionalLayout(statsClass);
            RuntimeField healthField = RequiredOptionalField(statsLayout, "Health", 0x12, 8);
            RuntimeField ownerField = RequiredOptionalField(statsLayout, "m_entity", 0x12, 8);
            DistinctOptionalFields(healthField, ownerField);
            if (healthField.Offset != statsHealthOffset || ownerField.Offset != statsOwnerOffset ||
                ownerField.TypeData != gameClasses["EntityAlive"].Address)
                throw new IOException("Chaine EntityStats non confirmee.");
            RuntimeClass statClass = GetClass(healthField.TypeData);
            if (statClass.Kind != 1 || statClass.Name != "Stat" || statClass.Namespace != String.Empty || statClass.Image != gameImage)
                throw new IOException("Le champ Health ne declare pas le Stat attendu.");
            OptionalLayout statLayout = GetOptionalLayout(statClass);
            RuntimeField value = RequiredOptionalField(statLayout, "m_value", 0x0C, 4);
            RuntimeField baseMax = RequiredOptionalField(statLayout, "m_baseMax", 0x0C, 4);
            RuntimeField modifier = RequiredOptionalField(statLayout, "m_maxModifier", 0x0C, 4);
            RuntimeField statOwner = RequiredOptionalField(statLayout, "Entity", 0x12, 8);
            DistinctOptionalFields(value, baseMax, modifier, statOwner);
            if (statOwner.TypeData != gameClasses["EntityAlive"].Address)
                throw new IOException("Proprietaire de Stat non confirme.");
            byte[] stats = ReadObject(state.StatsPointer, statsClass, domain);
            if (BitConverter.ToUInt64(stats, ownerField.Offset) != instance) throw new IOException("EntityStats appartient a une autre entite.");
            ulong stat = BufferPointer(stats, healthField.Offset);
            byte[] first = ReadObject(stat, statClass, domain);
            byte[] second = ReadObject(stat, statClass, domain);
            if (BitConverter.ToUInt64(first, 0) != BitConverter.ToUInt64(second, 0) ||
                BitConverter.ToUInt64(first, statOwner.Offset) != instance || BitConverter.ToUInt64(second, statOwner.Offset) != instance ||
                BitConverter.ToInt32(first, value.Offset) != BitConverter.ToInt32(second, value.Offset) ||
                BitConverter.ToInt32(first, baseMax.Offset) != BitConverter.ToInt32(second, baseMax.Offset) ||
                BitConverter.ToInt32(first, modifier.Offset) != BitConverter.ToInt32(second, modifier.Offset))
                throw new IOException("La valeur de vie a change pendant sa lecture.");
            byte[] after = ReadObject(state.StatsPointer, statsClass, domain);
            if (BitConverter.ToUInt64(after, 0) != BitConverter.ToUInt64(stats, 0) ||
                BitConverter.ToUInt64(after, ownerField.Offset) != instance || BitConverter.ToUInt64(after, healthField.Offset) != stat)
                throw new IOException("La reference Health a change pendant sa lecture.");
            float raw = BitConverter.ToSingle(second, value.Offset);
            float baseValue = BitConverter.ToSingle(second, baseMax.Offset);
            float adjustment = BitConverter.ToSingle(second, modifier.Offset);
            float effective = baseValue + adjustment;
            if (!Finite(raw) || !Finite(baseValue) || !Finite(adjustment) || !Finite(effective) ||
                baseValue < 0 || Math.Abs(baseValue) > 1000000000f || Math.Abs(adjustment) > 1000000000f ||
                effective < 1 || effective > 1000000000f)
                throw new IOException("Valeurs de vie non finies ou hors limites.");
            // Assembly-CSharp supplied by the user: Stats.Health.Value clamps
            // m_value to [0, ModifiedMax]; ModifiedMax is baseMax + maxModifier.
            // The GodModeEntity branch only applies to World's primary local
            // player, which this capture excludes, after checking both owners.
            // MaxHealth here is the effective ceiling for the bar, not the
            // unmodified base returned by EntityAlive.GetMaxHealth().
            health = (int)Math.Max(0f, Math.Min(raw, effective));
            maximum = (int)effective;
        }

        private void ValidateClassDictionaryType(RuntimeClass type, string name, string ns)
        {
            if (type.Kind != 3 || type.Name != name || type.Namespace != ns)
                throw new IOException("Type de registre de noms non reconnu.");
            OptionalLayout layout = GetOptionalLayout(type);
            byte[] generic = Read(layout.GenericContext, 0x28);
            ulong arguments = BufferPointer(generic, 8);
            byte[] args = Read(arguments, 24);
            uint flags = BitConverter.ToUInt32(args, 4);
            if ((flags & 0x3FFFFFU) != 2 || (flags & 0x400000U) != 0 || BitConverter.ToUInt64(generic, 0x10) != 0)
                throw new IOException("Arguments du registre de noms non reconnus.");
            byte[] key = Read(BufferPointer(args, 8), 16), value = Read(BufferPointer(args, 16), 16);
            if (key[10] != 0x08 || value[10] != 0x12 || BitConverter.ToUInt64(value, 0) != classDefinitionClass.Address)
                throw new IOException("Le registre ne declare pas Int32 et EntityClass.");
        }

        private NameRegistry ReadNameRegistry(ulong domain)
        {
            if (classDefinitionClass == null) return null;
            StaticStorage storage = GetStorageForDomain(classDefinitionClass, domain);
            CheckOffset(classListOffset, storage.Size, 8, false);
            ulong wrapper = Pointer(Add(storage.Data, classListOffset));
            ulong wrapperTable = Pointer(wrapper);
            RuntimeClass wrapperType = GetClass(ValidateVTable(wrapperTable, domain));
            if (wrapperType.Image != gameImage) throw new IOException("Le registre de noms appartient a une autre assembly.");
            ValidateClassDictionaryType(wrapperType, "DictionarySave`2", "");
            RuntimeField dicField = RequiredOptionalField(GetOptionalLayout(wrapperType), "dic", 0x15, 8);
            byte[] wrapperData = ReadObject(wrapper, wrapperType, domain);
            ulong dictionary = BufferPointer(wrapperData, dicField.Offset), dictionaryTable = Pointer(dictionary);
            RuntimeClass dictionaryType = GetClass(ValidateVTable(dictionaryTable, domain));
            byte[] declaredDictionary = Read(dicField.TypeData, 0x28);
            if (BitConverter.ToUInt64(declaredDictionary, 0x20) != dictionaryType.Address)
                throw new IOException("Le type declare du dictionnaire de noms ne correspond pas a son objet.");
            ValidateClassDictionaryType(dictionaryType, "Dictionary`2", "System.Collections.Generic");
            OptionalLayout layout = GetOptionalLayout(dictionaryType);
            RuntimeField entries = RequiredOptionalField(layout, "entries", 0x1D, 8);
            RuntimeField count = RequiredOptionalField(layout, "count", 0x08, 4);
            RuntimeField version = RequiredOptionalField(layout, "version", 0x08, 4);
            DistinctOptionalFields(entries, count, version);
            byte[] dictionaryData = ReadObject(dictionary, dictionaryType, domain);
            int entryCount = BitConverter.ToInt32(dictionaryData, count.Offset);
            if (entryCount < 0 || entryCount > MaximumRegistryEntries) throw new IOException("Registre de noms trop grand.");
            var result = new NameRegistry { Storage = storage, Wrapper = wrapper, WrapperTable = wrapperTable, WrapperType = wrapperType,
                Dictionary = dictionary, DictionaryTable = dictionaryTable, DictionaryType = dictionaryType,
                WrapperDictionaryOffset = dicField.Offset, EntriesOffset = entries.Offset, CountOffset = count.Offset,
                VersionOffset = version.Offset, Count = entryCount, Version = BitConverter.ToInt32(dictionaryData, version.Offset) };
            if (entryCount == 0) { ValidateNameRegistry(result); return result; }
            result.Entries = BufferPointer(dictionaryData, entries.Offset);
            byte[] header = Read(result.Entries, 0x20);
            result.EntriesTable = BufferPointer(header, 0);
            RuntimeClass array = GetClass(ValidateVTable(result.EntriesTable, domain));
            byte[] arrayData = Read(array.Address, 0x98);
            uint capacity = BitConverter.ToUInt32(header, 0x18);
            RuntimeClass entryClass = GetClass(entries.TypeData);
            if (array.Kind != 5 || arrayData[0x1A] != 1 || BitConverter.ToUInt64(arrayData, 0) != entryClass.Address ||
                BitConverter.ToUInt64(header, 0x10) != 0 || capacity > 65536 || entryCount > capacity ||
                entryClass.Kind != 3 || entryClass.Name != "Entry" || entryClass.Image != dictionaryType.Image)
                throw new IOException("Tableau d'entrees du registre non reconnu.");
            OptionalLayout entryLayout = GetOptionalLayout(entryClass);
            RuntimeField hash = RequiredOptionalField(entryLayout, "hashCode", 0x08, 4);
            RuntimeField key = RequiredOptionalField(entryLayout, "key", 0x08, 4);
            RuntimeField value = RequiredOptionalField(entryLayout, "value", 0x12, 8);
            DistinctOptionalFields(hash, key, value);
            if (value.TypeData != classDefinitionClass.Address) throw new IOException("Valeur d'entree de nom non reconnue.");
            // Mono field offsets are relative to the boxed value type. Array
            // entries contain the unboxed payload; the object header is 16 bytes.
            int stride = BitConverter.ToInt32(arrayData, 0x90);
            int hashOffset = hash.Offset - 16, keyOffset = key.Offset - 16, valueOffset = value.Offset - 16;
            if (stride < 16 || stride > 128 || hashOffset < 0 || keyOffset < 0 || valueOffset < 0 ||
                hashOffset > stride - 4 || keyOffset > stride - 4 || valueOffset > stride - 8)
                throw new IOException("Taille d'entree du registre incoherente.");
            int totalBytes = checked(entryCount * stride);
            CheckOptionalBudget(totalBytes);
            byte[] values = new byte[totalBytes];
            for (int at = 0; at < totalBytes; at += 32768)
            {
                int chunk = Math.Min(32768, totalBytes - at);
                byte[] part = Read(result.Entries + 0x20UL + (uint)at, chunk);
                Buffer.BlockCopy(part, 0, values, at, chunk);
            }
            for (int i = 0; i < entryCount; i++)
            {
                int start = i * stride;
                if (BitConverter.ToInt32(values, start + hashOffset) < 0) continue;
                // EntityClass.FromString/Add use String.GetHashCode; unlike
                // entity IDs, class keys are signed and can be negative.
                int id = BitConverter.ToInt32(values, start + keyOffset);
                ulong item = BitConverter.ToUInt64(values, start + valueOffset);
                if (result.Objects.ContainsKey(id)) throw new IOException("Identifiant de classe de nom duplique.");
                RequirePointer(item); result.Objects.Add(id, item);
            }
            ValidateNameRegistry(result);
            return result;
        }

        private void ValidateNameRegistry(NameRegistry registry)
        {
            ValidateStorage(registry.Storage);
            if (Pointer(Add(registry.Storage.Data, classListOffset)) != registry.Wrapper)
                throw new IOException("Le registre de noms a change.");
            byte[] wrapper = ReadObject(registry.Wrapper, registry.WrapperType, registry.Storage.Domain);
            byte[] dictionary = ReadObject(registry.Dictionary, registry.DictionaryType, registry.Storage.Domain);
            if (BitConverter.ToUInt64(wrapper, 0) != registry.WrapperTable ||
                BitConverter.ToUInt64(wrapper, registry.WrapperDictionaryOffset) != registry.Dictionary ||
                BitConverter.ToUInt64(dictionary, 0) != registry.DictionaryTable ||
                BitConverter.ToInt32(dictionary, registry.CountOffset) != registry.Count ||
                BitConverter.ToInt32(dictionary, registry.VersionOffset) != registry.Version ||
                (registry.Count > 0 && BitConverter.ToUInt64(dictionary, registry.EntriesOffset) != registry.Entries))
                throw new IOException("Le dictionnaire des noms a change pendant la capture.");
        }

        private string ReadClassName(int classId, ulong domain)
        {
            if (!nameRegistryAttempted) { nameRegistryAttempted = true; nameRegistry = ReadNameRegistry(domain); }
            ulong instance;
            if (nameRegistry == null || !nameRegistry.Objects.TryGetValue(classId, out instance)) return null;
            int length = Math.Max(16, classNameOffset + 8);
            if (length > classDefinitionClass.Size || length > 4096) throw new IOException("Champ de nom de classe hors limites.");
            byte[] data = Read(instance, length);
            if (ValidateVTable(BufferPointer(data, 0), domain) != classDefinitionClass.Address)
                throw new IOException("La definition d'entite a change de type.");
            ulong name = BufferPointer(data, classNameOffset);
            CachedClassName cached;
            if (classNames.TryGetValue(instance, out cached) && cached.Pointer == name) return cached.Name;
            string result = ReadName(name, domain);
            byte[] after = Read(instance, length);
            if (BitConverter.ToUInt64(after, 0) != BitConverter.ToUInt64(data, 0) || BitConverter.ToUInt64(after, classNameOffset) != name)
                throw new IOException("Le nom de classe a change pendant la lecture.");
            if (classNames.Count >= 512) classNames.Clear();
            classNames[instance] = new CachedClassName { Pointer = name, Name = result };
            return result;
        }

        private LiveBounds ReadBounds(byte[] data)
        {
            if (boundsOffset < 0) return null;
            try
            {
                LivePosition center = Position(data, boundsOffset);
                LivePosition extents = Position(data, boundsOffset + 12);
                // A malformed optional volume must never reject an otherwise
                // usable radar entity. Limits are deliberately broad for the
                // profiled player/zombie types, not universal Unity Bounds rules.
                if (extents.X <= 0 || extents.Y <= 0 || extents.Z <= 0 ||
                    extents.X > 64 || extents.Y > 64 || extents.Z > 64) return null;
                return new LiveBounds { Center = center, Extents = extents };
            }
            catch (IOException) { return null; }
        }

        private string Classify(ulong address)
        {
            string kind;
            if (kindCache.TryGetValue(address, out kind)) return kind;
            bool player = HasAncestor(address, gameClasses["EntityPlayer"].Address);
            bool zombie = HasAncestor(address, gameClasses["EntityZombie"].Address);
            if (player && zombie) throw new IOException("Hierarchie d'entite ambigue.");
            if ((player || zombie) && !HasAncestor(address, gameClasses["EntityAlive"].Address))
                throw new IOException("Classe d'entite hors de la hierarchie EntityAlive.");
            kind = player ? "player" : (zombie ? "zombie" : null);
            kindCache.Add(address, kind);
            return kind;
        }

        private bool HasAncestor(ulong address, ulong expected)
        {
            HashSet<ulong> visited = new HashSet<ulong>();
            for (int depth = 0; address != 0 && depth < 32; depth++)
            {
                if (!visited.Add(address)) throw new IOException("Cycle dans la hierarchie Mono.");
                if (address == expected) return true;
                address = GetClass(address).Parent;
            }
            if (address != 0) throw new IOException("Hierarchie Mono trop profonde.");
            return false;
        }

        private RuntimeClass GetClass(ulong address)
        {
            RequirePointer(address);
            RuntimeClass cached;
            if (classCache.TryGetValue(address, out cached)) return cached;
            if (classCache.Count >= 2048) throw new IOException("Trop de classes rencontrees ; redemarre le lecteur.");
            byte[] data = Read(address, 0x60);
            byte kind = data[0x1B];
            int size = BitConverter.ToInt32(data, 0x1C);
            ulong parent = BitConverter.ToUInt64(data, 0x30);
            if (kind < 1 || kind > 5 || size < 16 || size > 1048576) throw new IOException("Classe Mono non reconnue.");
            if (parent != 0) RequirePointer(parent);
            cached = new RuntimeClass { Address = address, Parent = parent, Image = BufferPointer(data, 0x40), Size = size, Kind = kind,
                Name = CString(BufferPointer(data, 0x48)), Namespace = CString(BufferPointer(data, 0x50)) };
            if (String.IsNullOrEmpty(cached.Name)) throw new IOException("Nom de classe Mono vide.");
            classCache.Add(address, cached);
            return cached;
        }

        private static void ValidateClassHeader(RuntimeClass type, byte[] data)
        {
            if (data[0x1B] != type.Kind || BitConverter.ToInt32(data, 0x1C) != type.Size ||
                BitConverter.ToUInt64(data, 0x40) != type.Image || BitConverter.ToUInt64(data, 0x30) != type.Parent)
                throw new IOException("Une classe Mono a change. Relance le lecteur pour reconstruire son profil.");
        }

        private ulong ValidateVTable(ulong address, ulong domain)
        {
            byte[] table = Read(address, 24);
            if (BitConverter.ToUInt64(table, 0x10) != domain) throw new IOException("L'objet appartient a un autre domaine Mono.");
            return BufferPointer(table, 0);
        }

        private byte[] ReadObject(ulong instance, RuntimeClass expected, ulong domain)
        {
            if (expected.Size > 65536) throw new IOException("Objet de controle trop volumineux.");
            byte[] data = Read(instance, expected.Size);
            if (ValidateVTable(BufferPointer(data, 0), domain) != expected.Address)
                throw new IOException("Type d'objet inattendu pour " + expected.Name + ".");
            return data;
        }

        private string ReadName(ulong instance, ulong domain)
        {
            byte[] header = Read(instance, 0x14);
            ulong table = BufferPointer(header, 0);
            RuntimeClass type = GetClass(ValidateVTable(table, domain));
            if (type.Kind != 1 || type.Name != "String" || type.Namespace != "System") throw new IOException("Type de nom d'entite inattendu.");
            int length = BitConverter.ToInt32(header, 0x10);
            if (length < 0 || length > 128) throw new IOException("Nom d'entite trop long.");
            if (length == 0) return String.Empty;
            string value;
            try { value = utf16.GetString(Read(instance + 0x14UL, length * 2)); }
            catch (DecoderFallbackException) { throw new IOException("Nom d'entite UTF-16 invalide."); }
            foreach (char c in value) if (Char.IsControl(c)) throw new IOException("Nom d'entite contenant des caracteres de controle.");
            byte[] after = Read(instance, 0x14);
            if (BitConverter.ToUInt64(after, 0) != table || BitConverter.ToInt32(after, 0x10) != length)
                throw new IOException("Nom d'entite modifie pendant la lecture.");
            return value;
        }

        private void Bind(MonoInspectionReport metadata, string className, string fieldName, string code, string type,
            int width, bool isStatic, bool partialGeneric)
        {
            MonoClassReport report = ReportClass(metadata, className);
            MonoFieldReport field = null;
            foreach (MonoFieldReport candidate in report.Fields)
                if (candidate.Name == fieldName) { if (field != null) throw new IOException("Champ duplique : " + className + "." + fieldName); field = candidate; }
            if (field == null || field.IsStatic != isStatic || field.IsLiteral || field.TypeCode != code ||
                (partialGeneric ? (field.Type == null || !field.Type.StartsWith(type, StringComparison.Ordinal)) : field.Type != type) ||
                (!partialGeneric && !String.IsNullOrEmpty(field.Issue)))
                throw new IOException("Champ requis absent ou incompatible : " + className + "." + fieldName);
            CheckOffset(field.Offset, isStatic ? 1048576 : gameClasses[className].Size, width, !isStatic);
            fields.Add(className + "." + fieldName, field.Offset);
        }

        private static MonoClassReport ReportClass(MonoInspectionReport metadata, string name)
        {
            MonoClassReport found = null;
            if (metadata.Classes != null)
                foreach (MonoClassReport item in metadata.Classes)
                    if (item != null && item.Name == name && String.IsNullOrEmpty(item.Namespace))
                    { if (found != null) throw new IOException("Classe ambigue : " + name); found = item; }
            if (found == null || found.Fields == null) throw new IOException("Classe requise absente : " + name);
            return found;
        }

        private int Offset(string type, string name) { return fields[type + "." + name]; }
        private static void CheckOffset(int offset, int size, int width, bool instance)
        {
            int alignment = width == 12 || width == 24 ? 4 : width;
            if (offset < (instance ? 16 : 0) || size < width || offset > size - width || offset % alignment != 0)
                throw new IOException("Offset de champ hors de son objet.");
        }
        private static bool Boolean(byte[] bytes, int offset)
        {
            byte value = bytes[offset];
            if (value > 1) throw new IOException("Valeur booleenne incoherente.");
            return value != 0;
        }
        private static LivePosition Position(byte[] bytes, int offset)
        {
            float x = BitConverter.ToSingle(bytes, offset), y = BitConverter.ToSingle(bytes, offset + 4), z = BitConverter.ToSingle(bytes, offset + 8);
            if (!Finite(x) || !Finite(y) || !Finite(z) || Math.Abs(x) > 10000000 || Math.Abs(y) > 10000000 || Math.Abs(z) > 10000000)
                throw new IOException("Position non finie ou hors limites.");
            return new LivePosition { X = x, Y = y, Z = z };
        }
        private static bool Finite(float value) { return !Single.IsNaN(value) && !Single.IsInfinity(value); }
        private static bool Overlaps(int first, int firstWidth, int second, int secondWidth)
        {
            return first < second + secondWidth && second < first + firstWidth;
        }
        private static bool SameBytes(byte[] a, byte[] b)
        {
            if (a.Length != b.Length) return false;
            for (int i = 0; i < a.Length; i++) if (a[i] != b[i]) return false;
            return true;
        }
        private string CString(ulong address)
        {
            RequirePointer(address);
            List<byte> bytes = new List<byte>();
            for (int offset = 0; offset < 256; )
            {
                int count = Math.Min(32, Math.Min(256 - offset, 4096 - (int)((address + (ulong)offset) & 4095UL)));
                byte[] block = Read(address + (ulong)offset, count);
                foreach (byte value in block)
                {
                    if (value == 0)
                    {
                        try { return utf8.GetString(bytes.ToArray()); }
                        catch (DecoderFallbackException) { throw new IOException("Nom de classe UTF-8 invalide."); }
                    }
                    if (value < 0x20) throw new IOException("Nom de classe invalide.");
                    bytes.Add(value);
                }
                offset += count;
            }
            throw new IOException("Nom de classe sans terminaison.");
        }
        private void ResetBudget() { clock = Stopwatch.StartNew(); readCalls = 0; readBytes = 0; }
        private byte[] Read(ulong address, int count)
        {
            CheckOptionalBudget(count);
            if (readingOptional) { optionalReadCalls++; optionalReadBytes += count; }
            RequirePointer(address);
            if (count < 1 || count > 65536 || address > 0x00007FFFFFFFFFFFUL - (uint)(count - 1)) throw new IOException("Plage de lecture invalide.");
            int limitMs = initializing ? 10000 : MaximumCaptureMilliseconds;
            if (clock.ElapsedMilliseconds > limitMs || readCalls >= MaximumReadCalls || readBytes > MaximumReadBytes - count) throw new ReadLimitException();
            readCalls++; readBytes += count;
            byte[] bytes = memory.Read(address, count);
            if (bytes == null || bytes.Length != count) throw new IOException("Lecture memoire incomplete.");
            CheckOptionalBudget(0);
            if (clock.ElapsedMilliseconds > limitMs) throw new ReadLimitException();
            return bytes;
        }
        private ulong Pointer(ulong address) { ulong value = U64(address); RequirePointer(value); return value; }
        private ulong U64(ulong address) { return BitConverter.ToUInt64(Read(address, 8), 0); }
        private int I32(ulong address) { return BitConverter.ToInt32(Read(address, 4), 0); }
        private int U16(ulong address) { return BitConverter.ToUInt16(Read(address, 2), 0); }
        private static ulong BufferPointer(byte[] bytes, int offset) { ulong value = BitConverter.ToUInt64(bytes, offset); RequirePointer(value); return value; }
        private static ulong Add(ulong address, int offset)
        {
            if (offset < 0 || address > 0x00007FFFFFFFFFFFUL - (uint)offset) throw new IOException("Depassement d'adresse.");
            return address + (uint)offset;
        }
        private static void RequirePointer(ulong value)
        {
            if (value < 0x10000 || value > 0x00007FFFFFFFFFFFUL) throw new IOException("Pointeur nul ou hors de la plage utilisateur reconnue.");
        }
        private static ulong ParseAddress(string value)
        {
            if (String.IsNullOrEmpty(value)) throw new IOException("Adresse de classe absente.");
            ulong address;
            string hex = value.StartsWith("0x", StringComparison.OrdinalIgnoreCase) ? value.Substring(2) : value;
            if (!UInt64.TryParse(hex, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out address)) throw new IOException("Adresse de classe invalide.");
            RequirePointer(address);
            return address;
        }
    }
}
