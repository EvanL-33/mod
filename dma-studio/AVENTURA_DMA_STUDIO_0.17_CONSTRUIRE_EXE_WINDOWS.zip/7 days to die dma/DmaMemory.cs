// SevenDaysEsp - acquisition MemProcFS ; ecriture de reference du menu sur demande explicite.
// API: https://github.com/ufrisk/MemProcFS/blob/master/includes/vmmdll.h
// Le succes d'une lecture exige le nombre exact d'octets demande.
using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

namespace SevenDaysEsp
{
    public interface IMemoryReader
    {
        byte[] Read(ulong address, int count);
        ulong ModuleBase(string name);
        ulong ExportAddress(string module, string symbol);
    }

    // Deliberately separate from IMemoryReader: ordinary acquisition and old
    // diagnostic scripts remain read-only. No caller supplies this through the UI.
    public interface IMenuMemoryWriter
    {
        uint ProcessId { get; }
        MenuReferenceWriteResult WriteMenuReference(uint expectedProcessId, ulong slot,
            ulong expectedReference, ulong replacementReference, CancellationToken cancellationToken);
    }

    public sealed class MenuReferenceWriteResult
    {
        public bool Attempted { get; set; }
        public bool ReportedSuccess { get; set; }
        public string Message { get; set; }
    }

    // Only the control bridge can mint this capability after validating the
    // pinned byte[] and all of its Mono roots. It is not an arbitrary address API.
    public sealed class ControlBufferLease
    {
        public ulong ArrayAddress { get; private set; }
        public long RequestedTimestamp { get; private set; }
        public ulong DataAddress { get { return checked(ArrayAddress + 0x20UL); } }
        public int Length { get { return 256; } }
        internal ControlBufferLease(ulong arrayAddress, long requestedTimestamp)
        { ArrayAddress = arrayAddress; RequestedTimestamp = requestedTimestamp; }
    }

    public interface IControlMemoryWriter
    {
        uint ProcessId { get; }
        ControlBufferWriteResult WriteControlRecord(uint expectedProcessId, ControlBufferLease lease,
            byte[] expectedRecord, byte[] replacementRecord, Action validateRoots, CancellationToken cancellationToken);
    }

    public sealed class ControlBufferWriteResult
    {
        public bool Attempted { get; set; }
        public bool CommitAttempted { get; set; }
        public bool ReportedSuccess { get; set; }
        public bool ReadbackConfirmed { get; set; }
        public string Message { get; set; }
    }

    // Capability for a single validated 4-byte value owned by the LOCAL player.
    // The address is resolved by LiveEntityReader, never typed by the user.
    public sealed class PlayerStatWriteLease
    {
        public ulong Address { get; private set; }
        public ulong Owner { get; private set; }
        internal PlayerStatWriteLease(ulong address, ulong owner) { Address = address; Owner = owner; }
    }

    public interface IPlayerStatMemoryWriter
    {
        uint ProcessId { get; }
        PlayerStatScalarWriteResult WritePlayerStatScalar(uint processId, PlayerStatWriteLease lease,
            byte[] before, byte[] after, Action validateRoots, CancellationToken cancellationToken);
    }

    public sealed class PlayerStatScalarWriteResult
    {
        public bool Attempted { get; set; }
        public bool Confirmed { get; set; }
        public string Message { get; set; }
    }

    public sealed class ModuleIdentity
    {
        public string Name { get; set; }
        public string BaseAddress { get; set; }
        public bool Present { get; set; }
        public bool HeaderReadable { get; set; }
        public string Machine { get; set; }
        public string TimeDateStamp { get; set; }
        public uint ImageSize { get; set; }
        public string HeaderSha256 { get; set; }
        public string Error { get; set; }
    }

    public sealed class DmaMemory : IMemoryReader, IMenuMemoryWriter, IControlMemoryWriter, IPlayerStatMemoryWriter, IDisposable
    {
        private readonly object gate = new object();
        private IntPtr library;
        private IntPtr directoryCookie;
        private IntPtr session;
        private bool disposed;
        public uint ProcessId { get; private set; }
        public long ReadCalls { get; private set; }
        public long ReadBytes { get; private set; }
        public string VmmVersion { get; private set; }
        public string TargetWindowsBuild { get; private set; }

        [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetDefaultDllDirectories(uint flags);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
        private static extern IntPtr AddDllDirectory(string path);
        [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool RemoveDllDirectory(IntPtr cookie);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
        private static extern IntPtr LoadLibraryExW(string path, IntPtr file, uint flags);
        [DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
        private static extern IntPtr GetProcAddress(IntPtr module, string name);
        [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool FreeLibrary(IntPtr module);

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate IntPtr InitializeFn(uint argc, IntPtr argv);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate void CloseFn(IntPtr vmm);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private delegate bool PidFn(IntPtr vmm, IntPtr name, out uint pid);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate ulong ModuleFn(IntPtr vmm, uint pid, IntPtr name);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate ulong ExportFn(IntPtr vmm, uint pid, IntPtr module, IntPtr name);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private delegate bool ReadFn(IntPtr vmm, uint pid, ulong address,
            [Out, MarshalAs(UnmanagedType.LPArray, SizeParamIndex = 4)] byte[] bytes,
            uint count, out uint bytesRead, ulong flags);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private delegate bool ConfigGetFn(IntPtr vmm, ulong option, out ulong value);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private delegate bool WriteFn(IntPtr vmm, uint pid, ulong address,
            [In, MarshalAs(UnmanagedType.LPArray, SizeParamIndex = 4)] byte[] bytes, uint count);

        private InitializeFn initialize;
        private CloseFn close;
        private PidFn pidFromName;
        private ModuleFn getModule;
        private ExportFn getExport;
        private ReadFn read;
        private ConfigGetFn configGet;
        private WriteFn writeMenu;

        // Legacy diagnostic scripts still require the process during construction.
        public DmaMemory(string sdkDirectory, string device) : this(sdkDirectory, device, true) { }

        public DmaMemory(string sdkDirectory, string device, bool requireGameProcess)
        {
            if (Environment.OSVersion.Platform != PlatformID.Win32NT || IntPtr.Size != 8)
                throw new PlatformNotSupportedException("Un processus Windows 64 bits est requis.");
            if (String.IsNullOrWhiteSpace(device) ||
                !System.Text.RegularExpressions.Regex.IsMatch(device, @"\Afpga(?:://[^\s\x00]+)?\z", System.Text.RegularExpressions.RegexOptions.IgnoreCase))
                throw new ArgumentException("Peripherique attendu : fpga ou fpga://...");
            try
            {
                string sdk = Path.GetFullPath(sdkDirectory);
                if (!File.Exists(Path.Combine(sdk, "vmm.dll")) || !File.Exists(Path.Combine(sdk, "leechcore.dll")))
                    throw new FileNotFoundException("Choisis la distribution MemProcFS x64 complete avec vmm.dll et leechcore.dll.");
                if (!SetDefaultDllDirectories(0x00000800 | 0x00000400))
                    throw new Win32Exception(Marshal.GetLastWin32Error());
                directoryCookie = AddDllDirectory(sdk);
                if (directoryCookie == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
                library = LoadLibraryExW(Path.Combine(sdk, "vmm.dll"), IntPtr.Zero, 0x00000100 | 0x00000800 | 0x00000400);
                if (library == IntPtr.Zero)
                    throw new Win32Exception(Marshal.GetLastWin32Error(), "Chargement MemProcFS impossible.");
                initialize = Bind<InitializeFn>("VMMDLL_Initialize");
                close = Bind<CloseFn>("VMMDLL_Close");
                pidFromName = Bind<PidFn>("VMMDLL_PidGetFromName");
                getModule = Bind<ModuleFn>("VMMDLL_ProcessGetModuleBaseU");
                getExport = Bind<ExportFn>("VMMDLL_ProcessGetProcAddressU");
                read = Bind<ReadFn>("VMMDLL_MemReadEx");
                configGet = Bind<ConfigGetFn>("VMMDLL_ConfigGet");
                Open(device);
                VmmVersion = Option(0x2000000900000000UL) + "." + Option(0x2000000A00000000UL) + "." + Option(0x2000000B00000000UL);
                TargetWindowsBuild = Option(0x2000010300000000UL);
                if (requireGameProcess && !TryFindGameProcess())
                    throw new InvalidOperationException("JEU_NON_TROUVE : 7DaysToDie.exe absent de la vue DMA actuelle.");
            }
            catch { Dispose(); throw; }
        }

        private T Bind<T>(string name) where T : class
        {
            IntPtr p = GetProcAddress(library, name);
            if (p == IntPtr.Zero) throw new EntryPointNotFoundException("Export MemProcFS absent : " + name);
            return (T)(object)Marshal.GetDelegateForFunctionPointer(p, typeof(T));
        }

        private static IntPtr Utf8(string value)
        {
            if (value == null || value.IndexOf('\0') >= 0) throw new ArgumentException("Texte natif invalide.");
            byte[] bytes = Encoding.UTF8.GetBytes(value + "\0");
            IntPtr p = Marshal.AllocHGlobal(bytes.Length);
            try { Marshal.Copy(bytes, 0, p, bytes.Length); return p; }
            catch { Marshal.FreeHGlobal(p); throw; }
        }

        private void Open(string device)
        {
            string[] args = { "", "-device", device, "-memmap", "auto", "-waitinitialize", "-disable-symbolserver", "-disable-python" };
            IntPtr[] strings = new IntPtr[args.Length];
            IntPtr argv = IntPtr.Zero;
            try
            {
                argv = Marshal.AllocHGlobal((args.Length + 1) * IntPtr.Size);
                for (int i = 0; i < args.Length; ++i)
                {
                    strings[i] = Utf8(args[i]);
                    Marshal.WriteIntPtr(argv, i * IntPtr.Size, strings[i]);
                }
                Marshal.WriteIntPtr(argv, args.Length * IntPtr.Size, IntPtr.Zero);
                session = initialize((uint)args.Length, argv);
                if (session == IntPtr.Zero) throw new IOException("MemProcFS ne peut pas initialiser la cible.");
            }
            finally
            {
                foreach (IntPtr p in strings) if (p != IntPtr.Zero) Marshal.FreeHGlobal(p);
                if (argv != IntPtr.Zero) Marshal.FreeHGlobal(argv);
            }
        }

        private void RequireSession()
        {
            if (disposed || session == IntPtr.Zero) throw new ObjectDisposedException("DmaMemory");
        }

        // The session remains open while no game is visible. MemProcFS background
        // refresh is left enabled (the default) so newly launched processes can
        // appear. This lookup never reuses the previously selected PID on failure.
        // https://github.com/ufrisk/MemProcFS/wiki/FAQ_Timing
        public bool TryFindGameProcess()
        {
            lock (gate)
            {
                RequireSession();
                IntPtr name = Utf8("7DaysToDie.exe");
                try
                {
                    uint gameProcessId;
                    bool found = pidFromName(session, name, out gameProcessId) && gameProcessId != 0;
                    ProcessId = found ? gameProcessId : 0;
                    return found;
                }
                finally { Marshal.FreeHGlobal(name); }
            }
        }

        private void RequireGameProcess()
        {
            RequireSession();
            if (ProcessId == 0)
                throw new InvalidOperationException("JEU_NON_TROUVE : aucune lecture de processus sans PID valide.");
        }

        private string Option(ulong option)
        {
            ulong value;
            return configGet(session, option, out value) ? value.ToString(System.Globalization.CultureInfo.InvariantCulture) : "inconnue";
        }

        public byte[] Read(ulong address, int count)
        {
            if (count < 1 || count > 1024 * 1024 || address < 0x10000 ||
                address > 0x00007FFFFFFFFFFFUL - (ulong)(count - 1))
                throw new ArgumentOutOfRangeException("address", "Plage de lecture utilisateur invalide.");
            lock (gate)
            {
                RequireGameProcess();
                byte[] data = new byte[count];
                uint received;
                ++ReadCalls;
                // NOCACHE: never substitute a previously cached data page for a fresh snapshot.
                bool ok = read(session, ProcessId, address, data, (uint)count, out received, 0x0001UL);
                ReadBytes += received;
                if (!ok || received != count)
                    throw new IOException(String.Format("Lecture DMA incomplete a 0x{0:X16} : {1}/{2} octets.", address, received, count));
                return data;
            }
        }

        // A single aligned object-reference slot, never a code page, arbitrary
        // buffer or retry loop. The owning menu resolver validates the graph and
        // strongly rooted replacement; this last guard rechecks PID and old slot.
        public MenuReferenceWriteResult WriteMenuReference(uint expectedProcessId, ulong slot,
            ulong expectedReference, ulong replacementReference, CancellationToken cancellationToken)
        {
            MenuReferenceWriteResult result = new MenuReferenceWriteResult();
            lock (gate)
            {
                try
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    RequireGameProcess();
                    if (expectedProcessId == 0 || ProcessId != expectedProcessId ||
                        !TryFindGameProcess() || ProcessId != expectedProcessId)
                        throw new IOException("Le processus du jeu a change avant l'ecriture du menu.");
                    if ((slot & 7UL) != 0 || slot < 0x10000UL || slot > 0x00007FFFFFFFFFF8UL ||
                        (expectedReference & 7UL) != 0 || expectedReference < 0x10000UL || expectedReference > 0x00007FFFFFFFFFFFUL ||
                        (replacementReference & 7UL) != 0 || replacementReference < 0x10000UL || replacementReference > 0x00007FFFFFFFFFFFUL)
                        throw new IOException("Reference de menu hors plage ou non alignee.");
                    // Bind lazily: a distribution without MemWrite must not break ESP.
                    if (writeMenu == null) writeMenu = Bind<WriteFn>("VMMDLL_MemWrite");
                    if (BitConverter.ToUInt64(Read(slot, 8), 0) != expectedReference)
                        throw new IOException("La valeur du menu a change avant l'ecriture.");
                    if (expectedReference == replacementReference)
                    {
                        result.ReportedSuccess = true;
                        result.Message = "Reference deja presente ; aucune ecriture.";
                        return result;
                    }
                    cancellationToken.ThrowIfCancellationRequested();
                    result.Attempted = true;
                    result.ReportedSuccess = writeMenu(session, expectedProcessId, slot,
                        BitConverter.GetBytes(replacementReference), 8);
                    result.Message = result.ReportedSuccess ? "Ecriture native retournee ; verification requise." :
                        "MemProcFS n'a pas confirme l'ecriture ; etat a verifier.";
                }
                catch (Exception e)
                {
                    result.Message = e.Message;
                }
            }
            return result;
        }

        // Experimental client-state write; not a claim of server persistence.
        // Exactly one float32/int32 field, after full object/owner/type validation.
        public PlayerStatScalarWriteResult WritePlayerStatScalar(uint expectedProcessId, PlayerStatWriteLease lease,
            byte[] before, byte[] after, Action validateRoots, CancellationToken cancellationToken)
        {
            var result = new PlayerStatScalarWriteResult();
            lock (gate)
            {
                try
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (lease == null || validateRoots == null || before == null || after == null ||
                        before.Length != 4 || after.Length != 4 ||
                        (lease.Address & 3UL) != 0 || lease.Address < 0x10000UL ||
                        lease.Address > 0x00007FFFFFFFFFFCUL ||
                        (lease.Owner & 7UL) != 0 || lease.Owner < 0x10000UL ||
                        lease.Owner > 0x00007FFFFFFFFFFFUL)
                        throw new IOException("Bail de statistique DMA invalide.");
                    RequireGameProcess();
                    if (expectedProcessId == 0 || ProcessId != expectedProcessId ||
                        !TryFindGameProcess() || ProcessId != expectedProcessId)
                        throw new IOException("Le processus du jeu a changé.");
                    validateRoots();
                    if (!ControlBytesEqual(Read(lease.Address, 4), before))
                        throw new IOException("Valeur modifiée avant l'écriture ; aucune mutation.");
                    cancellationToken.ThrowIfCancellationRequested();
                    if (writeMenu == null) writeMenu = Bind<WriteFn>("VMMDLL_MemWrite");
                    result.Attempted = true;
                    bool ok = writeMenu(session, expectedProcessId, lease.Address, after, 4);
                    if (!ok) throw new IOException("MemProcFS ne confirme pas l'écriture, sans nouvel essai.");
                    if (!ControlBytesEqual(Read(lease.Address, 4), after))
                        throw new IOException("Relecture différente après écriture DMA.");
                    validateRoots();
                    result.Confirmed = true;
                    result.Message = "Scalaire confirmé dans la mémoire du client uniquement.";
                }
                catch (Exception e) when (e is IOException || e is InvalidOperationException ||
                    e is ArgumentException || e is OverflowException || e is OperationCanceledException)
                {
                    result.Message = e.GetBaseException().Message;
                }
            }
            return result;
        }

        // This mailbox is the only buffer writable through this interface. The
        // ABI is deliberately repeated here so legacy diagnostic compilations do
        // not acquire a dependency on the optional game module's shared source.
        public ControlBufferWriteResult WriteControlRecord(uint expectedProcessId, ControlBufferLease lease,
            byte[] expectedRecord, byte[] replacementRecord, Action validateRoots, CancellationToken cancellationToken)
        {
            ControlBufferWriteResult result = new ControlBufferWriteResult();
            lock (gate)
            {
                try
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    if (lease == null || validateRoots == null || expectedRecord == null || replacementRecord == null ||
                        expectedRecord.Length != 256 || replacementRecord.Length != 256 || lease.Length != 256 ||
                        (lease.ArrayAddress & 7UL) != 0 || lease.ArrayAddress < 0x10000UL ||
                        lease.ArrayAddress > 0x00007FFFFFFFFFFFUL - 0x11FUL)
                        throw new IOException("Capacite de boite de commandes invalide.");
                    // Clone caller buffers before validating or publishing them.
                    byte[] before = (byte[])expectedRecord.Clone();
                    byte[] after = (byte[])replacementRecord.Clone();
                    uint sequence = BitConverter.ToUInt32(after, 12);
                    if (BitConverter.ToUInt32(after, 0) != 0x51523744U ||
                        BitConverter.ToUInt32(after, 4) != 1U ||
                        BitConverter.ToUInt32(after, 8) != 256U || sequence == 0 || (sequence & 1U) != 0 ||
                        BitConverter.ToUInt32(after, 252) != ControlRecordCrc(after))
                        throw new IOException("Format ou CRC de commande DMA incompatible.");
                    RequireGameProcess();
                    if (expectedProcessId == 0 || ProcessId != expectedProcessId ||
                        !TryFindGameProcess() || ProcessId != expectedProcessId)
                        throw new IOException("Le processus du jeu a change avant la commande.");
                    validateRoots();
                    if (!ControlBytesEqual(Read(lease.DataAddress, 256), before))
                        throw new IOException("La boite de commandes a change ; aucune ecriture.");
                    if (writeMenu == null) writeMenu = Bind<WriteFn>("VMMDLL_MemWrite");
                    cancellationToken.ThrowIfCancellationRequested();
                    byte[] odd = BitConverter.GetBytes(sequence - 1U);
                    RequireCurrentControlIntent(lease);
                    result.Attempted = true;
                    if (!writeMenu(session, expectedProcessId, lease.DataAddress + 12UL, odd, 4))
                        throw new IOException("Sequence de preparation non confirmee ; aucun nouvel essai.");
                    byte[] staged = (byte[])before.Clone();
                    Buffer.BlockCopy(odd, 0, staged, 12, 4);
                    if (!ControlBytesEqual(Read(lease.DataAddress, 256), staged))
                        throw new IOException("Boite modifiee pendant la preparation de la commande.");
                    cancellationToken.ThrowIfCancellationRequested();
                    byte[] prefix = new byte[12], payload = new byte[240];
                    Buffer.BlockCopy(after, 0, prefix, 0, 12); Buffer.BlockCopy(after, 16, payload, 0, 240);
                    if (!writeMenu(session, expectedProcessId, lease.DataAddress, prefix, 12) ||
                        !writeMenu(session, expectedProcessId, lease.DataAddress + 16UL, payload, 240))
                        throw new IOException("Donnees de commande non confirmees ; sequence laissee non validee.");
                    staged = (byte[])after.Clone(); Buffer.BlockCopy(odd, 0, staged, 12, 4);
                    if (!ControlBytesEqual(Read(lease.DataAddress, 256), staged))
                        throw new IOException("Relecture des donnees de commande differente ; aucune validation finale.");
                    // A context change after staging leaves an odd record. The
                    // module never executes it, even if the DMA write was partial.
                    cancellationToken.ThrowIfCancellationRequested();
                    validateRoots();
                    if (ProcessId != expectedProcessId || !TryFindGameProcess() || ProcessId != expectedProcessId)
                        throw new IOException("Processus modifie avant la validation de commande.");
                    if (!ControlBytesEqual(Read(lease.DataAddress, 256), staged))
                        throw new IOException("La boite a change avant la validation finale.");
                    cancellationToken.ThrowIfCancellationRequested();
                    RequireCurrentControlIntent(lease);
                    result.CommitAttempted = true;
                    result.ReportedSuccess = writeMenu(session, expectedProcessId, lease.DataAddress + 12UL,
                        BitConverter.GetBytes(sequence), 4);
                    result.ReadbackConfirmed = ControlBytesEqual(Read(lease.DataAddress, 256), after);
                    result.Message = result.ReportedSuccess && result.ReadbackConfirmed ?
                        "Commande transmise et relue ; execution locale a observer dans le module." :
                        "Validation de commande non confirmee ; aucun nouvel essai automatique.";
                }
                catch (Exception e) { result.Message = e.Message; }
            }
            return result;
        }

        private static bool ControlBytesEqual(byte[] left, byte[] right)
        {
            if (left == null || right == null || left.Length != right.Length) return false;
            for (int i = 0; i < left.Length; ++i) if (left[i] != right[i]) return false;
            return true;
        }

        private static uint ControlRecordCrc(byte[] bytes)
        {
            uint crc = 0xFFFFFFFFU;
            for (int i = 0; i < 252; ++i)
            {
                crc ^= bytes[i];
                for (int bit = 0; bit < 8; ++bit) crc = (crc >> 1) ^ ((crc & 1U) == 0 ? 0U : 0xEDB88320U);
            }
            return ~crc;
        }

        private static void RequireCurrentControlIntent(ControlBufferLease lease)
        {
            long now = System.Diagnostics.Stopwatch.GetTimestamp();
            if (lease.RequestedTimestamp <= 0 || lease.RequestedTimestamp > now ||
                (now - lease.RequestedTimestamp) * 1000.0 / System.Diagnostics.Stopwatch.Frequency >= 3000)
                throw new IOException("La demande utilisateur a expire avant l'ecriture native ; aucun rejeu.");
        }

        public ulong ModuleBase(string name)
        {
            lock (gate)
            {
                RequireGameProcess();
                IntPtr p = Utf8(name);
                try { return getModule(session, ProcessId, p); }
                finally { Marshal.FreeHGlobal(p); }
            }
        }

        public ulong ExportAddress(string module, string symbol)
        {
            lock (gate)
            {
                RequireGameProcess();
                IntPtr m = Utf8(module);
                IntPtr n = IntPtr.Zero;
                try { n = Utf8(symbol); return getExport(session, ProcessId, m, n); }
                finally { if (n != IntPtr.Zero) Marshal.FreeHGlobal(n); Marshal.FreeHGlobal(m); }
            }
        }

        public ModuleIdentity IdentifyModule(string name)
        {
            ModuleIdentity result = new ModuleIdentity { Name = name };
            try
            {
                ulong address = ModuleBase(name);
                result.Present = address != 0;
                result.BaseAddress = "0x" + address.ToString("X16");
                if (address == 0) return result;
                byte[] dos = Read(address, 64);
                if (dos[0] != 0x4D || dos[1] != 0x5A) throw new InvalidDataException("Signature MZ absente.");
                int peOffset = BitConverter.ToInt32(dos, 0x3C);
                if (peOffset < 64 || peOffset > 1024 * 1024) throw new InvalidDataException("En-tete PE hors limites.");
                byte[] pe = Read(checked(address + (ulong)peOffset), 88);
                if (BitConverter.ToUInt32(pe, 0) != 0x4550) throw new InvalidDataException("Signature PE absente.");
                if (BitConverter.ToUInt16(pe, 20) < 112) throw new InvalidDataException("En-tete optionnel PE32+ incomplet.");
                result.Machine = "0x" + BitConverter.ToUInt16(pe, 4).ToString("X4");
                if (result.Machine != "0x8664" || BitConverter.ToUInt16(pe, 24) != 0x20B)
                    throw new InvalidDataException("Module non PE32+ x64.");
                result.TimeDateStamp = "0x" + BitConverter.ToUInt32(pe, 8).ToString("X8");
                result.ImageSize = BitConverter.ToUInt32(pe, 80);
                if (result.ImageSize < 4096 || result.ImageSize > 0x80000000U) throw new InvalidDataException("Taille image invalide.");
                uint headerSize = BitConverter.ToUInt32(pe, 84);
                if (headerSize < (uint)(peOffset + 24 + BitConverter.ToUInt16(pe, 20)) || headerSize > result.ImageSize)
                    throw new InvalidDataException("Taille des en-tetes PE incoherente.");
                // Identification only: header hash is not a whole-file hash or a game build number.
                byte[] bytes = new byte[dos.Length + pe.Length];
                Buffer.BlockCopy(dos, 0, bytes, 0, dos.Length);
                Buffer.BlockCopy(pe, 0, bytes, dos.Length, pe.Length);
                using (SHA256 hash = SHA256.Create())
                    result.HeaderSha256 = BitConverter.ToString(hash.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant();
                result.HeaderReadable = true;
            }
            catch (Exception ex) { result.Error = ex.Message; }
            return result;
        }

        public void Dispose()
        {
            lock (gate)
            {
                if (disposed) return;
                disposed = true;
                ProcessId = 0;
                try
                {
                    if (session != IntPtr.Zero && close != null)
                    {
                        IntPtr handle = session;
                        session = IntPtr.Zero;
                        close(handle);
                    }
                }
                finally
                {
                    if (library != IntPtr.Zero) { FreeLibrary(library); library = IntPtr.Zero; }
                    if (directoryCookie != IntPtr.Zero) { RemoveDllDirectory(directoryCookie); directoryCookie = IntPtr.Zero; }
                }
            }
        }
    }
}
