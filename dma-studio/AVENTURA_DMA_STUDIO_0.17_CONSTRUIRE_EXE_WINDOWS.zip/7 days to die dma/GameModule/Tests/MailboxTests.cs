using System;
using System.Collections.Generic;
using System.Text;
using SevenDaysDmaControl;

internal static class MailboxTests
{
    private static int _checks;
    private static void Check(bool condition, string message)
    {
        ++_checks;
        if (!condition) throw new InvalidOperationException(message);
    }

    private sealed class FakeActions : IGameActions
    {
        public GameObservation Current = new GameObservation { ContextId = Guid.NewGuid(), PlayerId = 77, Availability = BridgeAvailability.Ready };
        public int ExecuteCount, PollCount, ReleaseCount;
        public bool ThrowExecute, ThrowObserve;
        public Func<ControlRequest, GameActionResult> ExecuteResult;
        public Func<GameActionResult> PollResult;
        public GameObservation Observe()
        {
            if (ThrowObserve) throw new InvalidOperationException("lost world");
            return new GameObservation { ContextId = Current.ContextId, PlayerId = Current.PlayerId,
                Availability = Current.Availability, PositionX = Current.PositionX, PositionY = Current.PositionY,
                PositionZ = Current.PositionZ, Speed = Current.Speed, Brightness = Current.Brightness,
                Flags = Current.Flags, SupportedOperations = Current.SupportedOperations, OwnedOperations = Current.OwnedOperations,
                Message = Current.Message };
        }
        public GameActionResult Execute(ControlRequest request, GameObservation current)
        {
            ++ExecuteCount;
            if (ThrowExecute) throw new InvalidOperationException("native action failed");
            if (ExecuteResult != null) return ExecuteResult(request);
            if (request.Operation == ControlOperation.SetFly) Current.Flags = request.Enabled ? ControlFlags.Fly : ControlFlags.None;
            return GameActionResult.Applied("Etat local relu.");
        }
        public GameActionResult Poll(ulong requestId, GameObservation current) { ++PollCount; return PollResult == null ? GameActionResult.Pending("En attente.") : PollResult(); }
        public void Release(GameObservation current) { ++ReleaseCount; Current.Flags = ControlFlags.None; }
    }

    private sealed class Fixture
    {
        public readonly Guid Session = Guid.NewGuid();
        public readonly byte[] Request = new byte[ControlProtocol.RequestSize];
        public readonly byte[] State = new byte[ControlProtocol.StateSize];
        public readonly FakeActions Actions = new FakeActions();
        public readonly ControlMailbox Mailbox;
        public long Now = 1000;
        private uint _sequence;
        public Fixture() { Mailbox = new ControlMailbox(Actions, Session, Request, State, () => Now); Mailbox.Tick(); }
        public ControlRequest NewRequest(ulong id, ControlOperation operation = ControlOperation.SetFly)
        {
            return new ControlRequest { SessionId = Session, ContextId = Actions.Current.ContextId, PlayerId = Actions.Current.PlayerId,
                RequestId = id, Operation = operation, IssuedGameTimeMs = Now, ExpiresGameTimeMs = Now + 3000, Enabled = true, Value = 1 };
        }
        public void Send(ControlRequest request) { _sequence = ControlProtocol.NextSequence(_sequence); var wire = ControlProtocol.EncodeRequest(request, _sequence); Buffer.BlockCopy(wire, 0, Request, 0, wire.Length); }
        public ControlSnapshot Snapshot()
        {
            ControlSnapshot value; string error;
            Check(ControlProtocol.TryDecodeSnapshot(State, out value, out error), "snapshot decode: " + error);
            return value;
        }
    }

    private static void ProtocolRoundTrip()
    {
        byte[] vector = Encoding.ASCII.GetBytes("123456789");
        Check(ControlProtocol.ComputeCrc32(vector, vector.Length) == 0xCBF43926, "CRC32 standard vector");
        var fixture = new Fixture(); var request = fixture.NewRequest(0x0102030405060708, ControlOperation.Teleport);
        request.PositionX = -123.5f; request.PositionY = 83.25f; request.PositionZ = 701.125f; request.TargetEntityId = 944;
        byte[] bytes = ControlProtocol.EncodeRequest(request, 2); ControlRequest decoded; string error;
        Check(ControlProtocol.TryDecodeRequest(bytes, out decoded, out error), error);
        Check(decoded.SessionId == request.SessionId && decoded.ContextId == request.ContextId && decoded.RequestId == request.RequestId, "request identities");
        Check(decoded.PositionX == request.PositionX && decoded.PositionY == request.PositionY && decoded.TargetEntityId == 944, "request payload");
        var state = new ControlSnapshot { SessionId = fixture.Session, Observation = fixture.Actions.Current, LastRequestId = 12,
            LastRequestContextId = request.ContextId,
            LastMessage = new string('é', 600), LastStatus = ControlStatus.Refused, RequestHighWatermark = 20, PendingRequestId = 19 };
        byte[] wire = ControlProtocol.EncodeSnapshot(state, 4); ControlSnapshot result;
        Check(ControlProtocol.TryDecodeSnapshot(wire, out result, out error), error);
        Check(result.LastMessage.Length > 0 && result.LastMessage.IndexOf('\uFFFD') < 0, "UTF8 truncation preserves complete characters");
        Check(result.RequestHighWatermark == 20 && result.PendingRequestId == 19 && result.Sequence == 4, "state counters");
        Check(result.LastRequestContextId == request.ContextId, "result context GUID survives round trip at offset 128");
        wire[72] ^= 0x80;
        Check(!ControlProtocol.TryDecodeSnapshot(wire, out result, out error) && error == "CRC_MISMATCH", "CRC rejects changed snapshot");
    }

    private static void CommitAndIntegrity()
    {
        var fixture = new Fixture(); byte[] wire = ControlProtocol.EncodeRequest(fixture.NewRequest(1), 2);
        Buffer.BlockCopy(wire, 0, fixture.Request, 0, wire.Length); ControlProtocol.PutUInt32(fixture.Request, 12, 1);
        fixture.Mailbox.Tick(); Check(fixture.Actions.ExecuteCount == 0, "odd commit must never execute");
        ControlProtocol.PutUInt32(fixture.Request, 12, 2); fixture.Request[84] ^= 1;
        fixture.Mailbox.Tick(); Check(fixture.Actions.ExecuteCount == 0, "corrupt payload must never execute");
        fixture.Request[84] ^= 1; byte[] before = (byte[])fixture.Request.Clone();
        fixture.Mailbox.Tick(); Check(fixture.Actions.ExecuteCount == 1, "complete request executes once");
        Check(ControlProtocol.SameCommittedRecord(before, fixture.Request), "game must never clear or acknowledge in RequestBuffer");
        Check(fixture.Snapshot().Observation.Flags == ControlFlags.Fly, "snapshot observes actual result after execution");
        byte[] stale = (byte[])before.Clone(); stale[88] ^= 1;
        Check(!ControlProtocol.SameCommittedRecord(before, stale), "same sequence with altered body is not a stable read");
    }

    private static void AtMostOnce()
    {
        var f = new Fixture(); f.Send(f.NewRequest(1)); f.Mailbox.Tick();
        for (int i = 0; i < 4; ++i) f.Mailbox.Tick();
        var replay = f.NewRequest(1); replay.Enabled = false; f.Send(replay); f.Mailbox.Tick();
        Check(f.Actions.ExecuteCount == 1 && f.Actions.Current.Flags == ControlFlags.Fly, "replay/new commit cannot replay request id");
        f.Send(f.NewRequest(5)); f.Mailbox.Tick(); f.Send(f.NewRequest(3)); f.Mailbox.Tick();
        Check(f.Actions.ExecuteCount == 2 && f.Snapshot().RequestHighWatermark == 5, "older out-of-order id is consumed by high watermark");
        Guid previousContext = f.Actions.Current.ContextId;
        f.Actions.Current.ContextId = Guid.NewGuid(); f.Send(f.NewRequest(2)); f.Mailbox.Tick();
        Check(f.Actions.ExecuteCount == 2, "new world does not reset session watermark");
        var moved = f.Snapshot();
        Check(moved.LastRequestId == 5 && moved.LastStatus == ControlStatus.AppliedLocal &&
            moved.LastRequestContextId == previousContext && moved.Observation.ContextId == f.Actions.Current.ContextId &&
            moved.LastRequestContextId != moved.Observation.ContextId,
            "old terminal result remains explicitly tied to its previous world after a context change");
    }

    private static void ExpirationAndNonce()
    {
        var f = new Fixture(); f.Now = 4000; var request = f.NewRequest(1); request.ExpiresGameTimeMs = f.Now - 1; request.IssuedGameTimeMs = f.Now - 2000;
        f.Send(request); f.Mailbox.Tick(); var state = f.Snapshot();
        Check(state.LastStatus == ControlStatus.Refused && state.LastMessage == "DEMANDE_EXPIREE" && f.Actions.ExecuteCount == 0, "expired snapshot-derived time");
        Check(state.RequestHighWatermark == 1, "refused request is consumed");
        request = f.NewRequest(2); request.SessionId = Guid.NewGuid(); f.Send(request); f.Mailbox.Tick();
        Check(f.Snapshot().RequestHighWatermark == 1, "foreign session cannot poison current watermark");
        request = f.NewRequest(2); request.ContextId = Guid.NewGuid(); f.Send(request); f.Mailbox.Tick();
        Check(f.Snapshot().LastStatus == ControlStatus.Refused && f.Actions.ExecuteCount == 0, "foreign world context rejected");
        request = f.NewRequest(3); request.IssuedGameTimeMs = f.Now + 1; f.Send(request); f.Mailbox.Tick();
        Check(f.Snapshot().LastMessage == "HORODATAGE_JEU_INVALIDE", "loader clock cannot author future game timestamp");
        request = f.NewRequest(4); request.ExpiresGameTimeMs = f.Now + ControlProtocol.MaxRequestLifetimeMs + 1; f.Send(request); f.Mailbox.Tick();
        Check(f.Snapshot().LastMessage == "DUREE_DEMANDE_INVALIDE", "request TTL is bounded");
    }

    private static void PendingAndCompletion()
    {
        var f = new Fixture(); f.Actions.ExecuteResult = request => { f.Actions.Current.Flags = ControlFlags.Teleporting; return GameActionResult.Pending("Teleportation en cours."); };
        f.Send(f.NewRequest(1, ControlOperation.Teleport)); f.Mailbox.Tick(); var state = f.Snapshot();
        Check(state.LastStatus == ControlStatus.Pending && state.PendingRequestId == 1, "pending does not claim success");
        f.Now += 4000; f.Mailbox.Tick();
        Check(f.Actions.ExecuteCount == 1 && f.Snapshot().LastStatus == ControlStatus.Pending, "acceptance expiration must not retrigger/cancel active native coroutine");
        f.Actions.PollResult = () => { f.Actions.Current.Flags = ControlFlags.None; return GameActionResult.Applied("Position locale confirmee."); }; f.Mailbox.Tick();
        state = f.Snapshot(); Check(state.LastStatus == ControlStatus.AppliedLocal && state.PendingRequestId == 0 && f.Actions.ExecuteCount == 1, "poll confirms once without repeat execute");
        Check(state.Observation.Flags == ControlFlags.None, "completed transition publishes a fresh observation, not its earlier teleporting flag");
    }

    private static void PendingTimeoutAndContextChange()
    {
        var f = new Fixture(); f.Actions.ExecuteResult = request => GameActionResult.Pending("Waiting");
        f.Send(f.NewRequest(1)); f.Mailbox.Tick(); f.Now += ControlProtocol.MaxPendingDurationMs + 1; f.Mailbox.Tick();
        Check(f.Snapshot().LastStatus == ControlStatus.Failed && f.Actions.ReleaseCount == 1, "pending timeout releases owned modes and reports failure");
        f.Mailbox.Tick(); Check(f.Actions.ExecuteCount == 1 && f.Actions.ReleaseCount == 1, "timed out request cannot replay");
        f.Send(f.NewRequest(2)); f.Mailbox.Tick(); f.Actions.Current.ContextId = Guid.NewGuid(); f.Mailbox.Tick();
        Check(f.Snapshot().LastStatus == ControlStatus.Refused && f.Actions.ReleaseCount == 2, "context change cancels pending with guarded release");
    }

    private static void BusyAndRestore()
    {
        var f = new Fixture(); f.Actions.ExecuteResult = request => request.Operation == ControlOperation.RestoreOwned ? GameActionResult.Applied("Restaure") : GameActionResult.Pending("Waiting");
        f.Send(f.NewRequest(1)); f.Mailbox.Tick(); f.Send(f.NewRequest(2)); f.Mailbox.Tick();
        Check(f.Snapshot().LastStatus == ControlStatus.Refused && f.Snapshot().PendingRequestId == 1 && f.Actions.ExecuteCount == 1, "second action refused while first pending");
        Check(f.Snapshot().RequestHighWatermark == 2, "busy request also consumed");
        f.Send(f.NewRequest(3, ControlOperation.RestoreOwned)); f.Mailbox.Tick();
        Check(f.Actions.ReleaseCount == 1 && f.Actions.ExecuteCount == 2 && f.Snapshot().PendingRequestId == 0, "restore can preempt pending safely");
        Check(f.Snapshot().LastRequestId == 3 && f.Snapshot().LastStatus == ControlStatus.AppliedLocal, "restore receives its own result");
    }

    private static void FailuresAndRecovery()
    {
        var f = new Fixture(); f.Actions.ThrowExecute = true; f.Send(f.NewRequest(1)); f.Mailbox.Tick(); f.Mailbox.Tick();
        Check(f.Actions.ExecuteCount == 1 && f.Snapshot().LastStatus == ControlStatus.Failed, "throwing action consumed once");
        Check(f.Actions.ReleaseCount == 1, "throwing action restores owned state once");
        f.Actions.ThrowExecute = false; f.Actions.ThrowObserve = true; f.Mailbox.Tick();
        Check(f.Snapshot().Observation.Availability == BridgeAvailability.Faulted, "observation failure is explicit");
        f.Actions.ThrowObserve = false; f.Mailbox.Tick();
        Check(f.Actions.ReleaseCount == 2, "restore deferred until valid observation after failure");
        f.Send(f.NewRequest(2)); f.Mailbox.Tick(); Check(f.Actions.ExecuteCount == 2, "new request works after observed recovery");
        f.Mailbox.ReleaseForWorldShutdown();
        Check(f.Snapshot().Observation.Availability == BridgeAvailability.NoWorld, "shutdown publishes unavailable context");
    }

    private static void InvalidInputs()
    {
        var f = new Fixture(); var r = f.NewRequest(1, (ControlOperation)65000); f.Send(r); f.Mailbox.Tick();
        Check(f.Snapshot().LastMessage == "OPERATION_INCONNUE", "only fixed operations accepted");
        r = f.NewRequest(2); r.Value = float.NaN; f.Send(r); f.Mailbox.Tick();
        Check(f.Snapshot().LastMessage == "VALEUR_NON_FINIE", "NaN rejected");
        r = f.NewRequest(3, ControlOperation.SetNightBrightness); r.Value = 9; f.Send(r); f.Mailbox.Tick();
        Check(f.Snapshot().LastMessage == "LUMINOSITE_HORS_LIMITES", "brightness bounded");
        r = f.NewRequest(4, ControlOperation.SetSpeed); r.Value = 999; f.Send(r); f.Mailbox.Tick();
        Check(f.Snapshot().LastMessage == "VITESSE_HORS_LIMITES", "speed bounded");
        Check(f.Actions.ExecuteCount == 0, "invalid operations never call game actions");
    }

    public static int Main()
    {
        var tests = new Action[] { ProtocolRoundTrip, CommitAndIntegrity, AtMostOnce, ExpirationAndNonce,
            PendingAndCompletion, PendingTimeoutAndContextChange, BusyAndRestore, FailuresAndRecovery, InvalidInputs };
        foreach (var test in tests) { test(); Console.WriteLine("PASS " + test.Method.Name); }
        Console.WriteLine("PASS " + tests.Length + " scenarios, " + _checks + " assertions; no game or DMA hardware used.");
        return 0;
    }
}
