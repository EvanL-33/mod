using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using SevenDaysLoader.Services;

namespace SevenDaysLoader.UI;

internal sealed class ModuleInstallerWindow : Window
{
    private readonly TextBox game = new() { Text = GameModuleInstaller.DefaultGameDirectory };
    private readonly TextBox mods = new() { Text = GameModuleInstaller.DefaultModsDirectory };
    private readonly TextBlock message = Theme.Text("Ferme le jeu, puis clique sur Installer. L’ESP existant peut être utilisé sans ce module.", 12, Theme.Muted);
    private readonly Button install = new() { Content = "Installer / mettre à jour", BorderBrush = Theme.Cyan };
    private readonly Button remove = new() { Content = "Retirer le module" };

    internal ModuleInstallerWindow()
    {
        Title = "AVENTURA  /  7DTD DMA Studio — module du personnage";
        Width = 835; Height = 670; MinWidth = 620; MinHeight = 510;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        Theme.Apply(this);
        var header = Theme.Stack(
            Theme.Eyebrow("AVENTURA  /  DMA STUDIO  /  INSTALLATION"),
            Theme.Text("Module du personnage", 27, Theme.Foreground, true),
            Theme.Text("Gère le module optionnel du jeu. La liaison principale du loader reste effectuée par DMA.", 13, Theme.Muted));
        var hero = new Border { Child = header, Background = Theme.Gradient("#20384B", "#142435"),
            BorderBrush = Theme.Line, BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(17), Padding = new Thickness(24),
            Margin = new Thickness(0, 0, 0, 17) };
        var paths = Theme.Stack(
            Theme.Eyebrow("EMPLACEMENTS"),
            Theme.Label("Dossier de 7 Days to Die"), BrowseRow(game),
            Theme.Label("Dossier Mods chargé par le jeu"), BrowseRow(mods),
            Theme.Text("Si tu utilises un UserDataFolder personnalisé, sélectionne son dossier Mods ou celui de l’installation.", 11, Theme.Muted));
        var note = Theme.Stack(
            Theme.Eyebrow("COMPATIBILITÉ"),
            Theme.Text("V 3.4.0 (b10) · mods avec code", 14, Theme.Foreground, true),
            Theme.Text("Avec l’anti-cheat actif, le jeu ignore ce module. L’ESP et le radar indépendants restent utilisables sans lui.", 12, Theme.Muted));
        var actions = new WrapPanel { Margin = new Thickness(0, 5, 0, 15) };
        install.Margin = new Thickness(0, 0, 10, 6); remove.Margin = new Thickness(0, 0, 0, 6);
        install.Background = Theme.Cyan; install.Foreground = Theme.Background; install.BorderBrush = Theme.Cyan;
        install.Click += async (_, _) => await RunAsync(false);
        remove.Click += async (_, _) => await RunAsync(true);
        actions.Children.Add(install); actions.Children.Add(remove);
        var panel = Theme.Stack(hero, Theme.Card(paths), Theme.Card(note), actions,
            Theme.Card(Theme.Stack(Theme.Eyebrow("RÉSULTAT DE L’OPÉRATION"), message)));
        panel.Margin = new Thickness(25, 23, 25, 15);
        Content = new ScrollViewer { Content = panel, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };
    }

    private static UIElement BrowseRow(TextBox text)
    {
        var grid = new Grid { Margin = new Thickness(0, 0, 0, 14) };
        grid.ColumnDefinitions.Add(new ColumnDefinition()); grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        var browse = new Button { Content = "Choisir…", Margin = new Thickness(8, 0, 0, 0) };
        browse.Click += (_, _) =>
        {
            using var dialog = new System.Windows.Forms.FolderBrowserDialog { Description = "Choisis le dossier", UseDescriptionForTitle = true,
                SelectedPath = Directory.Exists(text.Text) ? text.Text : "" };
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK) text.Text = dialog.SelectedPath;
        };
        grid.Children.Add(text); Grid.SetColumn(browse, 1); grid.Children.Add(browse); return grid;
    }

    private async Task RunAsync(bool uninstall)
    {
        string gamePath = game.Text.Trim(), modsPath = mods.Text.Trim();
        string package = Path.Combine(AppContext.BaseDirectory, "GameModule", "Package");
        install.IsEnabled = remove.IsEnabled = game.IsEnabled = mods.IsEnabled = false;
        message.Text = uninstall ? "Retrait du module…" : "Vérification du profil et installation…";
        message.Foreground = Theme.Muted;
        try
        {
            var result = await Task.Run(() => uninstall ? GameModuleInstaller.Remove(modsPath) : GameModuleInstaller.Install(package, gamePath, modsPath));
            message.Text = result.Message + "\n\nDossier : " + result.Directory +
                (result.BackupDirectory.Length > 0 && !uninstall ? "\nSauvegarde précédente : " + result.BackupDirectory : "");
            message.Foreground = Theme.Cyan;
        }
        catch (Exception error)
        {
            message.Text = error.GetBaseException().Message;
            message.Foreground = Theme.Orange;
        }
        finally { install.IsEnabled = remove.IsEnabled = game.IsEnabled = mods.IsEnabled = true; }
    }
}
