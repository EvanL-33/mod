// All supplementary PvP fields are optional and are discovered from the
// current Mono profile. An unsupported or changing value stays null.
using System;
using System.IO;

namespace SevenDaysEsp
{
    public sealed partial class LiveEntityReader
    {
        private int pvpRunningOffset = -1, pvpCrouchingOffset = -1, pvpJumpingOffset = -1;
        private int pvpYawOffset = -1, pvpHandItemOffset = -1, pvpAttackTargetOffset = -1;
        private int pvpBloodMoonOffset = -1, pvpWorldDayOffset = -1, pvpWorldHourOffset = -1;

        private void InitializePvpSense(MonoInspectionReport metadata)
        {
            pvpRunningOffset = TryPvpField(metadata, "EntityAlive", "bMovementRunning", "0x02", "System.Boolean", 1);
            pvpCrouchingOffset = TryPvpField(metadata, "EntityAlive", "bCrouching", "0x02", "System.Boolean", 1);
            pvpJumpingOffset = TryPvpField(metadata, "EntityAlive", "bJumping", "0x02", "System.Boolean", 1);
            pvpYawOffset = TryPvpField(metadata, "Entity", "rotation", "0x11", "UnityEngine.Vector3", 12);
            pvpHandItemOffset = TryPvpField(metadata, "EntityAlive", "handItem", "0x12", "ItemValue", 8);
            pvpAttackTargetOffset = TryPvpField(metadata, "EntityAlive", "attackTarget", "0x12", "EntityAlive", 8);
            pvpBloodMoonOffset = TryPvpField(metadata, "World", "isEventBloodMoon", "0x02", "System.Boolean", 1);
            pvpWorldDayOffset = TryPvpField(metadata, "World", "WorldDay", "0x08", "System.Int32", 4);
            pvpWorldHourOffset = TryPvpField(metadata, "World", "WorldHour", "0x08", "System.Int32", 4);
        }

        private int TryPvpField(MonoInspectionReport metadata, string cls, string field, string code, string type, int width)
        {
            try
            {
                Bind(metadata, cls, field, code, type, width, false, false);
                return Offset(cls, field);
            }
            catch (ReadLimitException) { throw; }
            catch (IOException) { return -1; }
        }

        private void ReadPvpWorld(byte[] before, byte[] after, LiveEntitySnapshot snapshot)
        {
            if (pvpBloodMoonOffset >= 0 && before[pvpBloodMoonOffset] == after[pvpBloodMoonOffset])
            {
                byte state = before[pvpBloodMoonOffset];
                if (state <= 1) snapshot.BloodMoonActive = state == 1;
            }
            if (pvpWorldDayOffset >= 0 &&
                BitConverter.ToInt32(before, pvpWorldDayOffset) == BitConverter.ToInt32(after, pvpWorldDayOffset))
            {
                int day = BitConverter.ToInt32(before, pvpWorldDayOffset);
                if (day >= 0 && day <= 1000000) snapshot.WorldDay = day;
            }
            if (pvpWorldHourOffset >= 0 &&
                BitConverter.ToInt32(before, pvpWorldHourOffset) == BitConverter.ToInt32(after, pvpWorldHourOffset))
            {
                int hour = BitConverter.ToInt32(before, pvpWorldHourOffset);
                if (hour >= 0 && hour <= 23) snapshot.WorldHour = hour;
            }
        }

        private void ReadPvpEntity(ulong entity, string kind, ulong local, ulong domain,
            LiveReadOptions requested, LiveEntity dst)
        {
            if (kind == "player")
            {
                if (requested.PlayerMovement && pvpRunningOffset >= 0 && pvpCrouchingOffset >= 0 && pvpJumpingOffset >= 0)
                {
                    // The three bools are contiguous in the profiled game, but
                    // verify that before doing a single bounded memory read.
                    if (pvpCrouchingOffset == pvpRunningOffset + 1 && pvpJumpingOffset == pvpRunningOffset + 2)
                    {
                        byte[] raw = Read(Add(entity, pvpRunningOffset), 3);
                        if (raw[0] <= 1 && raw[1] <= 1 && raw[2] <= 1)
                        {
                            dst.IsRunning = raw[0] == 1;
                            dst.IsCrouching = raw[1] == 1;
                            dst.IsJumping = raw[2] == 1;
                        }
                    }
                }
                if (requested.PlayerFacing && pvpYawOffset >= 0)
                {
                    float yaw = BitConverter.ToSingle(Read(Add(entity, pvpYawOffset + 4), 4), 0);
                    if (float.IsFinite(yaw) && Math.Abs(yaw) <= 100000) dst.BodyYawDegrees = yaw;
                }
                if (requested.PlayerHeldItem && pvpHandItemOffset >= 0)
                    dst.HeldItemTypeId = TryPvpHeldItem(entity, domain);
            }
            else if (kind == "zombie" && requested.ZombieAttackTarget && pvpAttackTargetOffset >= 0)
            {
                ulong pointer = BitConverter.ToUInt64(Read(Add(entity, pvpAttackTargetOffset), 8), 0);
                if (pointer != 0 && pointer == local &&
                    BitConverter.ToUInt64(Read(Add(entity, pvpAttackTargetOffset), 8), 0) == pointer)
                    dst.ZombieTargetsLocal = true;
            }
        }

        private int? TryPvpHeldItem(ulong entity, ulong domain)
        {
            try
            {
                ulong item = BitConverter.ToUInt64(Read(Add(entity, pvpHandItemOffset), 8), 0);
                if (item == 0) return null;
                RequirePointer(item);
                ulong itemClassAddress = ValidateVTable(Pointer(item), domain);
                RuntimeClass type = GetClass(itemClassAddress);
                if (type.Kind != 1 || type.Image != gameImage || type.Namespace != String.Empty ||
                    type.Name != "ItemValue" || type.Size > 1024) return null;
                RuntimeField itemType = RequiredOptionalField(GetOptionalLayout(type), "typeField", 0x08, 4);
                byte[] raw = ReadObject(item, type, domain);
                int id = BitConverter.ToInt32(raw, itemType.Offset);
                if (id < 1 || id > 100000) return null;
                if (BitConverter.ToUInt64(Read(Add(entity, pvpHandItemOffset), 8), 0) != item)
                    return null;
                return id;
            }
            catch (ReadLimitException) { throw; }
            catch (IOException) { return null; }
        }
    }
}
