using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using SevenDaysEsp;

// Deterministic metadata/object fixtures for the actual CameraProbe.Inspect.
// These addresses and fields are test data, not a native Unity camera layout.
internal static class CameraProbeTests
{
    public static Task SparseLocalFieldsStayBounded()
    {
        var f = new Fixture();
        CameraProbeReport report = f.Probe();
        Check(report.Status == "CAMERA_METADONNEES_RELEVEES", report.Status + ": " + report.Message);
        Check(report.Objects.Count == 6 && report.LocalClass != null && report.LocalClass.Fields.Count == 6,
            "The six current metadata targets were not retained.");
        Check(report.LocalClass.DeclaredFieldCount == 220 && !report.LocalClass.FieldsComplete,
            "The targeted local field report must not pretend to describe every field.");
        Check(f.Memory.UnrelatedNameReads == 0, "Names of unrelated local fields were read before filtering.");
        Check(report.BytesRead < 65536 && report.ReadCalls < 1000,
            "Sparse names caused excessive metadata amplification: " + report.BytesRead + " bytes / " + report.ReadCalls + " calls.");
        foreach (CameraObjectReport item in report.Objects)
            Check(item.IdentityValidated && item.NativePointer != null && item.NativePointerFieldOffset == 16,
                item.SourceField + " lost its confirmed object/native pointer metadata.");
        Check(!report.CanProject, "Metadata collection must not imply a validated projection.");
        return Task.CompletedTask;
    }

    public static Task PartialMetadataSurvivesTargetLimit()
    {
        var f = new Fixture();
        f.ExpandCameraMetadata();
        CameraProbeReport report = f.Probe();
        CameraObjectReport first = Item(report, "playerCamera");
        Check(first.Status == "LIMITE_RELEVE_CIBLE", "Expected the unchanged per-target byte limit: " + first.Status);
        Check(first.ClassHierarchy.Count > 0 && first.ClassHierarchy[0].Fields.Count > 0 &&
            !first.ClassHierarchy[0].FieldsComplete && first.ClassHierarchy[0].Issue.Contains("interrompu"),
            "A bounded interruption discarded the class/fields already collected.");
        Check(!first.IdentityValidated && first.NativePointer == null && first.MatrixCandidates.Count == 0,
            "An interrupted target retained unconfirmed object data.");
        Check(report.LocalClass != null && report.LocalClass.Fields.Count == 6 && report.Objects.Count == 6,
            "A target interruption discarded the prepared target list.");
        Check(report.BytesRead <= 1048576 && report.ReadCalls <= 4096,
            "Total byte/read budgets were not enforced.");
        Check(!report.CanProject, "A partial probe cannot authorize a projection.");
        return Task.CompletedTask;
    }

    public static Task WrongIdentityInvalidatesPointers()
    {
        var f = new Fixture();
        f.Memory.U64(f.CameraVtable + 0x10, f.Memory.Allocate());
        CameraObjectReport wrongDomain = Item(f.Probe(), "playerCamera");
        Check(!wrongDomain.IdentityValidated && wrongDomain.NativePointer == null && wrongDomain.MatrixCandidates.Count == 0,
            "A camera in another Mono domain was accepted.");

        f = new Fixture();
        ulong changedNative = f.Memory.Allocate();
        int nativeReads = 0;
        f.Memory.BeforeRead = (address, count) =>
        {
            if (address == f.Camera + 16 && count == 8 && ++nativeReads == 2)
                f.Memory.U64(f.Camera + 16, changedNative);
        };
        CameraObjectReport changed = Item(f.Probe(), "playerCamera");
        Check(nativeReads >= 2 && changed.Status == "LECTURE_NON_VALIDEE" && !changed.IdentityValidated &&
            changed.NativePointer == null && changed.MatrixCandidates.Count == 0,
            "A native pointer changing during the probe retained confirmation.");
        return Task.CompletedTask;
    }

    public static Task ManagedMatrixRemainsCandidate()
    {
        var f = new Fixture();
        CameraProbeReport report = f.Probe();
        CameraObjectReport item = Item(report, "characterMatrixOverride");
        Check(item.IdentityValidated && item.MatrixCandidates.Count == 1, "Managed matrix was not collected from its declared field.");
        CameraMatrixCandidate candidate = item.MatrixCandidates[0];
        Check(candidate.Field == "TestManagedMatrix" && candidate.DeclaringType == "CharacterMatrixOverride" && candidate.Offset == 32,
            "The candidate is not tied to confirmed field metadata.");
        Check(candidate.Values.Length == 16 && candidate.Values[0] == 1 && candidate.Values[15] == 16 &&
            candidate.StorageOrder.StartsWith("column-major", StringComparison.Ordinal), "Matrix component order was not retained.");
        Check(!candidate.IsProjectionValidated && !report.CanProject, "An arbitrary managed matrix was treated as a camera projection.");
        return Task.CompletedTask;
    }

    private static CameraObjectReport Item(CameraProbeReport report, string name)
    {
        CameraObjectReport? item = report.Objects.Find(value => value.SourceField == name);
        if (item == null) throw new InvalidOperationException("Missing target " + name);
        return item;
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    private sealed class FieldSpec
    {
        internal readonly string Name;
        internal readonly byte Code;
        internal readonly ulong TypeData;
        internal readonly int Offset;
        internal FieldSpec(string name, byte code, ulong typeData, int offset)
        { Name = name; Code = code; TypeData = typeData; Offset = offset; }
    }

    private sealed class Fixture
    {
        internal readonly FakeMemory Memory = new();
        internal readonly MonoInspectionReport Metadata = new()
        { Status = "METADONNEES_PARTIELLES", SelectedLayout = "Unity Mono x64 2022 (candidate)" };
        internal readonly ulong Camera, CameraVtable;
        private readonly ulong domain, image, localClass, local, cameraClass;
        private uint token = 0x02000001;

        internal Fixture()
        {
            domain = Memory.Allocate(); image = Memory.Allocate();
            ulong unityObject = Class("Object", "UnityEngine", 24);
            SetFields(unityObject, new[] { new FieldSpec("m_CachedPtr", 0x18, 0, 16) });
            cameraClass = Class("Camera", "UnityEngine", 4096, unityObject);
            ulong transformClass = Class("Transform", "UnityEngine", 32, unityObject);
            ulong fpCameraClass = Class("vp_FPCamera", "", 32, unityObject);
            ulong renderClass = Class("GameRenderManager", "", 32, unityObject);
            ulong overrideClass = Class("CharacterMatrixOverride", "", 96, unityObject);
            ulong matrixClass = Class("Matrix4x4", "UnityEngine", 80);
            var components = new List<FieldSpec>();
            for (int column = 0; column < 4; column++)
                for (int row = 0; row < 4; row++)
                    components.Add(new FieldSpec("m" + row + column, 0x0C, 0, 16 + (column * 4 + row) * 4));
            SetFields(matrixClass, components);
            SetFields(overrideClass, new[] { new FieldSpec("TestManagedMatrix", 0x11, matrixClass, 32) });
            var camera = Object(cameraClass, 4096); Camera = camera.address; CameraVtable = camera.vtable;
            var transform = Object(transformClass, 32);
            var fp = Object(fpCameraClass, 32);
            var render = Object(renderClass, 32);
            var matrixOwner = Object(overrideClass, 96);
            for (int index = 0; index < 16; index++) Memory.Float(matrixOwner.address + 32UL + (ulong)index * 4, index + 1);

            localClass = Class("EntityPlayerLocal", "", 4096);
            var localObject = Object(localClass, 4096); local = localObject.address;
            ulong runtime = Memory.Allocate();
            Memory.U64(localClass + 0xD0, runtime);
            Memory.U16(runtime, 0); Memory.U64(runtime + 8, localObject.vtable);
            var fields = new List<FieldSpec>();
            for (int index = 0; index < 214; index++)
                fields.Add(new FieldSpec("UnrelatedField" + index, 0x08, 0, 24 + index * 4));
            var names = new[] { "playerCamera", "finalCamera", "cameraTransform", "m_vp_FPCamera", "renderManager", "characterMatrixOverride" };
            var types = new[] { cameraClass, cameraClass, transformClass, fpCameraClass, renderClass, overrideClass };
            var typeNames = new[] { "UnityEngine.Camera", "UnityEngine.Camera", "UnityEngine.Transform", "vp_FPCamera", "GameRenderManager", "CharacterMatrixOverride" };
            var instances = new[] { Camera, Camera, transform.address, fp.address, render.address, matrixOwner.address };
            var localMetadata = new MonoClassReport
            {
                Name = "EntityPlayerLocal", Namespace = "", Address = Hex(localClass), InstanceSize = 4096,
                DeclaredFieldCount = 220, FieldsComplete = true
            };
            foreach (FieldSpec field in fields)
                localMetadata.Fields.Add(new MonoFieldReport
                { Name = field.Name, Offset = field.Offset, OffsetHex = "0x" + field.Offset.ToString("X"), Type = "System.Int32", TypeCode = "0x08" });
            for (int index = 0; index < names.Length; index++)
            {
                int offset = 3000 + index * 8;
                fields.Add(new FieldSpec(names[index], 0x12, types[index], offset));
                Memory.U64(local + (ulong)offset, instances[index]);
                localMetadata.Fields.Add(new MonoFieldReport
                { Name = names[index], Offset = offset, OffsetHex = "0x" + offset.ToString("X"), Type = typeNames[index], TypeCode = "0x12" });
            }
            SetFields(localClass, fields);
            Metadata.Classes.Add(localMetadata);
        }

        internal CameraProbeReport Probe() => new CameraProbe(Memory).Inspect(Metadata, local);

        internal void ExpandCameraMetadata()
        {
            var fields = new List<FieldSpec>();
            for (int index = 0; index < 500; index++)
            {
                ulong fieldClass = Class("SparseType" + index, "ProbeTests", 32);
                fields.Add(new FieldSpec("SparseReference" + index, 0x12, fieldClass, 24 + index * 8));
            }
            SetFields(cameraClass, fields);
        }

        private ulong Class(string name, string space, int size, ulong parent = 0)
        {
            ulong value = Memory.Allocate();
            Memory.Byte(value + 0x1B, 1); Memory.I32(value + 0x1C, size);
            Memory.U64(value + 0x30, parent); Memory.U64(value + 0x40, image);
            Memory.U64(value + 0x48, Memory.Name(name)); Memory.U64(value + 0x50, Memory.Name(space));
            Memory.U32(value + 0x58, token++);
            return value;
        }

        private (ulong address, ulong vtable) Object(ulong type, int size)
        {
            ulong table = Memory.Allocate(), value = Memory.Allocate(size);
            Memory.U64(table, type); Memory.U64(table + 0x10, domain); Memory.U64(value, table);
            Memory.U64(value + 16, Memory.Allocate());
            return (value, table);
        }

        private void SetFields(ulong type, IEnumerable<FieldSpec> specs)
        {
            var list = new List<FieldSpec>(specs);
            ulong data = Memory.Allocate(Math.Max(4096, list.Count * 32));
            Memory.U64(type + 0x98, data); Memory.I32(type + 0x100, list.Count);
            for (int index = 0; index < list.Count; index++)
            {
                FieldSpec field = list[index];
                ulong monoType = Memory.Allocate();
                Memory.U64(monoType, field.TypeData); Memory.Byte(monoType + 10, field.Code);
                ulong name = Memory.Name(field.Name);
                if (field.Name.StartsWith("UnrelatedField", StringComparison.Ordinal)) Memory.UnrelatedNames.Add(name);
                ulong descriptor = data + (ulong)index * 32;
                Memory.U64(descriptor, monoType); Memory.U64(descriptor + 8, name);
                Memory.U64(descriptor + 16, type); Memory.I32(descriptor + 24, field.Offset);
            }
        }
    }

    private sealed class FakeMemory : IMemoryReader
    {
        private readonly Dictionary<ulong, byte[]> pages = new();
        private ulong next = 0x100000;
        internal readonly HashSet<ulong> UnrelatedNames = new();
        internal int UnrelatedNameReads;
        internal Action<ulong, int>? BeforeRead;

        internal ulong Allocate(int count = 4096)
        {
            int total = (count + 4095) / 4096;
            ulong result = next;
            for (int index = 0; index < total; index++) { pages.Add(next, new byte[4096]); next += 4096; }
            return result;
        }

        internal ulong Name(string text)
        {
            ulong address = Allocate(); Write(address, Encoding.UTF8.GetBytes(text + "\0")); return address;
        }

        public byte[] Read(ulong address, int count)
        {
            BeforeRead?.Invoke(address, count);
            var result = new byte[count];
            for (int index = 0; index < count; index++)
            {
                ulong current = address + (ulong)index, page = current & ~4095UL;
                if (!pages.TryGetValue(page, out byte[]? bytes)) throw new IOException("Unmapped test memory.");
                result[index] = bytes[(int)(current - page)];
            }
            if (UnrelatedNames.Contains(address & ~4095UL)) UnrelatedNameReads++;
            return result;
        }

        private void Write(ulong address, byte[] bytes)
        {
            for (int index = 0; index < bytes.Length; index++)
            {
                ulong current = address + (ulong)index, page = current & ~4095UL;
                pages[page][(int)(current - page)] = bytes[index];
            }
        }
        internal void Byte(ulong address, byte value) => Write(address, new[] { value });
        internal void U16(ulong address, ushort value) { var b = new byte[2]; BinaryPrimitives.WriteUInt16LittleEndian(b, value); Write(address, b); }
        internal void U32(ulong address, uint value) { var b = new byte[4]; BinaryPrimitives.WriteUInt32LittleEndian(b, value); Write(address, b); }
        internal void I32(ulong address, int value) { var b = new byte[4]; BinaryPrimitives.WriteInt32LittleEndian(b, value); Write(address, b); }
        internal void U64(ulong address, ulong value) { var b = new byte[8]; BinaryPrimitives.WriteUInt64LittleEndian(b, value); Write(address, b); }
        internal void Float(ulong address, float value) { var b = new byte[4]; BinaryPrimitives.WriteSingleLittleEndian(b, value); Write(address, b); }
        public ulong ModuleBase(string name) => 0;
        public ulong ExportAddress(string module, string symbol) => 0;
    }

    private static string Hex(ulong value) => "0x" + value.ToString("X16");
}
