using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using SevenDaysEsp;

internal static class CreativeMenuAccessTests
{
    public static Task QueryAndIdempotentRequestsNeverWrite()
    {
        var f = new Fixture();
        var state = f.Apply(null);
        Check(state.Success && state.Code == "ETAT_LU" && state.ObservedEnabled == false && !state.WriteAttempted, state.Message);
        var same = f.Apply(false);
        Check(same.Success && same.Code == "DEJA_APPLIQUE" && f.Writer.Writes.Count == 0, same.Message);
        Check(f.Writer.ReadCalls < 1800, "Query/idempotent validation chased excessive metadata literals.");
        return Task.CompletedTask;
    }

    public static Task ArrayLengthPaddingDoesNotChangeLengthOrGetOverwritten()
    {
        var f = new Fixture();
        ulong[] arrays = { f.Values, f.Sandbox, f.Declarations };
        uint[] padding = { 0xA5B6C7D8U, 0x89ABCDEFU, 0xFEDCBA98U };
        for (int i = 0; i < arrays.Length; i++) f.Memory.U32(arrays[i] + 0x1C, padding[i]);
        var query = f.Apply(null);
        Check(query.Success && query.ObservedEnabled == false && !query.WriteAttempted, query.Message);
        var activated = f.Apply(true);
        Check(activated.Success && activated.ObservedEnabled == true && activated.WriteAttempted &&
            f.Writer.Writes.Count == 1 && f.Writer.Writes[0].Slot == f.TargetSlot, activated.Message);
        for (int i = 0; i < arrays.Length; i++)
            Check(BitConverter.ToUInt32(f.Memory.Read(arrays[i] + 0x1C, 4), 0) == padding[i],
                "A menu action overwrote the alignment bytes after Mono's UInt32 array length.");
        return Task.CompletedTask;
    }

    public static Task OnlyCreativeSlotChangesAndSharedDefaultsStayImmutable()
    {
        var f = new Fixture();
        byte[] defaults = f.Memory.Read(f.Declarations + 0x20, 293 * 40);
        byte[] values = f.Memory.Read(f.Values + 0x20, 316 * 8);
        var enabled = f.Apply(true);
        Check(enabled.Success && enabled.Code == "CONFIRME" && enabled.WriteAttempted && enabled.ObservedEnabled == true, enabled.Message);
        Check(f.Writer.Writes.Count == 1 && f.Writer.Writes[0].Slot == f.TargetSlot && f.Writer.Writes[0].Value == f.True,
            "The action wrote outside the single creative reference slot.");
        Check(f.Memory.ReadU64(f.Values + 0x20 + 5 * 8) == f.False && f.Memory.Read(f.False + 16, 1)[0] == 0 &&
            f.Memory.Read(f.True + 16, 1)[0] == 1, "A shared boxed Boolean was mutated.");
        Check(defaults.SequenceEqual(f.Memory.Read(f.Declarations + 0x20, defaults.Length)), "The static declaration table was modified.");
        byte[] after = f.Memory.Read(f.Values + 0x20, values.Length);
        for (int i = 0; i < values.Length; i++)
            if (i < 47 * 8 || i >= 48 * 8) Check(values[i] == after[i], "Another preference changed.");
        var disabled = f.Apply(false);
        Check(disabled.Success && disabled.WriteAttempted && disabled.ObservedEnabled == false &&
            f.Memory.ReadU64(f.TargetSlot) == f.False && f.Writer.Writes.Count == 2, disabled.Message);
        Check(f.Writer.ReadCalls < 1800, "Two menu operations performed excessive metadata reads.");
        return Task.CompletedTask;
    }

    public static Task CurrentUnsharedBoxCanBeReplacedWithoutMutatingIt()
    {
        var f = new Fixture();
        ulong own = f.NewBoolean(false);
        f.Memory.U64(f.TargetSlot, own);
        var result = f.Apply(true);
        Check(result.Success && f.Memory.Read(own + 16, 1)[0] == 0 && f.Memory.ReadU64(f.TargetSlot) == f.True, result.Message);
        return Task.CompletedTask;
    }

    public static Task SandboxNullAndInvalidValuesRefuseBeforeWrite()
    {
        foreach (Action<Fixture> invalidate in new Action<Fixture>[]
        {
            f => f.Memory.U64(f.Sandbox + 0x20 + 47 * 8, f.False),
            f => f.Memory.U64(f.TargetSlot, 0),
            f => f.Memory.Byte(f.False + 16, 2),
            f => f.Memory.U64(f.Memory.ReadU64(f.False) + 0x10, f.Memory.Allocate(32)),
            f => f.Memory.U64(f.Values + 0x18, 315),
            f => f.Memory.U64(f.Declarations + 0x18, 292),
            f => f.Memory.U32(f.PrefsClass + 0x58, 0x02001216),
            f => f.Memory.U32(f.EnumClass + 0x58, 0x0200120C)
        })
        {
            var f = new Fixture(); invalidate(f);
            var result = f.Apply(true);
            Check(!result.Success && !result.WriteAttempted && result.ObservedEnabled == null && f.Writer.Writes.Count == 0,
                "An invalid graph was written: " + result.Message);
        }
        return Task.CompletedTask;
    }

    public static Task WrongVersionPidAndContextNeverWrite()
    {
        var wrongVersion = new Fixture();
        var access = wrongVersion.Access(new GameVersionReport { Status = "VERSION_JEU_LUE", DisplayVersion = "V 3.5.0 (b1)" });
        Check(!access.Apply(wrongVersion.Context, 77, true).Success && wrongVersion.Writer.Writes.Count == 0,
            "An unknown game profile enabled writes.");
        var f = new Fixture();
        Check(!f.ReaderAccess.Apply(Guid.NewGuid().ToString("N"), 77, true).Success, "A foreign context was accepted.");
        Check(!f.ReaderAccess.Apply(f.Context, 78, true).Success, "A foreign PID was accepted.");
        Check(f.Writer.Writes.Count == 0, "A stale request caused a write.");
        return Task.CompletedTask;
    }

    public static Task ChangedWorldAndRejectedCapturesInvalidateMenuContext()
    {
        foreach (Action<Fixture> change in new Action<Fixture>[]
        {
            f => f.World.ReplaceWorld(), f => f.World.ReplaceLocalPlayer(), f => f.World.SetLocalId(200),
            f => { f.World.SetFlags(0, 0); f.Reader.Capture(); f.World.SetFlags(1, 1); }
        })
        {
            var f = new Fixture(); change(f);
            var result = f.Apply(true);
            Check(!result.Success && !result.WriteAttempted && f.Writer.Writes.Count == 0,
                "A changed or rejected world allowed menu writes.");
        }
        var completed = new Fixture();
        LiveMenuContext? escaped = null;
        completed.Reader.ExecuteInValidatedContext(completed.Context, context => { escaped = context; return 0; });
        bool rejected = false;
        try { escaped!.Validate(); } catch (InvalidOperationException) { rejected = true; }
        Check(rejected, "An escaped context remained usable after its callback.");
        return Task.CompletedTask;
    }

    public static Task PreferencesChangingDuringValidationRefuseWrite()
    {
        var f = new Fixture();
        bool fired = false;
        f.Memory.BeforeRead = (address, _) =>
        {
            if (!fired && address == f.Declarations + 0x20)
            {
                fired = true;
                f.Memory.U64(f.Instance + 0x10, f.Sandbox);
            }
        };
        var result = f.Apply(true);
        Check(fired && !result.Success && !result.WriteAttempted && f.Writer.Writes.Count == 0, result.Message);
        return Task.CompletedTask;
    }

    public static Task LastSlotCompareRefusesConcurrentPreferenceChange()
    {
        var f = new Fixture();
        f.Writer.BeforeWrite = () => f.Memory.U64(f.TargetSlot, f.True);
        var result = f.Apply(true);
        Check(!result.Success && !result.WriteAttempted && f.Writer.Writes.Count == 0,
            "The last expected-reference guard overwrote a concurrently changed slot.");
        return Task.CompletedTask;
    }

    public static Task NativeRefusalAndPostWriteReadFailureNeverRetry()
    {
        var refused = new Fixture(); refused.Writer.RejectNative = true;
        var failure = refused.Apply(true);
        Check(!failure.Success && failure.WriteAttempted && refused.Writer.Writes.Count == 1 &&
            refused.Memory.ReadU64(refused.TargetSlot) == refused.False, failure.Message);
        var uncertain = new Fixture();
        uncertain.Writer.AfterWrite = () => uncertain.Memory.BeforeRead = (address, _) =>
        { if (address == uncertain.PrefsClass) throw new IOException("Simulated readback interruption."); };
        var result = uncertain.Apply(true);
        Check(!result.Success && result.WriteAttempted && result.ObservedEnabled == null && result.Code == "CREATIF_ETAT_INDETERMINE" &&
            uncertain.Writer.Writes.Count == 1, result.Message);
        return Task.CompletedTask;
    }

    public static Task PostWriteWorldChangeIsUnconfirmedWithoutRestore()
    {
        var f = new Fixture(); f.Writer.AfterWrite = () => f.World.ReplaceWorld();
        var result = f.Apply(true);
        Check(!result.Success && result.WriteAttempted && result.ObservedEnabled == null && f.Writer.Writes.Count == 1 &&
            f.Memory.ReadU64(f.TargetSlot) == f.True, "A changed world was confirmed or an old address was restored.");
        return Task.CompletedTask;
    }

    public static Task CancellationBeforeNativeWriteAndAfterWriteAreDistinct()
    {
        var f = new Fixture(); using var cancelled = new CancellationTokenSource();
        f.Writer.BeforeWrite = cancelled.Cancel;
        var before = f.ReaderAccess.Apply(f.Context, 77, true, cancelled.Token);
        Check(!before.Success && !before.WriteAttempted && f.Writer.Writes.Count == 0, "Cancellation allowed a new native write.");
        var afterFixture = new Fixture(); using var afterCancel = new CancellationTokenSource();
        afterFixture.Writer.AfterWrite = afterCancel.Cancel;
        var after = afterFixture.ReaderAccess.Apply(afterFixture.Context, 77, true, afterCancel.Token);
        Check(!after.Success && after.WriteAttempted && after.ObservedEnabled == null && afterFixture.Writer.Writes.Count == 1,
            "Cancellation after write falsely confirmed or retried the operation.");
        return Task.CompletedTask;
    }

    public static async Task ExpiredContextRequiresNewCapture()
    {
        var f = new Fixture();
        await Task.Delay(2100);
        var expired = f.Apply(true);
        Check(!expired.Success && !expired.WriteAttempted && f.Writer.Writes.Count == 0, "An expired capture allowed a write.");
        Check(f.Reader.Capture().Status == "ENTITES_LUES", "Fresh synthetic capture failed.");
        var fresh = f.Apply(true);
        Check(fresh.Success && fresh.WriteAttempted, fresh.Message);
    }

    public static Task SlowValidationReservesTimeForReadbackBeforeWriting()
    {
        var f = new Fixture(); bool delayed = false;
        f.Memory.BeforeRead = (address, _) =>
        {
            if (!delayed && address == f.Declarations + 0x20)
            { delayed = true; Thread.Sleep(1300); }
        };
        var result = f.Apply(true);
        Check(delayed && !result.Success && !result.WriteAttempted && f.Writer.Writes.Count == 0,
            "The action consumed its verification reserve before writing.");
        return Task.CompletedTask;
    }

    public static Task ReadOnlySourceCanQueryButCannotChange()
    {
        var f = new Fixture();
        var readOnly = new CreativeMenuAccess(f.Memory, f.Reader, f.World.Metadata, Fixture.Version());
        var query = readOnly.Apply(f.Context, 77, null);
        Check(query.Success && query.ObservedEnabled == false, query.Message);
        var change = readOnly.Apply(f.Context, 77, true);
        Check(!change.Success && !change.WriteAttempted && f.Writer.Writes.Count == 0, change.Message);
        return Task.CompletedTask;
    }

    private static void Check(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }

    internal sealed class Fixture
    {
        internal readonly LiveReaderTests.Fixture World = new();
        internal LiveReaderTests.FakeMemory Memory => World.Memory;
        internal readonly WriterMemory Writer;
        internal readonly LiveEntityReader Reader;
        internal readonly CreativeMenuAccess ReaderAccess;
        internal readonly string Context;
        internal readonly ulong PrefsClass, EnumClass, Instance, Values, Sandbox, Declarations, False, True;
        private readonly ulong boolClass, coreImage, gameImage;
        internal ulong TargetSlot => Values + 0x20 + 47 * 8;

        internal Fixture()
        {
            gameImage = Memory.ReadU64(World.Classes["GameManager"] + 0x40);
            coreImage = Memory.Allocate(32);
            ulong objectType = Class("Object", "System", 1, 16, coreImage);
            boolClass = Class("Boolean", "System", 1, 24, coreImage);
            Fields(boolClass, new[] { ("m_value", 16, (byte)0x02, false, 0UL) });
            False = NewBoolean(false); True = NewBoolean(true);
            EnumClass = Class("EnumGamePrefs", "", 1, 24, gameImage, 0x0200120B);
            Fields(EnumClass, new[] { ("value__", 16, (byte)0x08, false, 0UL) });
            ulong declarationEnum = Class("EnumType", "", 1, 24, gameImage, 0x02001216);
            Fields(declarationEnum, new[] { ("value__", 16, (byte)0x08, false, 0UL) });
            ulong declarationType = Class("PropertyDecl", "", 1, 56, gameImage, 0x02001217);
            Fields(declarationType, new[]
            {
                ("name", 16, (byte)0x11, false, EnumClass), ("type", 20, (byte)0x11, false, declarationEnum),
                ("defaultValue", 24, (byte)0x1C, false, 0UL)
            });
            ulong sandboxType = Class("BaseSandboxOption", "SandboxOptions", 1, 24, gameImage);
            PrefsClass = Class("GamePrefs", "", 1, 24, gameImage, 0x02001215);
            var prefsFields = new[]
            {
                ("m_Instance", 0, (byte)0x12, true, PrefsClass),
                ("propertyValues", 16, (byte)0x1D, false, objectType),
                ("sandboxReferences", 8, (byte)0x1D, true, sandboxType),
                ("s_propertyList", 16, (byte)0x1D, true, declarationType)
            };
            Fields(PrefsClass, prefsFields);
            var report = new MonoClassReport { Name = "GamePrefs", Namespace = "", Address = "0x" + PrefsClass.ToString("X"),
                MetadataToken = "0x02001215", InstanceSize = 24, FieldsComplete = true };
            foreach (var field in prefsFields)
                report.Fields.Add(new MonoFieldReport { Name = field.Item1, Offset = field.Item2,
                    TypeCode = "0x" + field.Item3.ToString("X2"), IsStatic = field.Item4 });
            World.Metadata.Classes.Add(report);
            Instance = Object(PrefsClass, 24);
            Values = Array(objectType, "Object[]", "System", coreImage, 316, 8);
            Sandbox = Array(sandboxType, "BaseSandboxOption[]", "SandboxOptions", gameImage, 316, 8);
            Declarations = Array(declarationType, "PropertyDecl[]", "", gameImage, 293, 40);
            for (int index = 0; index < 316; index++) Memory.U64(Values + 0x20 + (ulong)index * 8, False);
            for (int index = 0; index < 293; index++)
            {
                int name = (index + 91) % 293;
                ulong at = Declarations + 0x20 + (ulong)index * 40;
                Memory.I32(at, name);
                Memory.I32(at + 4, name == 47 || index == 1 ? 3 : 0);
                Memory.U64(at + 8, name == 47 ? False : index == 1 ? True : 0);
            }
            Memory.U64(Instance + 16, Values);
            ulong runtime = Memory.Allocate(32), table = Vtable(PrefsClass), statics = Memory.Allocate(24);
            Memory.U64(PrefsClass + 0xD0, runtime); Memory.I32(PrefsClass + 0x90, 24);
            Memory.U64(runtime + 8, table); Memory.Byte(table + 0x2D, 1); Memory.U32(table + 0x30, 4);
            Memory.U64(table + 0x48, statics); Memory.U64(statics, Instance); Memory.U64(statics + 8, Sandbox); Memory.U64(statics + 16, Declarations);
            Writer = new WriterMemory(Memory);
            Reader = new LiveEntityReader(Writer, World.Metadata);
            var capture = Reader.Capture();
            Check(capture.Status == "ENTITES_LUES", capture.Message);
            Context = capture.PlayerContextId;
            ReaderAccess = Access(Version());
            Writer.ReadCalls = 0;
        }
        internal CreativeMenuAccess Access(GameVersionReport version) => new(Writer, Reader, World.Metadata, version);
        internal CreativeMenuAccessResult Apply(bool? enabled) => ReaderAccess.Apply(Context, 77, enabled);
        internal static GameVersionReport Version() => new() { Status = "VERSION_JEU_LUE", DisplayVersion = "V 3.4.0 (b10)" };
        internal ulong NewBoolean(bool value)
        {
            ulong box = Object(boolClass, 24); Memory.Byte(box + 16, value ? (byte)1 : (byte)0); return box;
        }
        private ulong Class(string name, string ns, byte kind, int size, ulong image, uint token = 0)
        {
            ulong result = Memory.Allocate(0x180);
            Memory.Byte(result + 0x1B, kind); Memory.I32(result + 0x1C, size); Memory.U64(result + 0x40, image);
            Memory.U64(result + 0x48, Memory.CString(name)); Memory.U64(result + 0x50, Memory.CString(ns)); Memory.U32(result + 0x58, token);
            return result;
        }
        private void Fields(ulong type, (string Name, int Offset, byte Code, bool Static, ulong Data)[] values)
        {
            ulong fields = Memory.Allocate(values.Length * 32);
            Memory.U64(type + 0x98, fields); Memory.I32(type + 0x100, values.Length);
            for (int i = 0; i < values.Length; i++)
            {
                var value = values[i]; ulong at = fields + (ulong)i * 32, monoType = Memory.Allocate(16);
                Memory.U64(monoType, value.Data); Memory.Byte(monoType + 8, value.Static ? (byte)0x10 : (byte)0);
                Memory.Byte(monoType + 10, value.Code); Memory.U64(at, monoType); Memory.U64(at + 8, Memory.CString(value.Name));
                Memory.U64(at + 16, type); Memory.I32(at + 24, value.Offset);
            }
        }
        private ulong Vtable(ulong type)
        {
            ulong result = Memory.Allocate(0x58);
            Memory.U64(result, type); Memory.U64(result + 0x10, World.Domain); return result;
        }
        private ulong Object(ulong type, int size)
        {
            ulong result = Memory.Allocate(size); Memory.U64(result, Vtable(type)); return result;
        }
        private ulong Array(ulong element, string name, string ns, ulong image, int count, int stride)
        {
            ulong type = Class(name, ns, 5, 32, image);
            Memory.U64(type, element); Memory.Byte(type + 0x1A, 1); Memory.I32(type + 0x90, stride);
            ulong result = Object(type, 32 + count * stride); Memory.U64(result + 0x18, (ulong)count); return result;
        }
    }

    internal sealed class WriterMemory : IMemoryReader, IMenuMemoryWriter
    {
        private readonly LiveReaderTests.FakeMemory memory;
        public uint ProcessId { get; set; } = 77;
        internal Action? BeforeWrite, AfterWrite;
        internal bool RejectNative;
        internal int ReadCalls;
        internal List<(ulong Slot, ulong Value)> Writes = new();
        internal WriterMemory(LiveReaderTests.FakeMemory memory) => this.memory = memory;
        public byte[] Read(ulong address, int count) { ReadCalls++; return memory.Read(address, count); }
        public ulong ModuleBase(string name) => memory.ModuleBase(name);
        public ulong ExportAddress(string module, string symbol) => memory.ExportAddress(module, symbol);
        public MenuReferenceWriteResult WriteMenuReference(uint expectedPid, ulong slot, ulong expectedReference,
            ulong replacementReference, CancellationToken token)
        {
            BeforeWrite?.Invoke();
            if (token.IsCancellationRequested || expectedPid != ProcessId || memory.ReadU64(slot) != expectedReference)
                return new() { Message = "Last guard refused." };
            Writes.Add((slot, replacementReference));
            if (!RejectNative) memory.U64(slot, replacementReference);
            AfterWrite?.Invoke();
            return new() { Attempted = true, ReportedSuccess = !RejectNative, Message = "Synthetic native result." };
        }
    }
}
