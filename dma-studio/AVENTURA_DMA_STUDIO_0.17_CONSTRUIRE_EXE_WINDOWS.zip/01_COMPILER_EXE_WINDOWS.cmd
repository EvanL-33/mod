@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
where powershell.exe >nul 2>&1
if errorlevel 1 (
  echo Windows PowerShell est necessaire.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Compiler-Aventura-DMA-Studio-0.17.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
if "%RESULT%"=="0" (
  echo Publication terminee. Voir le dossier DIST dans cette archive extraite.
) else (
  echo Publication non terminee. Aucun nouvel exe n'a ete valide.
)
pause
exit /b %RESULT%
