using System;
using System.Collections.Generic;
using System.Linq;
using SevenDaysEsp;

namespace SevenDaysLoader;

// Experimental DMA-only watchlist. The game client does not expose a verified
// administrator role in its current LiveEntity feed. These are user-entered
// display names, not proof of permissions, invisibility or account identity.
public sealed class AdminWatchSettings
{
    public bool Enabled { get; set; }
    public string Names { get; set; } = "";
    public bool PurpleEsp { get; set; } = true;
    public bool Sound { get; set; }
    public int AlertRangeMeters { get; set; } = 100;
    public int CooldownSeconds { get; set; } = 20;
    public string Color { get; set; } = "#C6A0FF";
}

public static class AdminWatchMatcher
{
    public static bool IsListed(AdminWatchSettings? settings, string? name)
    {
        if (settings?.Enabled != true || string.IsNullOrWhiteSpace(name)) return false;
        return (settings.Names ?? "").Split(new[] { ',', ';', '\n', '\r' },
            StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Take(64).Any(candidate => candidate.Length <= 128 &&
                string.Equals(candidate, name.Trim(), StringComparison.OrdinalIgnoreCase));
    }

    public static IReadOnlyList<LiveEntity> Nearby(FeedSample? frame, AdminWatchSettings? settings)
    {
        if (frame?.IsFresh != true || settings?.Enabled != true) return Array.Empty<LiveEntity>();
        var origin = frame.Snapshot.LocalPosition;
        double max = Math.Clamp(settings.AlertRangeMeters, 5, 1000);
        return frame.Snapshot.Entities.Where(entity => entity.Kind == "player" &&
            IsListed(settings, entity.Name) && Distance(entity.Position, origin) <= max)
            .Take(64).ToArray();
    }

    public static double Distance(LivePosition a, LivePosition b)
    {
        double x = a.X - b.X, y = a.Y - b.Y, z = a.Z - b.Z;
        return Math.Sqrt(x*x + y*y + z*z);
    }
}
