using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;
using SevenDaysDmaControl;

namespace SevenDaysEsp
{
    public sealed class ControlCommand
    {
        public Guid ExpectedSessionId { get; set; }
        public Guid ExpectedContextId { get; set; }
        public int ExpectedPlayerId { get; set; } = -1;
        // Monotonic timestamp captured for the user's original intent on the
        // reader PC. The module's separate TTL uses its own game clock.
        public long RequestedTimestamp { get; set; }
        public ControlOperation Operation { get; set; }
        public bool Enabled { get; set; }
        public float Value { get; set; }
        public float PositionX { get; set; }
        public float PositionY { get; set; }
        public float PositionZ { get; set; }
        public int TargetEntityId { get; set; } = -1;
    }

    public sealed class ControlProbeResult
    {
        public bool Available { get; internal set; }
        public bool Fresh { get; internal set; }
        public string Code { get; internal set; }
        public string Message { get; internal set; }
        public ControlSnapshot Snapshot { get; internal set; }
        public ulong PendingRequestId { get; internal set; }
        public long ObservedAgeMs { get; internal set; }
        public int ReadCalls { get; internal set; }
        public int ReadBytes { get; internal set; }
        public long ProbeDurationMs { get; internal set; }
    }

    public sealed class ControlSubmitResult
    {
        // Accepted means committed and read back, never "applied by the server".
        public bool Accepted { get; internal set; }
        public bool WriteAttempted { get; internal set; }
        public bool CommitAttempted { get; internal set; }
        public ulong RequestId { get; internal set; }
        public string Code { get; internal set; }
        public string Message { get; internal set; }
    }

    // Targeted metadata traversal only. Addresses never leave this component.
    // No Unity/native function, delegate, executable page or game-state field is
    // written. Requests go only to the optional module's rooted, pinned mailbox.
    public sealed class DmaControlBridge
    {
        private const string AssemblyName = "SevenDaysDmaControl";
        private const string BridgeNamespace = "SevenDaysDmaControl";
        private const string BridgeClassName = "ControlBridge";
        // Kept in sync with the packaged deterministic module build.
        private const uint BridgeTypeToken = 0x02000002U;
        private const int HeartbeatTimeoutMs = 1000;
        private const int MaxAssemblies = 512;
        private const int AssemblyNodesPerProbe = 16;
        private readonly IMemoryReader memory;
        private readonly MonoInspectionReport metadata;
        private readonly object gate = new object();
        private readonly UTF8Encoding utf8 = new UTF8Encoding(false, true);
        private readonly ulong monoBase;
        private readonly uint monoSize;
        private string liveContextId;
        private uint processId;
        private ulong domain, world, player;
        private int playerId;
        private Graph graph;
        private Discovery discovery;
        private long lastProbeTicks;
        private byte[] lastState;
        private ControlSnapshot lastDecoded;
        private long heartbeatTicks;
        private bool heartbeatAdvanced;
        private bool lastReadValid;
        private string lastCode = "MODULE_NON_RECHERCHE", lastMessage = "Module de commandes en attente.";
        private ulong pendingRequestId;
        private ControlOperation pendingOperation;
        private Guid pendingSession;
        private Guid pendingContext;
        private long pendingExpiresMs;
        private Guid issuedSession;
        private ulong lastIssuedRequestId;
        private Stopwatch budget;
        private int calls, bytes, maximumMs;
        private CancellationToken token;
        private int presentPollIntervalMs = 100;

        // The worker can honor this before entering a validated context. It
        // avoids paying for a game-root validation when discovery is throttled.
        public int RecommendedPollIntervalMs
        { get { lock (gate) { return graph == null ? 500 : presentPollIntervalMs; } } }

        private sealed class Discovery
        {
            internal ulong Head, Next, Assembly, AssemblyNode, Image;
            internal bool GameSeen, Complete;
            internal int Matches;
            internal readonly HashSet<ulong> Nodes = new HashSet<ulong>();
        }

        private sealed class TypeInfo
        {
            internal ulong Address, Image, Fields, Element, NamePointer, NamespacePointer;
            internal int Size, Count, Stride, StaticSize, VtableSlots;
            internal uint Token;
            internal byte Kind, Rank;
            internal string Name, Namespace;
        }

        private sealed class FieldInfo
        {
            internal int Offset;
            internal byte Code;
            internal ushort Flags;
            internal ulong Data;
        }

        private sealed class ArrayInfo
        {
            internal ulong Address, Table;
            internal int Length;
            internal TypeInfo Type;
            internal ulong Data { get { return checked(Address + 0x20UL); } }
        }

        private sealed class Graph
        {
            internal ulong AssemblyNode, Assembly, Image, AssemblyNamePointer;
            internal ulong Runtime, RuntimeSlot, StaticTable, StaticSlot, Statics;
            internal TypeInfo Type, ByteType;
            internal int RequestOffset, StateOffset;
            internal ArrayInfo Request, State;
        }

        public DmaControlBridge(IMemoryReader memory, MonoInspectionReport metadata)
        {
            this.memory = memory ?? throw new ArgumentNullException(nameof(memory));
            this.metadata = metadata ?? throw new ArgumentNullException(nameof(metadata));
            if (metadata.Modules != null)
                foreach (MonoModuleReport item in metadata.Modules)
                    if (item != null && item.Name == metadata.MonoModule)
                    {
                        monoBase = ParseAddress(item.BaseAddress); monoSize = item.ImageSize;
                        break;
                    }
        }

        public void Reset()
        {
            lock (gate)
            {
                liveContextId = null; processId = 0; domain = world = player = 0; playerId = -1;
                graph = null; discovery = null; lastProbeTicks = 0; lastState = null; lastDecoded = null;
                heartbeatTicks = 0; heartbeatAdvanced = false; lastReadValid = false;
                pendingRequestId = 0; pendingSession = Guid.Empty; pendingExpiresMs = 0;
                lastCode = "MODULE_NON_RECHERCHE"; lastMessage = "Module de commandes en attente.";
            }
        }

        public ControlProbeResult Probe(LiveMenuContext context, uint expectedProcessId,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            lock (gate)
            {
                try
                {
                    Begin(cancellationToken, 250);
                    CheckScope(context, expectedProcessId);
                    long now = Stopwatch.GetTimestamp();
                    if (lastProbeTicks != 0 && AgeMs(lastProbeTicks, now) < RecommendedPollIntervalMs)
                        return Result(now);
                    lastProbeTicks = now;
                    ProbeCore(context);
                    if (graph != null) presentPollIntervalMs = budget.ElapsedMilliseconds <= 15 ? 100 : budget.ElapsedMilliseconds <= 40 ? 200 : 500;
                    return Result(Stopwatch.GetTimestamp());
                }
                catch (Exception e)
                {
                    lastReadValid = false; lastCode = "MODULE_LECTURE_NON_CONFIRMEE"; lastMessage = e.Message;
                    return Result(Stopwatch.GetTimestamp());
                }
            }
        }

        public ControlSubmitResult Submit(LiveMenuContext context, uint expectedProcessId, ControlCommand command,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            lock (gate)
            {
                var result = new ControlSubmitResult { Code = "COMMANDE_REFUSEE" };
                ControlBufferWriteResult native = null;
                try
                {
                    Begin(cancellationToken, 1000);
                    CheckScope(context, expectedProcessId);
                    ValidateCommand(command);
                    long intentTimestamp = command.RequestedTimestamp;
                    var writer = memory as IControlMemoryWriter;
                    if (writer == null || writer.ProcessId != expectedProcessId)
                        throw new IOException("La source DMA ne permet pas les commandes du module.");
                    if (graph == null)
                        throw new IOException("Le module client n'a pas encore ete identifie. Attends son etat dans le loader.");
                    // The user's intent is bound to the module snapshot displayed
                    // when the action was created. A new world is never substituted.
                    ProbeCore(context);
                    ControlProbeResult current = Result(Stopwatch.GetTimestamp());
                    ControlSnapshot state = lastDecoded;
                    if (!current.Available || !current.Fresh || state == null || !state.Observation.IsReady)
                        throw new IOException("Un module pret avec un heartbeat recent et progressant est requis.");
                    if (state.SessionId != command.ExpectedSessionId || state.Observation.ContextId != command.ExpectedContextId ||
                        state.Observation.PlayerId != command.ExpectedPlayerId)
                        throw new IOException("La session ou le joueur affiche a change ; renouvelle explicitement la demande.");
                    if (pendingRequestId != 0 || state.PendingRequestId != 0)
                        throw new IOException("Une commande est deja en cours ou son resultat reste a observer.");
                    if ((state.Observation.SupportedOperations & ControlProtocol.OperationMask(command.Operation)) == 0)
                        throw new IOException("Cette operation n'est pas prise en charge par le module courant.");
                    byte[] requestBefore = Read(graph.Request.Data, ControlProtocol.RequestSize);
                    byte[] requestCheck = Read(graph.Request.Data, ControlProtocol.RequestSize);
                    if (!SameBytes(requestBefore, requestCheck)) throw new IOException("La boite de commandes est occupee.");
                    ulong highest = Math.Max(state.RequestHighWatermark, state.LastRequestId);
                    if (issuedSession == state.SessionId) highest = Math.Max(highest, lastIssuedRequestId);
                    ControlRequest previous; string decodeError;
                    if (ControlProtocol.TryDecodeRequest(requestBefore, out previous, out decodeError) && previous.SessionId == state.SessionId)
                    {
                        highest = Math.Max(highest, previous.RequestId);
                        if (previous.RequestId > state.RequestHighWatermark &&
                            previous.ExpiresGameTimeMs >= state.Observation.GameTimestampMs)
                            throw new IOException("Une commande precedente attend encore d'etre consommee par le module.");
                    }
                    else if (!AllZero(requestBefore) && ControlProtocol.ReadSequence(requestBefore) != 0 &&
                        (ControlProtocol.ReadSequence(requestBefore) & 1U) == 0)
                        throw new IOException("Le contenu de la boite de commandes est incompatible ou incomplet.");
                    if (highest == ulong.MaxValue) throw new IOException("Compteur de commandes epuise ; redemarre le module.");
                    ulong requestId = highest + 1UL;
                    var request = new ControlRequest {
                        SessionId = state.SessionId, ContextId = state.Observation.ContextId,
                        RequestId = requestId, PlayerId = state.Observation.PlayerId, Operation = command.Operation,
                        IssuedGameTimeMs = state.Observation.GameTimestampMs,
                        ExpiresGameTimeMs = checked(state.Observation.GameTimestampMs + ControlProtocol.DefaultRequestLifetimeMs),
                        Enabled = command.Enabled, Value = command.Value, PositionX = command.PositionX,
                        PositionY = command.PositionY, PositionZ = command.PositionZ, TargetEntityId = command.TargetEntityId
                    };
                    byte[] record = ControlProtocol.EncodeRequest(request, ControlProtocol.NextSequence(ControlProtocol.ReadSequence(requestBefore)));
                    Graph target = graph;
                    Action validate = delegate {
                        ValidateIntentAge(intentTimestamp);
                        context.Validate(); CheckProcess(expectedProcessId); ValidateGraph(target, context, true);
                        ControlSnapshot fresh = ReadState(target, context);
                        if (fresh.SessionId != request.SessionId || fresh.Observation.ContextId != request.ContextId ||
                            !fresh.Observation.IsReady || fresh.Observation.PlayerId != request.PlayerId ||
                            fresh.PendingRequestId != 0 || fresh.RequestHighWatermark >= requestId ||
                            fresh.Observation.GameTimestampMs < request.IssuedGameTimeMs ||
                            fresh.Observation.GameTimestampMs >= request.ExpiresGameTimeMs)
                            throw new IOException("Le module ou son contexte a change avant la validation de la commande.");
                        ValidateIntentAge(intentTimestamp);
                    };
                    validate();
                    // Preserve uncertain outcomes. Once a write may have happened,
                    // only observations/expiry release this reservation, never retry.
                    result.RequestId = requestId;
                    issuedSession = request.SessionId; lastIssuedRequestId = requestId;
                    pendingRequestId = requestId; pendingOperation = request.Operation;
                    pendingSession = request.SessionId; pendingContext = request.ContextId; pendingExpiresMs = request.ExpiresGameTimeMs;
                    native = writer.WriteControlRecord(expectedProcessId, new ControlBufferLease(target.Request.Address, intentTimestamp),
                        requestBefore, record, validate, token);
                    if (native == null) throw new IOException("Resultat natif absent ; transmission indeterminee.");
                    result.WriteAttempted = native.Attempted; result.CommitAttempted = native.CommitAttempted;
                    if (!native.Attempted) { pendingRequestId = 0; pendingSession = Guid.Empty; }
                    result.Accepted = native.Attempted && native.CommitAttempted && native.ReportedSuccess && native.ReadbackConfirmed;
                    result.Code = result.Accepted ? "COMMANDE_TRANSMISE" : native.Attempted ? "COMMANDE_TRANSMISSION_INDETERMINEE" : "COMMANDE_REFUSEE";
                    result.Message = native.Message;
                    lastProbeTicks = 0;
                }
                catch (Exception e)
                {
                    if (native != null)
                    {
                        result.WriteAttempted = native.Attempted; result.CommitAttempted = native.CommitAttempted;
                    }
                    // Writer implementations must return native attempt markers.
                    // A writer throwing after invocation is conservatively unknown.
                    if (result.RequestId != 0 && native == null) result.WriteAttempted = true;
                    result.Accepted = false;
                    result.Code = result.WriteAttempted ? "COMMANDE_TRANSMISSION_INDETERMINEE" : "COMMANDE_REFUSEE";
                    result.Message = (result.WriteAttempted ? "Aucun nouvel essai automatique. " : "") + e.Message;
                }
                return result;
            }
        }

        private void ProbeCore(LiveMenuContext context)
        {
            CheckProcess(processId);
            if (graph == null)
            {
                graph = Discover(context);
                if (graph == null) { lastReadValid = false; return; }
            }
            ValidateGraph(graph, context, false);
            ControlSnapshot state = ReadState(graph, context);
            context.Validate(); CheckProcess(processId);
            long now = Stopwatch.GetTimestamp();
            if (lastDecoded == null || state.SessionId != lastDecoded.SessionId)
            {
                heartbeatTicks = now; heartbeatAdvanced = false;
                if (pendingSession != Guid.Empty && pendingSession != state.SessionId) pendingRequestId = 0;
            }
            else
            {
                if (state.Observation.GameTimestampMs < lastDecoded.Observation.GameTimestampMs ||
                    state.RequestHighWatermark < lastDecoded.RequestHighWatermark)
                    throw new IOException("Le compteur ou l'horloge du module a recule.");
                if (state.Observation.GameTimestampMs > lastDecoded.Observation.GameTimestampMs)
                { heartbeatTicks = now; heartbeatAdvanced = true; }
            }
            lastDecoded = state;
            lastState = ControlProtocol.EncodeSnapshot(state, state.Sequence);
            lastReadValid = true;
            lastCode = state.Observation.IsReady ? "MODULE_IDENTIFIE" : "MODULE_EN_ATTENTE";
            lastMessage = state.Observation.IsReady ? "Module client identifie ; etat local observe par DMA." : state.LastMessage;
            if (pendingRequestId != 0 && pendingSession == state.SessionId && state.PendingRequestId != pendingRequestId)
            {
                if (state.LastRequestId == pendingRequestId && state.LastStatus != ControlStatus.Pending && state.LastStatus != ControlStatus.None)
                {
                    if (state.LastOperation != pendingOperation || state.LastRequestContextId != pendingContext)
                    { lastCode = "COMMANDE_CONFLIT"; lastMessage = "Une autre commande porte le meme identifiant ; resultat non attribuable."; }
                    pendingRequestId = 0;
                }
                else if (state.RequestHighWatermark >= pendingRequestId || state.Observation.GameTimestampMs > pendingExpiresMs)
                {
                    lastCode = "COMMANDE_RESULTAT_NON_CONFIRME";
                    lastMessage = "La demande n'est plus en attente ; son resultat exact n'a pas ete observe. Aucun rejeu.";
                    pendingRequestId = 0;
                }
            }
        }

        private ControlProbeResult Result(long now)
        {
            long age = heartbeatTicks == 0 ? long.MaxValue : AgeMs(heartbeatTicks, now);
            bool fresh = lastReadValid && heartbeatAdvanced && age >= 0 && age <= HeartbeatTimeoutMs;
            ControlSnapshot copy = null; string error;
            if (lastState != null) ControlProtocol.TryDecodeSnapshot((byte[])lastState.Clone(), out copy, out error);
            string code = lastCode, message = lastMessage;
            if (graph != null && lastReadValid && !fresh)
            {
                code = heartbeatAdvanced ? "MODULE_HEARTBEAT_EXPIRE" : "MODULE_HEARTBEAT_EN_ATTENTE";
                message = heartbeatAdvanced ? "Le heartbeat du module ne progresse plus ; commandes suspendues." :
                    "Module trouve ; verification de la progression de son heartbeat.";
            }
            return new ControlProbeResult { Available = graph != null, Fresh = fresh, Code = code, Message = message,
                Snapshot = copy, PendingRequestId = pendingRequestId != 0 ? pendingRequestId : copy == null ? 0 : copy.PendingRequestId,
                ObservedAgeMs = age, ReadCalls = calls, ReadBytes = bytes,
                ProbeDurationMs = budget == null ? 0 : budget.ElapsedMilliseconds };
        }

        private void CheckScope(LiveMenuContext context, uint expectedProcessId)
        {
            if (context == null || expectedProcessId == 0 || string.IsNullOrEmpty(context.ContextId))
                throw new IOException("Une partie et un processus valides sont requis.");
            context.Validate(); CheckProcess(expectedProcessId);
            if (metadata.SelectedLayout != "Unity Mono x64 2022 (candidate)" ||
                (metadata.Status != "METADONNEES_PARTIELLES" && metadata.Status != "METADONNEES_COLLECTEES") ||
                monoBase == 0 || monoSize < 4096)
                throw new IOException("Le profil Mono requis pour le module n'est pas valide.");
            if (liveContextId != context.ContextId || processId != expectedProcessId || domain != context.Domain ||
                world != context.WorldAddress || player != context.LocalPlayerAddress || playerId != context.LocalPlayerId)
            {
                Reset(); liveContextId = context.ContextId; processId = expectedProcessId; domain = context.Domain;
                world = context.WorldAddress; player = context.LocalPlayerAddress; playerId = context.LocalPlayerId;
            }
            RequirePointer(domain); RequirePointer(world); RequirePointer(player);
        }

        private void CheckProcess(uint expectedProcessId)
        {
            var writer = memory as IControlMemoryWriter;
            if (writer != null && writer.ProcessId != expectedProcessId)
                throw new IOException("Le processus DMA a change.");
        }

        private Graph Discover(LiveMenuContext context)
        {
            ulong head = U64(context.Domain + 0xA0UL);
            if (discovery == null || discovery.Head != head)
                discovery = new Discovery { Head = head, Next = head };
            if (!discovery.Complete)
            {
                for (int n = 0; discovery.Next != 0 && n < AssemblyNodesPerProbe; ++n)
                {
                    if (n != 0 && budget.ElapsedMilliseconds >= 50) break;
                    ulong node = discovery.Next;
                    if (discovery.Nodes.Count >= MaxAssemblies || discovery.Nodes.Contains(node))
                    { discovery = null; throw new IOException("Liste d'assemblies Mono cyclique ou hors limites."); }
                    byte[] link = Read(node, 16);
                    ulong assembly = BufferPointer(link, 0);
                    byte[] info = Read(assembly, 0x68);
                    string name = CString(BufferPointer(info, 0x10));
                    ulong image = BufferPointer(info, 0x60);
                    if (name == "Assembly-CSharp")
                    {
                        if (image != context.GameImage || discovery.GameSeen)
                            throw new IOException("Assembly du jeu ambigue dans ce domaine Mono.");
                        discovery.GameSeen = true;
                    }
                    if (name == AssemblyName)
                    {
                        discovery.Matches++; discovery.Assembly = assembly; discovery.AssemblyNode = node; discovery.Image = image;
                    }
                    discovery.Nodes.Add(node);
                    discovery.Next = BitConverter.ToUInt64(link, 8);
                }
                if (discovery.Next != 0)
                {
                    lastCode = "MODULE_RECHERCHE"; lastMessage = "Recherche du module dans les assemblies du domaine valide.";
                    return null;
                }
                discovery.Complete = true;
            }
            if (!discovery.GameSeen) { discovery = null; throw new IOException("Domaine du module non relie a l'assembly du jeu."); }
            if (discovery.Matches == 0)
            {
                discovery = null; lastCode = "MODULE_ABSENT";
                lastMessage = "Module client SevenDaysDmaControl absent de cette partie."; return null;
            }
            if (discovery.Matches != 1) { discovery = null; throw new IOException("Plusieurs modules de commandes dans le domaine."); }
            ulong address = FindBridgeType(discovery.Image);
            TypeInfo type = ReadType(address);
            if (type.Kind != 1 || type.Token != BridgeTypeToken || type.Image != discovery.Image ||
                type.Name != BridgeClassName || type.Namespace != BridgeNamespace || type.Count < 2 || type.Count > 64 ||
                type.StaticSize < 16 || type.StaticSize > 8192 || type.VtableSlots < 0 || type.VtableSlots > 512)
                throw new IOException("Metadonnees du module incompatibles avec le profil distribue.");
            Dictionary<string, FieldInfo> fields = ReadFields(type);
            FieldInfo request = BufferField(fields, "RequestBuffer", type.StaticSize);
            FieldInfo state = BufferField(fields, "StateBuffer", type.StaticSize);
            if (request.Offset == state.Offset || request.Data != state.Data)
                throw new IOException("Champs de communication superposes ou de types differents.");
            TypeInfo byteType = ReadType(request.Data);
            if (byteType.Kind != 1 || byteType.Name != "Byte" || byteType.Namespace != "System" ||
                byteType.Image == type.Image || byteType.Size < 17 || byteType.Size > 32 ||
                (byteType.Token & 0xFF000000U) != 0x02000000U)
                throw new IOException("Le module n'expose pas des tableaux System.Byte reconnus.");
            var result = new Graph { AssemblyNode = discovery.AssemblyNode, Assembly = discovery.Assembly, Image = discovery.Image,
                AssemblyNamePointer = Pointer(discovery.Assembly + 0x10UL), Type = type, ByteType = byteType,
                RequestOffset = request.Offset, StateOffset = state.Offset };
            ResolveStatics(result, context.Domain);
            byte[] statics = Read(result.Statics, type.StaticSize);
            result.Request = ReadArray(BufferPointer(statics, request.Offset), byteType, context.Domain, ControlProtocol.RequestSize);
            result.State = ReadArray(BufferPointer(statics, state.Offset), byteType, context.Domain, ControlProtocol.StateSize);
            if (RangesOverlap(result.Request.Address, 32 + result.Request.Length, result.State.Address, 32 + result.State.Length))
                throw new IOException("Les buffers du module se superposent.");
            ValidateGraph(result, context, true); discovery = null; return result;
        }

        private ulong FindBridgeType(ulong image)
        {
            ulong cache = image + 0x4D0UL;
            byte[] header = Read(cache, 0x28);
            for (int at = 0; at < 24; at += 8)
            {
                ulong function = BitConverter.ToUInt64(header, at);
                if (function < monoBase || function - monoBase >= monoSize)
                    throw new IOException("Cache de classes hors du module Mono valide.");
            }
            int buckets = BitConverter.ToInt32(header, 0x18), entries = BitConverter.ToInt32(header, 0x1C);
            if (buckets < 1 || buckets > 2048 || entries < 1 || entries > 256)
                throw new IOException("Cache du module de commandes hors limites.");
            ulong table = BufferPointer(header, 0x20);
            byte[] heads = Read(table, buckets * 8);
            ulong found = 0; var visited = new HashSet<ulong>();
            for (int index = 0; index < buckets; ++index)
            {
                ulong klass = BitConverter.ToUInt64(heads, index * 8);
                while (klass != 0)
                {
                    if (!visited.Add(klass) || visited.Count > 256) throw new IOException("Cache du module cyclique ou modifie.");
                    byte[] data = Read(klass, 0x110);
                    uint metadataToken = BitConverter.ToUInt32(data, 0x58);
                    if ((metadataToken & 0xFF000000U) != 0x02000000U ||
                        BitConverter.ToUInt64(data, 0x40) != image)
                        throw new IOException("Classe du module dans une autre image.");
                    if (metadataToken == BridgeTypeToken && CString(BufferPointer(data, 0x48)) == BridgeClassName &&
                        CString(BufferPointer(data, 0x50)) == BridgeNamespace)
                    { if (found != 0) throw new IOException("Classe de communication ambigue."); found = klass; }
                    klass = BitConverter.ToUInt64(data, 0x108);
                }
            }
            if (found == 0 || visited.Count != entries || !SameBytes(header, Read(cache, 0x28)))
                throw new IOException("Classe de communication absente ou cache encore en chargement.");
            return found;
        }

        private void ResolveStatics(Graph target, ulong expectedDomain)
        {
            target.Runtime = Pointer(target.Type.Address + 0xD0UL);
            int maximum = BitConverter.ToUInt16(Read(target.Runtime, 2), 0);
            if (maximum >= 32) throw new IOException("Trop de domaines Mono pour le module.");
            for (int index = 0; index <= maximum; ++index)
            {
                ulong slot = target.Runtime + 8UL + (uint)index * 8UL;
                ulong table = U64(slot); if (table == 0) continue;
                byte[] header = Read(table, 0x48);
                if (BitConverter.ToUInt64(header, 0) != target.Type.Address)
                    throw new IOException("Vtable du module reliee a une autre classe.");
                if (BitConverter.ToUInt64(header, 0x10) != expectedDomain || header[0x2D] == 0) continue;
                uint flags = BitConverter.ToUInt32(header, 0x30);
                if (header[0x2D] != 1 || (flags & 2U) != 0 || (flags & 4U) == 0 || target.StaticTable != 0)
                    throw new IOException("Initialisation statique du module non confirmee.");
                target.RuntimeSlot = slot; target.StaticTable = table;
                target.StaticSlot = table + 0x48UL + (uint)target.Type.VtableSlots * 8UL;
                target.Statics = Pointer(target.StaticSlot);
            }
            if (target.StaticTable == 0) throw new IOException("Module non initialise dans le domaine courant.");
        }

        private void ValidateGraph(Graph target, LiveMenuContext context, bool fullMetadata)
        {
            if (target == null || Pointer(target.AssemblyNode) != target.Assembly ||
                Pointer(target.Assembly + 0x10UL) != target.AssemblyNamePointer || Pointer(target.Assembly + 0x60UL) != target.Image)
                throw new IOException("Racine d'assembly du module modifiee.");
            byte[] klass = Read(target.Type.Address, 0x110);
            if (!SameTypeHeader(target.Type, klass) || BitConverter.ToUInt64(klass, 0xD0) != target.Runtime ||
                U64(target.RuntimeSlot) != target.StaticTable || Pointer(target.StaticSlot) != target.Statics)
                throw new IOException("Metadonnees ou racines statiques du module modifiees.");
            byte[] vtable = Read(target.StaticTable, 0x48);
            uint flags = BitConverter.ToUInt32(vtable, 0x30);
            if (BitConverter.ToUInt64(vtable, 0) != target.Type.Address || BitConverter.ToUInt64(vtable, 0x10) != context.Domain ||
                vtable[0x2D] != 1 || (flags & 2U) != 0 || (flags & 4U) == 0)
                throw new IOException("Vtable du module non initialisee dans ce domaine.");
            byte[] statics = Read(target.Statics, target.Type.StaticSize);
            if (BufferPointer(statics, target.RequestOffset) != target.Request.Address ||
                BufferPointer(statics, target.StateOffset) != target.State.Address)
                throw new IOException("Buffer du module remplace.");
            ValidateArray(target.Request, target.ByteType, context.Domain);
            ValidateArray(target.State, target.ByteType, context.Domain);
            if (fullMetadata)
            {
                if (CString(target.AssemblyNamePointer) != AssemblyName ||
                    CString(target.Type.NamePointer) != BridgeClassName || CString(target.Type.NamespacePointer) != BridgeNamespace)
                    throw new IOException("Identite du module modifiee.");
                var fields = ReadFields(target.Type);
                FieldInfo request = BufferField(fields, "RequestBuffer", target.Type.StaticSize);
                FieldInfo state = BufferField(fields, "StateBuffer", target.Type.StaticSize);
                if (request.Offset != target.RequestOffset || state.Offset != target.StateOffset ||
                    request.Data != target.ByteType.Address || state.Data != target.ByteType.Address)
                    throw new IOException("Declarations des buffers modifiees.");
            }
        }

        private ControlSnapshot ReadState(Graph target, LiveMenuContext context)
        {
            byte[] first = Read(target.State.Data, ControlProtocol.StateSize);
            byte[] second = Read(target.State.Data, ControlProtocol.StateSize);
            ControlSnapshot result; string error;
            if (!ControlProtocol.SameCommittedRecord(first, second) ||
                !ControlProtocol.TryDecodeSnapshot(second, out result, out error))
                throw new IOException("Etat du module en publication ou CRC non confirme.");
            var observation = result.Observation;
            if (result.SessionId == Guid.Empty || observation.GameTimestampMs < 0 ||
                observation.GameTimestampMs > long.MaxValue - ControlProtocol.MaxRequestLifetimeMs ||
                result.LastRequestId > result.RequestHighWatermark || result.PendingRequestId > result.RequestHighWatermark ||
                (result.LastOperation != ControlOperation.None && !ControlProtocol.IsKnownOperation(result.LastOperation)) ||
                (observation.SupportedOperations & ~ControlProtocol.AllOperationsMask) != 0 ||
                (observation.OwnedOperations & ~ControlProtocol.AllOperationsMask) != 0 ||
                ((uint)observation.Flags & ~0x1FFU) != 0 ||
                !ControlProtocol.IsFinite(observation.PositionX) || !ControlProtocol.IsFinite(observation.PositionY) ||
                !ControlProtocol.IsFinite(observation.PositionZ) || !ControlProtocol.IsFinite(observation.Speed) ||
                !ControlProtocol.IsFinite(observation.Brightness) ||
                (observation.IsReady && (observation.ContextId == Guid.Empty || observation.PlayerId != context.LocalPlayerId)))
                throw new IOException("Identite ou valeurs de l'etat du module incoherentes.");
            return result;
        }

        private TypeInfo ReadType(ulong address)
        {
            byte[] prefix = Read(address, 0x60); byte kind = prefix[0x1B];
            if (kind != 1 && kind != 5) throw new IOException("Type Mono du module non pris en charge.");
            byte[] data = Read(address, kind == 1 ? 0x110 : 0x98);
            var result = new TypeInfo { Address = address, Kind = kind, Rank = data[0x1A],
                Image = BufferPointer(data, 0x40), NamePointer = BufferPointer(data, 0x48), NamespacePointer = BufferPointer(data, 0x50),
                Size = BitConverter.ToInt32(data, 0x1C), Token = BitConverter.ToUInt32(data, 0x58),
                Fields = kind == 1 ? BitConverter.ToUInt64(data, 0x98) : 0,
                Count = kind == 1 ? BitConverter.ToInt32(data, 0x100) : 0,
                Element = BitConverter.ToUInt64(data, 0), Stride = BitConverter.ToInt32(data, 0x90),
                StaticSize = kind == 1 ? BitConverter.ToInt32(data, 0x90) : 0,
                VtableSlots = BitConverter.ToInt32(data, 0x5C) };
            result.Name = CString(result.NamePointer); result.Namespace = CString(result.NamespacePointer);
            if (result.Size < 16 || result.Size > 65536) throw new IOException("Taille du type Mono invalide.");
            return result;
        }

        private static bool SameTypeHeader(TypeInfo type, byte[] data)
        {
            return data.Length >= (type.Kind == 1 ? 0x110 : 0x98) && data[0x1B] == type.Kind && data[0x1A] == type.Rank &&
                BitConverter.ToInt32(data, 0x1C) == type.Size && BitConverter.ToUInt64(data, 0x40) == type.Image &&
                BitConverter.ToUInt64(data, 0x48) == type.NamePointer && BitConverter.ToUInt64(data, 0x50) == type.NamespacePointer &&
                BitConverter.ToUInt32(data, 0x58) == type.Token && BitConverter.ToInt32(data, 0x90) == type.Stride &&
                BitConverter.ToInt32(data, 0x5C) == type.VtableSlots &&
                (type.Kind != 1 || (BitConverter.ToUInt64(data, 0x98) == type.Fields && BitConverter.ToInt32(data, 0x100) == type.Count)) &&
                (type.Kind != 5 || BitConverter.ToUInt64(data, 0) == type.Element);
        }

        private Dictionary<string, FieldInfo> ReadFields(TypeInfo type)
        {
            if (type.Kind != 1 || type.Count < 1 || type.Count > 64) throw new IOException("Nombre de champs du module hors limites.");
            byte[] fields = Read(type.Fields, type.Count * 32);
            var result = new Dictionary<string, FieldInfo>(StringComparer.Ordinal);
            for (int index = 0; index < type.Count; ++index)
            {
                int at = index * 32;
                if (BitConverter.ToUInt64(fields, at + 16) != type.Address) throw new IOException("Parent d'un champ Mono modifie.");
                string name = CString(BufferPointer(fields, at + 8));
                if (result.ContainsKey(name)) throw new IOException("Champ du module duplique.");
                byte[] data = Read(BufferPointer(fields, at), 16);
                result.Add(name, new FieldInfo { Offset = BitConverter.ToInt32(fields, at + 24),
                    Code = data[10], Flags = BitConverter.ToUInt16(data, 8), Data = BitConverter.ToUInt64(data, 0) });
            }
            return result;
        }

        private static FieldInfo BufferField(Dictionary<string, FieldInfo> fields, string name, int staticSize)
        {
            FieldInfo value;
            if (!fields.TryGetValue(name, out value) || value.Code != 0x1D || (value.Flags & 0x37) != 0x36 ||
                (value.Flags & 0x40) != 0 || value.Offset < 0 || value.Offset > staticSize - 8 || (value.Offset & 7) != 0)
                throw new IOException("Champ public static readonly byte[] incompatible : " + name);
            return value;
        }

        private ArrayInfo ReadArray(ulong address, TypeInfo element, ulong expectedDomain, int length)
        {
            byte[] data = Read(address, 0x20);
            ulong table = BufferPointer(data, 0); byte[] header = Read(table, 24);
            if (BitConverter.ToUInt64(header, 0x10) != expectedDomain) throw new IOException("Buffer dans un autre domaine Mono.");
            TypeInfo type = ReadType(BufferPointer(header, 0));
            if (type.Kind != 5 || type.Rank != 1 || type.Element != element.Address || type.Image != element.Image || type.Stride != 1 ||
                BitConverter.ToUInt64(data, 0x10) != 0 || BitConverter.ToUInt32(data, 0x18) != (uint)length || (address & 7UL) != 0)
                throw new IOException("Tableau de communication non conforme.");
            return new ArrayInfo { Address = address, Table = table, Type = type, Length = length };
        }

        private void ValidateArray(ArrayInfo array, TypeInfo element, ulong expectedDomain)
        {
            byte[] data = Read(array.Address, 0x20), table = Read(array.Table, 24);
            if (BitConverter.ToUInt64(data, 0) != array.Table || BitConverter.ToUInt64(data, 0x10) != 0 ||
                BitConverter.ToUInt32(data, 0x18) != (uint)array.Length || BitConverter.ToUInt64(table, 0) != array.Type.Address ||
                BitConverter.ToUInt64(table, 0x10) != expectedDomain || !SameTypeHeader(array.Type, Read(array.Type.Address, 0x98)) ||
                !SameTypeHeader(element, Read(element.Address, 0x110)))
                throw new IOException("Buffer, classe ou domaine modifie pendant la lecture.");
        }

        private static void ValidateCommand(ControlCommand command)
        {
            if (command == null || command.ExpectedSessionId == Guid.Empty || command.ExpectedContextId == Guid.Empty ||
                command.ExpectedPlayerId < 0 || !ControlProtocol.IsKnownOperation(command.Operation) ||
                !ControlProtocol.IsFinite(command.Value) || !ControlProtocol.IsFinite(command.PositionX) ||
                !ControlProtocol.IsFinite(command.PositionY) || !ControlProtocol.IsFinite(command.PositionZ) || command.TargetEntityId < -1)
                throw new IOException("Commande ou contexte utilisateur invalide.");
            ValidateIntentAge(command.RequestedTimestamp);
        }

        private static void ValidateIntentAge(long requestedTimestamp)
        {
            long now = Stopwatch.GetTimestamp();
            if (requestedTimestamp <= 0 || requestedTimestamp > now ||
                (now - requestedTimestamp) * 1000.0 / Stopwatch.Frequency >= ControlProtocol.DefaultRequestLifetimeMs)
                throw new IOException("La demande utilisateur a expire ou son horodatage est incoherent ; aucune nouvelle tentative automatique.");
        }

        private void Begin(CancellationToken cancellationToken, int milliseconds)
        { token = cancellationToken; token.ThrowIfCancellationRequested(); calls = bytes = 0; maximumMs = milliseconds; budget = Stopwatch.StartNew(); }
        private byte[] Read(ulong address, int count)
        {
            token.ThrowIfCancellationRequested(); RequirePointer(address);
            if (count < 1 || count > 65536 || address > 0x00007FFFFFFFFFFFUL - (uint)(count - 1) ||
                calls >= 1024 || bytes > 262144 - count || budget.ElapsedMilliseconds > maximumMs)
                throw new IOException("Budget de verification du module atteint ; nouvelle lecture ulterieure.");
            calls++; bytes += count; byte[] data = memory.Read(address, count);
            if (data == null || data.Length != count) throw new IOException("Lecture DMA du module incomplete.");
            if (budget.ElapsedMilliseconds > maximumMs) throw new IOException("Budget de verification du module atteint.");
            return data;
        }
        private string CString(ulong address)
        {
            var result = new List<byte>();
            for (uint offset = 0; offset < 256;)
            {
                int count = Math.Min(32, Math.Min(256 - (int)offset, 4096 - (int)((address + offset) & 4095UL)));
                foreach (byte value in Read(address + offset, count))
                { if (value == 0) return utf8.GetString(result.ToArray()); if (value < 0x20) throw new IOException("Nom Mono invalide."); result.Add(value); }
                offset += (uint)count;
            }
            throw new IOException("Nom Mono sans terminaison.");
        }
        private static long AgeMs(long from, long to) { return (long)((to - from) * 1000.0 / Stopwatch.Frequency); }
        private ulong U64(ulong address) { return BitConverter.ToUInt64(Read(address, 8), 0); }
        private ulong Pointer(ulong address) { ulong value = U64(address); RequirePointer(value); return value; }
        private static ulong BufferPointer(byte[] bytes, int offset) { ulong value = BitConverter.ToUInt64(bytes, offset); RequirePointer(value); return value; }
        private static void RequirePointer(ulong value) { if (value < 0x10000UL || value > 0x00007FFFFFFFFFFFUL) throw new IOException("Adresse utilisateur du module invalide."); }
        private static ulong ParseAddress(string value)
        { ulong result; string text = (value ?? "").StartsWith("0x", StringComparison.OrdinalIgnoreCase) ? value.Substring(2) : value; return ulong.TryParse(text, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out result) ? result : 0; }
        private static bool RangesOverlap(ulong a, int lengthA, ulong b, int lengthB) { return a < b + (uint)lengthB && b < a + (uint)lengthA; }
        private static bool AllZero(byte[] bytes) { foreach (byte value in bytes) if (value != 0) return false; return true; }
        private static bool SameBytes(byte[] a, byte[] b) { if (a == null || b == null || a.Length != b.Length) return false; for (int i = 0; i < a.Length; ++i) if (a[i] != b[i]) return false; return true; }
    }
}
