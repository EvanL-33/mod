using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using SevenDaysEsp;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class CreativeMenuExecutorTests
{
    private const string Version = "V 3.4.0 (b10)";

    public static Task EligibleCommandRunsOnceAndPreservesCorrelation()
    {
        var request = Request(true);
        var frame = Frame(request);
        int checkedProcess = 0, applied = 0;
        var result = CreativeMenuExecutor.Execute(request, 73, frame, 12, Version,
            () => { ++checkedProcess; return true; },
            () => { ++applied; return new() { Success = true, Code = "CONFIRME", Message = "Relu", ObservedEnabled = true, WriteAttempted = true }; });
        Check(checkedProcess == 1 && applied == 1, "Command was skipped or applied more than once.");
        Check(result.RequestId == request.RequestId && result.Sequence == request.Sequence &&
            result.ProcessId == request.ExpectedProcessId && result.PlayerContextId == request.ExpectedPlayerContextId &&
            result.DesiredEnabled == true && result.ObservedEnabled == true && result.WriteAttempted,
            "Result lost its exact command context or confirmed value.");
        Check(frame.PlayerContextId == request.ExpectedPlayerContextId && frame.Status == "ENTITES_LUES",
            "Command execution changed the published entity snapshot.");
        return Task.CompletedTask;
    }

    public static Task ExpiredFutureAndOtherProcessesNeverReachMemory()
    {
        var expired = Request(true);
        expired.RequestedTimestamp = Stopwatch.GetTimestamp() - 11 * Stopwatch.Frequency;
        AssertRejected(expired, Frame(expired), 73, 10, Version, "EXPIRE");
        var future = Request(true);
        future.RequestedTimestamp += 60 * Stopwatch.Frequency;
        AssertRejected(future, Frame(future), 73, 10, Version, "EXPIRE");
        var current = Request(false);
        AssertRejected(current, Frame(current), 74, 10, Version, "CONTEXTE_CHANGE");
        AssertRejected(current, Frame(current), 0, 10, Version, "CONTEXTE_CHANGE");
        return Task.CompletedTask;
    }

    public static Task VersionCaptureAgeAndWorldGateTheAction()
    {
        var request = Request(true);
        AssertRejected(request, Frame(request), 73, 10, "V 3.5.0 (b1)", "VERSION_NON_SUPPORTEE");
        foreach (double age in new[] { -1.0, double.NaN, double.PositiveInfinity, 2000.0, 9000.0 })
            AssertRejected(request, Frame(request), 73, age, Version, "CONTEXTE_CHANGE");
        var invalid = Frame(request); invalid.Status = "MONDE_ABSENT";
        AssertRejected(request, invalid, 73, 10, Version, "CONTEXTE_CHANGE");
        var changed = Frame(request); changed.PlayerContextId = Guid.NewGuid().ToString("N");
        AssertRejected(request, changed, 73, 10, Version, "CONTEXTE_CHANGE");
        return Task.CompletedTask;
    }

    public static Task AProcessLostDuringValidationCannotWrite()
    {
        var request = Request(true);
        foreach (bool throws in new[] { false, true })
        {
            int applied = 0;
            var result = CreativeMenuExecutor.Execute(request, 73, Frame(request), 10, Version,
                () => throws ? throw new IOException("PID indisponible") : false,
                () => { ++applied; throw new Exception("Must not execute"); });
            Check(applied == 0 && !result.WriteAttempted && result.ObservedEnabled == null,
                "Lost process reached the memory action.");
            Check(result.Code == (throws ? "PROCESSUS_NON_CONFIRME" : "CONTEXTE_CHANGE"), "Wrong process failure status.");
        }
        return Task.CompletedTask;
    }

    public static Task UncertainWriteIsNotRetriedOrShownAsConfirmed()
    {
        var request = Request(false);
        int applied = 0;
        var result = CreativeMenuExecutor.Execute(request, 73, Frame(request), 10, Version, () => true,
            () => { ++applied; return new() { Success = false, Code = "RESULTAT_INDETERMINE", Message = new string('x', 1700) + '\0', ObservedEnabled = true, WriteAttempted = true }; });
        Check(applied == 1 && result.WriteAttempted && result.ObservedEnabled == null,
            "Uncertain write was retried or published as a known value.");
        Check(result.Message.Length == CreativeMenuProtocol.MaxMessageLength &&
            CreativeMenuProtocol.IsValidResult(result), "Long core errors broke the IPC result contract.");
        return Task.CompletedTask;
    }

    public static Task RefreshRequestsReturnAnObservationWithoutWriteIntent()
    {
        var request = Request(null);
        var result = CreativeMenuExecutor.Execute(request, 73, Frame(request), 10, Version, () => true,
            () => new() { Success = true, Code = "ETAT_LU", Message = "Lu", ObservedEnabled = false });
        Check(result.DesiredEnabled == null && result.ObservedEnabled == false && !result.WriteAttempted &&
            CreativeMenuProtocol.IsValidResult(result), "Refresh became a memory-changing intent.");
        return Task.CompletedTask;
    }

    private static void AssertRejected(CreativeMenuRequest request, LiveEntitySnapshot frame,
        uint pid, double age, string version, string code)
    {
        int checks = 0, actions = 0;
        var result = CreativeMenuExecutor.Execute(request, pid, frame, age, version,
            () => { ++checks; return true; },
            () => { ++actions; throw new Exception("Unexpected action"); });
        Check(checks == 0 && actions == 0 && result.Code == code && !result.WriteAttempted && result.ObservedEnabled == null,
            "Refused command reached process/memory access: " + result.Code);
    }

    private static CreativeMenuRequest Request(bool? value) => new()
    {
        Sequence = 3, RequestId = Guid.NewGuid().ToString("N"), ExpectedProcessId = 73,
        ExpectedPlayerContextId = Guid.NewGuid().ToString("N"), DesiredEnabled = value,
        RequestedTimestamp = Stopwatch.GetTimestamp()
    };

    private static LiveEntitySnapshot Frame(CreativeMenuRequest request) => new()
    {
        Status = "ENTITES_LUES", PlayerContextId = request.ExpectedPlayerContextId,
        LocalId = 2, LocalPosition = new LivePosition()
    };

    private static void Check(bool value, string message)
    {
        if (!value) throw new InvalidOperationException(message);
    }
}
