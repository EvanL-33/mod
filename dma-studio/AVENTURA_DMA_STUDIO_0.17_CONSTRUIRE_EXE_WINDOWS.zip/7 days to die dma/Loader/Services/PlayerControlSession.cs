using System;
using System.Diagnostics;
using SevenDaysDmaControl;

namespace SevenDaysLoader.Services;

// Controls and ESP have independent state. A command result must never remove
// a rendered frame, restart the capture worker or manufacture a confirmation.
public sealed class PlayerControlSession
{
    private readonly object gate = new();
    private readonly Func<long> clock;
    private readonly Func<DateTime> utcNow;
    private int generation;
    private long nextSequence;
    private uint processId;
    private string playerContext = "";
    private FeedSample? feed;
    private bool connected;
    private long receivedAt;
    private double initialAge;
    private bool moduleFresh;
    private ulong modulePending;
    private ulong submittedId;
    private PlayerControlRequest? pending;
    private PlayerControlState state = new();
    private string lastAckKey = "", outcomeCode = "", outcomeMessage = "";

    public PlayerControlSession() : this(Stopwatch.GetTimestamp, () => DateTime.UtcNow) { }
    internal PlayerControlSession(Func<long> clock, Func<DateTime> utcNow)
    { this.clock = clock; this.utcNow = utcNow; }
    public PlayerControlState State { get { lock (gate) { Refresh(); return CopyState(); } } }

    private PlayerControlState CopyState()
    {
        if (state.Snapshot == null) return state;
        // Views may keep their copy while a new worker update arrives.
        var encoded = ControlProtocol.EncodeSnapshot(state.Snapshot, state.Snapshot.Sequence);
        ControlProtocol.TryDecodeSnapshot(encoded, out var snapshot, out _);
        return state with { Snapshot = snapshot };
    }

    public void Reset(int currentGeneration)
    {
        lock (gate)
        {
            generation = currentGeneration; processId = 0; playerContext = ""; connected = false;
            feed = null; pending = null; submittedId = modulePending = 0; moduleFresh = false;
            receivedAt = 0; state = new();
            lastAckKey = outcomeCode = outcomeMessage = "";
        }
    }

    public void ObserveContext(int expectedGeneration, uint pid, FeedSample? current, bool isConnected)
    {
        lock (gate)
        {
            if (generation != expectedGeneration) return;
            // Briefly rejected frames block new actions, but keep an in-flight
            // teleport correlation. A real new identity clears it immediately.
            string nextContext = current?.Snapshot.PlayerContextId ?? playerContext;
            bool changed = processId != pid || (current != null && nextContext != playerContext);
            processId = pid; playerContext = nextContext; feed = current; connected = isConnected;
            if (changed)
            {
                bool wasPending = pending != null;
                pending = null; submittedId = modulePending = 0; moduleFresh = false;
                lastAckKey = outcomeCode = outcomeMessage = "";
                state = new PlayerControlState { Code = "CONTEXTE_CHANGE", Message = wasPending
                    ? "La partie a changé. Le résultat précédent reste indéterminé ; aucune commande n’est rejouée."
                    : "Recherche du module dans la partie courante…" };
            }
            Refresh();
        }
    }

    public bool Observe(int expectedGeneration, PlayerControlObservation packet)
    {
        lock (gate)
        {
            if (generation != expectedGeneration || packet.ProcessId != processId || packet.PlayerContextId != playerContext)
                return false;
            long now = clock();
            if (!PlayerControlPolicy.TryReadSnapshot(packet, now, out var snapshot, out double age))
            {
                moduleFresh = false;
                state = state with { Available = false, Snapshot = null, ObservedUtc = null,
                    Code = packet.Code?.Length <= 80 ? packet.Code : "MODULE_NON_LU",
                    Message = packet.Message?.Length <= 1024 ? packet.Message : "État du module non validé." };
                Refresh(); return true;
            }
            bool contextChanged = (state.Snapshot != null && (state.Snapshot.SessionId != snapshot!.SessionId ||
                state.Snapshot.Observation.ContextId != snapshot.Observation.ContextId)) ||
                (pending != null && (pending.ExpectedModuleSessionId != snapshot!.SessionId ||
                    pending.ExpectedModuleContextId != snapshot.Observation.ContextId));
            if (contextChanged)
            {
                pending = null; submittedId = 0;
                lastAckKey = outcomeCode = outcomeMessage = "";
            }
            receivedAt = now; initialAge = age; moduleFresh = packet.Available && packet.Fresh;
            modulePending = packet.PendingRequestId;
            state = state with { Snapshot = snapshot, ObservedUtc = utcNow(), Code = packet.Code,
                Message = packet.Message, ProcessId = processId, PlayerContextId = playerContext };
            string ackKey = snapshot!.SessionId.ToString("N") + "|" + snapshot.LastRequestContextId.ToString("N") + "|" +
                snapshot.LastRequestId + "|" + snapshot.LastStatus + "|" + snapshot.LastMessage;
            bool newAck = ackKey != lastAckKey;
            lastAckKey = ackKey;
            bool currentAck = snapshot.LastRequestId != 0 && snapshot.LastRequestContextId != Guid.Empty &&
                snapshot.LastRequestContextId == snapshot.Observation.ContextId && snapshot.LastStatus != ControlStatus.None;
            if (pending != null && submittedId != 0 && snapshot!.LastRequestId == submittedId &&
                snapshot.LastOperation == pending.Operation && snapshot.SessionId == pending.ExpectedModuleSessionId &&
                currentAck && snapshot.Observation.ContextId == pending.ExpectedModuleContextId && snapshot.LastStatus != ControlStatus.Pending &&
                snapshot.LastStatus != ControlStatus.None)
            {
                outcomeCode = snapshot.LastStatus.ToString().ToUpperInvariant(); outcomeMessage = snapshot.LastMessage;
                state = state with { Code = outcomeCode, Message = outcomeMessage };
                pending = null; submittedId = 0;
            }
            else if (pending != null)
                state = state with { Code = "EN_ATTENTE", Message = submittedId == 0
                    ? "Transmission de la commande en cours…" : "Commande transmise ; transition du jeu en cours…" };
            else if (currentAck && newAck)
            {
                outcomeCode = snapshot.LastStatus.ToString().ToUpperInvariant(); outcomeMessage = snapshot.LastMessage;
                state = state with { Code = outcomeCode, Message = outcomeMessage };
            }
            else if (outcomeCode.Length != 0)
                state = state with { Code = outcomeCode, Message = outcomeMessage };
            else if (contextChanged)
                state = state with { Code = "CONTEXTE_CHANGE", Message = "Le personnage a changé. Les anciennes demandes sont abandonnées, sans rejeu." };
            Refresh(); return true;
        }
    }

    public PlayerControlRequest Begin(int expectedGeneration, ControlOperation operation, bool enabled = false,
        float value = 0, float x = 0, float y = 0, float z = 0)
    {
        lock (gate)
        {
            Refresh();
            if (expectedGeneration != generation || !state.Supports(operation) || state.Snapshot == null)
                throw new InvalidOperationException(state.IsBusy ? "Une transition du personnage est déjà en cours."
                    : "Une partie récente et le module du jeu prêt sont nécessaires.");
            if (nextSequence == long.MaxValue) throw new InvalidOperationException("Redémarre le loader pour réinitialiser ses séquences.");
            var snapshot = state.Snapshot;
            var request = new PlayerControlRequest
            {
                Sequence = ++nextSequence, RequestId = Guid.NewGuid().ToString("N"), ExpectedProcessId = processId,
                ExpectedPlayerContextId = playerContext, ExpectedModuleSessionId = snapshot.SessionId,
                ExpectedModuleContextId = snapshot.Observation.ContextId, ExpectedPlayerId = snapshot.Observation.PlayerId,
                Operation = operation, Enabled = enabled, Value = value, PositionX = x, PositionY = y, PositionZ = z,
                RequestedTimestamp = clock()
            };
            PlayerControlPolicy.ValidateRequest(request);
            pending = request; submittedId = 0;
            outcomeCode = outcomeMessage = "";
            state = state with { IsBusy = true, Code = "EN_ATTENTE", Message = "Transmission de la commande en cours…" };
            return request.Copy();
        }
    }

    public bool AcceptSubmission(int expectedGeneration, PlayerControlSubmission result)
    {
        lock (gate)
        {
            if (generation != expectedGeneration || pending == null || result.Sequence != pending.Sequence ||
                result.RequestId != pending.RequestId || result.ProcessId != pending.ExpectedProcessId ||
                result.PlayerContextId != pending.ExpectedPlayerContextId || result.Code == null || result.Code.Length > 80 ||
                result.Message == null || result.Message.Length > 1024 ||
                (result.Accepted && (result.ModuleRequestId == 0 || !result.CommitAttempted || !result.WriteAttempted))) return false;
            state = state with { Code = result.Code, Message = result.Message };
            if (result.Accepted) submittedId = result.ModuleRequestId;
            else
            {
                pending = null; submittedId = 0;
                outcomeCode = result.Code; outcomeMessage = result.Message;
            }
            Refresh(); return true;
        }
    }

    public bool FailSend(int expectedGeneration, PlayerControlRequest request, string detail)
        => AcceptSubmission(expectedGeneration, new PlayerControlSubmission
        {
            Sequence = request.Sequence, RequestId = request.RequestId, ProcessId = request.ExpectedProcessId,
            PlayerContextId = request.ExpectedPlayerContextId, Code = "ENVOI_NON_CONFIRME",
            Message = detail.Length <= 1024 ? detail : detail[..1024]
        });

    private void Refresh()
    {
        long now = clock();
        if (pending != null && (now < pending.RequestedTimestamp ||
            Stopwatch.GetElapsedTime(pending.RequestedTimestamp, now).TotalMilliseconds >= PlayerControlPolicy.ResultLifetimeMs))
        {
            pending = null; submittedId = 0;
            outcomeCode = "DELAI_DEPASSE"; outcomeMessage = "Résultat non confirmé. Aucune relance automatique ; l’état courant est relu.";
            state = state with { Code = outcomeCode, Message = outcomeMessage };
        }
        bool fresh = moduleFresh && receivedAt > 0 && now >= receivedAt &&
            initialAge + Stopwatch.GetElapsedTime(receivedAt, now).TotalMilliseconds < PlayerControlPolicy.StateLifetimeMs;
        bool ready = connected && processId > 0 && feed?.IsFresh == true && fresh &&
            state.Snapshot?.Observation.IsReady == true &&
            state.Snapshot.Observation.PlayerId == feed.Snapshot.LocalId;
        state = state with { Available = ready, IsBusy = pending != null || (fresh && modulePending != 0),
            ProcessId = processId, PlayerContextId = playerContext };
    }
}
