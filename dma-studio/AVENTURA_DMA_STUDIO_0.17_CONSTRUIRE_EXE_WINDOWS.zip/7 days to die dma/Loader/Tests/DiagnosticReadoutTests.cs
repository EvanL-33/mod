using System;
using System.Threading.Tasks;
using SevenDaysLoader.UI;

internal static class DiagnosticReadoutTests
{
    public static Task AutomaticUpdatesAreRateLimited()
    {
        var state = new DiagnosticReadoutState();
        Check(state.ShouldPublish(0, false, true), "The first diagnostic stayed blank just because the pointer was over its empty field.");
        for (long time = 100; time < 1000; time += 100)
            Check(!state.ShouldPublish(time, false, false), "The diagnostic was rewritten at the acquisition cadence.");
        Check(state.ShouldPublish(1000, false, false), "The next automatic readout was never published.");
        Check(!state.ShouldPublish(1999, false, false), "The update deadline drifted early.");
        Check(state.ShouldPublish(2000, false, false), "The second full interval was missed.");
        return Task.CompletedTask;
    }

    public static Task PauseAndSelectionPreserveTheReadout()
    {
        var state = new DiagnosticReadoutState();
        Check(state.ShouldPublish(0, false, false), "Missing initial readout.");
        Check(!state.ShouldPublish(4000, true, false), "Figer did not freeze the readout.");
        Check(!state.ShouldPublish(5000, false, true), "A selection or reading interaction was overwritten.");
        Check(state.ShouldPublish(6000, true, true, force: true), "Explicit refresh could not update a frozen view once.");
        Check(!state.ShouldPublish(9000, true, false), "One manual refresh silently resumed automatic updates.");
        Check(state.ShouldPublish(9001, false, false), "Automatic updates did not resume after unfreezing.");
        const string lastActive = "ESP actif · 6 repères dans la vue";
        Check(DiagnosticReadoutState.ProjectionAtReadout(lastActive, false) != lastActive,
            "A diagnostic could freeze the preceding tick's active claim after its camera expired.");
        Check(DiagnosticReadoutState.ProjectionAtReadout(lastActive, true) == lastActive,
            "A fresh camera lost its current display status.");
        const string disabled = "ESP désactivé dans les réglages.";
        Check(DiagnosticReadoutState.ProjectionAtReadout(disabled, false) == disabled,
            "The freshness guard erased an explicit display setting.");
        return Task.CompletedTask;
    }

    public static Task LastSourceSurvivesIntermittenceOnlyWithinItsSession()
    {
        var state = new DiagnosticReadoutState();
        state.ObserveSource("first-report", 42, 1920, 1080);
        Check(state.HasSource && state.LastSourceWidth == 1920 && state.LastSourceHeight == 1080, "Source dimensions were lost.");
        state.ObserveSource("first-report", 42, null, null);
        state.ObserveSource("first-report", 42, -1, 100000);
        Check(state.LastSourceWidth == 1920 && state.LastSourceHeight == 1080, "A missing or invalid current camera made the historical resolution oscillate.");
        state.ObserveSource("second-report", 42, null, null);
        Check(!state.HasSource, "A new connection inherited the previous source resolution.");
        state.ObserveSource("second-report", 42, 2560, 1440);
        state.ObserveSource("second-report", 43, null, null);
        Check(!state.HasSource, "A new process inherited the old camera resolution.");
        return Task.CompletedTask;
    }

    public static Task ClockRollbackAndManualRefreshDoNotStallUpdates()
    {
        var state = new DiagnosticReadoutState();
        Check(state.ShouldPublish(5000, false, false), "Missing initial readout.");
        Check(state.ShouldPublish(5100, false, false, force: true), "Manual refresh was rate limited.");
        Check(!state.ShouldPublish(6000, false, false), "An explicit refresh did not reset the next automatic deadline.");
        Check(state.ShouldPublish(50, false, false), "Clock rollback stalled diagnostics indefinitely.");
        Check(!state.ShouldPublish(1049, false, false), "Deadline after rollback was not reset.");
        Check(state.ShouldPublish(1050, false, false), "No update after the rollback interval.");
        return Task.CompletedTask;
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
