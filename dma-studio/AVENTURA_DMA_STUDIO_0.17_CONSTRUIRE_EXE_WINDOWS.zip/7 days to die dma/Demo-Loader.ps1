﻿#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)

Write-Output '[TEST LOCAL] Test du lanceur uniquement : aucune connexion DMA.'
Write-Output '[TEST LOCAL] Aucun processus de jeu ou contenu de memoire ne sera lu.'
Write-Output ('[TEST LOCAL] PowerShell {0} ; processus {1} bits.' -f $PSVersionTable.PSVersion, ([IntPtr]::Size * 8))
Write-Output '[TEST LOCAL] Demarrage et capture de la sortie standard : OK.'
Start-Sleep -Milliseconds 700
[Console]::Error.WriteLine('[TEST LOCAL] Message de test volontaire sur stderr : ce message ne signale pas une panne.')
Start-Sleep -Milliseconds 700
Write-Output '[TEST LOCAL] Tu peux cliquer sur Arreter pendant ce test pour essayer la gestion du processus.'
Start-Sleep -Milliseconds 1800
Write-Output '[TEST LOCAL] Fin normale du programme de test ; code de sortie attendu : 0.'
Write-Output '[TEST LOCAL] Ce resultat ne valide ni le materiel DMA ni un ESP.'
exit 0
