using System;
using System.IO;
using System.Text.Json.Serialization;

namespace SevenDaysLoader;

// A preset is intentionally narrower than LoaderSettings: connections, output
// calibration/placement, networking and keyboard bindings never enter it.
public sealed class EspPresetOptions
{
    [JsonRequired] public bool EspEnabled { get; set; } = true;
    [JsonRequired] public bool ShowProjectedEsp { get; set; } = true;
    [JsonRequired] public bool ShowRadar { get; set; } = true;
    [JsonRequired] public bool ShowHud { get; set; } = true;
    [JsonRequired] public int RadarSize { get; set; } = 300;
    [JsonRequired] public double RadarOpacity { get; set; } = 0.88;
    // Optional fields preserve imports of presets saved before 0.12.
    public bool RadarIndependentRange { get; set; }
    public int RadarRangeMeters { get; set; } = 300;
    public bool ShowRadarCounts { get; set; }
    [JsonRequired] public EntityEspSettings PlayerEsp { get; set; } = new();
    [JsonRequired] public EntityEspSettings ZombieEsp { get; set; } = new() { Color = "#FF9A52" };

    public static EspPresetOptions Capture(LoaderSettings settings)
    {
        ArgumentNullException.ThrowIfNull(settings);
        var value = new EspPresetOptions
        {
            EspEnabled = settings.EspEnabled, ShowProjectedEsp = settings.ShowProjectedEsp,
            ShowRadar = settings.ShowRadar, ShowHud = settings.ShowHud,
            RadarSize = settings.RadarSize, RadarOpacity = settings.RadarOpacity,
            RadarIndependentRange = settings.RadarIndependentRange, RadarRangeMeters = settings.RadarRangeMeters,
            ShowRadarCounts = settings.ShowRadarCounts,
            PlayerEsp = settings.PlayerEsp?.Copy()!, ZombieEsp = settings.ZombieEsp?.Copy()!
        };
        value.Validate();
        return value;
    }

    public EspPresetOptions Copy()
    {
        Validate();
        return new EspPresetOptions
        {
            EspEnabled = EspEnabled, ShowProjectedEsp = ShowProjectedEsp,
            ShowRadar = ShowRadar, ShowHud = ShowHud,
            RadarSize = RadarSize, RadarOpacity = RadarOpacity,
            RadarIndependentRange = RadarIndependentRange, RadarRangeMeters = RadarRangeMeters,
            ShowRadarCounts = ShowRadarCounts,
            PlayerEsp = PlayerEsp.Copy(), ZombieEsp = ZombieEsp.Copy()
        };
    }

    public void ApplyTo(LoaderSettings settings)
    {
        ArgumentNullException.ThrowIfNull(settings);
        // Validate and prepare both copies before touching the live settings.
        var copy = Copy();
        settings.EspEnabled = copy.EspEnabled;
        settings.ShowProjectedEsp = copy.ShowProjectedEsp;
        settings.ShowRadar = copy.ShowRadar;
        settings.ShowHud = copy.ShowHud;
        settings.RadarSize = copy.RadarSize;
        settings.RadarOpacity = copy.RadarOpacity;
        settings.RadarIndependentRange = copy.RadarIndependentRange;
        settings.RadarRangeMeters = copy.RadarRangeMeters;
        settings.ShowRadarCounts = copy.ShowRadarCounts;
        settings.PlayerEsp = copy.PlayerEsp;
        settings.ZombieEsp = copy.ZombieEsp;
        settings.EspProfilesVersion = 1;
    }

    public void Validate()
    {
        if (RadarSize is < 180 or > 520 || !double.IsFinite(RadarOpacity) || RadarOpacity is < 0.25 or > 1)
            throw new InvalidDataException("La taille ou l’opacité du radar est hors limites.");
        if (RadarRangeMeters is < 25 or > 5000)
            throw new InvalidDataException("La portée indépendante du radar est hors limites.");
        ValidateProfile(PlayerEsp, "Joueurs");
        ValidateProfile(ZombieEsp, "Zombies");
    }

    private static void ValidateProfile(EntityEspSettings? profile, string name)
    {
        if (profile == null) throw new InvalidDataException("Le profil " + name + " est absent.");
        if (profile.MaxDistance is < 25 or > 5000 || !double.IsFinite(profile.FontSize) ||
            profile.FontSize is < 10 or > 20 || !double.IsFinite(profile.LineThickness) ||
            profile.LineThickness is < 1 or > 4)
            throw new InvalidDataException("Le profil " + name + " contient une portée, une taille ou une épaisseur hors limites.");
        if (profile.BoxStyle != "full" && profile.BoxStyle != "corners")
            throw new InvalidDataException("Le style de cadre du profil " + name + " n’est pas reconnu.");
        if (!ValidColor(profile.Color))
            throw new InvalidDataException("La couleur du profil " + name + " doit suivre le format #RRGGBB.");
        if (profile.Rules == null)
            throw new InvalidDataException("Les règles d’affichage du profil " + name + " sont absentes.");
        if (!profile.Rules.IsValid(out string reason))
            throw new InvalidDataException("Règles d’affichage du profil " + name + " : " + reason);
    }

    private static bool ValidColor(string? value)
    {
        if (value == null || value.Length != 7 || value[0] != '#') return false;
        for (int i = 1; i < value.Length; i++)
        {
            char c = value[i];
            if (!(c is >= '0' and <= '9' or >= 'a' and <= 'f' or >= 'A' and <= 'F')) return false;
        }
        return true;
    }
}

public sealed class EspPreset
{
    [JsonRequired] public string Id { get; set; } = Guid.NewGuid().ToString("N");
    [JsonRequired] public string Name { get; set; } = "";
    [JsonRequired] public EspPresetOptions Options { get; set; } = new();

    public EspPreset Copy() => new() { Id = Id, Name = Name, Options = Options.Copy() };
}
