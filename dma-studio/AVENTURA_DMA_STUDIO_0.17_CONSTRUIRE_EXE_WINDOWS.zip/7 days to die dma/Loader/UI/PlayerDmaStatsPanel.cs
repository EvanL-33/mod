using System;
using System.Globalization;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace SevenDaysLoader.UI;

// DMA-only experimental scalars: no game-client module, no server plugin.
internal sealed class PlayerDmaStatsPanel : StackPanel
{
    private readonly ILoaderController controller;
    private readonly ComboBox target;
    private readonly TextBox value;
    private readonly Button read, apply;
    private readonly TextBlock status, observation;
    private string? error;

    public PlayerDmaStatsPanel(ILoaderController controller)
    {
        this.controller = controller;
        Orientation = Orientation.Vertical;
        Children.Add(Theme.Eyebrow("STATISTIQUES LOCALES — DMA SEULE"));
        Children.Add(Theme.Text("Cette fonction lit/modifie la mémoire du PERSONNAGE LOCAL. Le serveur peut ignorer ou rétablir la valeur. Aucune écriture n'est persistée ou rejouée au redémarrage.", 11, Theme.Muted));
        target = new ComboBox
        {
            ItemsSource = new[] { "Vie (Health)", "Endurance (Stamina)", "Nourriture (Food)",
                "Hydratation (Water)", "Points de compétence (SkillPoints)", "Niveau (lecture seule)" },
            SelectedIndex = 0, Margin = new Thickness(0, 12, 0, 8), MinHeight = 32
        };
        Children.Add(target);
        status = Theme.Text("Aucune statistique lue.", 11, Theme.Muted);
        Children.Add(status);
        observation = Theme.Text("", 11, Theme.Muted);
        Children.Add(observation);
        Children.Add(Theme.Label("Valeur demandée"));
        value = new TextBox { Text = "100", MinHeight = 32, MaxLength = 16,
            Margin = new Thickness(0, 3, 0, 12) };
        Children.Add(value);
        read = new Button { Content = "Lire uniquement", Margin = new Thickness(0, 0, 0, 7) };
        apply = new Button { Content = "Appliquer une fois via DMA", Margin = new Thickness(0, 0, 0, 12) };
        read.Click += async (_, _) => await RequestAsync(null);
        apply.Click += async (_, _) =>
        {
            if (!float.TryParse(value.Text, NumberStyles.Float, CultureInfo.GetCultureInfo("fr-FR"), out float entered) &&
                !float.TryParse(value.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out entered))
            { error = "Saisis un nombre valide."; Refresh(); return; }
            await RequestAsync(entered);
        };
        Children.Add(read); Children.Add(apply);
        target.SelectionChanged += (_, _) => { error = null; Refresh(); };
        Children.Add(Theme.Text("EXP / niveaux / multiplicateurs de dégâts : non modifiés par cette option. Leur effet n'est pas validé par lecture DMA côté client et ne doit pas être simulé dans l'interface.", 10.5, Theme.Muted));
        Refresh();
    }

    private PlayerDmaStatKind SelectedKind => (PlayerDmaStatKind)Math.Clamp(target.SelectedIndex + 1, 1, 6);

    private async Task RequestAsync(float? desired)
    {
        error = null;
        try { await controller.RequestDmaStatAsync(SelectedKind, desired); }
        catch (Exception e)
        {
            error = e.GetBaseException().Message;
            controller.Log("[STATS_DMA] " + error);
        }
        Refresh();
    }

    internal void Refresh()
    {
        bool connected = controller.Status.IsReader && controller.Status.IsConnected &&
            controller.Status.HasDmaSession && controller.CurrentFrame?.IsFresh == true;
        bool busy = controller.IsDmaStatBusy;
        read.IsEnabled = connected && !busy;
        apply.IsEnabled = connected && !busy && SelectedKind != PlayerDmaStatKind.Level;
        status.Text = error ?? (busy ? "Opération DMA en cours…" : connected
            ? "Personnage détecté. Lecture possible." : "En attente de la DMA et du personnage local.");
        var r = controller.LastDmaStatResult;
        if (r != null && r.Stat == SelectedKind)
        {
            observation.Text = r.Code + " — " + r.Message + (r.ObservedValue.HasValue
                ? "\nValeur client : " + r.ObservedValue.Value.ToString("0.##", CultureInfo.CurrentCulture) +
                  (r.ObservedMaximum.HasValue ? " / " + r.ObservedMaximum.Value.ToString("0.##", CultureInfo.CurrentCulture) : "")
                : "\nValeur non confirmée.");
        }
        else observation.Text = "Aucune lecture confirmée pour cette statistique.";
    }
}
