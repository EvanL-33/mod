using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using SevenDaysEsp;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class EspProfileTests
{
    public static Task LegacyFileMigratesWithoutChangingVisibilityOrOutput()
    {
        using var fixture = new SettingsFixture();
        const string legacy = """
        {
          "SchemaVersion": 2,
          "AutoConnectDma": false,
          "SdkDirectory": "C:\\custom dma\\MemProcFS",
          "ReadCadenceVersion": 1,
          "IntervalMs": 75,
          "EspEnabled": false,
          "ShowProjectedEsp": false,
          "ShowPlayers": false,
          "ShowZombies": true,
          "ShowNames": false,
          "ShowHealth": false,
          "ShowDistances": false,
          "PlayerColor": "#1a2b3c",
          "ZombieColor": "#c4d5e6",
          "MaxDistance": 475,
          "ShowRadar": false,
          "ShowHud": false,
          "RadarSize": 420,
          "RadarOpacity": 0.65,
          "OutputMode": "fuser",
          "FuserDeviceName": "\\\\.\\DISPLAY3",
          "FuserKeyColor": "#ff00ff",
          "MonitorIndex": 2,
          "EspScaleMode": "fill",
          "OverlayAnchor": "BottomLeft",
          "MenuKey": "Home",
          "ToggleKey": "F8"
        }
        """;
        File.WriteAllText(fixture.Store.FilePath, legacy, new UTF8Encoding(false));
        var migrated = fixture.Store.Load();
        Check(fixture.Store.LoadWarning == null, "The legacy file was discarded instead of migrated.");
        Check(migrated.EspProfilesVersion == 1, "The independent-profile migration was not marked complete.");
        Check(!ReferenceEquals(migrated.PlayerEsp, migrated.ZombieEsp), "Migration created one shared profile for two categories.");
        Check(!migrated.EspEnabled && !migrated.ShowProjectedEsp && !migrated.PlayerEsp.Enabled && migrated.ZombieEsp.Enabled,
            "Migration re-enabled an explicitly hidden display or category.");
        foreach (var profile in new[] { migrated.PlayerEsp, migrated.ZombieEsp })
        {
            Check(!profile.ShowNames && !profile.ShowHealth && !profile.ShowDistances,
                "Migration lost an explicit names, health or distances preference.");
            Check(profile.MaxDistance == 475 && profile.ShowBoxes && !profile.ShowTracers,
                "Migration changed the old range or unexpectedly enabled a new drawing feature.");
        }
        Check(migrated.PlayerEsp.Color == "#1A2B3C" && migrated.ZombieEsp.Color == "#C4D5E6",
            "Migration swapped or lost the category colors.");
        CheckUnrelatedLegacyChoices(migrated);
        Check(File.ReadAllText(fixture.Store.FilePath) == legacy, "Loading silently rewrote the original legacy file.");

        fixture.Store.Save(migrated);
        var reloaded = fixture.Store.Load();
        Check(reloaded.EspProfilesVersion == 1 && !reloaded.PlayerEsp.Enabled && reloaded.ZombieEsp.Enabled &&
            !reloaded.EspEnabled && !reloaded.ShowProjectedEsp, "The migration marker or hidden preferences did not survive saving.");
        Check(ProfileState(reloaded.PlayerEsp) == ProfileState(migrated.PlayerEsp) &&
            ProfileState(reloaded.ZombieEsp) == ProfileState(migrated.ZombieEsp), "A migrated profile changed on reload.");
        CheckUnrelatedLegacyChoices(reloaded);
        using var json = JsonDocument.Parse(File.ReadAllText(fixture.Store.FilePath));
        Check(json.RootElement.TryGetProperty("PlayerEsp", out _) && json.RootElement.TryGetProperty("ZombieEsp", out _),
            "The saved settings did not contain both independently editable profiles.");
        return Task.CompletedTask;
    }

    public static Task ProfileRoundtripsKeepCategoriesIndependent()
    {
        using var fixture = new SettingsFixture();
        var settings = NewSettings();
        settings.PlayerEsp = new EntityEspSettings
        {
            Enabled = true, ShowBoxes = true, ShowNames = false, ShowHealth = true,
            ShowDistances = false, ShowTracers = true, Color = "#F881AA", BoxStyle = "corners",
            MaxDistance = 150, FontSize = 10.5, LineThickness = 1.75
        };
        settings.ZombieEsp = new EntityEspSettings
        {
            Enabled = false, ShowBoxes = false, ShowNames = true, ShowHealth = false,
            ShowDistances = true, ShowTracers = false, Color = "#9BF0A3", BoxStyle = "full",
            MaxDistance = 675, FontSize = 17.5, LineThickness = 3.25
        };
        string playerBefore = ProfileState(settings.PlayerEsp);
        string zombieBefore = ProfileState(settings.ZombieEsp);
        fixture.Store.Save(settings);
        var first = fixture.Store.Load();
        Check(ProfileState(first.PlayerEsp) == playerBefore && ProfileState(first.ZombieEsp) == zombieBefore,
            "A complete profile did not survive a real settings-file roundtrip.");
        Check(!ReferenceEquals(first.PlayerEsp, first.ZombieEsp), "Reloaded category profiles share one object.");

        first.ZombieEsp.Enabled = true;
        first.ZombieEsp.ShowBoxes = true;
        first.ZombieEsp.ShowNames = false;
        first.ZombieEsp.ShowHealth = true;
        first.ZombieEsp.ShowDistances = false;
        first.ZombieEsp.ShowTracers = true;
        first.ZombieEsp.Color = "#FFE27A";
        first.ZombieEsp.BoxStyle = "corners";
        first.ZombieEsp.MaxDistance = 925;
        first.ZombieEsp.FontSize = 19;
        first.ZombieEsp.LineThickness = 2.5;
        string editedZombie = ProfileState(first.ZombieEsp);
        Check(ProfileState(first.PlayerEsp) == playerBefore, "Editing zombies changed the live player preferences.");
        fixture.Store.Save(first);
        var second = fixture.Store.Load();
        Check(ProfileState(second.PlayerEsp) == playerBefore && ProfileState(second.ZombieEsp) == editedZombie,
            "Saving a zombie-only edit changed players or lost the zombie edit.");

        second.PlayerEsp.Enabled = false;
        second.PlayerEsp.MaxDistance = 75;
        second.PlayerEsp.ShowHealth = false;
        fixture.Store.Save(second);
        var third = fixture.Store.Load();
        Check(!third.PlayerEsp.Enabled && third.PlayerEsp.MaxDistance == 75 && !third.PlayerEsp.ShowHealth &&
            ProfileState(third.ZombieEsp) == editedZombie, "The reverse player-only edit leaked into zombies.");
        return Task.CompletedTask;
    }

    public static Task MigrationRunsOnceAndIgnoresStaleLegacyFields()
    {
        using var fixture = new SettingsFixture();
        File.WriteAllText(fixture.Store.FilePath,
            "{\"EspProfilesVersion\":0,\"ShowPlayers\":true,\"ShowZombies\":false,\"ShowNames\":false,\"ShowHealth\":false,\"MaxDistance\":215}");
        var settings = fixture.Store.Load();
        Check(settings.EspProfilesVersion == 1 && !settings.ZombieEsp.Enabled && settings.PlayerEsp.MaxDistance == 215,
            "The explicit version-zero settings did not migrate.");
        settings.PlayerEsp.Enabled = false;
        settings.PlayerEsp.ShowNames = true;
        settings.PlayerEsp.ShowHealth = true;
        settings.PlayerEsp.ShowDistances = false;
        settings.PlayerEsp.ShowTracers = true;
        settings.PlayerEsp.Color = "#112233";
        settings.PlayerEsp.BoxStyle = "corners";
        settings.PlayerEsp.MaxDistance = 650;
        settings.PlayerEsp.FontSize = 14.5;
        settings.PlayerEsp.LineThickness = 2.25;
        settings.ZombieEsp.Enabled = true;
        settings.ZombieEsp.ShowHealth = false;
        settings.ZombieEsp.Color = "#445566";
        settings.ZombieEsp.MaxDistance = 90;
        string player = ProfileState(settings.PlayerEsp), zombie = ProfileState(settings.ZombieEsp);

        // Stale compatibility fields must never overwrite edits to migrated profiles.
        settings.ShowPlayers = true; settings.ShowZombies = false;
        settings.ShowNames = false; settings.ShowHealth = false; settings.ShowDistances = true;
        settings.PlayerColor = "#ABCDEF"; settings.ZombieColor = "#FEDCBA";
        settings.MaxDistance = 5000;
        for (int pass = 0; pass < 3; pass++)
        {
            SettingsStore.Normalize(settings);
            Check(ProfileState(settings.PlayerEsp) == player && ProfileState(settings.ZombieEsp) == zombie,
                "Repeated normalization reapplied legacy preferences after migration.");
            fixture.Store.Save(settings);
            settings = fixture.Store.Load();
            Check(settings.EspProfilesVersion == 1 && ProfileState(settings.PlayerEsp) == player && ProfileState(settings.ZombieEsp) == zombie,
                "A saved version-one profile was migrated again on reload.");
        }
        return Task.CompletedTask;
    }

    public static Task NullAndSharedProfilesRecoverWithoutCoupling()
    {
        using var fixture = new SettingsFixture();
        File.WriteAllText(fixture.Store.FilePath,
            "{\"EspProfilesVersion\":1,\"EspEnabled\":false,\"PlayerEsp\":null,\"ZombieEsp\":null}");
        var restored = fixture.Store.Load();
        Check(fixture.Store.LoadWarning == null && !restored.EspEnabled && restored.PlayerEsp != null && restored.ZombieEsp != null,
            "Null profiles caused full settings loss or activated the master display.");
        Check(!ReferenceEquals(restored.PlayerEsp, restored.ZombieEsp) && restored.PlayerEsp.Color == "#66DEF2" &&
            restored.ZombieEsp.Color == "#FF9A52", "Missing categories did not recover independent category defaults.");
        fixture.Store.Save(restored);
        Check(!fixture.Store.Load().EspEnabled, "Saving recovered profiles changed the master display choice.");

        var shared = new EntityEspSettings
        {
            Enabled = false, Color = null!, BoxStyle = "corners", MaxDistance = 725,
            ShowHealth = false, FontSize = 16, LineThickness = 2.75
        };
        var settings = NewSettings();
        settings.PlayerEsp = shared; settings.ZombieEsp = shared;
        SettingsStore.Normalize(settings);
        Check(!ReferenceEquals(settings.PlayerEsp, settings.ZombieEsp), "Shared input profiles were not separated.");
        Check(settings.PlayerEsp.Color == "#66DEF2" && settings.ZombieEsp.Color == "#FF9A52" &&
            !settings.PlayerEsp.Enabled && !settings.ZombieEsp.Enabled && settings.ZombieEsp.MaxDistance == 725,
            "Separating a shared profile lost its options or used the other category's fallback color.");
        string player = ProfileState(settings.PlayerEsp);
        settings.ZombieEsp.Enabled = true;
        settings.ZombieEsp.Color = "#FFFFFF";
        settings.ZombieEsp.MaxDistance = 50;
        Check(ProfileState(settings.PlayerEsp) == player, "A formerly aliased zombie profile still changes players.");

        var snapshot = settings.PlayerEsp.Copy();
        snapshot.Color = "#000000"; snapshot.Enabled = true; snapshot.FontSize = 20;
        Check(ProfileState(settings.PlayerEsp) == player && !ReferenceEquals(snapshot, settings.PlayerEsp),
            "A profile snapshot retained mutable ownership of the live preferences.");
        return Task.CompletedTask;
    }

    public static Task InvalidValuesAreNormalizedBeforePersistence()
    {
        using var fixture = new SettingsFixture();
        var settings = NewSettings();
        settings.PlayerEsp.Enabled = false;
        settings.PlayerEsp.Color = "red";
        settings.PlayerEsp.BoxStyle = "invalid";
        settings.PlayerEsp.MaxDistance = int.MinValue;
        settings.PlayerEsp.FontSize = double.NaN;
        settings.PlayerEsp.LineThickness = double.NegativeInfinity;
        settings.ZombieEsp.Color = "#12345G";
        settings.ZombieEsp.BoxStyle = null!;
        settings.ZombieEsp.MaxDistance = int.MaxValue;
        settings.ZombieEsp.FontSize = double.PositiveInfinity;
        settings.ZombieEsp.LineThickness = double.NaN;
        fixture.Store.Save(settings); // JSON cannot serialize the original non-finite inputs.
        var saved = fixture.Store.Load();
        Check(fixture.Store.LoadWarning == null && !saved.PlayerEsp.Enabled && saved.EspProfilesVersion == 1,
            "Invalid profile numbers caused fallback to an unrelated settings object.");
        Check(saved.PlayerEsp.MaxDistance == 25 && saved.ZombieEsp.MaxDistance == 5000,
            "Out-of-range category distances were not bounded independently.");
        Check(saved.PlayerEsp.Color == "#66DEF2" && saved.ZombieEsp.Color == "#FF9A52" &&
            saved.PlayerEsp.BoxStyle == "full" && saved.ZombieEsp.BoxStyle == "full", "Invalid drawing styles were persisted.");
        foreach (var profile in new[] { saved.PlayerEsp, saved.ZombieEsp })
            Check(profile.FontSize == 12 && profile.LineThickness == 1.5,
                "Non-finite text or line size did not recover a usable default.");

        saved.PlayerEsp.FontSize = 1; saved.PlayerEsp.LineThickness = -5;
        saved.ZombieEsp.FontSize = 100; saved.ZombieEsp.LineThickness = 50;
        saved.PlayerEsp.Color = "#aBcDeF"; saved.ZombieEsp.BoxStyle = "corners";
        fixture.Store.Save(saved); saved = fixture.Store.Load();
        Check(saved.PlayerEsp.FontSize == 10 && saved.PlayerEsp.LineThickness == 1 &&
            saved.ZombieEsp.FontSize == 20 && saved.ZombieEsp.LineThickness == 4,
            "Finite values beyond the drawing limits were not clamped at the supported edges.");
        Check(saved.PlayerEsp.Color == "#ABCDEF" && saved.ZombieEsp.BoxStyle == "corners",
            "A valid hexadecimal color or corner-box preference was lost.");
        foreach (double invalid in new[] { double.NaN, double.PositiveInfinity, double.NegativeInfinity })
        {
            saved.PlayerEsp.FontSize = invalid; saved.PlayerEsp.LineThickness = invalid;
            saved.ZombieEsp.FontSize = invalid; saved.ZombieEsp.LineThickness = invalid;
            fixture.Store.Save(saved); saved = fixture.Store.Load();
            Check(saved.PlayerEsp.FontSize == 12 && saved.ZombieEsp.FontSize == 12 &&
                saved.PlayerEsp.LineThickness == 1.5 && saved.ZombieEsp.LineThickness == 1.5,
                "A non-finite drawing value survived saving and reloading.");
        }
        foreach (string? invalid in new string?[] { null, "", "#abc", "#11223344", "#112233\n" })
        {
            saved.PlayerEsp.Color = invalid!; saved.ZombieEsp.Color = invalid!;
            fixture.Store.Save(saved); saved = fixture.Store.Load();
            Check(saved.PlayerEsp.Color == "#66DEF2" && saved.ZombieEsp.Color == "#FF9A52",
                "A malformed color survived persistence or mixed the category fallbacks.");
        }
        return Task.CompletedTask;
    }

    public static Task CategoryAndDistanceFiltersAreIndependent()
    {
        var settings = NewSettings();
        settings.PlayerEsp.MaxDistance = 120;
        settings.ZombieEsp.MaxDistance = 600;
        settings.ShowPlayers = false; settings.ShowZombies = false; settings.MaxDistance = 25;
        Check(EspDisplayPolicy.TryGetVisibleProfile(settings, "player", 120, true, out var player) &&
            ReferenceEquals(player, settings.PlayerEsp), "The player boundary or migrated profile selection is wrong.");
        Check(!EspDisplayPolicy.TryGetVisibleProfile(settings, "player", 120.01, true, out _) &&
            EspDisplayPolicy.TryGetVisibleProfile(settings, "zombie", 120.01, true, out var zombie) &&
            ReferenceEquals(zombie, settings.ZombieEsp), "One category's distance was applied to the other.");
        Check(EspDisplayPolicy.TryGetVisibleProfile(settings, "zombie", 600, true, out _) &&
            !EspDisplayPolicy.TryGetVisibleProfile(settings, "zombie", 600.01, true, out _), "The zombie boundary is wrong.");
        Check(EspDisplayPolicy.TryGetVisibleProfile(settings, "player", 0, false, out _), "A valid zero distance was rejected.");
        foreach (string? kind in new string?[] { null, "", "animal", "Player", "ZOMBIE" })
            Check(!EspDisplayPolicy.TryGetVisibleProfile(settings, kind!, 1, false, out _), "An unknown kind used an existing category's preferences.");
        foreach (double invalid in new[] { -0.01, double.NaN, double.PositiveInfinity, double.NegativeInfinity })
            foreach (bool projected in new[] { false, true })
                Check(!EspDisplayPolicy.TryGetVisibleProfile(settings, "player", invalid, projected, out _) &&
                    !EspDisplayPolicy.TryGetVisibleProfile(settings, "zombie", invalid, projected, out _), "An invalid distance became visible.");
        settings.PlayerEsp.Enabled = false;
        Check(!EspDisplayPolicy.TryGetVisibleProfile(settings, "player", 1, false, out _) &&
            !EspDisplayPolicy.TryGetVisibleProfile(settings, "player", 1, true, out _) &&
            EspDisplayPolicy.TryGetVisibleProfile(settings, "zombie", 1, true, out _), "Disabling players affected zombies or left players visible.");
        settings.ZombieEsp.Enabled = false;
        Check(!EspDisplayPolicy.HasProjectedProfile(settings), "Disabled categories still advertise projected content.");
        return Task.CompletedTask;
    }

    public static Task EmptyProjectedProfilesKeepIndependentRadarVisibility()
    {
        var settings = NewSettings();
        ClearProjectedContent(settings.PlayerEsp);
        ClearProjectedContent(settings.ZombieEsp);
        Check(!EspDisplayPolicy.HasProjectedProfile(settings), "An empty drawing configuration advertises projected content.");
        foreach (string kind in new[] { "player", "zombie" })
        {
            Check(!EspDisplayPolicy.TryGetVisibleProfile(settings, kind, 5, true, out _), "A category with no requested drawing element projects.");
            Check(EspDisplayPolicy.TryGetVisibleProfile(settings, kind, 5, false, out _), "Removing ESP drawing elements unexpectedly removed its radar points.");
        }
        // Every independently selectable element must be sufficient on its own.
        foreach (Action<EntityEspSettings> enable in new Action<EntityEspSettings>[]
        {
            p => p.ShowBoxes = true, p => p.ShowNames = true, p => p.ShowHealth = true,
            p => p.ShowDistances = true, p => p.ShowTracers = true
        })
        {
            ClearProjectedContent(settings.ZombieEsp);
            enable(settings.ZombieEsp);
            Check(EspDisplayPolicy.HasProjectedProfile(settings) &&
                EspDisplayPolicy.TryGetVisibleProfile(settings, "zombie", 5, true, out _) &&
                !EspDisplayPolicy.TryGetVisibleProfile(settings, "player", 5, true, out _),
                "An individually enabled drawing feature was ignored or leaked into the other category.");
            settings.ZombieEsp.Enabled = false;
            Check(!EspDisplayPolicy.HasProjectedProfile(settings), "A drawing option overrode the category's disabled state.");
            settings.ZombieEsp.Enabled = true;
        }
        return Task.CompletedTask;
    }

    public static Task RadarRangeUsesOnlyActiveCategories()
    {
        var settings = NewSettings();
        settings.PlayerEsp.MaxDistance = 100;
        settings.ZombieEsp.MaxDistance = 800;
        settings.MaxDistance = 5000; // The old global range is no longer authoritative.
        Check(EspDisplayPolicy.RadarRange(settings) == 800, "The radar scale does not include the farther active category.");
        settings.ZombieEsp.Enabled = false;
        Check(EspDisplayPolicy.RadarRange(settings) == 100, "A disabled zombie category still expands the radar scale.");
        settings.PlayerEsp.Enabled = false;
        Check(EspDisplayPolicy.RadarRange(settings) == 25, "No active category produced an invalid or stale radar range.");
        settings.ZombieEsp.Enabled = true;
        ClearProjectedContent(settings.ZombieEsp);
        Check(EspDisplayPolicy.RadarRange(settings) == 800, "Radar range incorrectly depends on projected drawing elements.");
        settings.PlayerEsp.Enabled = true;
        settings.PlayerEsp.MaxDistance = int.MinValue;
        settings.ZombieEsp.MaxDistance = int.MaxValue;
        Check(EspDisplayPolicy.RadarRange(settings) == 5000, "An unnormalized range exceeded the radar's supported maximum.");
        settings.ZombieEsp.Enabled = false;
        Check(EspDisplayPolicy.RadarRange(settings) == 25, "An unnormalized range produced a zero or negative radar scale.");
        settings.PlayerEsp = null!; settings.ZombieEsp = null!;
        Check(EspDisplayPolicy.RadarRange(settings) == 25 && !EspDisplayPolicy.HasProjectedProfile(settings) &&
            !EspDisplayPolicy.TryGetVisibleProfile(settings, "zombie", 1, false, out _), "Missing profiles produced visible or invalid radar output.");
        return Task.CompletedTask;
    }

    public static Task ProjectedLabelBudgetIsFairBoundedAndCurrent()
    {
        var settings = NewSettings();
        var zombies = Enumerable.Range(0, 96).Select(i => Marker(1000 + i, "zombie", 1 + i)).ToArray();
        var players = Enumerable.Range(0, 80).Select(i => Marker(2000 + i, "player", 200 + i)).ToArray();
        var crowd = zombies.Concat(players).Reverse().ToArray();
        var selected = EspDisplayPolicy.SelectProjectedLabels(settings, crowd);
        var expectedBalanced = Enumerable.Range(1000, 32).Concat(Enumerable.Range(2000, 32)).ToArray();
        Check(selected.Count == 64 && selected.SetEquals(expectedBalanced),
            "A nearby horde exhausted the 64-label budget or displaced the nearest 32 players.");
        Check(EspDisplayPolicy.SelectProjectedLabels(settings, crowd.Reverse()).SetEquals(expectedBalanced),
            "Input enumeration order changed the labels selected for the same capture.");

        var fewerPlayers = EspDisplayPolicy.SelectProjectedLabels(settings, zombies.Concat(players.Take(8)));
        Check(fewerPlayers.Count == 64 && fewerPlayers.SetEquals(Enumerable.Range(1000, 56).Concat(Enumerable.Range(2000, 8))),
            "Unused player reservations were not reassigned to the closest remaining zombies.");
        var fewerZombies = EspDisplayPolicy.SelectProjectedLabels(settings, players.Concat(zombies.Take(8)));
        Check(fewerZombies.Count == 64 && fewerZombies.SetEquals(Enumerable.Range(1000, 8).Concat(Enumerable.Range(2000, 56))),
            "Unused zombie reservations were not reassigned to the closest remaining players.");

        // Boxes and tracers remain drawable, but neither needs a text label.
        settings.ZombieEsp.ShowNames = false; settings.ZombieEsp.ShowHealth = false; settings.ZombieEsp.ShowDistances = false;
        Check(EspDisplayPolicy.SelectProjectedLabels(settings, crowd).SetEquals(Enumerable.Range(2000, 64)),
            "A boxes-only zombie profile consumed labels reserved for visible player text.");
        settings.ZombieEsp.ShowTracers = true;
        settings.PlayerEsp.ShowNames = false; settings.PlayerEsp.ShowHealth = false; settings.PlayerEsp.ShowDistances = false;
        Check(EspDisplayPolicy.SelectProjectedLabels(settings, crowd).Count == 0,
            "Text was allocated when names, health and distances were disabled for both categories.");
        settings.ZombieEsp.ShowDistances = true;
        Check(EspDisplayPolicy.SelectProjectedLabels(settings, crowd).SetEquals(Enumerable.Range(1000, 64)),
            "A boxes-only player profile consumed zombie text capacity or distance-only labels were ignored.");

        var filtered = NewSettings();
        filtered.PlayerEsp.MaxDistance = 25; filtered.ZombieEsp.MaxDistance = 50;
        var distances = new[]
        {
            Marker(1, "player", 10), Marker(2, "player", 25), Marker(3, "player", 25.01),
            Marker(11, "zombie", 10), Marker(12, "zombie", 50), Marker(13, "zombie", 50.01),
            Marker(90, "animal", 1), Marker(91, "player", double.NaN), Marker(92, "zombie", -1)
        };
        Check(EspDisplayPolicy.SelectProjectedLabels(filtered, distances).SetEquals(new[] { 1, 2, 11, 12 }),
            "Label selection admitted an unknown category or ignored independent distance limits.");
        filtered.PlayerEsp.Enabled = false;
        Check(EspDisplayPolicy.SelectProjectedLabels(filtered, distances).SetEquals(new[] { 11, 12 }),
            "A disabled player category still consumed label capacity.");
        filtered.ZombieEsp.Enabled = false;
        Check(EspDisplayPolicy.SelectProjectedLabels(filtered, distances).Count == 0,
            "Disabled categories retained labels from the previous selection.");

        var ties = new[] { Marker(43, "player", 10), Marker(42, "player", 10), Marker(9, "player", 20), Marker(99, "player", 5) };
        var tieSettings = NewSettings();
        Check(EspDisplayPolicy.SelectProjectedLabels(tieSettings, ties, 2).SetEquals(new[] { 99, 42 }) &&
            EspDisplayPolicy.SelectProjectedLabels(tieSettings, ties.Reverse(), 2).SetEquals(new[] { 99, 42 }),
            "Distance followed by entity ID did not deterministically resolve a limited label budget.");
        Check(EspDisplayPolicy.SelectProjectedLabels(tieSettings, ties, 0).Count == 0,
            "A zero label budget still emitted text.");
        Check(EspDisplayPolicy.SelectProjectedLabels(tieSettings, Array.Empty<ProjectedMarker>()).Count == 0 &&
            EspDisplayPolicy.SelectProjectedLabels(tieSettings, new[] { Marker(7777, "player", 1) }).SetEquals(new[] { 7777 }),
            "Label selection retained entities from an earlier capture.");
        Check(selected.SetEquals(expectedBalanced), "A later capture mutated an earlier selection result.");
        return Task.CompletedTask;
    }

    private static ProjectedMarker Marker(int id, string kind, double distance) =>
        new(id, kind, "Entity " + id, distance, new ProjectionPoint(100, 100), null);

    private static LoaderSettings NewSettings() => new() { EspProfilesVersion = 1 };

    private static string ProfileState(EntityEspSettings profile) => JsonSerializer.Serialize(profile, Wire.Json);

    private static void ClearProjectedContent(EntityEspSettings profile)
    {
        profile.ShowBoxes = false; profile.ShowNames = false; profile.ShowHealth = false;
        profile.ShowDistances = false; profile.ShowTracers = false;
    }

    private static void CheckUnrelatedLegacyChoices(LoaderSettings settings)
    {
        Check(!settings.AutoConnectDma && settings.SdkDirectory == @"C:\custom dma\MemProcFS" && settings.IntervalMs == 75,
            "Profile migration changed connection preferences.");
        Check(settings.OutputMode == "fuser" && settings.FuserDeviceName == @"\\.\DISPLAY3" &&
            settings.FuserKeyColor == "#FF00FF" && settings.MonitorIndex == 2 && settings.EspScaleMode == "fill",
            "Profile migration changed the fuser output or image mapping.");
        Check(settings.MenuKey == "Home" && settings.ToggleKey == "F8" && settings.OverlayAnchor == "BottomLeft" &&
            !settings.ShowRadar && !settings.ShowHud && settings.RadarSize == 420 && settings.RadarOpacity == 0.65,
            "Profile migration changed shortcuts, placement or radar preferences.");
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    private sealed class SettingsFixture : IDisposable
    {
        private readonly string directory = Path.Combine(Path.GetTempPath(), "7dtd-esp-profiles-" + Guid.NewGuid().ToString("N"));
        internal SettingsStore Store { get; }
        internal SettingsFixture()
        {
            Directory.CreateDirectory(directory);
            Store = new SettingsStore(directory);
        }
        public void Dispose() => Directory.Delete(directory, true);
    }
}
