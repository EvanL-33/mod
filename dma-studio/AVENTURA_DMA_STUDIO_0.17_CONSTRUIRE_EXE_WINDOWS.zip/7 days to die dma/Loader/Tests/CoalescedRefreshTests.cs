using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using SevenDaysLoader.UI;

internal static class CoalescedRefreshTests
{
    public static Task BurstUsesLatestState()
    {
        var queue = new Queue<Action>();
        int current = 0, shown = -1, calls = 0;
        var refresh = new CoalescedRefresh(queue.Enqueue, () => { calls++; shown = current; });
        for (int i = 1; i <= 1000; i++) { current = i; refresh.Request(); }
        Check(queue.Count == 1 && calls == 0, "A burst queued multiple renders or ran on the producer thread.");
        queue.Dequeue()();
        Check(shown == 1000 && calls == 1 && queue.Count == 0, "The renderer displayed an old captured state instead of the latest one.");
        current = 1001; refresh.Request();
        Check(queue.Count == 1, "A completed render prevented the next state from being queued.");
        queue.Dequeue()();
        Check(shown == 1001 && calls == 2, "The next update was lost.");
        Parallel.For(0, 1000, _ => refresh.Request());
        current = 1002;
        Check(queue.Count == 1, "Concurrent producer notifications queued multiple renders.");
        queue.Dequeue()();
        Check(shown == 1002 && calls == 3, "Concurrent producers lost the latest state.");
        return Task.CompletedTask;
    }

    public static Task RequestDuringRefreshIsNotLost()
    {
        var queue = new Queue<Action>();
        int current = 1, shown = 0, calls = 0;
        CoalescedRefresh? refresh = null;
        refresh = new CoalescedRefresh(queue.Enqueue, () =>
        {
            calls++; shown = current;
            if (calls != 1) return;
            for (int i = 2; i <= 25; i++) { current = i; refresh!.Request(); }
            Check(queue.Count == 0, "An update recursively rendered while the current callback was still running.");
        });
        refresh.Request(); queue.Dequeue()();
        Check(shown == 1 && queue.Count == 1, "An update that arrived during rendering was dropped or posted more than once.");
        queue.Dequeue()();
        Check(shown == 25 && calls == 2 && queue.Count == 0, "The single follow-up failed to use the latest state.");
        return Task.CompletedTask;
    }

    public static Task ClosingCancelsPendingWork()
    {
        var queue = new Queue<Action>();
        int calls = 0;
        var refresh = new CoalescedRefresh(queue.Enqueue, () => calls++);
        refresh.Request(); refresh.Close(); refresh.Close(); refresh.Request();
        Check(queue.Count == 1, "Closing queued a new operation.");
        queue.Dequeue()();
        Check(calls == 0 && queue.Count == 0, "A queued operation rendered after closure.");

        CoalescedRefresh? closingDuringRender = null;
        closingDuringRender = new CoalescedRefresh(queue.Enqueue, () =>
        {
            calls++;
            closingDuringRender!.Request();
            closingDuringRender.Close();
        });
        closingDuringRender.Request(); queue.Dequeue()();
        Check(calls == 1 && queue.Count == 0, "A render requested before closure escaped as a follow-up.");
        return Task.CompletedTask;
    }

    public static Task PostingFailureCanRecover()
    {
        var queue = new Queue<Action>();
        bool fail = true;
        int calls = 0;
        var refresh = new CoalescedRefresh(action =>
        {
            if (fail) throw new InvalidOperationException("Simulated dispatcher rejection.");
            queue.Enqueue(action);
        }, () => calls++);
        bool rejected = false;
        try { refresh.Request(); }
        catch (InvalidOperationException) { rejected = true; }
        Check(rejected && queue.Count == 0, "The simulated post rejection was not observed.");
        fail = false;
        refresh.Request(); refresh.Request();
        Check(queue.Count == 1, "A failed post left the bridge stuck or broke coalescing.");
        queue.Dequeue()();
        Check(calls == 1, "A recovered dispatcher did not render the next update.");

        bool callbackFails = true;
        var failedCallback = new CoalescedRefresh(queue.Enqueue, () =>
        {
            if (callbackFails) throw new InvalidOperationException("Simulated callback error.");
            calls++;
        });
        failedCallback.Request();
        try { queue.Dequeue()(); }
        catch (InvalidOperationException) { }
        callbackFails = false; failedCallback.Request();
        Check(queue.Count == 1, "A callback exception left the bridge permanently pending.");
        queue.Dequeue()();
        Check(calls == 2, "The bridge did not recover after a callback exception.");
        return Task.CompletedTask;
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
