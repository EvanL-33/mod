using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;

namespace SevenDaysEsp
{
    public sealed class CreativeMenuAccessResult
    {
        public bool Success { get; set; }
        public string Code { get; set; }
        public string Message { get; set; }
        public bool? ObservedEnabled { get; set; }
        public bool WriteAttempted { get; set; }
        public string ContextId { get; set; }
    }

    // Profile evidence: the supplied Assembly-CSharp.dll, V 3.4.0 (b10),
    // SHA256 cb54022ccc862aa673e0ee55dafe67d842b364c80df6916958d171e959656c58.
    // GamePrefs.GetBool reads sandboxReferences first, then propertyValues.
    // No boxed Boolean is modified. The only permitted target is that one
    // object[] slot; the replacement already has a strong static root in the
    // declaration table. No remote allocation, invocation, code patch or restore.
    public sealed class CreativeMenuAccess
    {
        private const int CreativeIndex = 47;
        private const int BooleanDeclaration = 3;
        private const int PrefCount = 316;
        private const int DeclarationCount = 293;
        private const string ProfileVersion = "V 3.4.0 (b10)";
        private readonly IMemoryReader memory;
        private readonly LiveEntityReader entities;
        private readonly MonoInspectionReport metadata;
        private readonly string gameVersion;
        private readonly bool versionFound;
        private readonly object gate = new object();
        private readonly UTF8Encoding utf8 = new UTF8Encoding(false, true);
        private Stopwatch clock;
        private int calls, bytes;
        private CancellationToken token;

        private sealed class TypeInfo
        {
            internal ulong Address, Image, Fields, Parent;
            internal int Size, Count, Stride;
            internal uint Token;
            internal byte Kind, Rank;
            internal string Name, Namespace;
            internal ulong Element;
        }
        private sealed class FieldInfo
        {
            internal string Name;
            internal int Offset;
            internal byte Code;
            internal ushort Flags;
            internal ulong Data;
        }
        private sealed class ArrayInfo
        {
            internal ulong Address, Table;
            internal TypeInfo Type, Element;
            internal int Length, Stride;
        }
        private sealed class BoolInfo
        {
            internal ulong Address, Table;
            internal TypeInfo Type;
            internal int ValueOffset;
            internal bool Value;
        }
        private sealed class Graph
        {
            internal ulong Runtime, RuntimeSlot, StaticTable, StaticSlot, Statics, Instance, InstanceTable;
            internal ulong TargetSlot, TargetReference, SourceSlot, SourceReference, Domain;
            internal ArrayInfo Values, Sandbox, Declarations;
            internal TypeInfo Prefs;
            internal BoolInfo Current, Source;
            internal bool? DesiredEnabled;
            internal byte[] DeclarationBytes;
            internal int InstanceOffset, ValuesOffset, SandboxOffset, DeclarationsOffset;
        }

        public CreativeMenuAccess(IMemoryReader memory, LiveEntityReader entities,
            MonoInspectionReport metadata, GameVersionReport version)
        {
            if (memory == null || entities == null || metadata == null)
                throw new ArgumentNullException("memory/entities/metadata");
            this.memory = memory; this.entities = entities; this.metadata = metadata;
            gameVersion = version == null ? null : version.DisplayVersion;
            versionFound = version != null && version.VersionFound;
        }

        public CreativeMenuAccessResult Apply(string expectedContextId, uint expectedProcessId, bool? desiredEnabled, CancellationToken cancellationToken = default(CancellationToken))
        {
            return ApplyCore(expectedContextId, expectedProcessId, desiredEnabled, false, cancellationToken);
        }

        public CreativeMenuAccessResult ApplyToggle(string expectedContextId, uint expectedProcessId, CancellationToken cancellationToken = default(CancellationToken))
        {
            return ApplyCore(expectedContextId, expectedProcessId, null, true, cancellationToken);
        }

        private CreativeMenuAccessResult ApplyCore(string expectedContextId, uint expectedProcessId, bool? desiredEnabled,
            bool toggle, CancellationToken cancellationToken)
        {
            lock (gate)
            {
                CreativeMenuAccessResult result = new CreativeMenuAccessResult { ContextId = expectedContextId };
                clock = Stopwatch.StartNew(); calls = 0; bytes = 0; token = cancellationToken;
                try
                {
                    token.ThrowIfCancellationRequested();
                    if (!versionFound || gameVersion != ProfileVersion ||
                        metadata.SelectedLayout != "Unity Mono x64 2022 (candidate)" ||
                        (metadata.Status != "METADONNEES_COLLECTEES" && metadata.Status != "METADONNEES_PARTIELLES"))
                        throw new IOException("Profil du menu non reconnu : V 3.4.0 (b10) et metadonnees Mono courantes requis.");
                    if (expectedProcessId == 0) throw new IOException("PID du jeu absent.");
                    IMenuMemoryWriter writer = memory as IMenuMemoryWriter;
                    CheckProcess(writer, expectedProcessId);
                    return entities.ExecuteInValidatedContext(expectedContextId, delegate(LiveMenuContext context)
                    {
                        // Resolve a toggle once, from this operation's actual
                        // current value. Later passes validate that same target;
                        // a concurrent preference change refuses the operation.
                        Graph before = ReadGraph(context, desiredEnabled, toggle);
                        bool? effectiveDesired = before.DesiredEnabled;
                        context.Validate(); CheckProcess(writer, expectedProcessId);
                        long checkStarted = clock.ElapsedMilliseconds;
                        int checkCalls = calls, checkBytes = bytes;
                        Graph check = ReadGraph(context, effectiveDesired);
                        long checkDuration = clock.ElapsedMilliseconds - checkStarted;
                        int graphCalls = calls - checkCalls, graphBytes = bytes - checkBytes;
                        RequireSameGraph(before, check, false);
                        context.Validate(); CheckProcess(writer, expectedProcessId);
                        result.ObservedEnabled = check.Current.Value;
                        if (!effectiveDesired.HasValue || effectiveDesired.Value == check.Current.Value)
                        {
                            result.Success = true;
                            result.Code = effectiveDesired.HasValue ? "DEJA_APPLIQUE" : "ETAT_LU";
                            result.Message = check.Current.Value ? "Menu creatif client active (lecture confirmee)." :
                                "Menu creatif client desactive (lecture confirmee).";
                            return result;
                        }
                        if (writer == null)
                            throw new IOException("Cette source memoire ne prend pas en charge l'ecriture du menu.");
                        // No blind retry. A failed native write may still have touched
                        // memory; its outcome must remain unconfirmed until observed.
                        token.ThrowIfCancellationRequested();
                        // Reserve a complete verification pass before touching the
                        // slot. A slow bus must refuse early instead of knowingly
                        // exhausting its whole budget before readback.
                        if (clock.ElapsedMilliseconds + Math.Max(250, checkDuration * 2) > 1500 ||
                            calls > 4096 - graphCalls || bytes > 524288 - graphBytes)
                            throw new IOException("Budget restant insuffisant pour verifier une ecriture ; aucune mutation.");
                        MenuReferenceWriteResult native = writer.WriteMenuReference(expectedProcessId,
                            check.TargetSlot, check.TargetReference, check.SourceReference, token);
                        result.WriteAttempted = native != null && native.Attempted;
                        if (native == null) throw new IOException("Resultat d'ecriture absent.");
                        if (!native.Attempted && !native.ReportedSuccess)
                            throw new IOException(native.Message ?? "Ecriture du menu refusee avant mutation.");
                        Graph after = ReadGraph(context, effectiveDesired);
                        RequireSameGraph(check, after, true);
                        context.Validate(); CheckProcess(writer, expectedProcessId);
                        result.ObservedEnabled = after.Current.Value;
                        if (!native.ReportedSuccess || after.TargetReference != check.SourceReference ||
                            after.Current.Value != effectiveDesired.Value)
                        {
                            result.Code = "CREATIF_ECRITURE_NON_CONFIRMEE";
                            result.Message = "Ecriture non confirmee. Etat observe : " +
                                (after.Current.Value ? "active" : "desactive") + ". Aucun nouvel essai automatique.";
                            return result;
                        }
                        result.Success = true;
                        result.Code = "CONFIRME";
                        result.Message = effectiveDesired.Value ?
                            "Menu creatif client active et relu. Ouvre-le avec la touche du jeu ; les succes restent soumis aux regles du jeu." :
                            "Menu creatif client desactive et relu. Aucun autre indicateur de partie n'a ete modifie.";
                        return result;
                    });
                }
                catch (Exception e)
                {
                    result.Success = false;
                    result.Code = result.WriteAttempted ? "CREATIF_ETAT_INDETERMINE" : "CREATIF_REFUSE";
                    result.ObservedEnabled = null;
                    result.Message = (result.WriteAttempted ? "Verification apres ecriture impossible ; aucun nouvel essai automatique. " : "") + e.Message;
                    return result;
                }
            }
        }

        private static void CheckProcess(IMenuMemoryWriter writer, uint expected)
        {
            if (writer != null && writer.ProcessId != expected)
                throw new IOException("Le processus du jeu a change ; relis l'etat dans la nouvelle partie.");
        }

        private Graph ReadGraph(LiveMenuContext context, bool? desired, bool toggle = false)
        {
            MonoClassReport report = null;
            foreach (MonoClassReport candidate in metadata.Classes)
                if (candidate != null && candidate.Name == "GamePrefs" && String.IsNullOrEmpty(candidate.Namespace))
                {
                    if (report != null) throw new IOException("Classe GamePrefs ambigue.");
                    report = candidate;
                }
            if (report == null || report.Fields == null || report.MetadataToken != "0x02001215")
                throw new IOException("Classe GamePrefs du profil absent ou token different.");
            TypeInfo prefs = ReadType(ParseAddress(report.Address));
            if (prefs.Kind != 1 || prefs.Name != "GamePrefs" || prefs.Namespace != "" ||
                prefs.Token != 0x02001215 || prefs.Image != context.GameImage || prefs.Size != report.InstanceSize)
                throw new IOException("Identite de GamePrefs non confirmee.");
            Dictionary<string, FieldInfo> fields = ReadFields(prefs);
            FieldInfo instanceField = Field(fields, "m_Instance", 0x12, true, 8, 1048576);
            FieldInfo valuesField = Field(fields, "propertyValues", 0x1D, false, 8, prefs.Size);
            FieldInfo sandboxField = Field(fields, "sandboxReferences", 0x1D, true, 8, 1048576);
            FieldInfo declarationsField = Field(fields, "s_propertyList", 0x1D, true, 8, 1048576);
            if (instanceField.Data != prefs.Address) throw new IOException("Type declare de m_Instance incoherent.");
            MatchReport(report, instanceField); MatchReport(report, valuesField);
            MatchReport(report, sandboxField); MatchReport(report, declarationsField);
            Distinct(instanceField, 8, sandboxField, 8); Distinct(instanceField, 8, declarationsField, 8);
            Distinct(sandboxField, 8, declarationsField, 8);
            TypeInfo objectType = ReadType(valuesField.Data);
            if (objectType.Kind != 1 || objectType.Name != "Object" || objectType.Namespace != "System" || objectType.Image == prefs.Image)
                throw new IOException("propertyValues n'est pas un tableau d'objets du runtime.");
            TypeInfo sandboxType = ReadType(sandboxField.Data);
            if (sandboxType.Name != "BaseSandboxOption" || sandboxType.Image != prefs.Image)
                throw new IOException("Type des options sandbox non confirme.");
            TypeInfo declarationType = ReadType(declarationsField.Data);
            if (declarationType.Kind != 1 || declarationType.Name != "PropertyDecl" || declarationType.Namespace != "" ||
                declarationType.Token != 0x02001217 || declarationType.Image != prefs.Image)
                throw new IOException("Type de declaration des preferences non confirme.");
            Dictionary<string, FieldInfo> declFields = ReadFields(declarationType);
            FieldInfo declName = Field(declFields, "name", 0x11, false, 4, declarationType.Size);
            FieldInfo declType = Field(declFields, "type", 0x11, false, 4, declarationType.Size);
            FieldInfo declDefault = Field(declFields, "defaultValue", 0x1C, false, 8, declarationType.Size);
            Distinct(declName, 4, declType, 4); Distinct(declName, 4, declDefault, 8); Distinct(declType, 4, declDefault, 8);
            ValidateEnum(declName.Data, "EnumGamePrefs", prefs.Image);
            ValidateEnum(declType.Data, "EnumType", prefs.Image);
            Graph result = StaticGraph(prefs, context.Domain);
            result.InstanceOffset = instanceField.Offset; result.ValuesOffset = valuesField.Offset;
            result.SandboxOffset = sandboxField.Offset; result.DeclarationsOffset = declarationsField.Offset;
            int staticSize = I32(prefs.Address + 0x90);
            CheckOffset(instanceField.Offset, staticSize, 8, false); CheckOffset(sandboxField.Offset, staticSize, 8, false);
            CheckOffset(declarationsField.Offset, staticSize, 8, false);
            byte[] statics = Read(result.Statics, staticSize);
            result.Instance = BufferPointer(statics, instanceField.Offset);
            byte[] instance = ReadObject(result.Instance, prefs, context.Domain, out result.InstanceTable);
            result.Values = ReadArray(BufferPointer(instance, valuesField.Offset), objectType, context.Domain, PrefCount, 8);
            result.Sandbox = ReadArray(BufferPointer(statics, sandboxField.Offset), sandboxType, context.Domain, PrefCount, 8);
            result.Declarations = ReadArray(BufferPointer(statics, declarationsField.Offset), declarationType, context.Domain, DeclarationCount, 0);
            int stride = result.Declarations.Stride;
            if (stride < 24 || stride > 256 || declarationType.Size - 16 != stride)
                throw new IOException("Taille de declaration inline non confirmee.");
            int nameOffset = declName.Offset - 16, typeOffset = declType.Offset - 16, defaultOffset = declDefault.Offset - 16;
            CheckOffset(nameOffset, stride, 4, false); CheckOffset(typeOffset, stride, 4, false); CheckOffset(defaultOffset, stride, 8, false);
            if (U64(result.Sandbox.Address + 0x20UL + CreativeIndex * 8UL) != 0)
                throw new IOException("Le menu creatif est pilote par une option sandbox ; aucune ecriture directe n'est effectuee.");
            result.TargetSlot = result.Values.Address + 0x20UL + CreativeIndex * 8UL;
            result.TargetReference = Pointer(result.TargetSlot);
            result.Current = ReadBoolean(result.TargetReference, objectType.Image, context.Domain);
            result.DesiredEnabled = toggle ? !result.Current.Value : desired;
            desired = result.DesiredEnabled;
            result.DeclarationBytes = Read(result.Declarations.Address + 0x20, DeclarationCount * stride);
            HashSet<int> names = new HashSet<int>();
            bool creativeDeclarationFound = false;
            for (int index = 0; index < DeclarationCount; index++)
            {
                int at = index * stride;
                int name = BitConverter.ToInt32(result.DeclarationBytes, at + nameOffset);
                int type = BitConverter.ToInt32(result.DeclarationBytes, at + typeOffset);
                if (name < 0 || name >= PrefCount || !names.Add(name))
                    throw new IOException("Table des declarations incoherente ou dupliquee.");
                ulong reference = BitConverter.ToUInt64(result.DeclarationBytes, at + defaultOffset);
                if (name == CreativeIndex)
                {
                    if (type != BooleanDeclaration) throw new IOException("Le menu creatif n'est pas declare booleen.");
                    BoolInfo creativeDefault = ReadBoolean(reference, objectType.Image, context.Domain);
                    if (creativeDefault.Value || creativeDefault.Type.Address != result.Current.Type.Address)
                        throw new IOException("Declaration initiale du menu creatif differente du profil.");
                    creativeDeclarationFound = true;
                }
                if (desired.HasValue && result.Source == null && type == BooleanDeclaration)
                {
                    BoolInfo source = ReadBoolean(reference, objectType.Image, context.Domain);
                    if (source.Type.Address != result.Current.Type.Address)
                        throw new IOException("Types booleens incoherents entre preference et declaration.");
                    if (source.Value == desired.Value)
                    {
                        result.Source = source; result.SourceReference = reference;
                        result.SourceSlot = result.Declarations.Address + 0x20UL + (ulong)(at + defaultOffset);
                    }
                }
            }
            if (!creativeDeclarationFound) throw new IOException("Declaration CreativeMenuEnabled absente.");
            if (desired.HasValue && result.Source == null)
                throw new IOException("Aucune valeur booleenne deja enracinee correspondante ; aucune allocation ni ecriture.");
            // Recheck all roots after traversal, including the sandbox override.
            ValidateRoots(result, context, instanceField, valuesField, sandboxField, declarationsField);
            return result;
        }

        private Graph StaticGraph(TypeInfo type, ulong domain)
        {
            ulong runtime = Pointer(type.Address + 0xD0);
            int maximum = BitConverter.ToUInt16(Read(runtime, 2), 0);
            if (maximum >= 32) throw new IOException("Trop de domaines Mono.");
            int slots = I32(type.Address + 0x5C), size = I32(type.Address + 0x90);
            if (slots < 0 || slots > 4096 || size < 1 || size > 65536) throw new IOException("Stockage statique GamePrefs invalide.");
            Graph result = null;
            for (int index = 0; index <= maximum; index++)
            {
                ulong runtimeSlot = runtime + 8UL + (ulong)index * 8UL;
                ulong table = U64(runtimeSlot);
                if (table == 0) continue;
                byte[] header = Read(table, 0x48);
                if (BitConverter.ToUInt64(header, 0) != type.Address) throw new IOException("Classe de vtable statique differente.");
                if (header[0x2D] == 0) continue;
                if (BitConverter.ToUInt64(header, 0x10) != domain) continue;
                uint flags = BitConverter.ToUInt32(header, 0x30);
                if (header[0x2D] != 1 || (flags & 2) != 0 || (flags & 4) == 0 || result != null)
                    throw new IOException("Stockage statique GamePrefs ambigu ou non initialise.");
                ulong staticSlot = table + 0x48UL + (ulong)slots * 8UL;
                result = new Graph { Prefs = type, Domain = domain, Runtime = runtime, RuntimeSlot = runtimeSlot,
                    StaticTable = table, StaticSlot = staticSlot, Statics = Pointer(staticSlot) };
            }
            if (result == null) throw new IOException("GamePrefs absent du domaine de cette partie.");
            return result;
        }

        private void ValidateRoots(Graph graph, LiveMenuContext context, FieldInfo instanceField,
            FieldInfo valuesField, FieldInfo sandboxField, FieldInfo declarationsField)
        {
            int size = I32(graph.Prefs.Address + 0x90);
            CheckOffset(instanceField.Offset, size, 8, false); CheckOffset(sandboxField.Offset, size, 8, false);
            CheckOffset(declarationsField.Offset, size, 8, false);
            if (Pointer(graph.Prefs.Address + 0xD0) != graph.Runtime || U64(graph.RuntimeSlot) != graph.StaticTable ||
                Pointer(graph.StaticSlot) != graph.Statics || ValidateTable(graph.StaticTable, context.Domain) != graph.Prefs.Address ||
                Pointer(graph.Statics + (uint)instanceField.Offset) != graph.Instance || Pointer(graph.Instance) != graph.InstanceTable ||
                Pointer(graph.Instance + (uint)valuesField.Offset) != graph.Values.Address ||
                Pointer(graph.Statics + (uint)sandboxField.Offset) != graph.Sandbox.Address ||
                Pointer(graph.Statics + (uint)declarationsField.Offset) != graph.Declarations.Address ||
                U64(graph.Sandbox.Address + 0x20UL + CreativeIndex * 8UL) != 0 ||
                U64(graph.TargetSlot) != graph.TargetReference)
                throw new IOException("Preferences ou option sandbox modifiees pendant la lecture.");
            ValidateArray(graph.Values, context.Domain); ValidateArray(graph.Sandbox, context.Domain); ValidateArray(graph.Declarations, context.Domain);
            BoolInfo current = ReadBoolean(graph.TargetReference, graph.Current.Type.Image, context.Domain);
            if (!SameBoolean(current, graph.Current)) throw new IOException("Valeur booleenne modifiee pendant la lecture.");
            if (graph.Source != null)
            {
                if (Pointer(graph.SourceSlot) != graph.SourceReference ||
                    !SameBoolean(ReadBoolean(graph.SourceReference, graph.Source.Type.Image, context.Domain), graph.Source))
                    throw new IOException("La valeur de declaration a change ; aucune reference de remplacement utilisable.");
            }
        }

        private static bool SameBoolean(BoolInfo left, BoolInfo right)
        {
            return left.Address == right.Address && left.Table == right.Table && SameType(left.Type, right.Type) &&
                left.ValueOffset == right.ValueOffset && left.Value == right.Value;
        }
        private static bool SameType(TypeInfo left, TypeInfo right)
        {
            return left.Address == right.Address && left.Image == right.Image && left.Fields == right.Fields &&
                left.Size == right.Size && left.Count == right.Count && left.Token == right.Token && left.Kind == right.Kind &&
                left.Name == right.Name && left.Namespace == right.Namespace && left.Element == right.Element && left.Stride == right.Stride;
        }
        private static bool SameArray(ArrayInfo left, ArrayInfo right)
        {
            return left.Address == right.Address && left.Table == right.Table && left.Length == right.Length &&
                left.Stride == right.Stride && SameType(left.Type, right.Type) && SameType(left.Element, right.Element);
        }
        private static void RequireSameGraph(Graph before, Graph after, bool allowTargetReplacement)
        {
            if (before.Runtime != after.Runtime || before.RuntimeSlot != after.RuntimeSlot || before.StaticTable != after.StaticTable ||
                before.StaticSlot != after.StaticSlot || before.Statics != after.Statics || before.Instance != after.Instance ||
                before.InstanceTable != after.InstanceTable || before.Domain != after.Domain || before.TargetSlot != after.TargetSlot ||
                before.SourceSlot != after.SourceSlot || before.SourceReference != after.SourceReference ||
                before.DesiredEnabled != after.DesiredEnabled ||
                before.InstanceOffset != after.InstanceOffset || before.ValuesOffset != after.ValuesOffset ||
                before.SandboxOffset != after.SandboxOffset || before.DeclarationsOffset != after.DeclarationsOffset ||
                !SameType(before.Prefs, after.Prefs) || !SameArray(before.Values, after.Values) ||
                !SameArray(before.Sandbox, after.Sandbox) || !SameArray(before.Declarations, after.Declarations) ||
                !SameBytes(before.DeclarationBytes, after.DeclarationBytes) ||
                (!allowTargetReplacement && !SameBoolean(before.Current, after.Current)) ||
                (before.Source != null && (after.Source == null || !SameBoolean(before.Source, after.Source))))
                throw new IOException("Le graphe du menu a change entre les verifications.");
        }

        private ArrayInfo ReadArray(ulong address, TypeInfo element, ulong domain, int expectedLength, int expectedStride)
        {
            byte[] data = Read(address, 0x20);
            ulong table = BufferPointer(data, 0);
            TypeInfo type = ReadType(ValidateTable(table, domain));
            // This profile uses ordinary Mono arrays, as the entity reader does.
            // max_length is UInt32; +0x1C contains alignment, not length bits.
            // Upstream ABI evidence (not an inspection of the Unity branch):
            // https://github.com/mono/mono/blob/main/mono/metadata/object-internals.h
            // mono_array_size_t is uint32_t when MONO_BIG_ARRAYS is not defined.
            uint length = BitConverter.ToUInt32(data, 0x18);
            if (type.Kind != 5 || type.Rank != 1 || type.Element != element.Address || type.Image != element.Image ||
                BitConverter.ToUInt64(data, 0x10) != 0 || length != (uint)expectedLength ||
                type.Stride < 1 || type.Stride > 256 || (expectedStride != 0 && type.Stride != expectedStride))
                throw new IOException("Tableau du menu non conforme au profil.");
            return new ArrayInfo { Address = address, Table = table, Type = type, Element = element,
                Length = expectedLength, Stride = type.Stride };
        }
        private void ValidateArray(ArrayInfo array, ulong domain)
        {
            ArrayInfo after = ReadArray(array.Address, array.Element, domain, array.Length, array.Stride);
            if (!SameArray(array, after)) throw new IOException("Tableau du menu modifie pendant la lecture.");
        }
        private BoolInfo ReadBoolean(ulong address, ulong coreImage, ulong domain)
        {
            ulong table = Pointer(address);
            TypeInfo type = ReadType(ValidateTable(table, domain));
            if (type.Kind != 1 || type.Name != "Boolean" || type.Namespace != "System" || type.Image != coreImage ||
                type.Size < 17 || type.Size > 32)
                throw new IOException("La valeur du menu n'est pas un System.Boolean reconnu.");
            FieldInfo value = Field(ReadFields(type), "m_value", 0x02, false, 1, type.Size);
            byte[] data = ReadObject(address, type, domain, out var verifiedTable);
            if (verifiedTable != table || data[value.Offset] > 1) throw new IOException("Valeur booleenne incoherente.");
            return new BoolInfo { Address = address, Table = table, Type = type, ValueOffset = value.Offset, Value = data[value.Offset] != 0 };
        }
        private void ValidateEnum(ulong address, string name, ulong gameImage)
        {
            TypeInfo type = ReadType(address);
            uint expectedToken = name == "EnumGamePrefs" ? 0x0200120BU : 0x02001216U;
            if (type.Kind != 1 || type.Name != name || type.Namespace != "" || type.Image != gameImage || type.Size > 32 || type.Token != expectedToken)
                throw new IOException("Enum de declaration non reconnu : " + name);
            if (type.Count < 1 || type.Count > 512) throw new IOException("Enum du menu hors limites.");
            // The enum has hundreds of literal fields; only its underlying value
            // field participates in storage. Read its declaration without chasing
            // every literal name on the DMA bus.
            byte[] fields = Read(type.Fields, type.Count * 32);
            for (int index = 0; index < type.Count; index++)
            {
                int at = index * 32;
                if (BitConverter.ToUInt64(fields, at + 16) != type.Address) throw new IOException("Champ enum incoherent.");
                if (CString(BufferPointer(fields, at + 8)) != "value__") continue;
                byte[] value = Read(BufferPointer(fields, at), 16);
                if (value[10] != 0x08 || (BitConverter.ToUInt16(value, 8) & 0x50) != 0)
                    throw new IOException("Type sous-jacent de l'enum incompatible.");
                CheckOffset(BitConverter.ToInt32(fields, at + 24), type.Size, 4, true);
                return;
            }
            throw new IOException("Valeur sous-jacente de l'enum absente.");
        }
        private TypeInfo ReadType(ulong address)
        {
            byte[] prefix = Read(address, 0x60);
            byte kind = prefix[0x1B];
            if (kind != 1 && kind != 5) throw new IOException("Genre de classe Mono non pris en charge pour le menu.");
            byte[] data = Read(address, kind == 1 ? 0x110 : 0x98);
            TypeInfo result = new TypeInfo {
                Address = address, Kind = data[0x1B], Rank = data[0x1A], Size = BitConverter.ToInt32(data, 0x1C),
                Image = BufferPointer(data, 0x40), Parent = BitConverter.ToUInt64(data, 0x30),
                Name = CString(BufferPointer(data, 0x48)), Namespace = CString(BufferPointer(data, 0x50)),
                Token = BitConverter.ToUInt32(data, 0x58), Fields = kind == 1 ? BitConverter.ToUInt64(data, 0x98) : 0,
                Count = kind == 1 ? BitConverter.ToInt32(data, 0x100) : 0, Element = BitConverter.ToUInt64(data, 0),
                Stride = BitConverter.ToInt32(data, 0x90)
            };
            if ((result.Kind != 1 && result.Kind != 5) || result.Size < 16 || result.Size > 65536 || result.Name.Length == 0)
                throw new IOException("Classe Mono hors du profil du menu.");
            return result;
        }
        private Dictionary<string, FieldInfo> ReadFields(TypeInfo type)
        {
            if (type.Kind != 1 || type.Count < 1 || type.Count > 512) throw new IOException("Nombre de champs du menu hors limites.");
            byte[] fields = Read(type.Fields, type.Count * 32);
            var result = new Dictionary<string, FieldInfo>(StringComparer.Ordinal);
            for (int index = 0; index < type.Count; index++)
            {
                int at = index * 32;
                if (BitConverter.ToUInt64(fields, at + 16) != type.Address) throw new IOException("Parent de champ incoherent.");
                string name = CString(BufferPointer(fields, at + 8));
                byte[] data = Read(BufferPointer(fields, at), 16);
                if (result.ContainsKey(name)) throw new IOException("Champ Mono duplique.");
                result.Add(name, new FieldInfo { Name = name, Offset = BitConverter.ToInt32(fields, at + 24),
                    Code = data[10], Flags = BitConverter.ToUInt16(data, 8), Data = BitConverter.ToUInt64(data, 0) });
            }
            return result;
        }
        private static FieldInfo Field(Dictionary<string, FieldInfo> fields, string name, byte code, bool isStatic, int width, int size)
        {
            FieldInfo result;
            if (!fields.TryGetValue(name, out result) || result.Code != code || (result.Flags & 0x40) != 0 ||
                ((result.Flags & 0x10) != 0) != isStatic)
                throw new IOException("Champ du menu absent ou type different : " + name);
            CheckOffset(result.Offset, size, width, !isStatic);
            return result;
        }
        private static void MatchReport(MonoClassReport report, FieldInfo actual)
        {
            MonoFieldReport found = null;
            foreach (MonoFieldReport field in report.Fields)
                if (field.Name == actual.Name)
                { if (found != null) throw new IOException("Champ du rapport duplique."); found = field; }
            if (found == null || found.Offset != actual.Offset || found.TypeCode != "0x" + actual.Code.ToString("X2") ||
                found.IsStatic != ((actual.Flags & 0x10) != 0) || found.IsLiteral)
                throw new IOException("Le champ du menu ne correspond plus au rapport courant : " + actual.Name);
        }
        private byte[] ReadObject(ulong address, TypeInfo type, ulong domain, out ulong table)
        {
            byte[] data = Read(address, type.Size); table = BufferPointer(data, 0);
            if (ValidateTable(table, domain) != type.Address) throw new IOException("Type de l'objet menu modifie.");
            return data;
        }
        private ulong ValidateTable(ulong address, ulong domain)
        {
            byte[] data = Read(address, 24);
            if (BitConverter.ToUInt64(data, 0x10) != domain) throw new IOException("Objet du menu dans un autre domaine Mono.");
            return BufferPointer(data, 0);
        }
        private static void Distinct(FieldInfo a, int aw, FieldInfo b, int bw)
        {
            if (a.Offset < b.Offset + bw && b.Offset < a.Offset + aw) throw new IOException("Champs du menu superposes.");
        }
        private static void CheckOffset(int offset, int size, int width, bool instance)
        {
            if (offset < (instance ? 16 : 0) || size < width || offset > size - width || offset % width != 0)
                throw new IOException("Champ du menu hors de son stockage.");
        }
        private byte[] Read(ulong address, int count)
        {
            token.ThrowIfCancellationRequested();
            RequirePointer(address);
            if (count < 1 || count > 65536 || address > 0x00007FFFFFFFFFFFUL - (uint)(count - 1) ||
                calls >= 4096 || bytes > 524288 - count || clock.ElapsedMilliseconds > 1500)
                throw new IOException("Budget de validation du menu atteint.");
            calls++; bytes += count;
            byte[] result = memory.Read(address, count);
            if (result == null || result.Length != count) throw new IOException("Lecture du menu incomplete.");
            if (clock.ElapsedMilliseconds > 1500) throw new IOException("Budget de validation du menu atteint.");
            return result;
        }
        private string CString(ulong address)
        {
            var bytes = new List<byte>();
            for (int offset = 0; offset < 256; )
            {
                int count = Math.Min(16, Math.Min(256 - offset, 4096 - (int)((address + (uint)offset) & 4095UL)));
                foreach (byte value in Read(address + (uint)offset, count))
                {
                    if (value == 0) return utf8.GetString(bytes.ToArray());
                    if (value < 0x20) throw new IOException("Nom Mono invalide.");
                    bytes.Add(value);
                }
                offset += count;
            }
            throw new IOException("Nom Mono sans terminaison.");
        }
        private ulong Pointer(ulong address) { ulong value = U64(address); RequirePointer(value); return value; }
        private ulong U64(ulong address) { return BitConverter.ToUInt64(Read(address, 8), 0); }
        private int I32(ulong address) { return BitConverter.ToInt32(Read(address, 4), 0); }
        private static ulong BufferPointer(byte[] data, int offset) { ulong value = BitConverter.ToUInt64(data, offset); RequirePointer(value); return value; }
        private static void RequirePointer(ulong value)
        {
            if (value < 0x10000UL || value > 0x00007FFFFFFFFFFFUL) throw new IOException("Reference de menu hors plage utilisateur.");
        }
        private static ulong ParseAddress(string value)
        {
            ulong parsed;
            string hex = value != null && value.StartsWith("0x", StringComparison.OrdinalIgnoreCase) ? value.Substring(2) : value;
            if (!UInt64.TryParse(hex, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out parsed)) throw new IOException("Adresse de GamePrefs absente.");
            RequirePointer(parsed); return parsed;
        }
        private static bool SameBytes(byte[] a, byte[] b)
        {
            if (a.Length != b.Length) return false;
            for (int i = 0; i < a.Length; i++) if (a[i] != b[i]) return false;
            return true;
        }
    }
}
