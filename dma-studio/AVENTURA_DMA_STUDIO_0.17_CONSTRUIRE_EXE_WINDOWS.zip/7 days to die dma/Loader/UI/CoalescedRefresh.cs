using System;

namespace SevenDaysLoader.UI;

// A thread-safe notification bridge. The supplied post function must queue
// callbacks asynchronously on one consumer thread (the WPF render dispatcher
// in production). It never stores a camera frame or changes a freshness clock.
internal sealed class CoalescedRefresh
{
    private readonly object gate = new();
    private readonly Action<Action> post;
    private readonly Action refresh;
    private bool scheduled;
    private bool requested;
    private bool closed;

    internal CoalescedRefresh(Action<Action> post, Action refresh)
    {
        this.post = post ?? throw new ArgumentNullException(nameof(post));
        this.refresh = refresh ?? throw new ArgumentNullException(nameof(refresh));
    }

    internal void Request()
    {
        lock (gate)
        {
            if (closed) return;
            requested = true;
            if (scheduled) return;
            scheduled = true;
        }
        Post();
    }

    internal void Close()
    {
        lock (gate)
        {
            closed = true;
            requested = false;
        }
    }

    private void Post()
    {
        try { post(Drain); }
        catch
        {
            // A failed dispatcher post cannot leave the bridge permanently
            // pending. The latest request remains available to the next call.
            lock (gate) scheduled = false;
            throw;
        }
    }

    private void Drain()
    {
        lock (gate)
        {
            if (closed) { scheduled = false; requested = false; return; }
            requested = false;
        }
        try { refresh(); }
        finally
        {
            bool repeat;
            lock (gate)
            {
                repeat = !closed && requested;
                if (!repeat) scheduled = false;
            }
            // Keep scheduled true while posting the single follow-up. A
            // notification that arrived during refresh must not be discarded.
            if (repeat) Post();
        }
    }
}
