#nullable enable
// Typed, read-only presentation state for the supplied post-processing build.
// All reads share NativeCameraReader's operation budget. Managed offsets are
// resolved from this session's Mono fields; no object or assembly-wide scan.
using System;
using System.Collections.Generic;
using System.Text;

namespace SevenDaysEsp
{
    public sealed partial class NativeCameraReader
    {
        private const string PostProcessingNamespace = "UnityEngine.Rendering.PostProcessing";
        private const int PresentationTypeHeaderSize = 16;
        private const int PresentationTypeMaximumSpan = 512;
        private const int PresentationTypeMaximumGap = 64;
        private readonly Dictionary<ulong, PresentationClass> presentationClasses = new Dictionary<ulong, PresentationClass>();
        private PresentationClass? presentationLocal, presentationManager, presentationLayer, presentationContext, presentationMonoBehaviour;
        private PresentationClass? presentationFsr, presentationDlss, presentationRect, presentationVector;
        private PresentationField? localRenderManagerField;
        private bool presentationMetadataReady;

        // All members below describe a single current read. Context.width/height,
        // jitter and the layer's per-render flags are deliberately not cached or
        // compared: the verified IL changes those during ordinary rendering.
        private sealed class PresentationState
        {
            internal bool Active, FinalBlit;
            internal int Mode, Quality, DisplayWidth, DisplayHeight, RenderWidth, RenderHeight;
            internal int ContextScreenWidth, ContextScreenHeight;
            internal ulong OriginalTargetTexture, LayerNativeVtable;
            internal float[] OriginalRect = Array.Empty<float>();
            internal ManagedIdentity Manager = new ManagedIdentity(), Layer = new ManagedIdentity();
            internal ManagedIdentity? Context, Upscaler;
        }

        private sealed class PresentationClass
        {
            internal ClassIdentity Identity = new ClassIdentity();
            internal string Name = String.Empty, Namespace = String.Empty;
            internal ulong Image, FieldArray;
            internal int FieldCount;
            internal byte[] Descriptors = Array.Empty<byte>();
            internal readonly Dictionary<string, int> Names = new Dictionary<string, int>(StringComparer.Ordinal);
            internal readonly Dictionary<string, PresentationField> Fields = new Dictionary<string, PresentationField>(StringComparer.Ordinal);
            internal bool NamesRead;
            internal int FirstOffset = Int32.MaxValue, EndOffset;
            internal bool ReadPlanReady;
            internal int DescriptorStart, DescriptorLength;
            internal readonly List<PresentationTypeReadRange> TypeReads = new List<PresentationTypeReadRange>();
        }

        // Only addresses and field membership persist. Each verification reads
        // fresh bytes; no buffer is shared across a matrix pair or a capture.
        private sealed class PresentationTypeReadRange
        {
            internal ulong Address;
            internal int Length;
            internal readonly List<PresentationField> Fields = new List<PresentationField>();
        }

        private sealed class PresentationField
        {
            internal string Name = String.Empty;
            internal int Index, Offset, Width;
            internal byte Code;
            internal ulong TypeAddress, TypeClass;
            internal byte[] TypeHeader = Array.Empty<byte>();
        }

        private void ResetPresentationMetadata()
        {
            presentationMetadataReady = false;
            presentationClasses.Clear();
            presentationLocal = presentationManager = presentationLayer = presentationContext = null;
            presentationMonoBehaviour = null;
            presentationFsr = presentationDlss = presentationRect = presentationVector = null;
            localRenderManagerField = null;
        }

        private void InitializePresentationMetadata()
        {
            ResetPresentationMetadata();
            if (localClass == null || cameraClass == null || probe.LocalClass == null)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Les types locaux manquent pour verifier le chemin de presentation.");
            CameraObjectReport managerProbe = UniqueObject("renderManager");
            if (!managerProbe.IdentityValidated || managerProbe.ActualType != "GameRenderManager" ||
                managerProbe.ClassHierarchy == null || managerProbe.ClassHierarchy.Count != 2 ||
                FullName(managerProbe.ClassHierarchy[0]) != "GameRenderManager" ||
                FullName(managerProbe.ClassHierarchy[1]) != "System.Object")
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Le gestionnaire de rendu local n'est pas confirme par le releve courant.");

            MonoClassReport localReport = UniqueClass(metadata.Classes, "EntityPlayerLocal", "");
            MonoFieldReport renderField = RequiredField(probe.LocalClass, "renderManager", "GameRenderManager", 0x12);
            MatchField(renderField, RequiredField(localReport, "renderManager", "GameRenderManager", 0x12));
            ulong gameImage = BitConverter.ToUInt64(localClass.Header, 0x40);
            presentationLocal = PresentationType(localClass.Address, "EntityPlayerLocal", "", gameImage);
            presentationManager = PresentationType(ParseAddress(managerProbe.ClassHierarchy[0].Address), "GameRenderManager", "", gameImage);
            // Retain the independently collected class identity as an anchor.
            ClassIdentity managerReported = ReadClassIdentity(managerProbe.ClassHierarchy[0]);
            ClassIdentity managerBase = ReadClassIdentity(managerProbe.ClassHierarchy[1]);
            if (managerReported.Size != presentationManager.Identity.Size ||
                presentationManager.Identity.Parent != managerBase.Address || managerBase.Parent != 0)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Le gestionnaire de rendu differe du releve courant.");
            localRenderManagerField = PresentationBind(presentationLocal, "renderManager", 0x12, 8, renderField.Offset);
            PresentationReferenceType(localRenderManagerField, presentationManager.Identity.Address);

            PresentationField player = PresentationBind(presentationManager, "player", 0x12, 8,
                RequiredField(managerProbe.ClassHierarchy[0], "player", "EntityPlayerLocal", 0x12).Offset);
            PresentationReferenceType(player, localClass.Address);
            PresentationField layer = PresentationBind(presentationManager, "layer", 0x12, 8,
                RequiredField(managerProbe.ClassHierarchy[0], "layer", PostProcessingNamespace + ".PostProcessLayer", 0x12).Offset);
            PresentationBind(presentationManager, "upscalingEnabled", 0x02, 1);
            presentationLayer = PresentationType(layer.TypeClass, "PostProcessLayer", PostProcessingNamespace);
            ulong postImage = presentationLayer.Image;
            ulong unityImage = BitConverter.ToUInt64(cameraClass.Header, 0x40);
            // PostProcessLayer is a MonoBehaviour. Its native wrapper uses the
            // same inherited UnityEngine.Object.m_CachedPtr already verified
            // for Camera, and Behaviour.isActiveAndEnabled is covered by the
            // native profile's exact getter signature at byte +0x39.
            presentationMonoBehaviour = PresentationType(presentationLayer.Identity.Parent, "MonoBehaviour", "UnityEngine", unityImage);
            CameraObjectReport cameraProbe = UniqueObject("playerCamera");
            if (cameraProbe.ClassHierarchy.Count < 2 || FullName(cameraProbe.ClassHierarchy[1]) != "UnityEngine.Behaviour" ||
                presentationMonoBehaviour.Identity.Parent != ParseAddress(cameraProbe.ClassHierarchy[1].Address) ||
                presentationMonoBehaviour.Identity.Size < NativeCameraProfile.ManagedNativePointerOffset + 8 ||
                presentationMonoBehaviour.Identity.Size > presentationLayer.Identity.Size)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "L'heritage natif du composant de post-traitement n'est pas confirme.");
            PresentationField layerCamera = PresentationBind(presentationLayer, "m_Camera", 0x12, 8);
            PresentationReferenceType(layerCamera, cameraClass.Address);
            PresentationField aa = PresentationBind(presentationLayer, "antialiasingMode", 0x11, 4);
            PresentationEnum(aa, "Antialiasing", null, postImage);
            PresentationBind(presentationLayer, "finalBlitToCameraTarget", 0x02, 1);
            PresentationBind(presentationLayer, "m_IsRenderingInSceneView", 0x02, 1);
            PresentationField target = PresentationBind(presentationLayer, "m_originalTargetTexture", 0x12, 8);
            PresentationType(target.TypeClass, "RenderTexture", "UnityEngine", unityImage);
            PresentationField context = PresentationBind(presentationLayer, "m_CurrentContext", 0x12, 8);
            presentationContext = PresentationType(context.TypeClass, "PostProcessRenderContext", PostProcessingNamespace, postImage);
            PresentationReferenceType(PresentationBind(presentationContext, "m_Camera", 0x12, 8), cameraClass.Address);
            PresentationReferenceType(PresentationBind(presentationContext, "<antialiasing>k__BackingField", 0x11, 4), aa.TypeClass);
            PresentationBind(presentationContext, "<screenWidth>k__BackingField", 0x08, 4);
            PresentationBind(presentationContext, "<screenHeight>k__BackingField", 0x08, 4);
            PresentationBind(presentationContext, "<stereoActive>k__BackingField", 0x02, 1);
            PresentationBind(presentationContext, "<isSceneView>k__BackingField", 0x02, 1);
            PresentationBind(presentationContext, "physicalCamera", 0x02, 1);

            PresentationField fsr = PresentationBind(presentationLayer, "fsr3", 0x12, 8);
            PresentationField dlss = PresentationBind(presentationLayer, "dlss", 0x12, 8);
            presentationFsr = PresentationType(fsr.TypeClass, "FSR3", PostProcessingNamespace, postImage);
            presentationDlss = PresentationType(dlss.TypeClass, "DLSS", PostProcessingNamespace, postImage);
            PresentationReferenceType(PresentationBind(presentationContext, "<superResolution3>k__BackingField", 0x12, 8), fsr.TypeClass);
            PresentationReferenceType(PresentationBind(presentationContext, "<deepLearningSuperSampling>k__BackingField", 0x12, 8), dlss.TypeClass);

            BindUpscalerFields(presentationFsr, true, unityImage);
            BindUpscalerFields(presentationDlss, false, unityImage);
            foreach (PresentationClass layout in presentationClasses.Values)
                PreparePresentationReadPlan(layout);
            presentationMetadataReady = true;
        }

        private void BindUpscalerFields(PresentationClass owner, bool fsr, ulong unityImage)
        {
            PresentationField quality = PresentationBind(owner, "qualityMode", 0x11, 4);
            PresentationEnum(quality, fsr ? "FSR3_Quality" : "DLSS_Quality", fsr ? "TND.FSR" : "TND.DLSS", 0);
            PresentationBind(owner, "isStereoRendering", 0x02, 1);
            PresentationField rect = PresentationBind(owner, "_originalRect", 0x11, 16);
            PresentationClass rectType = PresentationType(rect.TypeClass, "Rect", "UnityEngine", unityImage);
            if (presentationRect != null && presentationRect.Identity.Address != rectType.Identity.Address)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Les upscalers ne declarent pas le meme type Rect.");
            presentationRect = rectType;
            PresentationValueComponent(rectType, "m_XMin", 0x0C, 0, 16);
            PresentationValueComponent(rectType, "m_YMin", 0x0C, 4, 16);
            PresentationValueComponent(rectType, "m_Width", 0x0C, 8, 16);
            PresentationValueComponent(rectType, "m_Height", 0x0C, 12, 16);
            PresentationField display = PresentationBind(owner, fsr ? "_displaySize" : "displaySize", 0x11, 8);
            PresentationField render = PresentationBind(owner, fsr ? "_maxRenderSize" : "renderSize", 0x11, 8);
            PresentationReferenceType(render, display.TypeClass);
            PresentationClass vector = PresentationType(display.TypeClass, "Vector2Int", "UnityEngine", unityImage);
            if (presentationVector != null && presentationVector.Identity.Address != vector.Identity.Address)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Les upscalers ne declarent pas le meme type Vector2Int.");
            presentationVector = vector;
            PresentationValueComponent(vector, "m_X", 0x08, 0, 8);
            PresentationValueComponent(vector, "m_Y", 0x08, 4, 8);
        }

        private PresentationState ReadPresentation(ulong local, ulong domain, ulong camera)
        {
            if (!presentationMetadataReady || presentationLocal == null || presentationManager == null ||
                presentationLayer == null || presentationContext == null || presentationFsr == null ||
                presentationDlss == null || presentationMonoBehaviour == null || localRenderManagerField == null)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Les metadonnees de presentation ne sont pas initialisees.");
            VerifyPresentationLayout(presentationLocal);
            ulong managerAddress = U64(local + (ulong)localRenderManagerField.Offset);
            if (managerAddress == 0)
                throw PresentationFault("Le gestionnaire de rendu local est absent.", "GameRenderManager.null");
            ulong managerRuntime = VerifyPresentationLayout(presentationManager);
            ManagedIdentity manager = ReadManagedIdentity(managerAddress, presentationManager.Identity, domain, false,
                observedRuntime: managerRuntime);
            byte[] managerData = PresentationData(presentationManager, managerAddress);
            if (PresentationU64(presentationManager, managerData, "player") != local)
                throw PresentationFault("Le gestionnaire de rendu appartient a un autre joueur.", "GameRenderManager.player");
            bool enabled = PresentationBool(presentationManager, managerData, "upscalingEnabled");
            ulong layerAddress = PresentationU64(presentationManager, managerData, "layer");
            if (layerAddress == 0)
                throw PresentationFault("Le composant de post-traitement local est absent.", "PostProcessLayer.null");
            ulong layerRuntime = VerifyPresentationLayout(presentationLayer);
            VerifyPresentationLayout(presentationClasses[presentationLayer.Fields["antialiasingMode"].TypeClass]);
            ManagedIdentity layer = ReadManagedIdentity(layerAddress, presentationLayer.Identity, domain, true,
                observedRuntime: layerRuntime);
            byte[] layerData = PresentationData(presentationLayer, layerAddress);
            if (PresentationU64(presentationLayer, layerData, "m_Camera") != camera)
                throw PresentationFault("Le composant de post-traitement utilise une autre camera.", "PostProcessLayer.m_Camera");
            int mode = PresentationI32(presentationLayer, layerData, "antialiasingMode");
            if (mode < 0 || mode > 10)
                throw PresentationFault("Mode d'anticrenelage hors limites.", "PostProcessLayer.antialiasingMode");
            bool finalBlit = PresentationBool(presentationLayer, layerData, "finalBlitToCameraTarget");
            bool scene = PresentationBool(presentationLayer, layerData, "m_IsRenderingInSceneView");
            ulong target = PresentationU64(presentationLayer, layerData, "m_originalTargetTexture");
            if (scene || target != 0)
                throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "Le post-traitement ne presente pas la camera de jeu directement a l'ecran.", false,
                    "PRESENTATION", scene ? "PostProcessLayer.sceneView" : "PostProcessLayer.originalTargetTexture");
            PresentationState state = new PresentationState { Manager = manager, Layer = layer, Mode = mode,
                Active = enabled, FinalBlit = finalBlit, OriginalTargetTexture = target };
            if (!enabled && mode >= 0 && mode <= 3)
            {
                VerifyPresentationOwners(local, camera, state);
                return state;
            }
            if (!enabled && (mode == 6 || mode == 7))
                throw PresentationFault("Les reglages de reconstruction sont en transition ; nouvelle capture au prochain passage.", "Upscaler.activationTransition");
            if (!enabled || (mode != 6 && mode != 7))
                throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "Ce mode de reconstruction d'image n'a pas de chemin de presentation valide dans ce profil.", false,
                    "PRESENTATION", "Upscaler.modeUnsupported");

            VerifyPresentationLayout(presentationMonoBehaviour);
            ValidatePresentationLayerNative(state, false);

            PresentationClass upscalerClass = mode == 6 ? presentationFsr : presentationDlss;
            string upscalerField = mode == 6 ? "fsr3" : "dlss";
            ulong upscalerAddress = PresentationU64(presentationLayer, layerData, upscalerField);
            ulong contextAddress = PresentationU64(presentationLayer, layerData, "m_CurrentContext");
            if (upscalerAddress == 0 || contextAddress == 0)
                throw PresentationFault("Le contexte de reconstruction n'est pas encore disponible.", "Upscaler.contextOrInstanceNull");
            ulong contextRuntime = VerifyPresentationLayout(presentationContext);
            ulong upscalerRuntime = VerifyPresentationLayout(upscalerClass);
            VerifyPresentationLayout(presentationRect!);
            VerifyPresentationLayout(presentationVector!);
            // Enum metadata is separate from the containing object and must
            // retain its actual Int32 backing layout, including after reloads.
            VerifyPresentationLayout(presentationClasses[upscalerClass.Fields["qualityMode"].TypeClass]);
            state.Context = ReadManagedIdentity(contextAddress, presentationContext.Identity, domain, false,
                observedRuntime: contextRuntime);
            state.Upscaler = ReadManagedIdentity(upscalerAddress, upscalerClass.Identity, domain, false,
                observedRuntime: upscalerRuntime);
            byte[] contextData = PresentationData(presentationContext, contextAddress);
            if (PresentationU64(presentationContext, contextData, "m_Camera") != camera ||
                PresentationI32(presentationContext, contextData, "<antialiasing>k__BackingField") != mode ||
                PresentationU64(presentationContext, contextData, mode == 6 ? "<superResolution3>k__BackingField" : "<deepLearningSuperSampling>k__BackingField") != upscalerAddress)
                throw PresentationFault("Le contexte de reconstruction ne correspond pas a la camera et au mode actifs.", "Upscaler.contextIdentity");
            if (PresentationBool(presentationContext, contextData, "<stereoActive>k__BackingField") ||
                PresentationBool(presentationContext, contextData, "<isSceneView>k__BackingField") ||
                PresentationBool(presentationContext, contextData, "physicalCamera"))
                throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "La reconstruction stereo, SceneView ou camera physique n'est pas prise en charge.", false,
                    "PRESENTATION", "Upscaler.contextConfiguration");
            state.ContextScreenWidth = PresentationI32(presentationContext, contextData, "<screenWidth>k__BackingField");
            state.ContextScreenHeight = PresentationI32(presentationContext, contextData, "<screenHeight>k__BackingField");
            byte[] upscalerData = PresentationData(upscalerClass, upscalerAddress);
            state.Quality = PresentationI32(upscalerClass, upscalerData, "qualityMode");
            if (state.Quality <= 0 || state.Quality > 32)
                throw PresentationFault("La qualite de reconstruction n'est pas active ou reconnue.", "Upscaler.qualityMode");
            if (PresentationBool(upscalerClass, upscalerData, "isStereoRendering"))
                throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "La reconstruction stereo n'est pas prise en charge.", false,
                    "PRESENTATION", "Upscaler.isStereoRendering");
            int rectOffset = PresentationOffset(upscalerClass, "_originalRect");
            state.OriginalRect = new float[4];
            for (int i = 0; i < 4; i++) state.OriginalRect[i] = BitConverter.ToSingle(upscalerData, rectOffset + i * 4);
            int displayOffset = PresentationOffset(upscalerClass, mode == 6 ? "_displaySize" : "displaySize");
            int renderOffset = PresentationOffset(upscalerClass, mode == 6 ? "_maxRenderSize" : "renderSize");
            state.DisplayWidth = BitConverter.ToInt32(upscalerData, displayOffset);
            state.DisplayHeight = BitConverter.ToInt32(upscalerData, displayOffset + 4);
            state.RenderWidth = BitConverter.ToInt32(upscalerData, renderOffset);
            state.RenderHeight = BitConverter.ToInt32(upscalerData, renderOffset + 4);
            VerifyPresentationOwners(local, camera, state);
            return state;
        }

        private void VerifyPresentationOwners(ulong local, ulong camera, PresentationState state)
        {
            byte[] manager = PresentationData(presentationManager!, state.Manager.Instance);
            byte[] layer = PresentationData(presentationLayer!, state.Layer.Instance);
            if (U64(local + (ulong)localRenderManagerField!.Offset) != state.Manager.Instance ||
                PresentationU64(presentationManager!, manager, "player") != local ||
                PresentationU64(presentationManager!, manager, "layer") != state.Layer.Instance ||
                PresentationBool(presentationManager!, manager, "upscalingEnabled") != state.Active ||
                PresentationU64(presentationLayer!, layer, "m_Camera") != camera ||
                PresentationI32(presentationLayer!, layer, "antialiasingMode") != state.Mode ||
                PresentationBool(presentationLayer!, layer, "finalBlitToCameraTarget") != state.FinalBlit ||
                PresentationBool(presentationLayer!, layer, "m_IsRenderingInSceneView") ||
                PresentationU64(presentationLayer!, layer, "m_originalTargetTexture") != state.OriginalTargetTexture)
                throw PresentationFault("Les proprietaires du chemin de presentation ont change pendant la lecture.", "Presentation.ownerChanged");
            if (state.Active)
            {
                if (state.Context == null || state.Upscaler == null ||
                    PresentationU64(presentationLayer!, layer, "m_CurrentContext") != state.Context.Instance ||
                    PresentationU64(presentationLayer!, layer, state.Mode == 6 ? "fsr3" : "dlss") != state.Upscaler.Instance)
                    throw PresentationFault("Une reference de reconstruction a change pendant la lecture.", "Upscaler.referenceChanged");
                byte[] context = PresentationData(presentationContext!, state.Context.Instance);
                if (PresentationU64(presentationContext!, context, "m_Camera") != camera ||
                    PresentationI32(presentationContext!, context, "<antialiasing>k__BackingField") != state.Mode ||
                    PresentationU64(presentationContext!, context, state.Mode == 6 ? "<superResolution3>k__BackingField" : "<deepLearningSuperSampling>k__BackingField") != state.Upscaler.Instance ||
                    PresentationI32(presentationContext!, context, "<screenWidth>k__BackingField") != state.ContextScreenWidth ||
                    PresentationI32(presentationContext!, context, "<screenHeight>k__BackingField") != state.ContextScreenHeight ||
                    PresentationBool(presentationContext!, context, "<stereoActive>k__BackingField") ||
                    PresentationBool(presentationContext!, context, "<isSceneView>k__BackingField") ||
                    PresentationBool(presentationContext!, context, "physicalCamera"))
                    throw PresentationFault("Le contexte de reconstruction a change pendant la lecture.", "Upscaler.contextChanged");
            }
            VerifyPresentationObject(state.Manager, presentationManager!.Identity);
            if (state.Active) ValidatePresentationLayerNative(state, true);
            VerifyPresentationObject(state.Layer, presentationLayer!.Identity, true);
            if (state.Context != null) VerifyPresentationObject(state.Context, presentationContext!.Identity);
            if (state.Upscaler != null) VerifyPresentationObject(state.Upscaler,
                state.Mode == 6 ? presentationFsr!.Identity : presentationDlss!.Identity);
        }

        private void VerifyPresentationObject(ManagedIdentity identity, ClassIdentity expected, bool native = false)
        {
            byte[] header = Read(identity.Instance, native ? 24 : 16);
            byte[] table = Read(identity.Table, 24);
            if (BitConverter.ToUInt64(header, 0) != identity.Table ||
                (native && BitConverter.ToUInt64(header, NativeCameraProfile.ManagedNativePointerOffset) != identity.Native) ||
                BitConverter.ToUInt64(table, 0) != expected.Address ||
                BitConverter.ToUInt64(table, 16) != identity.Domain || U64(identity.Slot) != identity.Table ||
                U64(expected.Address + 0xD0) != identity.Runtime)
                throw PresentationFault("Une identite Mono de presentation a change pendant la lecture.", "Presentation.objectIdentityChanged");
        }

        private void ValidatePresentationLayerNative(PresentationState state, bool closing)
        {
            if (state.Layer.Native == 0)
                throw PresentationFault("Le composant de reconstruction a ete detruit ou n'est pas initialise.", "PostProcessLayer.nativeNull");
            RequirePointer(state.Layer.Native);
            byte[] header = Read(state.Layer.Native, 0x40);
            ulong table = BitConverter.ToUInt64(header, 0);
            RequireReadOnlyPointer(table, 8);
            if (!InText(U64(table)))
                throw PresentationFault("La table native du composant de reconstruction n'est pas valide.", "PostProcessLayer.nativeVtable");
            if (header[NativeCameraProfile.ActiveOffset] == 0)
                throw Fault("CAMERA_INACTIVE", "Le composant de reconstruction est desactive ; ses anciens reglages ne peuvent pas valider une camera.", true,
                    "PRESENTATION", "PostProcessLayer.inactive");
            if (closing && state.LayerNativeVtable != table)
                throw PresentationFault("L'identite native du composant de reconstruction a change.", "PostProcessLayer.nativeVtableChanged");
            state.LayerNativeVtable = table;
        }

        private static string? PresentationDifference(PresentationState before, PresentationState after)
        {
            string? changed = ManagedDifference(before.Manager, after.Manager, "RenderManager") ??
                ManagedDifference(before.Layer, after.Layer, "PostProcessLayer");
            if (changed != null) return changed;
            if (before.Active != after.Active || before.Mode != after.Mode) return "Upscaler.modeChanged";
            if (before.FinalBlit != after.FinalBlit || before.OriginalTargetTexture != after.OriginalTargetTexture)
                return "PostProcessLayer.finalOutputChanged";
            if (!before.Active) return null;
            if (before.LayerNativeVtable != after.LayerNativeVtable) return "PostProcessLayer.nativeVtableChanged";
            if (before.Context == null || after.Context == null || before.Upscaler == null || after.Upscaler == null)
                return "Upscaler.contextMissing";
            changed = ManagedDifference(before.Context, after.Context, "PostProcessContext") ??
                ManagedDifference(before.Upscaler, after.Upscaler, "Upscaler");
            if (changed != null) return changed;
            if (before.Quality != after.Quality) return "Upscaler.qualityChanged";
            if (!SameFloats(before.OriginalRect, after.OriginalRect)) return "Upscaler.originalRectChanged";
            if (before.DisplayWidth != after.DisplayWidth || before.DisplayHeight != after.DisplayHeight ||
                before.ContextScreenWidth != after.ContextScreenWidth || before.ContextScreenHeight != after.ContextScreenHeight)
                return "Upscaler.displaySizeChanged";
            if (before.RenderWidth != after.RenderWidth || before.RenderHeight != after.RenderHeight)
                return "Upscaler.renderSizeChanged";
            return null;
        }

        private static void ValidatePresentationForSample(PresentationState state, NativeSample sample)
        {
            if (!state.Active) return;
            if (sample.Orthographic != 0)
                throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "La reconstruction orthographique n'est pas prise en charge.", false,
                    "PRESENTATION", "Upscaler.orthographic");
            if (state.OriginalRect.Length != 4 || !AllFinite(state.OriginalRect) ||
                Math.Abs(state.OriginalRect[0]) > 0.000001f || Math.Abs(state.OriginalRect[1]) > 0.000001f ||
                Math.Abs(state.OriginalRect[2] - 1f) > 0.000001f || Math.Abs(state.OriginalRect[3] - 1f) > 0.000001f)
                throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "La presentation reconstruite doit couvrir l'image complete pour ce profil.", false,
                    "PRESENTATION", "Upscaler.originalRectNotFullBackbuffer");
            if (state.DisplayWidth != sample.Width || state.DisplayHeight != sample.Height ||
                state.ContextScreenWidth != state.DisplayWidth || state.ContextScreenHeight != state.DisplayHeight)
                throw PresentationFault("La taille finale du post-traitement ne correspond pas a la sortie camera.", "Upscaler.displaySizeMismatch");
            if (state.RenderWidth < 1 || state.RenderHeight < 1 || state.RenderWidth > state.DisplayWidth || state.RenderHeight > state.DisplayHeight)
                throw PresentationFault("La taille intermediaire du post-traitement est incoherente.", "Upscaler.renderSizeInvalid");
        }

        private PresentationClass PresentationType(ulong address, string name, string? ns, ulong expectedImage = 0)
        {
            RequirePointer(address);
            if (presentationClasses.TryGetValue(address, out PresentationClass? cached))
            {
                if (cached.Name != name || (ns != null && cached.Namespace != ns) || (expectedImage != 0 && cached.Image != expectedImage))
                    throw Fault("METADONNEES_CAMERA_INVALIDES", "Un type de presentation est utilise avec une identite contradictoire.");
                return cached;
            }
            if (presentationClasses.Count >= 24)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Trop de dispositions de presentation.");
            byte[] header = Read(address, 0x110);
            string actualNamespace = ns ?? PresentationName(BitConverter.ToUInt64(header, 0x50));
            int size = BitConverter.ToInt32(header, 0x1C), count = BitConverter.ToInt32(header, 0x100);
            ulong image = BitConverter.ToUInt64(header, 0x40), fields = BitConverter.ToUInt64(header, 0x98);
            if (count < 0 || count > 512 || (expectedImage != 0 && image != expectedImage))
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Assembly ou nombre de champs de presentation incoherent.");
            ClassIdentity identity = ReadClassIdentity(new MonoClassReport { Address = "0x" + address.ToString("X"),
                Name = name, Namespace = actualNamespace, InstanceSize = size });
            if (BitConverter.ToInt32(identity.Header, 0x100) != count ||
                BitConverter.ToUInt64(identity.Header, 0x98) != fields ||
                BitConverter.ToUInt64(identity.Header, 0x40) != image)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Une disposition de presentation a change pendant son inspection.");
            byte[] descriptors = count == 0 ? Array.Empty<byte>() : Read(fields, count * 32);
            for (int i = 0; i < count; i++)
                if (BitConverter.ToUInt64(descriptors, i * 32 + 16) != address)
                    throw Fault("METADONNEES_CAMERA_INVALIDES", "Proprietaire de champ de presentation incoherent.");
            PresentationClass result = new PresentationClass { Identity = identity, Name = name, Namespace = actualNamespace,
                Image = image, FieldArray = fields, FieldCount = count, Descriptors = descriptors };
            presentationClasses.Add(address, result);
            return result;
        }

        private PresentationField PresentationBind(PresentationClass owner, string name, byte code, int width, int? knownOffset = null)
        {
            if (owner.Fields.TryGetValue(name, out PresentationField? already))
            {
                if (already.Code != code || already.Width != width || (knownOffset.HasValue && already.Offset != knownOffset.Value))
                    throw Fault("METADONNEES_CAMERA_INVALIDES", "Description de champ de presentation contradictoire.");
                return already;
            }
            int match = -1;
            if (knownOffset.HasValue)
            {
                for (int i = 0; i < owner.FieldCount; i++)
                    if (BitConverter.ToInt32(owner.Descriptors, i * 32 + 24) == knownOffset.Value &&
                        NameMatches(BitConverter.ToUInt64(owner.Descriptors, i * 32 + 8), name))
                    { if (match != -1) throw Fault("METADONNEES_CAMERA_INVALIDES", "Champ de presentation ambigu."); match = i; }
            }
            else
            {
                if (!owner.NamesRead)
                {
                    for (int i = 0; i < owner.FieldCount; i++)
                    {
                        string fieldName = PresentationName(BitConverter.ToUInt64(owner.Descriptors, i * 32 + 8));
                        if (!owner.Names.TryAdd(fieldName, i))
                            throw Fault("METADONNEES_CAMERA_INVALIDES", "Nom de champ de presentation duplique.");
                    }
                    owner.NamesRead = true;
                }
                owner.Names.TryGetValue(name, out match);
                if (!owner.Names.ContainsKey(name)) match = -1;
            }
            if (match < 0) throw Fault("METADONNEES_CAMERA_INVALIDES", "Champ de presentation absent : " + owner.Name + "." + name + ".");
            int descriptor = match * 32;
            int offset = BitConverter.ToInt32(owner.Descriptors, descriptor + 24);
            ulong typeAddress = BitConverter.ToUInt64(owner.Descriptors, descriptor);
            byte[] type = Read(typeAddress, 16);
            if (type[10] != code || (BitConverter.ToUInt16(type, 8) & 0x50) != 0 || offset < 16 || offset > owner.Identity.Size - width)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Type, portee ou offset de presentation invalide : " + name + ".");
            foreach (PresentationField other in owner.Fields.Values)
                if (offset < other.Offset + other.Width && other.Offset < offset + width)
                    throw Fault("METADONNEES_CAMERA_INVALIDES", "Champs utiles de presentation superposes.");
            PresentationField result = new PresentationField { Name = name, Index = match, Offset = offset, Width = width,
                Code = code, TypeAddress = typeAddress, TypeClass = BitConverter.ToUInt64(type, 0), TypeHeader = type };
            owner.Fields.Add(name, result);
            owner.FirstOffset = Math.Min(owner.FirstOffset, offset);
            owner.EndOffset = Math.Max(owner.EndOffset, offset + width);
            return result;
        }

        private void PresentationEnum(PresentationField field, string name, string? ns, ulong expectedImage)
        {
            PresentationClass type = PresentationType(field.TypeClass, name, ns, expectedImage);
            if (type.Identity.Parent == 0) throw Fault("METADONNEES_CAMERA_INVALIDES", "Enum de presentation sans heritage.");
            byte[] parent = Read(type.Identity.Parent, 0x60);
            VerifyName(BitConverter.ToUInt64(parent, 0x48), "Enum");
            VerifyName(BitConverter.ToUInt64(parent, 0x50), "System");
            PresentationValueComponent(type, "value__", 0x08, 0, 4);
        }

        private void PresentationValueComponent(PresentationClass owner, string name, byte code, int unboxedOffset, int valueSize)
        {
            PresentationField field = PresentationBind(owner, name, code, 4);
            if (owner.Identity.Size != 16 + valueSize || field.Offset != 16 + unboxedOffset)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Disposition inline de presentation non confirmee : " + owner.Name + "." + name + ".");
        }

        private static void PresentationReferenceType(PresentationField field, ulong expected)
        {
            if (field.TypeClass != expected)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Le type declare d'une reference de presentation est different.");
        }

        private static void PreparePresentationReadPlan(PresentationClass layout)
        {
            layout.ReadPlanReady = false;
            layout.DescriptorStart = 0;
            layout.DescriptorLength = 0;
            layout.TypeReads.Clear();
            if (layout.Fields.Count == 0)
            {
                layout.ReadPlanReady = true;
                return;
            }

            int first = Int32.MaxValue, last = -1;
            var ordered = new List<PresentationField>(layout.Fields.Values);
            foreach (PresentationField field in ordered)
            {
                if (field.Index < 0 || field.Index >= layout.FieldCount ||
                    field.TypeAddress < 0x10000 || field.TypeAddress > 0x00007FFFFFFFFFFFUL - PresentationTypeHeaderSize)
                    throw Fault("METADONNEES_CAMERA_INVALIDES", "Plage de metadonnee de presentation invalide.");
                first = Math.Min(first, field.Index);
                last = Math.Max(last, field.Index);
            }
            layout.DescriptorStart = checked(first * 32);
            layout.DescriptorLength = checked((last - first + 1) * 32);
            if (layout.DescriptorLength < 32 || layout.DescriptorLength > 16384 ||
                layout.DescriptorStart > layout.Descriptors.Length - layout.DescriptorLength)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Fenetre des champs de presentation hors limites.");

            ordered.Sort((left, right) => left.TypeAddress.CompareTo(right.TypeAddress));
            PresentationTypeReadRange? range = null;
            foreach (PresentationField field in ordered)
            {
                ulong end = field.TypeAddress + PresentationTypeHeaderSize;
                bool combine = false;
                int length = PresentationTypeHeaderSize;
                if (range != null)
                {
                    ulong previousEnd = range.Address + (ulong)range.Length;
                    ulong span = end - range.Address;
                    // Equal addresses share one read but keep every field's
                    // validation. A header crossing a page is read alone with
                    // its original 16-byte request, never widened into a group.
                    combine = (range.Address == field.TypeAddress && range.Length == PresentationTypeHeaderSize) ||
                        ((range.Address >> 12) == ((end - 1) >> 12) &&
                            span <= PresentationTypeMaximumSpan &&
                            (field.TypeAddress <= previousEnd || field.TypeAddress - previousEnd <= PresentationTypeMaximumGap));
                    if (combine) length = (int)span;
                }
                if (!combine)
                {
                    range = new PresentationTypeReadRange { Address = field.TypeAddress, Length = PresentationTypeHeaderSize };
                    layout.TypeReads.Add(range);
                }
                else range!.Length = length;
                range!.Fields.Add(field);
            }
            layout.ReadPlanReady = true;
        }

        private ulong VerifyPresentationLayout(PresentationClass layout)
        {
            if (!layout.ReadPlanReady)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Le plan de lecture des metadonnees de presentation manque.");
            byte[] current = Read(layout.Identity.Address, 0x110);
            int[] offsets = { 0x1B, 0x1C, 0x30, 0x40, 0x48, 0x50, 0x58, 0x98, 0x100 };
            int[] widths = { 1, 4, 8, 8, 8, 8, 4, 8, 4 };
            for (int i = 0; i < offsets.Length; i++)
                for (int j = 0; j < widths[i]; j++)
                    if (current[offsets[i] + j] != layout.Identity.Header[offsets[i] + j])
                        throw PresentationFault("Une disposition Mono de presentation a change depuis l'initialisation.", "Presentation.layoutChanged");
            ulong runtime = BitConverter.ToUInt64(current, 0xD0);
            if (layout.Fields.Count == 0) return runtime;
            byte[] fields = Read(checked(layout.FieldArray + (ulong)layout.DescriptorStart), layout.DescriptorLength);
            foreach (PresentationField field in layout.Fields.Values)
            {
                int start = field.Index * 32;
                int relative = start - layout.DescriptorStart;
                for (int i = 0; i < 32; i++)
                    if (fields[relative + i] != layout.Descriptors[start + i])
                        throw PresentationFault("Un champ de presentation a change depuis l'initialisation.", "Presentation.fieldChanged");
            }
            foreach (PresentationTypeReadRange range in layout.TypeReads)
            {
                byte[] types = Read(range.Address, range.Length);
                foreach (PresentationField field in range.Fields)
                {
                    int offset = checked((int)(field.TypeAddress - range.Address));
                    if (BitConverter.ToUInt64(types, offset) != field.TypeClass || types[offset + 10] != field.Code ||
                        (BitConverter.ToUInt16(types, offset + 8) & 0x50) != 0)
                        throw PresentationFault("Le type ou la portee d'un champ de presentation a change.", "Presentation.fieldTypeChanged");
                }
            }
            return runtime;
        }

        private byte[] PresentationData(PresentationClass layout, ulong instance)
        {
            int length = layout.EndOffset - layout.FirstOffset;
            if (layout.FirstOffset < 16 || length < 1 || length > 16384)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Plage des donnees de presentation hors limites.");
            return Read(instance + (ulong)layout.FirstOffset, length);
        }
        private static int PresentationOffset(PresentationClass layout, string field) => layout.Fields[field].Offset - layout.FirstOffset;
        private static ulong PresentationU64(PresentationClass layout, byte[] bytes, string field) => BitConverter.ToUInt64(bytes, PresentationOffset(layout, field));
        private static int PresentationI32(PresentationClass layout, byte[] bytes, string field) => BitConverter.ToInt32(bytes, PresentationOffset(layout, field));
        private static bool PresentationBool(PresentationClass layout, byte[] bytes, string field)
        {
            byte value = bytes[PresentationOffset(layout, field)];
            if (value > 1) throw PresentationFault("Valeur booleenne de presentation invalide.", "Presentation.booleanInvalid");
            return value != 0;
        }
        private string PresentationName(ulong address)
        {
            RequirePointer(address);
            List<byte> bytes = new List<byte>();
            while (bytes.Count < 256)
            {
                ulong current = address + (ulong)bytes.Count;
                int count = Math.Min(32, Math.Min(256 - bytes.Count, 4096 - (int)(current & 4095)));
                byte[] block = Read(current, count);
                foreach (byte value in block)
                {
                    if (value == 0) return new UTF8Encoding(false, true).GetString(bytes.ToArray());
                    bytes.Add(value);
                }
            }
            throw Fault("METADONNEES_CAMERA_INVALIDES", "Nom de metadonnee de presentation trop long.");
        }
        private static NativeFault PresentationFault(string message, string detail) =>
            Fault("CAMERA_CAPTURE_INSTABLE", message, true, "PRESENTATION", detail);
    }
}
