using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using SevenDaysEsp;

namespace SevenDaysLoader.Services;

public static class PlayerControlExecutor
{
    public static PlayerControlSubmission Execute(PlayerControlRequest request, uint pid, LiveEntitySnapshot snapshot,
        double ageMs, Func<bool> verifyProcess, Func<ControlSubmitResult> submit, CancellationToken token)
    {
        var result = new PlayerControlSubmission { Sequence = request.Sequence, RequestId = request.RequestId,
            ProcessId = request.ExpectedProcessId, PlayerContextId = request.ExpectedPlayerContextId };
        try
        {
            PlayerControlPolicy.ValidateRequest(request);
            token.ThrowIfCancellationRequested();
            if (PlayerControlPolicy.IsExpired(request, Stopwatch.GetTimestamp()))
                throw new InvalidOperationException("Demande expirée ; aucune transmission au module.");
            if (pid != request.ExpectedProcessId || !FeedSample.IsValid(snapshot) || !double.IsFinite(ageMs) ||
                ageMs < 0 || ageMs >= FeedSample.LifetimeMs || snapshot.PlayerContextId != request.ExpectedPlayerContextId ||
                snapshot.LocalId != request.ExpectedPlayerId)
                throw new InvalidOperationException("Le personnage ou la partie ont changé avant la commande.");
            if (!verifyProcess()) throw new InvalidOperationException("Le processus du jeu n’est plus celui de la demande.");
            token.ThrowIfCancellationRequested();
            if (PlayerControlPolicy.IsExpired(request, Stopwatch.GetTimestamp()))
                throw new InvalidOperationException("Demande expirée pendant la vérification du jeu.");
            var written = submit();
            result.Accepted = written.Accepted; result.WriteAttempted = written.WriteAttempted;
            result.CommitAttempted = written.CommitAttempted; result.ModuleRequestId = written.RequestId;
            result.Code = written.Code; result.Message = written.Message;
        }
        catch (OperationCanceledException) when (token.IsCancellationRequested)
        { result.Code = "ANNULE"; result.Message = "Lecteur arrêté avant confirmation de la commande."; }
        catch (Exception error) when (error is IOException || error is InvalidDataException || error is InvalidOperationException ||
            error is ArgumentException || error is OverflowException)
        {
            result.Code = "COMMANDE_NON_CONFIRMEE";
            string detail = error.GetBaseException().Message;
            result.Message = detail.Length <= 1024 ? detail : detail[..1024];
        }
        return result;
    }
}
