using System;

namespace SevenDaysLoader.Services;

// Each capture starts a new period. A slow acquisition never creates a queue
// of missed ticks, and never receives an additional fixed sleep afterwards.
public static class CaptureCadence
{
    public const int DefaultIntervalMs = 50;

    public static int RemainingDelayMs(int intervalMs, double elapsedMs)
    {
        int interval = Math.Clamp(intervalMs, 50, 2000);
        if (!double.IsFinite(elapsedMs) || elapsedMs < 0) return interval;
        if (elapsedMs >= interval) return 0;
        return (int)Math.Ceiling(interval - elapsedMs);
    }
}
