using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class PlayerDmaStatTests
{
    private static void Check(bool ok, string message) { if (!ok) throw new Exception(message); }
    private static PlayerDmaStatRequest Request(PlayerDmaStatKind kind = PlayerDmaStatKind.Health, float? desired = null) => new()
    {
        Sequence = 1, RequestId = Guid.NewGuid().ToString("N"), ExpectedProcessId = 111,
        ExpectedPlayerContextId = Guid.NewGuid().ToString("N"), ExpectedPlayerId = 2,
        Stat = kind, DesiredValue = desired, RequestedTimestamp = Stopwatch.GetTimestamp()
    };

    public static Task ExplicitValidatedOperations()
    {
        foreach (PlayerDmaStatKind target in Enum.GetValues<PlayerDmaStatKind>())
        {
            if (!PlayerDmaStatPolicy.Known(target)) continue;
            PlayerDmaStatPolicy.Validate(Request(target));
            if (target != PlayerDmaStatKind.Level)
                PlayerDmaStatPolicy.Validate(Request(target, target == PlayerDmaStatKind.SkillPoints ? 10f : 125.5f));
        }
        foreach (float bad in new[] { -1f, float.NaN, float.PositiveInfinity, 10001f })
        {
            bool rejected = false;
            try { PlayerDmaStatPolicy.Validate(Request(PlayerDmaStatKind.Health, bad)); }
            catch (InvalidDataException) { rejected = true; }
            Check(rejected, "Invalid stat request accepted.");
        }
        bool fractionalRejected = false;
        try { PlayerDmaStatPolicy.Validate(Request(PlayerDmaStatKind.SkillPoints, 0.5f)); }
        catch (InvalidDataException) { fractionalRejected = true; }
        Check(fractionalRejected, "Fractional points accepted.");
        bool levelWriteRejected = false;
        try { PlayerDmaStatPolicy.Validate(Request(PlayerDmaStatKind.Level, 30f)); }
        catch (InvalidDataException) { levelWriteRejected = true; }
        Check(levelWriteRejected, "Level is not read only.");
        bool unknownRejected = false;
        try { PlayerDmaStatPolicy.Validate(Request((PlayerDmaStatKind)99)); }
        catch (InvalidDataException) { unknownRejected = true; }
        Check(unknownRejected, "Unrecognized operation accepted.");
        return Task.CompletedTask;
    }

    public static Task NoReplayAndSinglePending()
    {
        var state = new WorkerReadOptionsState(null);
        var a = Request(PlayerDmaStatKind.Stamina, 90f);
        var b = Request(PlayerDmaStatKind.Health, 55f); b.Sequence = a.Sequence + 1;
        Check(state.TryQueueStatRequest(a), "First request not queued.");
        Check(!state.TryQueueStatRequest(b), "Second request replaced still-pending intent.");
        PlayerDmaStatRequest? consumed = state.TakeStatRequest();
        Check(consumed != null && consumed.RequestId == a.RequestId, "Request not consumed once.");
        Check(state.TakeStatRequest() == null, "Consumed request replayed.");
        Check(!state.TryQueueStatRequest(a), "Old sequence replayed.");
        Check(state.TryQueueStatRequest(b), "Fresh request rejected.");
        state.ClearStatRequest();
        Check(state.TakeStatRequest() == null, "Stop left a pending request.");
        Check(!PlayerDmaStatPolicy.IsExpired(b, Stopwatch.GetTimestamp()), "Fresh request expired prematurely.");
        b.RequestedTimestamp = Stopwatch.GetTimestamp() - 10L * Stopwatch.Frequency;
        Check(PlayerDmaStatPolicy.IsExpired(b, Stopwatch.GetTimestamp()), "Old request never expires.");
        return Task.CompletedTask;
    }
}
