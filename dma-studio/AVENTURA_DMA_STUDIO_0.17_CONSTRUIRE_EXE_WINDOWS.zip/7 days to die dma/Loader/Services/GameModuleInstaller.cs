using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace SevenDaysLoader.Services;

public sealed class GameModulePackage
{
    public string Format { get; set; } = "";
    public string Version { get; set; } = "";
    public string GameAssemblySha256 { get; set; } = "";
    public Dictionary<string, string> Files { get; set; } = new(StringComparer.Ordinal);
}

public sealed record GameModuleInstallResult(string Directory, string BackupDirectory, string Message);

// Copies only our two packaged files. No DLL in the game's Managed directory is
// replaced, no service is installed and no game/server setting is edited.
public static class GameModuleInstaller
{
    public const string ModuleName = "SevenDaysDmaControl";
    public const string PackageFormat = "DMA7DTD.ModulePackage/1";
    public const string InstallFormat = "DMA7DTD.ModuleInstallation/1";
    public const string GameAssemblyHash = "cb54022ccc862aa673e0ee55dafe67d842b364c80df6916958d171e959656c58";
    private const string MarkerName = "dma7dtd-install.json";
    private static readonly string[] PayloadNames = { "SevenDaysDmaControl.dll", "ModInfo.xml" };

    public static string DefaultGameDirectory => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
        "Steam", "steamapps", "common", "7 Days To Die");
    public static string DefaultModsDirectory => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "7DaysToDie", "Mods");

    public static GameModuleInstallResult Install(string packageDirectory, string gameDirectory, string modsDirectory)
    {
        EnsureGameStopped();
        string game = FullDirectory(gameDirectory), mods = FullDirectory(modsDirectory), package = FullDirectory(packageDirectory);
        string assembly = Path.Combine(game, "7DaysToDie_Data", "Managed", "Assembly-CSharp.dll");
        if (!File.Exists(Path.Combine(game, "7DaysToDie.exe")) || !File.Exists(assembly))
            throw new DirectoryNotFoundException("Choisis le dossier du jeu contenant 7DaysToDie.exe et 7DaysToDie_Data.");
        if (!string.Equals(Hash(assembly), GameAssemblyHash, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Cette installation ne correspond pas à l’assembly V 3.4.0 (b10) analysée. Aucun module n’a été copié.");
        var manifest = ReadManifest(Path.Combine(package, "module-package.json"), PackageFormat);
        if (!string.Equals(manifest.GameAssemblySha256, GameAssemblyHash, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Le profil du paquet ne correspond pas au loader.");
        ValidatePayload(package, manifest);
        return InstallValidated(package, mods, manifest, EnsureGameStopped);
    }

    // Isolated filesystem transaction used by deterministic tests as well as
    // the production installer after game/package validation above.
    internal static GameModuleInstallResult InstallValidated(string package, string mods, GameModulePackage manifest, Action ensureStopped)
    {
        string root = FullDirectory(mods);
        RequireModsDirectory(root);
        NoReparseAncestors(root);
        string target = Path.Combine(root, ModuleName);
        string parent = Path.GetDirectoryName(root) ?? throw new IOException("Dossier Mods sans parent.");
        string stage = Path.Combine(parent, ".dma7dtd-stage-" + Guid.NewGuid().ToString("N"));
        string backup = "";
        if (Directory.Exists(target)) ValidateOwnedInstallation(target);
        try
        {
            Directory.CreateDirectory(stage);
            foreach (string name in PayloadNames) File.Copy(Path.Combine(package, name), Path.Combine(stage, name), false);
            ValidatePayload(stage, manifest);
            var marker = new GameModulePackage { Format = InstallFormat, Version = manifest.Version,
                GameAssemblySha256 = manifest.GameAssemblySha256, Files = new Dictionary<string, string>(manifest.Files, StringComparer.Ordinal) };
            File.WriteAllText(Path.Combine(stage, MarkerName), JsonSerializer.Serialize(marker, new JsonSerializerOptions { WriteIndented = true }), new UTF8Encoding(false));
            ensureStopped();
            Directory.CreateDirectory(root);
            NoReparseAncestors(root);
            if (Directory.Exists(target))
            {
                ValidateOwnedInstallation(target);
                string backups = Path.Combine(parent, "DMA7DTD-module-backups");
                NoReparseAncestors(backups); Directory.CreateDirectory(backups);
                backup = Path.Combine(backups, DateTime.UtcNow.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N")[..8]);
                Directory.Move(target, backup);
            }
            try { Directory.Move(stage, target); }
            catch
            {
                if (backup.Length > 0 && !Directory.Exists(target)) Directory.Move(backup, target);
                throw;
            }
            return new(target, backup, "Module " + manifest.Version + " installé. Relance le jeu avec les mods, puis ouvre une partie ; le loader le détectera par DMA.");
        }
        finally { if (Directory.Exists(stage)) Directory.Delete(stage, true); }
    }

    public static GameModuleInstallResult Remove(string modsDirectory)
    {
        EnsureGameStopped();
        string root = FullDirectory(modsDirectory);
        RequireModsDirectory(root);
        NoReparseAncestors(root);
        string target = Path.Combine(root, ModuleName);
        if (!Directory.Exists(target)) return new(target, "", "Aucune installation de ce module dans ce dossier Mods.");
        ValidateOwnedInstallation(target);
        string parent = Path.GetDirectoryName(root) ?? throw new IOException("Dossier Mods sans parent.");
        string backups = Path.Combine(parent, "DMA7DTD-module-backups");
        NoReparseAncestors(backups); Directory.CreateDirectory(backups);
        string backup = Path.Combine(backups, "retire-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N")[..8]);
        EnsureGameStopped(); Directory.Move(target, backup);
        return new(target, backup, "Module retiré du dossier Mods. Une copie est conservée dans " + backup);
    }

    private static void ValidateOwnedInstallation(string target)
    {
        NoReparseAncestors(target);
        var manifest = ReadManifest(Path.Combine(target, MarkerName), InstallFormat);
        if (Directory.EnumerateDirectories(target).Any() || Directory.EnumerateFiles(target).Select(Path.GetFileName)
            .Any(name => name != MarkerName && !PayloadNames.Contains(name, StringComparer.Ordinal)))
            throw new IOException("Le dossier du module contient d’autres fichiers. Déplace-le manuellement avant une mise à jour.");
        ValidatePayload(target, manifest);
    }

    private static void ValidatePayload(string directory, GameModulePackage manifest)
    {
        if (manifest.Files.Count != PayloadNames.Length || string.IsNullOrWhiteSpace(manifest.Version) || manifest.Version.Length > 32)
            throw new InvalidDataException("Manifest du module invalide.");
        foreach (string name in PayloadNames)
        {
            string path = Path.Combine(directory, name);
            if (!manifest.Files.TryGetValue(name, out string? expected) || expected == null || expected.Length != 64 || !File.Exists(path) ||
                (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0 ||
                !string.Equals(Hash(path), expected, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Fichier du module absent ou modifié : " + name + ". Réextrais l’archive complète.");
        }
    }

    private static GameModulePackage ReadManifest(string path, string format)
    {
        if (!File.Exists(path) || new FileInfo(path).Length > 16384 || (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
            throw new InvalidDataException("Manifest du module absent ou invalide : " + Path.GetFileName(path));
        var result = JsonSerializer.Deserialize<GameModulePackage>(File.ReadAllText(path), new JsonSerializerOptions { MaxDepth = 8 });
        if (result == null || result.Format != format || result.Files == null) throw new InvalidDataException("Manifest du module non reconnu.");
        return result;
    }

    private static string Hash(string path)
    { using var stream = File.OpenRead(path); return Convert.ToHexString(SHA256.HashData(stream)).ToLowerInvariant(); }
    private static string FullDirectory(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || !Path.IsPathFullyQualified(path)) throw new ArgumentException("Un chemin de dossier absolu est nécessaire.");
        string full = Path.TrimEndingDirectorySeparator(Path.GetFullPath(path));
        if (Path.GetPathRoot(full) == full) throw new ArgumentException("Choisis un dossier, pas la racine du disque.");
        return full;
    }
    private static void RequireModsDirectory(string directory)
    {
        if (!string.Equals(Path.GetFileName(directory), "Mods", StringComparison.OrdinalIgnoreCase) ||
            directory.Split(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
                .Any(part => string.Equals(part, "Managed", StringComparison.OrdinalIgnoreCase)))
            throw new ArgumentException("Choisis le dossier nommé Mods chargé par le jeu, pas le dossier du jeu lui-même ni Managed.");
    }
    private static void NoReparseAncestors(string path)
    {
        for (DirectoryInfo? directory = new(path); directory != null; directory = directory.Parent)
            if (directory.Exists && (directory.Attributes & FileAttributes.ReparsePoint) != 0)
                throw new IOException("Un dossier lié ou redirigé a été détecté. Choisis le chemin réel pour installer le module.");
    }
    private static void EnsureGameStopped()
    {
        var processes = Process.GetProcessesByName("7DaysToDie");
        bool running = processes.Length > 0;
        foreach (var process in processes) process.Dispose();
        if (running) throw new InvalidOperationException("Ferme 7 Days to Die avant d’installer, mettre à jour ou retirer le module.");
    }
}
