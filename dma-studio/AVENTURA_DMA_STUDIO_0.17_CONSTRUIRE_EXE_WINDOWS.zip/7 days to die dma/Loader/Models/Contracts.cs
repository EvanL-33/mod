using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Text.Json.Serialization;
using SevenDaysEsp;

namespace SevenDaysLoader;

public sealed class LoaderSettings
{
    public int SchemaVersion { get; set; } = 2;
    public string Mode { get; set; } = "reader";
    public bool AutoConnectDma { get; set; } = true;
    public bool AutoReconnectGame { get; set; } = true;
    public string SdkDirectory { get; set; } = @"C:\Users\Media\Desktop\MemProcFS_files_and_binaries-win_x64-latest";
    public string Device { get; set; } = "fpga";
    public int IntervalMs { get; set; } = Services.CaptureCadence.DefaultIntervalMs;
    public int ReadCadenceVersion { get; set; }
    public bool EspEnabled { get; set; } = true;
    public int EspProfilesVersion { get; set; }
    public EntityEspSettings PlayerEsp { get; set; } = new();
    public EntityEspSettings ZombieEsp { get; set; } = new() { Color = "#FF9A52" };
    public PlayerFeaturesSettings PlayerFeatures { get; set; } = new();
    public AdminWatchSettings AdminWatch { get; set; } = new();
    public PvpSenseSettings PvpSense { get; set; } = new();
    // Retained only for importing settings written by versions before 0.8.0.
    // Display code uses the independent profiles above after normalization.
    public bool ShowPlayers { get; set; } = true;
    public bool ShowZombies { get; set; } = true;
    public bool ShowRadar { get; set; } = true;
    public bool ShowProjectedEsp { get; set; } = true;
    public string EspScaleMode { get; set; } = "fit";
    public bool ShowNames { get; set; } = true;
    public bool ShowHealth { get; set; } = true;
    public bool ShowDistances { get; set; } = true;
    public bool ShowHud { get; set; } = true;
    public string PlayerColor { get; set; } = "#66DEF2";
    public string ZombieColor { get; set; } = "#FF9A52";
    public int MaxDistance { get; set; } = 300;
    public int RadarSize { get; set; } = 300;
    public double RadarOpacity { get; set; } = 0.88;
    public bool RadarIndependentRange { get; set; }
    public int RadarRangeMeters { get; set; } = 300;
    public bool ShowRadarCounts { get; set; }
    public string MenuKey { get; set; } = "Insert";
    public string ToggleKey { get; set; } = "F6";
    public string PlayersKey { get; set; } = "F7";
    public string ZombiesKey { get; set; } = "F8";
    public string RadarKey { get; set; } = "F9";
    public string CreativeMenuKey { get; set; } = "F10";
    public string OutputMode { get; set; } = "overlay";
    public string FuserDeviceName { get; set; } = "";
    public string FuserKeyColor { get; set; } = "#000000";
    [JsonIgnore]
    public bool FuserTestPattern { get; set; } = false;
    public int MonitorIndex { get; set; } = 0;
    public string OverlayAnchor { get; set; } = "TopRight";
    public string ShareAddress { get; set; } = "";
    public int SharePort { get; set; } = 27841;
}

public sealed class EntityEspSettings
{
    public bool Enabled { get; set; } = true;
    public bool ShowBoxes { get; set; } = true;
    public bool ShowNames { get; set; } = true;
    public bool ShowHealth { get; set; } = true;
    public bool ShowDistances { get; set; } = true;
    public bool ShowTracers { get; set; }
    public string Color { get; set; } = "#66DEF2";
    public string BoxStyle { get; set; } = "full";
    public int MaxDistance { get; set; } = 300;
    public double FontSize { get; set; } = 12;
    public double LineThickness { get; set; } = 1.5;
    public EntityDisplayRulesSettings Rules { get; set; } = new();

    [JsonIgnore]
    public bool HasProjectedContent => ShowBoxes || ShowNames || ShowHealth || ShowDistances || ShowTracers || Rules?.ShowHeightIndicator == true;

    public EntityEspSettings Copy()
    {
        var copy = (EntityEspSettings)MemberwiseClone();
        copy.Rules = Rules?.Copy() ?? new EntityDisplayRulesSettings();
        return copy;
    }
}

public sealed record LoaderStatus
{
    public string Stage { get; init; } = "DECONNECTE";
    public string Message { get; init; } = "Le lecteur DMA démarre automatiquement à l'ouverture.";
    public bool IsBusy { get; init; }
    public bool IsConnected { get; init; }
    public bool HasDmaSession { get; init; }
    public bool IsReader { get; init; } = true;
    public bool IsSharing { get; init; }
    public bool HasDisplayClient { get; init; }
    public bool CanProject { get; init; } = false;
    public string ProjectionMessage { get; init; } = "Caméra en attente de lecture.";
    public uint ProcessId { get; init; }
    public string GameVersion { get; init; } = "Non lue";
    public string MemProcFsVersion { get; init; } = "Non connecté";
    public string ReportPath { get; init; } = "";
}

// Freshness is monotonic. Remote samples include source age AND the complete
// polling round trip; clocks on the two PCs never need to match.
public sealed class FeedSample
{
    public const int LifetimeMs = 2000;
    public const int ProjectionLifetimeMs = 250;
    public LiveEntitySnapshot Snapshot { get; }
    public double InitialAgeMs { get; }
    public long ReceivedTimestamp { get; }
    public double AgeMs => InitialAgeMs + Stopwatch.GetElapsedTime(ReceivedTimestamp).TotalMilliseconds;
    public bool IsFresh => double.IsFinite(InitialAgeMs) && InitialAgeMs >= 0 &&
        AgeMs >= 0 && AgeMs < LifetimeMs && IsValid(Snapshot);
    public bool IsProjectionFresh => IsFresh && AgeMs < ProjectionLifetimeMs &&
        TryGetProjectionView(out _, out _);

    public bool TryGetProjectionView(out ProjectionView? view, out string reason)
    {
        view = null;
        var camera = Snapshot.Camera;
        if (camera == null) { reason = "Caméra non disponible."; return false; }
        if (camera.Format != "SevenDaysEsp.CameraFrame/1" || camera.ClipDepth != "MinusOneToOne" ||
            camera.ProfileId != "unity-2022.3.62f2-7670c08855a9-native-v1" || camera.Sequence <= 0 || camera.CameraEpoch <= 0 ||
            !double.IsFinite(camera.ReadDurationMs) || camera.ReadDurationMs < 0 || camera.ReadDurationMs >= ProjectionLifetimeMs ||
            !ValidPosition(Snapshot.RenderOrigin))
        { reason = "Format ou cohérence caméra non reconnus."; return false; }
        return ProjectionMath.TryCreateView(camera.ViewProjection, Snapshot.RenderOrigin,
            camera.SourceWidth, camera.SourceHeight,
            new ProjectionViewport(camera.ViewportX, camera.ViewportY, camera.ViewportWidth, camera.ViewportHeight),
            ProjectionDepthRange.MinusOneToOne, out view, out reason);
    }

    public FeedSample(LiveEntitySnapshot snapshot, double initialAgeMs)
    {
        Snapshot = snapshot;
        InitialAgeMs = initialAgeMs;
        ReceivedTimestamp = Stopwatch.GetTimestamp();
    }

    public static bool IsValid(LiveEntitySnapshot? snapshot)
    {
        if (snapshot == null || snapshot.Status != "ENTITES_LUES" ||
            !ValidPosition(snapshot.LocalPosition) || snapshot.Entities == null ||
            snapshot.Entities.Count > 4096 || snapshot.LocalId < 0) return false;
        foreach (var entity in snapshot.Entities)
        {
            if (entity == null || (entity.Kind != "player" && entity.Kind != "zombie") ||
                !ValidPosition(entity.Position) || entity.Name?.Length > 128 ||
                entity.EntityId < 0 || entity.EntityId == snapshot.LocalId ||
                entity.HeldItemTypeId is < 1 or > 100000 ||
                (entity.BodyYawDegrees is float yaw && (!float.IsFinite(yaw) || Math.Abs(yaw) > 100000))) return false;
        }
        return true;
    }

    public static bool ValidPosition(LivePosition? p) => p != null &&
        float.IsFinite(p.X) && float.IsFinite(p.Y) && float.IsFinite(p.Z) &&
        Math.Abs(p.X) <= 1_000_000 && Math.Abs(p.Y) <= 1_000_000 && Math.Abs(p.Z) <= 1_000_000;
}

public interface ILoaderController
{
    LoaderSettings Settings { get; }
    LoaderStatus Status { get; }
    FeedSample? CurrentFrame { get; }
    IReadOnlyList<string> LogLines { get; }
    string ReportDirectory { get; }
    string SettingsDirectory { get; }
    Services.RenderPerformanceTracker Performance { get; }
    Services.PlayerSessionService Players { get; }
    CreativeMenuState CreativeMenu { get; }
    PlayerControlState PlayerControls { get; }
    PlayerDmaStatResult? LastDmaStatResult { get; }
    bool IsDmaStatBusy { get; }
    event Action? StateChanged;
    event Action? SettingsChanged;
    Task ConnectReaderAsync();
    Task ConnectDisplayAsync(string pairingCode);
    Task DisconnectAsync();
    // null requests a fresh observation without changing the game preference.
    Task SetCreativeMenuAsync(bool? enabled);
    Task ToggleCreativeMenuAsync();
    Task RequestDmaStatAsync(PlayerDmaStatKind stat, float? value = null);
    Task SendPlayerControlAsync(SevenDaysDmaControl.ControlOperation operation, bool enabled = false,
        float value = 0, float x = 0, float y = 0, float z = 0);
    Task<string> StartSharingAsync(string localAddress);
    Task StopSharingAsync();
    void SaveSettings();
    void SetPlayerDetailsVisible(object consumer, bool visible);
    void ToggleEsp();
    void TogglePlayers();
    void ToggleZombies();
    void ToggleRadar();
    void Log(string message);
    void OpenReportDirectory();
}

public sealed class WorkerStart
{
    public string SdkDirectory { get; set; } = "";
    public string Device { get; set; } = "fpga";
    public int IntervalMs { get; set; } = Services.CaptureCadence.DefaultIntervalMs;
    public string ReportDirectory { get; set; } = "";
    public DisplayConfigurationReport? OutputAtConnection { get; set; }
    public LiveReadOptions ReadOptions { get; set; } = new();
}

// A bounded diagnostic captured on the loader PC when it opens the reader.
// It deliberately excludes pairing credentials and settings unrelated to output.
public sealed class DisplayConfigurationReport
{
    public DateTime CapturedUtc { get; set; }
    public string OutputMode { get; set; } = "";
    public string? EspScaleMode { get; set; }
    public int SelectedMonitorIndex { get; set; }
    public string DeviceName { get; set; } = "";
    public int PixelWidth { get; set; }
    public int PixelHeight { get; set; }
    public bool EspEnabled { get; set; }
    public bool ShowProjectedEsp { get; set; }
    public bool ShowPlayers { get; set; }
    public bool ShowZombies { get; set; }
    public bool? ShowHealth { get; set; }
    public int MaxDistance { get; set; }
    public EntityEspSettings? PlayerEsp { get; set; }
    public EntityEspSettings? ZombieEsp { get; set; }
    public string Issue { get; set; } = "";
}

public sealed class WorkerMessage
{
    public PlayerDmaStatResult? PlayerDmaStatResult { get; set; }
    public PlayerControlObservation? PlayerControlObservation { get; set; }
    public PlayerControlSubmission? PlayerControlSubmission { get; set; }
    public CreativeMenuResult? CreativeResult { get; set; }
    public string ProjectionMessage { get; set; } = "Caméra en attente de lecture.";
    public bool HasDmaSession { get; set; }
    public string Kind { get; set; } = "status";
    public string Stage { get; set; } = "";
    public string Message { get; set; } = "";
    public uint ProcessId { get; set; }
    public string GameVersion { get; set; } = "";
    public string MemProcFsVersion { get; set; } = "";
    public string ReportPath { get; set; } = "";
    public LiveEntitySnapshot? Frame { get; set; }
    public double AgeMs { get; set; }
    // Windows QueryPerformanceCounter is shared across processes on one PC.
    // This timestamp includes pipe transit in freshness checks by the parent.
    public long CapturedTimestamp { get; set; }
}
