using System.Globalization;
using SevenDaysEsp;

namespace SevenDaysLoader.UI;

internal static class ProjectionOutputText
{
    internal static string ModeLabel(string? mode) => mode switch
    {
        ProjectionOutputMapping.Fit => "Conserver les proportions",
        ProjectionOutputMapping.Stretch => "Étirer sur toute la sortie",
        ProjectionOutputMapping.Fill => "Remplir et recadrer au centre",
        _ => "Mode non reconnu"
    };

    internal static string Summary(ProjectionOutputMapping mapping) =>
        mapping.SourceWidth + " × " + mapping.SourceHeight + " → " +
        mapping.OutputWidth + " × " + mapping.OutputHeight + " px · " + ModeLabel(mapping.Mode);

    internal static string Details(ProjectionOutputMapping mapping) =>
        Summary(mapping) + "\nÉchelle X : " + Number(mapping.ScaleX) +
        " · Y : " + Number(mapping.ScaleY) + " · décalage : (" +
        Number(mapping.OffsetX) + ", " + Number(mapping.OffsetY) + ") px.\n" +
        "Le mode choisi doit correspondre à la façon dont l’image du jeu est affichée par le fuser ou sur cet écran.";

    private static string Number(double value) => value.ToString("0.###", CultureInfo.GetCultureInfo("fr-FR"));
}
