using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using System.Threading;
using SevenDaysEsp;
using SevenDaysDmaControl;

static class Program
{
    static int assertions;
    static void Require(bool condition, string text) { assertions++; if (!condition) throw new Exception(text); }
    static void WaitProbe(Fixture fixture) { Thread.Sleep(fixture.Bridge.RecommendedPollIntervalMs + 10); }
    static void Main()
    {
        using (var f = new Fixture())
        {
            var first = f.Bridge.Probe(f.Context, f.Pid);
            Require(first.Available && !first.Fresh, "first heartbeat must not authorize commands");
            Console.WriteLine("Initial metadata probe: " + first.ReadCalls + " reads / " + first.ReadBytes + " bytes (fake memory).");
            f.Advance(100); WaitProbe(f);
            var warm = f.Bridge.Probe(f.Context, f.Pid);
            Require(warm.Fresh, "advancing heartbeat recognized");
            Require(warm.ReadCalls <= 20, "warm module probe uses bounded roots, never an assembly scan");
            Console.WriteLine("Cached metadata probe: " + warm.ReadCalls + " reads / " + warm.ReadBytes + " bytes (game-context validation and hardware latency not simulated).");
            var stale = f.Command(); stale.ExpectedContextId = Guid.NewGuid();
            Require(!f.Bridge.Submit(f.Context, f.Pid, stale).Accepted && f.Memory.Writes == 0, "stale UI context refuses before write");
            var submitted = f.Bridge.Submit(f.Context, f.Pid, f.Command());
            Require(submitted.Accepted && submitted.WriteAttempted && submitted.CommitAttempted && submitted.RequestId == 1, "valid request committed once");
            Require(f.Memory.Writes == 1, "one publication");
            Require(!f.Bridge.Submit(f.Context, f.Pid, f.Command()).Accepted && f.Memory.Writes == 1, "pending prevents second publication");
            f.Ack(submitted.RequestId, ControlStatus.AppliedLocal); WaitProbe(f);
            var ack = f.Bridge.Probe(f.Context, f.Pid);
            Require(ack.Snapshot.LastStatus == ControlStatus.AppliedLocal && ack.PendingRequestId == 0, "local acknowledgment observed separately");
            // Mutating the returned snapshot must never mutate the internal baseline.
            ack.Snapshot.SessionId = Guid.NewGuid();
            var next = f.Bridge.Submit(f.Context, f.Pid, f.Command());
            Require(next.Accepted && next.RequestId == 2, "request IDs strictly increase and result snapshots are detached");
            f.Ack(next.RequestId, ControlStatus.Refused); WaitProbe(f); f.Bridge.Probe(f.Context, f.Pid);
            Thread.Sleep(1050);
            var frozen = f.Bridge.Probe(f.Context, f.Pid);
            Require(!frozen.Fresh && frozen.ObservedAgeMs >= 1000, "re-reading frozen heartbeat does not refresh age");
            Require(!f.Bridge.Submit(f.Context, f.Pid, f.Command()).Accepted && f.Memory.Writes == 2, "stalled module prevents writing");
        }
        using (var f = new Fixture())
        {
            f.Ready(); f.Memory.FailAfterStaging = true;
            var uncertain = f.Bridge.Submit(f.Context, f.Pid, f.Command());
            Require(!uncertain.Accepted && uncertain.WriteAttempted && !uncertain.CommitAttempted, "partial publish preserves attempt markers");
            Require(!f.Bridge.Submit(f.Context, f.Pid, f.Command()).Accepted && f.Memory.Writes == 1, "partial publish is not retried");
            f.Advance(4000); WaitProbe(f); var expired = f.Bridge.Probe(f.Context, f.Pid);
            Require(expired.PendingRequestId == 0, "unconsumed expired request released only by advancing game time");
            f.Memory.FailAfterStaging = false;
            var explicitNew = f.Bridge.Submit(f.Context, f.Pid, f.Command());
            Require(explicitNew.Accepted && explicitNew.RequestId > uncertain.RequestId, "new explicit action never reuses uncertain request ID");
        }
        using (var f = new Fixture())
        {
            f.Ready(); f.Memory.BeforeCommit = () => { f.State.Observation.ContextId = Guid.NewGuid(); f.Advance(1); };
            var changed = f.Bridge.Submit(f.Context, f.Pid, f.Command());
            Require(changed.WriteAttempted && !changed.CommitAttempted && !changed.Accepted, "context change during payload prevents commit");
            Require((ControlProtocol.ReadSequence(f.Memory.Read(f.RequestData, 256)) & 1U) != 0, "failed context leaves uncommitted mailbox");
        }
        using (var f = new Fixture())
        {
            f.Ready(); var stateBytes = f.Memory.Read(f.StateData, 512); stateBytes[100] ^= 0x40; f.Memory.Write(f.StateData, stateBytes);
            WaitProbe(f); Require(!f.Bridge.Probe(f.Context, f.Pid).Fresh, "CRC corruption prevents fresh state");
            Require(!f.Bridge.Submit(f.Context, f.Pid, f.Command()).Accepted && f.Memory.Writes == 0, "CRC corruption prevents publication");
        }
        using (var f = new Fixture())
        {
            f.Memory.Put64(f.ArrayVtable + 0x10, f.Domain + 0x100);
            Require(!f.Bridge.Probe(f.Context, f.Pid).Available && f.Memory.Writes == 0, "foreign-domain buffers rejected");
        }
        using (var f = new Fixture())
        {
            f.Ready(); f.ValidContext = false;
            Require(!f.Bridge.Submit(f.Context, f.Pid, f.Command()).Accepted && f.Memory.Writes == 0, "invalid live game context rejected");
        }
        using (var f = new Fixture(18))
        {
            Require(!f.Bridge.Probe(f.Context, f.Pid).Available, "assembly traversal bounded per probe");
            Thread.Sleep(510);
            Require(f.Bridge.Probe(f.Context, f.Pid).Available, "assembly traversal resumes without exhaustive rescanning");
        }
        using (var f = new Fixture())
        {
            f.Ready(); var future = f.Command(); future.RequestedTimestamp = Stopwatch.GetTimestamp() + Stopwatch.Frequency;
            Require(!f.Bridge.Submit(f.Context, f.Pid, future).Accepted && f.Memory.Writes == 0, "future intent timestamp refuses before any write");
            var aging = f.Command(); aging.RequestedTimestamp = Stopwatch.GetTimestamp() - Stopwatch.Frequency * 5 / 2;
            f.Memory.BeforeCommit = () => Thread.Sleep(600);
            var expired = f.Bridge.Submit(f.Context, f.Pid, aging);
            Require(expired.WriteAttempted && !expired.CommitAttempted && !expired.Accepted, "intent expiring during staging cannot commit");
            Require((ControlProtocol.ReadSequence(f.Memory.Read(f.RequestData, 256)) & 1U) != 0, "expired intent leaves odd record");
            Require(!f.Bridge.Submit(f.Context, f.Pid, f.Command()).Accepted && f.Memory.Writes == 1, "expired staged command is not replayed");
        }
        using (var f = new Fixture())
        {
            f.Ready(); var submitted = f.Bridge.Submit(f.Context, f.Pid, f.Command());
            f.Ack(submitted.RequestId, ControlStatus.AppliedLocal); f.State.LastRequestContextId = Guid.NewGuid(); f.Publish();
            WaitProbe(f);
            Require(f.Bridge.Probe(f.Context, f.Pid).Code == "COMMANDE_CONFLIT", "acknowledgment from a different request context is never attributed to this command");
        }
        Console.WriteLine("PASS: " + assertions + " control bridge assertions; fake memory only, no native/game/hardware execution.");
    }
}

sealed class Fixture : IDisposable
{
    public readonly Memory Memory = new Memory();
    public readonly uint Pid = 77;
    public readonly LiveMenuContext Context;
    public readonly DmaControlBridge Bridge;
    public readonly ulong Domain, ArrayVtable, RequestData, StateData;
    public readonly ControlSnapshot State;
    public bool ValidContext = true;
    public Fixture(int extras = 0)
    {
        Domain = Memory.Alloc(0x200); ulong gameImage = Memory.Alloc(0x600), moduleImage = Memory.Alloc(0x600), coreImage = Memory.Alloc(0x600);
        ulong byteType = Type(coreImage, "System", "Byte", 1, 17, 0x02000006, 0, 0);
        ulong arrayType = Type(coreImage, "System", "Byte[]", 5, 32, 0, 0, 0);
        Memory.Put64(arrayType, byteType); Memory.Put8(arrayType + 0x1A, 1); Memory.Put32(arrayType + 0x90, 1);
        ArrayVtable = Memory.Alloc(0x50); Memory.Put64(ArrayVtable, arrayType); Memory.Put64(ArrayVtable + 0x10, Domain);
        ulong request = Array(256), state = Array(512); RequestData = request + 0x20; StateData = state + 0x20;
        ulong fields = Memory.Alloc(64);
        uint token = (uint)typeof(DmaControlBridge).GetField("BridgeTypeToken", BindingFlags.NonPublic | BindingFlags.Static).GetRawConstantValue();
        ulong bridgeType = Type(moduleImage, "SevenDaysDmaControl", "ControlBridge", 1, 16, token, 2, fields);
        Memory.Put32(bridgeType + 0x90, 16);
        Field(fields, bridgeType, byteType, "RequestBuffer", 0); Field(fields + 32, bridgeType, byteType, "StateBuffer", 8);
        ulong statics = Memory.Alloc(16); Memory.Put64(statics, request); Memory.Put64(statics + 8, state);
        ulong runtime = Memory.Alloc(16), table = Memory.Alloc(0x50);
        Memory.Put64(runtime + 8, table); Memory.Put64(bridgeType + 0xD0, runtime);
        Memory.Put64(table, bridgeType); Memory.Put64(table + 0x10, Domain); Memory.Put8(table + 0x2D, 1);
        Memory.Put32(table + 0x30, 4); Memory.Put64(table + 0x48, statics);
        ulong bucket = Memory.Alloc(8); Memory.Put64(bucket, bridgeType);
        for (uint at = 0; at < 24; at += 8) Memory.Put64(moduleImage + 0x4D0 + at, 0x1000010);
        Memory.Put32(moduleImage + 0x4E8, 1); Memory.Put32(moduleImage + 0x4EC, 1); Memory.Put64(moduleImage + 0x4F0, bucket);
        var assemblies = new List<ulong>(); assemblies.Add(Assembly("Assembly-CSharp", gameImage));
        for (int i = 0; i < extras; ++i) assemblies.Add(Assembly("Extra" + i, coreImage));
        assemblies.Add(Assembly("SevenDaysDmaControl", moduleImage));
        ulong first = 0, previous = 0;
        foreach (ulong assembly in assemblies)
        {
            ulong node = Memory.Alloc(16); Memory.Put64(node, assembly);
            if (first == 0) first = node; if (previous != 0) Memory.Put64(previous + 8, node); previous = node;
        }
        Memory.Put64(Domain + 0xA0, first);
        Context = new LiveMenuContext(); Set("ContextId", Guid.NewGuid().ToString("N")); Set("Domain", Domain);
        Set("GameImage", gameImage); Set("WorldAddress", Memory.Alloc(16)); Set("LocalPlayerAddress", Memory.Alloc(16)); Set("LocalPlayerId", 42);
        typeof(LiveMenuContext).GetField("ValidateAction", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(Context, (Action)(() => { if (!ValidContext) throw new IOException("fixture context changed"); }));
        var metadata = new MonoInspectionReport { Status = "METADONNEES_PARTIELLES", SelectedLayout = "Unity Mono x64 2022 (candidate)", MonoModule = "mono.dll" };
        metadata.Modules.Add(new MonoModuleReport { Name = "mono.dll", BaseAddress = "0x1000000", ImageSize = 0x100000 });
        State = new ControlSnapshot { SessionId = Guid.NewGuid(), Sequence = 2, Observation = new GameObservation { ContextId = Guid.NewGuid(), PlayerId = 42,
            Availability = BridgeAvailability.Ready, GameTimestampMs = 1000, Speed = 1, SupportedOperations = ControlProtocol.AllOperationsMask } };
        Publish(); Memory.ProcessId = Pid; Bridge = new DmaControlBridge(Memory, metadata);
    }
    void Set(string name, object value) { typeof(LiveMenuContext).GetProperty(name).SetValue(Context, value); }
    ulong Type(ulong image, string ns, string name, byte kind, int size, uint token, int count, ulong fields)
    {
        ulong address = Memory.Alloc(0x110); Memory.Put8(address + 0x1B, kind); Memory.Put32(address + 0x1C, (uint)size);
        Memory.Put64(address + 0x40, image); Memory.Put64(address + 0x48, Memory.String(name)); Memory.Put64(address + 0x50, Memory.String(ns));
        Memory.Put32(address + 0x58, token); Memory.Put64(address + 0x98, fields); Memory.Put32(address + 0x100, (uint)count); return address;
    }
    ulong Array(int length) { ulong address = Memory.Alloc(length + 32); Memory.Put64(address, ArrayVtable); Memory.Put32(address + 24, (uint)length); return address; }
    ulong Assembly(string name, ulong image) { ulong assembly = Memory.Alloc(0x68); Memory.Put64(assembly + 0x10, Memory.String(name)); Memory.Put64(assembly + 0x60, image); return assembly; }
    void Field(ulong address, ulong parent, ulong element, string name, int offset)
    {
        ulong type = Memory.Alloc(16); Memory.Put64(type, element); Memory.Put8(type + 8, 0x36); Memory.Put8(type + 10, 0x1D);
        Memory.Put64(address, type); Memory.Put64(address + 8, Memory.String(name)); Memory.Put64(address + 16, parent); Memory.Put32(address + 24, (uint)offset);
    }
    public void Publish() { Memory.Write(StateData, ControlProtocol.EncodeSnapshot(State, State.Sequence)); }
    public void Advance(long delta) { State.Observation.GameTimestampMs += delta; State.Sequence = ControlProtocol.NextSequence(State.Sequence); Publish(); }
    public void Ready() { Bridge.Probe(Context, Pid); Advance(100); Thread.Sleep(Bridge.RecommendedPollIntervalMs + 10); if (!Bridge.Probe(Context, Pid).Fresh) throw new Exception("fixture not ready"); }
    public void Ack(ulong id, ControlStatus status)
    { State.RequestHighWatermark = id; State.LastRequestId = id; State.LastStatus = status; State.LastOperation = ControlOperation.SetFly; State.LastRequestContextId = State.Observation.ContextId; State.PendingRequestId = 0; Advance(100); }
    public ControlCommand Command() { return new ControlCommand { ExpectedSessionId = State.SessionId, ExpectedContextId = State.Observation.ContextId, ExpectedPlayerId = 42, RequestedTimestamp = Stopwatch.GetTimestamp(), Operation = ControlOperation.SetFly, Enabled = true }; }
    public void Dispose() { }
}

sealed class Memory : IMemoryReader, IControlMemoryWriter
{
    readonly SortedDictionary<ulong, byte[]> blocks = new SortedDictionary<ulong, byte[]>();
    ulong next = 0x100000;
    public uint ProcessId { get; set; }
    public int Writes;
    public bool FailAfterStaging;
    public Action BeforeCommit;
    public ulong Alloc(int count) { ulong p = next; next += (ulong)((count + 31) & ~15); blocks.Add(p, new byte[count]); return p; }
    public ulong String(string text) { ulong address = Alloc(256); Write(address, Encoding.UTF8.GetBytes(text + "\0")); return address; }
    public void Put8(ulong p, byte b) { Write(p, new[] { b }); }
    public void Put32(ulong p, uint b) { Write(p, BitConverter.GetBytes(b)); }
    public void Put64(ulong p, ulong b) { Write(p, BitConverter.GetBytes(b)); }
    public byte[] Read(ulong address, int count)
    {
        foreach (var pair in blocks) if (address >= pair.Key && address - pair.Key <= (ulong)pair.Value.Length && (ulong)count <= (ulong)pair.Value.Length - (address - pair.Key))
        { var bytes = new byte[count]; Buffer.BlockCopy(pair.Value, (int)(address - pair.Key), bytes, 0, count); return bytes; }
        throw new IOException("unmapped fixture read " + address.ToString("X") + " + " + count);
    }
    public void Write(ulong address, byte[] bytes)
    {
        foreach (var pair in blocks) if (address >= pair.Key && address - pair.Key <= (ulong)pair.Value.Length && (ulong)bytes.Length <= (ulong)pair.Value.Length - (address - pair.Key))
        { Buffer.BlockCopy(bytes, 0, pair.Value, (int)(address - pair.Key), bytes.Length); return; }
        throw new IOException("unmapped fixture write");
    }
    public ulong ModuleBase(string name) { return 0; }
    public ulong ExportAddress(string module, string symbol) { return 0; }
    public ControlBufferWriteResult WriteControlRecord(uint pid, ControlBufferLease lease, byte[] before, byte[] after, Action validateRoots, CancellationToken token)
    {
        var result = new ControlBufferWriteResult();
        try
        {
            token.ThrowIfCancellationRequested(); validateRoots();
            if (pid != ProcessId || !Equal(Read(lease.DataAddress, 256), before)) throw new IOException("fixture compare refused");
            Writes++; result.Attempted = true;
            var staged = (byte[])after.Clone(); ControlProtocol.PutUInt32(staged, 12, ControlProtocol.ReadSequence(after) - 1); Write(lease.DataAddress, staged);
            if (FailAfterStaging) throw new IOException("fixture partial write");
            if (BeforeCommit != null) BeforeCommit(); validateRoots();
            result.CommitAttempted = true; Write(lease.DataAddress, after);
            result.ReportedSuccess = true; result.ReadbackConfirmed = Equal(Read(lease.DataAddress, 256), after); result.Message = "fixture transmitted";
        }
        catch (Exception e) { result.Message = e.Message; }
        return result;
    }
    static bool Equal(byte[] a, byte[] b) { if (a.Length != b.Length) return false; for (int i = 0; i < a.Length; ++i) if (a[i] != b[i]) return false; return true; }
}
