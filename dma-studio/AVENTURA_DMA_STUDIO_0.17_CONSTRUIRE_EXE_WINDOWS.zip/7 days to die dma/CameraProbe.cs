﻿// Targeted read-only camera metadata probe. No native-camera offset or projection is assumed.
// Mono ABI evidence is shared with MonoInspector.cs (Unity Mono x64 2022 candidate).
// Unity bindings: https://github.com/Unity-Technologies/UnityCsReference/tree/2022.3/Runtime/Export
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;

namespace SevenDaysEsp
{
    public sealed class CameraProbeReport
    {
        public string Format { get; set; }
        public string Status { get; set; }
        public string Message { get; set; }
        public bool CanProject { get { return false; } }
        public long BytesRead { get; set; }
        public int ReadCalls { get; set; }
        public string Stage { get; set; }
        public MonoClassReport LocalClass { get; set; }
        public long ElapsedMilliseconds { get; set; }
        public List<CameraObjectReport> Objects { get; set; }
        public List<string> Warnings { get; set; }
        public CameraProbeReport()
        {
            Format = "SevenDaysEsp.CameraProbe/2";
            Stage = "VALIDATION_LOCALE";
            Status = "CAMERA_NON_RELEVEE";
            Objects = new List<CameraObjectReport>();
            Warnings = new List<string>();
        }
    }

    public sealed class CameraObjectReport
    {
        public string SourceField { get; set; }
        public string DeclaredType { get; set; }
        public string ObjectAddress { get; set; }
        public string ActualType { get; set; }
        public string Status { get; set; }
        public bool IdentityValidated { get; set; }
        public string NativePointer { get; set; }
        public int? NativePointerFieldOffset { get; set; }
        public List<MonoClassReport> ClassHierarchy { get; set; }
        public List<CameraMatrixCandidate> MatrixCandidates { get; set; }
        public List<string> Warnings { get; set; }
        public CameraObjectReport()
        {
            Status = "NON_RELEVE";
            ClassHierarchy = new List<MonoClassReport>();
            MatrixCandidates = new List<CameraMatrixCandidate>();
            Warnings = new List<string>();
        }
    }

    public sealed class CameraMatrixCandidate
    {
        public string DeclaringType { get; set; }
        public string Field { get; set; }
        public int Offset { get; set; }
        public string StorageOrder { get { return "column-major: m00,m10,m20,m30,m01,...,m33"; } }
        public bool IsProjectionValidated { get { return false; } }
        public float[] Values { get; set; }
    }

    public sealed class CameraProbe
    {
        private const long MaxBytes = 1048576;
        private const long MaxObjectBytes = 262144;
        private const int MaxReads = 4096;
        private const int MaxFields = 512;
        private const int MaxTotalFields = 2048;
        private const int MaxParents = 12;
        private const int MaxMilliseconds = 2000;
        private const int MetadataBlockSize = 256;
        private const string Layout = "Unity Mono x64 2022 (candidate)";
        private static readonly string[] TargetFields = {
            "playerCamera", "finalCamera", "cameraTransform", "m_vp_FPCamera",
            "renderManager", "characterMatrixOverride"
        };
        private static readonly string[] TargetTypes = {
            "UnityEngine.Camera", "UnityEngine.Camera", "UnityEngine.Transform", "vp_FPCamera",
            "GameRenderManager", "CharacterMatrixOverride"
        };

        private sealed class ProbeLimitException : IOException
        {
            public ProbeLimitException(string message) : base(message) { }
        }
        private sealed class TargetLimitException : IOException
        {
            public TargetLimitException(string message) : base(message) { }
        }
        private sealed class Identity
        {
            public ulong Address;
            public ulong Parent;
            public ulong Image;
            public int Kind;
            public int Size;
            public string Name;
            public string Namespace;
            public string FullName { get { return Namespace.Length == 0 ? Name : Namespace + "." + Name; } }
        }
        private sealed class RuntimeField
        {
            public MonoFieldReport Report;
            public byte Code;
            public ulong TypeData;
        }
        private sealed class RuntimeClass
        {
            public Identity Identity;
            public MonoClassReport Report;
            public readonly List<RuntimeField> Fields = new List<RuntimeField>();
        }

        private readonly IMemoryReader memory;
        private readonly UTF8Encoding utf8 = new UTF8Encoding(false, true);
        private readonly Dictionary<ulong, byte[]> metadataBlocks = new Dictionary<ulong, byte[]>();
        private readonly Dictionary<ulong, Identity> identities = new Dictionary<ulong, Identity>();
        private readonly Dictionary<ulong, RuntimeClass> classes = new Dictionary<ulong, RuntimeClass>();
        private Stopwatch watch;
        private long bytesRead;
        private long objectStartBytes;
        private int readCalls;
        private int totalFields;

        public CameraProbe(IMemoryReader reader)
        {
            if (reader == null) throw new ArgumentNullException("reader");
            memory = reader;
        }

        public CameraProbeReport Inspect(MonoInspectionReport metadata, ulong localPlayerAddress)
        {
            CameraProbeReport report = new CameraProbeReport();
            metadataBlocks.Clear(); identities.Clear(); classes.Clear();
            bytesRead = 0; objectStartBytes = 0; readCalls = 0; totalFields = 0;
            watch = Stopwatch.StartNew();
            for (int index = 0; index < TargetFields.Length; index++)
                report.Objects.Add(new CameraObjectReport { SourceField = TargetFields[index], DeclaredType = TargetTypes[index] });
            report.Warnings.Add("Releve cible de metadonnees, pointeurs et eventuelles matrices gerees candidates ; aucune projection native n'est supposee ou validee.");
            try
            {
                if (metadata == null || metadata.SelectedLayout != Layout ||
                    (metadata.Status != "METADONNEES_COLLECTEES" && metadata.Status != "METADONNEES_PARTIELLES"))
                    throw new IOException("Le layout Mono requis n'est pas confirme.");
                MonoClassReport localMetadata = FindLocalClass(metadata);
                ulong localClassAddress = ParsePointer(localMetadata.Address);
                Identity localIdentity = ReadIdentity(localClassAddress);
                if (localIdentity.Kind != 1 || localIdentity.FullName != "EntityPlayerLocal" ||
                    localIdentity.Size != localMetadata.InstanceSize)
                    throw new IOException("La classe EntityPlayerLocal ne correspond plus aux metadonnees.");
                ulong domain, localRuntimeInfo, localVtableSlot;
                ulong localVtable = CheckLocalObject(localPlayerAddress, localClassAddress,
                    out domain, out localRuntimeInfo, out localVtableSlot);
                report.Stage = "CHAMPS_CIBLES_LOCAUX";
                RuntimeClass localClass = ReadClass(localClassAddress, true, localMetadata,
                    delegate(MonoClassReport value) { report.LocalClass = value; });
                bool partial = false;
                int found = 0;
                for (int index = 0; index < TargetFields.Length; index++)
                {
                    CheckBudget();
                    objectStartBytes = bytesRead;
                    CameraObjectReport item = report.Objects[index];
                    report.Stage = "OBJET_" + TargetFields[index];
                    try
                    {
                        MonoFieldReport prior = FindField(localMetadata, TargetFields[index]);
                        RuntimeField field = FindField(localClass, TargetFields[index]);
                        if (prior == null || field == null || field.Code != 0x12 ||
                            field.Report.IsStatic || field.Report.IsLiteral || !String.IsNullOrEmpty(field.Report.Issue) ||
                            field.Report.Offset != prior.Offset || field.Report.Type != TargetTypes[index] ||
                            prior.Type != field.Report.Type || prior.TypeCode != field.Report.TypeCode ||
                            prior.IsStatic || prior.IsLiteral || !String.IsNullOrEmpty(prior.Issue))
                            throw new IOException("Le champ cible n'est pas une reference d'instance confirmee.");
                        CheckOffset(field.Report.Offset, 8, localIdentity.Size);
                        ulong slot = Add(localPlayerAddress, field.Report.Offset);
                        ulong target = ReadU64(slot);
                        item.ObjectAddress = Hex(target);
                        if (target == 0) { item.Status = "REFERENCE_NULLE"; continue; }
                        RequirePointer(target);
                        InspectObject(item, target, field.TypeData, domain);
                        if (ReadU64(slot) != target || ReadU64(localPlayerAddress) != localVtable ||
                            ReadU64(localVtable) != localClassAddress || ReadU64(localVtable + 0x10) != domain ||
                            ReadU64(localClassAddress + 0xD0) != localRuntimeInfo || ReadU64(localVtableSlot) != localVtable)
                            throw new IOException("La reference camera ou le joueur local a change pendant le releve.");
                        item.IdentityValidated = item.Status == "METADONNEES_RELEVEES" || item.Status == "METADONNEES_PARTIELLES";
                        if (item.Status == "METADONNEES_RELEVEES") found++;
                        else partial = true;
                    }
                    catch (ProbeLimitException ex)
                    {
                        item.Status = "LIMITE_RELEVE"; item.Warnings.Add(ex.Message);
                        item.NativePointer = null; item.NativePointerFieldOffset = null;
                        item.MatrixCandidates.Clear();
                        throw;
                    }
                    catch (TargetLimitException ex)
                    {
                        item.Status = "LIMITE_RELEVE_CIBLE";
                        item.IdentityValidated = false;
                        item.NativePointer = null; item.NativePointerFieldOffset = null;
                        item.MatrixCandidates.Clear();
                        item.Warnings.Add(ex.Message);
                        partial = true;
                    }
                    catch (Exception ex)
                    {
                        item.Status = "LECTURE_NON_VALIDEE";
                        item.IdentityValidated = false;
                        item.NativePointer = null; item.NativePointerFieldOffset = null;
                        item.MatrixCandidates.Clear();
                        item.Warnings.Add(ex.Message);
                        partial = true;
                    }
                }
                report.Stage = "STABILITE_LOCALE";
                if (ReadU64(localPlayerAddress) != localVtable || ReadU64(localVtable) != localClassAddress ||
                    ReadU64(localVtable + 0x10) != domain || ReadU64(localClassAddress + 0xD0) != localRuntimeInfo ||
                    ReadU64(localVtableSlot) != localVtable)
                    throw new IOException("L'identite du joueur local a change pendant le releve camera.");
                report.Status = partial ? "CAMERA_METADONNEES_PARTIELLES" :
                    (found > 0 ? "CAMERA_METADONNEES_RELEVEES" : "CAMERA_REFERENCES_NULLES");
                report.Message = "Releve cible termine ; une projection exacte sur l'image du jeu reste a identifier et valider.";
                report.Stage = "TERMINE";
            }
            catch (ProbeLimitException ex)
            {
                report.Status = "CAMERA_LIMITE_RELEVE"; report.Message = ex.Message;
            }
            catch (TargetLimitException ex)
            {
                report.Status = "CAMERA_LIMITE_RELEVE"; report.Message = ex.Message;
            }
            catch (Exception ex)
            {
                report.Status = "CAMERA_LECTURE_NON_VALIDEE"; report.Message = ex.Message;
                foreach (CameraObjectReport item in report.Objects)
                {
                    item.IdentityValidated = false;
                    item.NativePointer = null; item.NativePointerFieldOffset = null;
                    item.MatrixCandidates.Clear();
                    if (item.Status == "METADONNEES_RELEVEES" || item.Status == "METADONNEES_PARTIELLES") item.Status = "STABILITE_NON_VALIDEE";
                }
            }
            finally
            {
                watch.Stop(); report.BytesRead = bytesRead; report.ReadCalls = readCalls; report.ElapsedMilliseconds = watch.ElapsedMilliseconds;
                if (report.Status == "CAMERA_LIMITE_RELEVE")
                    foreach (CameraObjectReport item in report.Objects)
                        if (item.Status == "NON_RELEVE") item.Status = "NON_RELEVE_BUDGET";
            }
            return report;
        }

        private void InspectObject(CameraObjectReport item, ulong instance, ulong declaredClass, ulong domain)
        {
            ulong vtable = ReadPointer(instance);
            ulong actualClass = ReadPointer(vtable);
            if (ReadPointer(vtable + 0x10) != domain) throw new IOException("Objet camera d'un autre domaine Mono.");
            Identity actualIdentity = ReadIdentity(actualClass);
            item.ActualType = actualIdentity.FullName;
            List<RuntimeClass> hierarchy = new List<RuntimeClass>();
            HashSet<ulong> seen = new HashSet<ulong>();
            ulong current = actualClass;
            bool typeConfirmed = false;
            while (current != 0)
            {
                if (hierarchy.Count >= MaxParents || !seen.Add(current)) throw new IOException("Heritage cyclique ou trop profond.");
                Identity identity = ReadIdentity(current);
                if (identity.Kind != 1)
                {
                    item.Status = "CLASSE_NON_PRISE_EN_CHARGE";
                    item.Warnings.Add("Classe " + identity.FullName + " : kind " + identity.Kind + ". Les champs de ce genre de classe ne sont pas interpretes.");
                    return;
                }
                // Attach the report before scanning fields: a bounded interruption
                // must retain the useful class and fields already collected.
                RuntimeClass type = ReadClass(current, false, null,
                    delegate(MonoClassReport value) { item.ClassHierarchy.Add(value); });
                if (type.Identity.Size > actualIdentity.Size) throw new IOException("Taille de parent superieure a celle de l'objet.");
                hierarchy.Add(type);
                if (current == declaredClass) typeConfirmed = true;
                current = identity.Parent;
            }
            if (!typeConfirmed) throw new IOException("Le type reel ne derive pas du type declare du champ camera.");
            bool partial = false;
            foreach (RuntimeClass type in hierarchy)
            {
                if (!type.Report.FieldsComplete) partial = true;
                foreach (RuntimeField field in type.Fields)
                {
                    if (field.Report.IsStatic || field.Report.IsLiteral || !String.IsNullOrEmpty(field.Report.Issue)) continue;
                    if (type.Identity.FullName == "UnityEngine.Object" && field.Report.Name == "m_CachedPtr")
                    {
                        if (field.Code != 0x18) throw new IOException("m_CachedPtr n'est pas un System.IntPtr confirme.");
                        CheckOffset(field.Report.Offset, 8, type.Identity.Size);
                        CheckOffset(field.Report.Offset, 8, actualIdentity.Size);
                        ulong pointer = ReadU64(Add(instance, field.Report.Offset));
                        if (pointer != 0) RequirePointer(pointer);
                        item.NativePointer = Hex(pointer);
                        item.NativePointerFieldOffset = field.Report.Offset;
                        if (pointer == 0) item.Warnings.Add("m_CachedPtr est nul ; l'objet natif peut etre absent ou detruit.");
                    }
                    else if (field.Code == 0x11 && field.Report.Type == "UnityEngine.Matrix4x4")
                    {
                        try { item.MatrixCandidates.Add(ReadMatrix(type, field, instance, actualIdentity.Size)); }
                        catch (ProbeLimitException) { throw; }
                        catch (TargetLimitException) { throw; }
                        catch (Exception ex) { partial = true; item.Warnings.Add("Matrice " + field.Report.Name + " : " + ex.Message); }
                    }
                }
            }
            if (ReadU64(instance) != vtable || ReadU64(vtable) != actualClass || ReadU64(vtable + 0x10) != domain)
                throw new IOException("L'identite de l'objet camera a change pendant le releve.");
            if (item.NativePointerFieldOffset.HasValue &&
                ReadU64(Add(instance, item.NativePointerFieldOffset.Value)) != ParseAddress(item.NativePointer))
                throw new IOException("Le pointeur natif a change pendant le releve.");
            item.Status = partial ? "METADONNEES_PARTIELLES" : "METADONNEES_RELEVEES";
        }

        private CameraMatrixCandidate ReadMatrix(RuntimeClass owner, RuntimeField field, ulong instance, int instanceSize)
        {
            RuntimeClass matrix = ReadClass(field.TypeData);
            if (matrix.Identity.FullName != "UnityEngine.Matrix4x4" || matrix.Identity.Size != 80)
                throw new IOException("Disposition de Matrix4x4 non confirmee.");
            // Mono field offsets of a value type include its 16-byte boxed-object header.
            for (int column = 0; column < 4; column++)
                for (int row = 0; row < 4; row++)
                {
                    RuntimeField component = FindField(matrix, "m" + row + column);
                    if (component == null || component.Code != 0x0C || component.Report.IsStatic || component.Report.IsLiteral ||
                        component.Report.Offset != 16 + (column * 4 + row) * 4)
                        throw new IOException("Ordre des composantes Matrix4x4 non confirme par les metadonnees.");
                }
            CheckOffset(field.Report.Offset, 64, instanceSize);
            CheckOffset(field.Report.Offset, 64, owner.Identity.Size);
            byte[] data = ReadRaw(Add(instance, field.Report.Offset), 64);
            float[] values = new float[16];
            for (int index = 0; index < 16; index++)
            {
                values[index] = BitConverter.ToSingle(data, index * 4);
                if (Single.IsNaN(values[index]) || Single.IsInfinity(values[index])) throw new IOException("Matrice non finie.");
            }
            return new CameraMatrixCandidate {
                DeclaringType = owner.Identity.FullName, Field = field.Report.Name, Offset = field.Report.Offset, Values = values
            };
        }

        private RuntimeClass ReadClass(ulong address, bool targetsOnly = false, MonoClassReport targetMetadata = null,
            Action<MonoClassReport> onReportCreated = null)
        {
            RuntimeClass cached;
            if (!targetsOnly && classes.TryGetValue(address, out cached))
            {
                if (onReportCreated != null) onReportCreated(cached.Report);
                return cached;
            }
            Identity identity = ReadIdentity(address);
            if (identity.Kind != 1) throw new IOException("Champs de classe kind " + identity.Kind + " non pris en charge.");
            byte[] data = ReadMeta(address, 0x110);
            int fieldCount = BitConverter.ToInt32(data, 0x100);
            if (fieldCount < 0 || fieldCount > MaxFields)
                throw new IOException("Nombre de champs de cette classe hors de la limite du releve camera.");
            if (totalFields > MaxTotalFields - fieldCount)
                throw new ProbeLimitException("Nombre total de champs du releve camera limite.");
            totalFields += fieldCount;
            ulong fields = BitConverter.ToUInt64(data, 0x98);
            if (fieldCount > 0) RequirePointer(fields);
            RuntimeClass type = new RuntimeClass { Identity = identity, Report = new MonoClassReport {
                Address = Hex(address), Name = identity.Name, Namespace = identity.Namespace,
                MetadataToken = "0x" + BitConverter.ToUInt32(data, 0x58).ToString("X8"),
                Parent = identity.Parent == 0 ? null : ReadIdentity(identity.Parent).FullName,
                InstanceSize = identity.Size, DeclaredFieldCount = fieldCount, FieldsComplete = true
            } };
            if (onReportCreated != null) onReportCreated(type.Report);
            HashSet<int> targetOffsets = new HashSet<int>();
            if (targetsOnly)
            {
                if (targetMetadata == null) throw new IOException("Metadonnees des champs cibles absentes.");
                foreach (string targetName in TargetFields)
                {
                    MonoFieldReport prior = FindField(targetMetadata, targetName);
                    if (prior != null) targetOffsets.Add(prior.Offset);
                }
                type.Report.FieldsComplete = false;
                type.Report.Issue = "Selection des champs camera cibles ; les autres champs ne sont pas decrits.";
            }
            HashSet<string> names = new HashSet<string>(StringComparer.Ordinal);
            try
            {
                for (int index = 0; index < fieldCount; index++)
                {
                    byte[] descriptor = ReadMeta(fields + (ulong)index * 32UL, 32);
                    if (BitConverter.ToUInt64(descriptor, 16) != address) throw new IOException("Proprietaire de champ incoherent.");
                    // Offset is only a cheap prefilter. The selected field is still
                    // checked by its live name, type, scope and exact offset against
                    // current inspection metadata before any object slot is followed.
                    if (targetsOnly && !targetOffsets.Contains(BitConverter.ToInt32(descriptor, 24))) continue;
                    string name = ReadName(BitConverter.ToUInt64(descriptor, 8), false);
                    if (!names.Add(name)) throw new IOException("Champ duplique dans une classe camera.");
                    if (targetsOnly && Array.IndexOf(TargetFields, name) < 0) continue;
                    ulong typePointer = BitConverter.ToUInt64(descriptor, 0);
                    byte[] monoType = ReadMeta(typePointer, 16);
                    ushort flags = BitConverter.ToUInt16(monoType, 8);
                    int offset = BitConverter.ToInt32(descriptor, 24);
                    bool isStatic = (flags & 0x10) != 0, isLiteral = (flags & 0x40) != 0;
                    if (offset < -1 || offset > 1048576 || (!isStatic && (offset < 16 || offset >= identity.Size)))
                        throw new IOException("Offset de champ camera hors de la taille declaree.");
                    RuntimeField field = new RuntimeField { Code = monoType[10], TypeData = BitConverter.ToUInt64(monoType, 0),
                        Report = new MonoFieldReport {
                            Name = name, Offset = offset, OffsetHex = offset < 0 ? "-1" : "0x" + offset.ToString("X"),
                            IsStatic = isStatic, IsLiteral = isLiteral, TypeCode = "0x" + monoType[10].ToString("X2"),
                            Storage = isLiteral ? "constante de metadonnees" : (isStatic ? "stockage statique non lu" : "depuis le debut de l'objet")
                        }
                    };
                    try
                    {
                        field.Report.Type = TypeName(typePointer, 0, new HashSet<ulong>());
                        if (field.Report.Type.IndexOf("non resolu", StringComparison.Ordinal) >= 0)
                            field.Report.Issue = "Type partiellement decrit ; aucun acces a sa valeur.";
                    }
                    catch (ProbeLimitException) { throw; }
                    catch (TargetLimitException) { throw; }
                    catch (Exception ex) { field.Report.Type = "non resolu"; field.Report.Issue = ex.Message; }
                    if (!String.IsNullOrEmpty(field.Report.Issue)) type.Report.FieldsComplete = false;
                    type.Fields.Add(field); type.Report.Fields.Add(field.Report);
                }
                if (!type.Report.FieldsComplete && !targetsOnly) type.Report.Issue = "Certains types de champs restent partiels.";
                if (!targetsOnly) classes.Add(address, type);
                return type;
            }
            catch (Exception ex)
            {
                type.Report.FieldsComplete = false;
                type.Report.Issue = "Releve de champs interrompu : " + ex.Message;
                // Do not cache an interrupted class; another target with a fresh
                // per-object budget can complete its own scan.
                throw;
            }
        }

        private Identity ReadIdentity(ulong address)
        {
            Identity existing;
            if (identities.TryGetValue(address, out existing)) return existing;
            byte[] data = ReadMeta(address, 0x60);
            int kind = data[0x1B], size = BitConverter.ToInt32(data, 0x1C);
            if (kind < 1 || kind > 6 || size < 16 || size > 1048576) throw new IOException("Identite de classe Mono incoherente.");
            ulong image = BitConverter.ToUInt64(data, 0x40);
            RequirePointer(image);
            uint token = BitConverter.ToUInt32(data, 0x58);
            if (kind == 1 && ((token & 0xFF000000U) != 0x02000000U || (token & 0x00FFFFFFU) == 0))
                throw new IOException("Jeton de classe Mono ordinaire invalide.");
            Identity result = new Identity {
                Address = address, Parent = BitConverter.ToUInt64(data, 0x30), Image = image, Kind = kind, Size = size,
                Name = ReadName(BitConverter.ToUInt64(data, 0x48), false),
                Namespace = ReadName(BitConverter.ToUInt64(data, 0x50), true)
            };
            if (result.Parent != 0) RequirePointer(result.Parent);
            identities.Add(address, result);
            return result;
        }

        private string TypeName(ulong address, int depth, HashSet<ulong> visited)
        {
            if (depth > 4 || !visited.Add(address)) throw new IOException("Description de type recursive ou trop profonde.");
            byte[] type = ReadMeta(address, 16);
            ulong data = BitConverter.ToUInt64(type, 0);
            switch (type[10])
            {
                case 0x01: return "System.Void"; case 0x02: return "System.Boolean";
                case 0x03: return "System.Char"; case 0x04: return "System.SByte"; case 0x05: return "System.Byte";
                case 0x06: return "System.Int16"; case 0x07: return "System.UInt16"; case 0x08: return "System.Int32";
                case 0x09: return "System.UInt32"; case 0x0A: return "System.Int64"; case 0x0B: return "System.UInt64";
                case 0x0C: return "System.Single"; case 0x0D: return "System.Double"; case 0x0E: return "System.String";
                case 0x0F: return TypeName(data, depth + 1, visited) + "*";
                case 0x10: return TypeName(data, depth + 1, visited) + "&";
                case 0x11: case 0x12: return ReadIdentity(data).FullName;
                case 0x13: case 0x1E: return "parametre generique non resolu";
                case 0x14: return ReadIdentity(BitConverter.ToUInt64(ReadMeta(data, 8), 0)).FullName + "[rang non resolu]";
                case 0x15: return ReadIdentity(BitConverter.ToUInt64(ReadMeta(data, 8), 0)).FullName + " [arguments generiques non resolus]";
                case 0x16: return "System.TypedReference"; case 0x18: return "System.IntPtr"; case 0x19: return "System.UIntPtr";
                case 0x1B: return "pointeur de fonction non resolu"; case 0x1C: return "System.Object";
                case 0x1D: return ReadIdentity(data).FullName + "[]";
                default: return "type non resolu 0x" + type[10].ToString("X2");
            }
        }

        private ulong CheckLocalObject(ulong instance, ulong expectedClass, out ulong domain,
            out ulong runtimeInfo, out ulong vtableSlot)
        {
            ulong vtable = ReadPointer(instance);
            if (ReadPointer(vtable) != expectedClass)
                throw new IOException("Le joueur local n'est pas une instance de la classe exacte EntityPlayerLocal.");
            // The game may instantiate objects in a child domain. Use this object's
            // domain, but require its vtable to be registered in the class runtime info.
            domain = ReadPointer(vtable + 0x10);
            runtimeInfo = ReadPointer(expectedClass + 0xD0);
            int maxDomain = BitConverter.ToUInt16(ReadRaw(runtimeInfo, 2), 0);
            if (maxDomain >= 32) throw new IOException("Plus de 32 emplacements de domaines Mono ; verification camera limitee.");
            byte[] entries = ReadRaw(runtimeInfo + 8UL, (maxDomain + 1) * 8);
            vtableSlot = 0;
            for (int index = 0; index <= maxDomain; index++)
            {
                ulong registered = BitConverter.ToUInt64(entries, index * 8);
                if (registered == 0) continue;
                RequirePointer(registered);
                if (registered == vtable)
                {
                    if (vtableSlot != 0) throw new IOException("Vtable du joueur local dupliquee dans les domaines de sa classe.");
                    vtableSlot = runtimeInfo + 8UL + (ulong)index * 8UL;
                }
            }
            if (vtableSlot == 0) throw new IOException("La vtable du joueur local n'est pas enregistree dans sa classe.");
            if (ReadU64(instance) != vtable || ReadU64(vtable) != expectedClass || ReadU64(vtable + 0x10) != domain ||
                ReadU64(expectedClass + 0xD0) != runtimeInfo || ReadU64(vtableSlot) != vtable)
                throw new IOException("La vtable ou le domaine du joueur local a change pendant la verification.");
            return vtable;
        }
        private static MonoClassReport FindLocalClass(MonoInspectionReport metadata)
        {
            MonoClassReport result = null;
            foreach (MonoClassReport type in metadata.Classes)
                if (type.Name == "EntityPlayerLocal" && String.IsNullOrEmpty(type.Namespace))
                { if (result != null) throw new IOException("Classe du joueur local ambigue."); result = type; }
            if (result == null) throw new IOException("Classe EntityPlayerLocal absente du rapport courant.");
            return result;
        }
        private static MonoFieldReport FindField(MonoClassReport type, string name)
        {
            MonoFieldReport result = null;
            foreach (MonoFieldReport field in type.Fields)
                if (field.Name == name) { if (result != null) throw new IOException("Champ cible ambigu."); result = field; }
            return result;
        }
        private static RuntimeField FindField(RuntimeClass type, string name)
        {
            foreach (RuntimeField field in type.Fields) if (field.Report.Name == name) return field;
            return null;
        }
        private string ReadName(ulong address, bool allowEmpty)
        {
            RequirePointer(address);
            List<byte> content = new List<byte>();
            for (int offset = 0; offset < 512; )
            {
                ulong current = address + (ulong)offset;
                int take = Math.Min(Math.Min(32, 512 - offset), 4096 - (int)(current & 4095UL));
                // Names are short and can be spread across hundreds of pages.
                // Fetch only the useful bytes, not a whole metadata page per name.
                byte[] bytes = ReadRaw(current, take);
                for (int index = 0; index < bytes.Length; index++)
                {
                    if (bytes[index] == 0)
                    {
                        string name;
                        try { name = utf8.GetString(content.ToArray()); }
                        catch (DecoderFallbackException ex) { throw new IOException("Nom de metadonnee UTF-8 invalide.", ex); }
                        if (!allowEmpty && name.Length == 0) throw new IOException("Nom de metadonnee vide.");
                        foreach (char character in name) if (Char.IsControl(character)) throw new IOException("Nom de metadonnee avec controle.");
                        return name;
                    }
                    content.Add(bytes[index]);
                }
                offset += take;
            }
            throw new IOException("Nom de metadonnee trop long ou non termine.");
        }
        private byte[] ReadMeta(ulong address, int count)
        {
            CheckRange(address, count); CheckBudget();
            byte[] result = new byte[count];
            int copied = 0;
            while (copied < count)
            {
                ulong current = address + (ulong)copied, block = current & ~((ulong)MetadataBlockSize - 1UL);
                byte[] data;
                if (!metadataBlocks.TryGetValue(block, out data))
                {
                    data = ReadRaw(block, MetadataBlockSize);
                    metadataBlocks.Add(block, data);
                }
                int offset = (int)(current - block), take = Math.Min(count - copied, MetadataBlockSize - offset);
                Buffer.BlockCopy(data, offset, result, copied, take); copied += take;
            }
            return result;
        }
        private byte[] ReadRaw(ulong address, int count)
        {
            CheckRange(address, count); CheckBudget();
            if (bytesRead > MaxBytes - count || readCalls >= MaxReads)
                throw new ProbeLimitException("Budget total de lecture camera atteint (1 Mio).");
            if (bytesRead - objectStartBytes > MaxObjectBytes - count)
                throw new TargetLimitException("Budget de lecture de cette cible camera atteint (256 Kio).");
            bytesRead += count; readCalls++;
            byte[] data = memory.Read(address, count);
            if (data == null || data.Length != count) throw new IOException("Lecture camera incomplete.");
            return data;
        }
        private ulong ReadU64(ulong address) { return BitConverter.ToUInt64(ReadRaw(address, 8), 0); }
        private ulong ReadPointer(ulong address) { ulong value = ReadU64(address); RequirePointer(value); return value; }
        private void CheckBudget()
        {
            if (watch.ElapsedMilliseconds >= MaxMilliseconds)
                throw new ProbeLimitException("Budget camera de 2 secondes atteint entre les appels materiels.");
        }
        private static void CheckRange(ulong address, int count)
        {
            RequirePointer(address);
            if (count < 1 || count > 4096 || address > 0x00007FFFFFFFFFFFUL - (ulong)count)
                throw new IOException("Plage memoire camera invalide.");
        }
        private static void RequirePointer(ulong value)
        {
            if (value < 0x10000 || value > 0x00007FFFFFFFFFFFUL) throw new IOException("Pointeur utilisateur x64 invalide.");
        }
        private static void CheckOffset(int offset, int width, int size)
        {
            if (offset < 16 || width < 1 || offset > size - width) throw new IOException("Champ hors des limites de l'objet.");
        }
        private static ulong Add(ulong address, int offset)
        {
            if (offset < 0 || address > 0x00007FFFFFFFFFFFUL - (ulong)offset) throw new IOException("Addition d'adresse invalide.");
            return address + (ulong)offset;
        }
        private static ulong ParseAddress(string value)
        {
            ulong result;
            if (value == null || !value.StartsWith("0x", StringComparison.Ordinal) ||
                !UInt64.TryParse(value.Substring(2), NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out result))
                throw new IOException("Adresse de metadonnee invalide.");
            return result;
        }
        private static ulong ParsePointer(string value) { ulong result = ParseAddress(value); RequirePointer(result); return result; }
        private static string Hex(ulong value) { return "0x" + value.ToString("X16"); }
    }
}
