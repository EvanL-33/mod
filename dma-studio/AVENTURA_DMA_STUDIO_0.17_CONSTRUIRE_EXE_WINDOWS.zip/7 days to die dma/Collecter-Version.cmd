@echo off
setlocal
set "SEVENDAYS_PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "SEVENDAYS_PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%SEVENDAYS_PS%" -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Collect-GameInfo.ps1"
set "SEVENDAYS_RESULT=%ERRORLEVEL%"
echo.
if "%SEVENDAYS_RESULT%"=="0" echo Rapport cree dans le sous-dossier rapports.
if "%SEVENDAYS_RESULT%"=="4" echo Rapport partiel cree dans rapports. Les limites sont detaillees dans le JSON.
if not "%SEVENDAYS_RESULT%"=="0" if not "%SEVENDAYS_RESULT%"=="4" echo Collecte terminee avec le code %SEVENDAYS_RESULT%.
pause
exit /b %SEVENDAYS_RESULT%
