using System;
using SevenDaysEsp;

namespace SevenDaysLoader.Services;

/// <summary>Optional details required by the active local views.</summary>
public static class LiveReadPolicy
{
    public static LiveReadOptions FromSettings(LoaderSettings settings, bool sharing, bool playerDetails = false)
    {
        ArgumentNullException.ThrowIfNull(settings);
        // Remote display profiles are independent and are not sent back to the
        // reader. Keep the full feed while sharing, including before pairing.
        if (sharing) return new LiveReadOptions();
        var players = settings.PlayerEsp;
        var zombies = settings.ZombieEsp;
        bool playerVisible = settings.EspEnabled && players?.Enabled == true;
        bool zombieVisible = settings.EspEnabled && zombies?.Enabled == true;
        bool namesVisible = settings.ShowProjectedEsp || settings.ShowRadar;
        bool playerColorVisible = settings.ShowRadar || (settings.ShowProjectedEsp &&
            (players?.HasProjectedContent == true || settings.PlayerFeatures.OffscreenIndicators));
        bool zombieColorVisible = settings.ShowRadar || (settings.ShowProjectedEsp && zombies?.HasProjectedContent == true);
        return new LiveReadOptions
        {
            PlayerNames = playerDetails || (playerVisible && namesVisible && players!.ShowNames),
            PlayerHealth = playerDetails || (playerVisible && ((settings.ShowProjectedEsp && players!.ShowHealth) ||
                (playerColorVisible && EntityDisplayRules.UsesHealthColor(players)))),
            ZombieNames = zombieVisible && namesVisible && zombies!.ShowNames,
            ZombieHealth = zombieVisible && ((settings.ShowProjectedEsp && zombies!.ShowHealth) ||
                (zombieColorVisible && EntityDisplayRules.UsesHealthColor(zombies))),
            PlayerMovement = playerVisible && settings.PvpSense?.ShowMovement == true,
            PlayerFacing = playerVisible && settings.PvpSense?.ShowFacing == true,
            PlayerHeldItem = playerVisible && settings.PvpSense?.ShowHeldItemId == true,
            ZombieAttackTarget = zombieVisible && settings.PvpSense?.ShowZombieTarget == true,
            WorldBloodMoon = settings.EspEnabled && settings.PvpSense?.ShowBloodMoon == true
        };
    }
}
