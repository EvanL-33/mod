# Aventura DMA Studio 0.17.0-dev - constructeur Windows x64.
# Ce script ne modifie pas le jeu ni les reglages du loader.
# .NET SDK 10 est installe via Winget uniquement avec l'accord explicite de l'utilisateur.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-DotNet10 {
    $candidates = New-Object 'System.Collections.Generic.List[string]'
    $cmd = Get-Command dotnet.exe -ErrorAction SilentlyContinue
    if ($null -ne $cmd) { $candidates.Add($cmd.Source) }
    if ($env:ProgramFiles) { $candidates.Add((Join-Path $env:ProgramFiles 'dotnet\dotnet.exe')) }
    if (${env:ProgramFiles(x86)}) { $candidates.Add((Join-Path ${env:ProgramFiles(x86)} 'dotnet\dotnet.exe')) }
    if ($env:LOCALAPPDATA) { $candidates.Add((Join-Path $env:LOCALAPPDATA 'Microsoft\dotnet\dotnet.exe')) }
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
        try {
            $sdks = @(& $candidate --list-sdks 2>$null)
            if ($LASTEXITCODE -eq 0 -and (@($sdks | Where-Object { $_ -match '^10\.' }).Count -gt 0)) {
                return $candidate
            }
        } catch { continue }
    }
    return $null
}

try {
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'Windows x64 est requis.' }
    $root = Join-Path $PSScriptRoot '7 days to die dma'
    $proj = Join-Path $root 'Loader\7DTD-Loader.csproj'
    $tests1 = Join-Path $root 'Loader\Tests\ServiceTests.csproj'
    $tests2 = Join-Path $root 'Loader\Tests\Controller\ControllerTests.csproj'
    $tests3 = Join-Path $root 'Loader\Tests\ControlBridge\ControlBridgeTests.csproj'
    foreach ($p in @($proj, $tests1, $tests2, $tests3)) {
        if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { throw "Source manquante : $p" }
    }
    Write-Host ''
    Write-Host 'AVENTURA DMA STUDIO 0.17 - COMPILATION WINDOWS X64' -ForegroundColor Cyan
    Write-Host 'Sources : ' $root
    $sdk = Get-DotNet10
    if (-not $sdk) {
        Write-Host ''
        Write-Host 'Le SDK .NET 10 est absent.' -ForegroundColor Yellow
        Write-Host 'Microsoft publie ce SDK avec le nom WinGet Microsoft.DotNet.SDK.10.'
        $answer = Read-Host "Autoriser son installation via WinGet ? (O/N)"
        if ($answer -notmatch '^[OoYy]$') { throw 'Installation refusee : compiler manuellement apres installation du SDK .NET 10.' }
        $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
        if (-not $winget) {
            throw 'WinGet indisponible. Installe le SDK .NET 10 depuis https://dotnet.microsoft.com/download/dotnet/10.0, puis relance le script.'
        }
        & $winget.Source install --id Microsoft.DotNet.SDK.10 --exact --source winget --accept-source-agreements --accept-package-agreements
        if ($LASTEXITCODE -ne 0) { throw "Installation du SDK interrompue (code $LASTEXITCODE)." }
        $sdk = Get-DotNet10
        if (-not $sdk) { throw 'SDK .NET 10 non detecte apres installation. Ferme la console, puis relance le script.' }
    }
    Write-Host "SDK : $sdk" -ForegroundColor Green
    & $sdk --version
    if ($LASTEXITCODE -ne 0) { throw 'Le SDK .NET ne repond pas.' }

    Set-Location -LiteralPath $root
    Write-Host ''
    Write-Host '[1/4] Tests des services...' -ForegroundColor Cyan
    & $sdk run --project $tests1 --configuration Release
    if ($LASTEXITCODE -ne 0) { throw 'Les tests des services ont echoue : publication interrompue.' }

    Write-Host ''
    Write-Host '[2/4] Tests du controleur...' -ForegroundColor Cyan
    & $sdk run --project $tests2 --configuration Release
    if ($LASTEXITCODE -ne 0) { throw 'Les tests du controleur ont echoue : publication interrompue.' }

    Write-Host ''
    Write-Host '[3/4] Tests du transport DMA...' -ForegroundColor Cyan
    & $sdk run --project $tests3 --configuration Release
    if ($LASTEXITCODE -ne 0) { throw 'Les tests du transport ont echoue : publication interrompue.' }

    Write-Host ''
    Write-Host '[4/4] Compilation et publication WPF autonome...' -ForegroundColor Cyan
    $dist = Join-Path $PSScriptRoot 'DIST\Aventura-DMA-Studio-0.17'
    if (Test-Path -LiteralPath $dist) { Remove-Item -LiteralPath $dist -Recurse -Force }
    New-Item -ItemType Directory -Path $dist -Force | Out-Null
    & $sdk publish $proj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o $dist
    if ($LASTEXITCODE -ne 0) { throw 'La compilation WPF a echoue : aucun EXE valide.' }

    $exe = Join-Path $dist '7DTD-Loader.exe'
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'La publication n a pas genere 7DTD-Loader.exe.' }
    $size = (Get-Item -LiteralPath $exe).Length
    if ($size -lt 100000) { throw 'Executable anormalement petit : publication refusee.' }
    # Valide MZ, signature PE et machine AMD64 sans charger le binaire en memoire.
    $stream = [System.IO.File]::OpenRead($exe)
    try {
        $reader = New-Object System.IO.BinaryReader($stream)
        if ($reader.ReadUInt16() -ne 0x5A4D) { throw 'Signature MZ invalide.' }
        $stream.Position = 0x3C
        $peOffset = $reader.ReadInt32()
        if ($peOffset -lt 64 -or $peOffset -gt 4096) { throw 'Offset PE invalide.' }
        $stream.Position = $peOffset
        if ($reader.ReadUInt32() -ne 0x00004550) { throw 'Signature PE invalide.' }
        if ($reader.ReadUInt16() -ne 0x8664) { throw 'Executable non x64.' }
    } finally { $stream.Dispose() }

    $sha = (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash
    $hashFile = Join-Path $dist 'SHA256-7DTD-Loader.txt'
    "7DTD-Loader.exe  SHA256 $sha" | Set-Content -LiteralPath $hashFile -Encoding ASCII
    $zipFile = Join-Path $PSScriptRoot 'DIST\Aventura-DMA-Studio-0.17-Windows-x64.zip'
    if (Test-Path -LiteralPath $zipFile) { Remove-Item -LiteralPath $zipFile -Force }
    Compress-Archive -LiteralPath $dist -DestinationPath $zipFile -CompressionLevel Optimal
    Write-Host ''
    Write-Host 'SUCCES : executable Windows x64 compile et verifie.' -ForegroundColor Green
    Write-Host "EXE : $exe"
    Write-Host "ZIP : $zipFile"
    Write-Host "SHA256 : $sha"
    Write-Host 'Tester sur une machine Windows avant de remplacer ton ancien loader.'
    exit 0
} catch {
    Write-Host ''
    Write-Host ('ERREUR : ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Le loader ancien reste inchange. Corrige le probleme avant de relancer.'
    exit 1
}
