using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SevenDaysEsp;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class PlayerProjectionTests
{
    public static Task OffscreenArrowsUseOutputEdgesWithoutChangingProjection()
    {
        var view = View();
        var mapping = Mapping(view, 1000, 800, ProjectionOutputMapping.Fit);
        var right = Arrow(view, mapping, Point(4, 0, -2));
        Close(right.Position.X, 978); Close(right.Position.Y, 400);
        Close(right.Direction.X, 1); Close(right.Direction.Y, 0);
        var left = Arrow(view, mapping, Point(-4, 0, -2));
        Close(left.Position.X, 22); Close(left.Position.Y, 400);
        var top = Arrow(view, mapping, Point(0, 4, -2));
        Close(top.Position.X, 500); Close(top.Position.Y, 22);
        var bottom = Arrow(view, mapping, Point(0, -4, -2));
        Close(bottom.Position.X, 500); Close(bottom.Position.Y, 778);
        Check(!ProjectionMath.TryProjectPoint(view, Point(4, 0, -2), out _),
            "The directional helper made an off-screen point into valid marker geometry.");
        Check(OffscreenProjection.TryCreateDirection(view, Point(0, 0, -2), out var visible) &&
            !OffscreenProjection.TryPlace(visible, mapping, view.Viewport, 22, out _),
            "A visible point received an edge arrow.");
        return Task.CompletedTask;
    }

    public static Task BehindArrowsKeepSidesAndRejectAmbiguousOrInvalidPositions()
    {
        var view = View();
        var mapping = Mapping(view, 1000, 800, ProjectionOutputMapping.Fit);
        var right = Arrow(view, mapping, Point(4, 0, 2));
        var left = Arrow(view, mapping, Point(-4, 0, 2));
        Check(right.Behind && left.Behind, "Behind information was lost.");
        Close(right.Position.X, 978); Close(left.Position.X, 22);
        foreach (var point in new[] { Point(0, 0, 2), Point(2, 0, 0), Point(float.NaN, 0, -2),
            Point(1_000_001, 0, -2), Point(4, 0, -.5f), Point(40, 0, -20) })
            Check(!OffscreenProjection.TryCreateDirection(view, point, out _),
                "An ambiguous axis, invalid position, or forward near/far violation produced an arrow.");
        Check(!OffscreenProjection.TryCreateDirection(null, Point(4, 0, -2), out _) &&
            !OffscreenProjection.TryCreateDirection(view, null, out _), "A missing camera/position produced direction.");
        Check(!OffscreenProjection.TryPlace(new(new(double.NaN, 0), false), mapping, view.Viewport, 22, out _) &&
            !OffscreenProjection.TryPlace(new(new(1500, 400), false), mapping, view.Viewport, double.NaN, out _),
            "Invalid directional output was accepted.");
        return Task.CompletedTask;
    }

    public static Task OffscreenMappingHandlesFitStretchFillAndCameraSubViewport()
    {
        var view = View(1920, 1080);
        foreach (var dimensions in new[] { (1280, 720), (2560, 1440), (3840, 2160), (3440, 1440), (1080, 1920) })
        foreach (string mode in new[] { ProjectionOutputMapping.Fit, ProjectionOutputMapping.Stretch, ProjectionOutputMapping.Fill })
        {
            var mapping = Mapping(view, dimensions.Item1, dimensions.Item2, mode);
            var arrow = Arrow(view, mapping, Point(4, 0, -2));
            Close(arrow.Position.X, mapping.ClipViewport.Right - 22);
            Close(arrow.Position.Y, mapping.ClipViewport.Y + mapping.ClipViewport.Height / 2);
        }
        var fit = Mapping(view, 3440, 1440, ProjectionOutputMapping.Fit);
        Close(Arrow(view, fit, Point(4, 0, -2)).Position.X, 2978);
        // The player is inside the source picture, but its origin is removed by
        // the output's vertical Fill crop. It needs an arrow only on that output.
        Check(OffscreenProjection.TryCreateDirection(view, Point(0, 1.8f, -2), out var cropped), "Valid crop fixture rejected.");
        Check(!OffscreenProjection.TryPlace(cropped, fit, view.Viewport, 22, out _), "Fit added an arrow for a visible player.");
        var fill = Mapping(view, 3440, 1440, ProjectionOutputMapping.Fill);
        Check(OffscreenProjection.TryPlace(cropped, fill, view.Viewport, 22, out var cropArrow), "Fill lost a cropped player direction.");
        Close(cropArrow.Position.Y, 22);
        var sub = View(1920, 1080, new(480, 270, 960, 540));
        var subMapping = Mapping(sub, 3440, 1440, ProjectionOutputMapping.Fit);
        var subArrow = Arrow(sub, subMapping, Point(4, 0, -2));
        Close(subArrow.Position.X, 2338); Close(subArrow.Position.Y, 720);
        var tiny = Mapping(view, 20, 20, ProjectionOutputMapping.Stretch);
        Check(!OffscreenProjection.TryPlace(cropped, tiny, view.Viewport, 22, out _), "Arrow escaped a too-small viewport.");
        var narrow = Mapping(view, 45, 45, ProjectionOutputMapping.Stretch);
        var narrowArrow = Arrow(view, narrow, Point(4, 0, -2));
        Check(!OffscreenProjection.TryPlaceCaption(narrowArrow, 32, 15, narrow.ClipViewport, 10, out _),
            "A tiny viewport clamped distance text onto its own arrow.");
        var normalArrow = Arrow(view, fit, Point(4, 0, -2));
        Check(OffscreenProjection.TryPlaceCaption(normalArrow, 45, 15, fit.ClipViewport, 10, out var caption) &&
            caption.Left >= fit.ClipViewport.X && caption.Right < normalArrow.Position.X - 10 &&
            caption.Top >= fit.ClipViewport.Y && caption.Bottom <= fit.ClipViewport.Bottom,
            "Normal directional distance text did not fit safely inside the camera viewport.");
        return Task.CompletedTask;
    }

    public static Task ProjectedFrameCopiesIdentityAndSeparateOffscreenDirections()
    {
        var view = View();
        string context = Guid.NewGuid().ToString("N");
        var visible = new LiveEntity { EntityId = 7, Kind = "player", Name = "Visible", Position = Point(.5f, 0, -2), IdentityToken = 14 };
        var offscreen = new LiveEntity { EntityId = 8, Kind = "player", Name = "Outside", Position = Point(4, 0, -2), IdentityToken = 15 };
        var zombie = new LiveEntity { EntityId = 9, Kind = "zombie", Name = "Zombie", Position = Point(-4, 0, -2) };
        var entities = new List<LiveEntity> { visible, offscreen, zombie };
        Check(ProjectionMath.TryBuildFrame(view, Point(0, 0, 0), 1, entities, null, out var frame, out _, context), "Valid identity frame rejected.");
        Check(frame!.PlayerContextId == context && frame.Markers.Count == 1 && frame.Markers[0].IdentityToken == 14,
            "Visible identity was dropped or invisible marker geometry invented.");
        Check(frame.PlayerDirections.Count == 2 && frame.PlayerDirections.Any(p => p.EntityId == 8 && p.IdentityToken == 15),
            "Directional candidates dropped a player or included a zombie.");
        visible.IdentityToken = 90; visible.Position.X = 100; offscreen.Name = "mutated"; entities.Clear();
        Check(frame.Markers[0].IdentityToken == 14 && frame.PlayerDirections[1].Name == "Outside",
            "A published projection changed through mutable source entities.");
        Check(ProjectionMath.TryBuildFrame(view, Point(0, 0, 0), 1, Array.Empty<LiveEntity>(), null, out var empty, out _) &&
            empty!.PlayerDirections.Count == 0 && empty.PlayerContextId == "", "Legacy/empty projection compatibility broke.");
        return Task.CompletedTask;
    }

    public static Task VisualAnnotationsNeverTransferToReusedOrUnknownIdentities()
    {
        string context = Guid.NewGuid().ToString("N"), nextContext = Guid.NewGuid().ToString("N");
        var hidden = new PlayerIdentity(context, 42, 7);
        var pinned = new PlayerIdentity(context, 43, 8);
        var snapshot = new PlayerSessionSnapshot
        {
            Revision = 17, HasCurrentData = true,
            Rows = new[]
            {
                new PlayerRow { Identity = hidden, Visual = new() { Hidden = true, Color = "#FF0000" } },
                new PlayerRow { Identity = pinned, Visual = new() { Pinned = true, Marked = true, Color = "#00FF00" } }
            }
        };
        var lookup = new PlayerVisualLookup(snapshot);
        Check(lookup.Revision == 17 && !lookup.TryResolve(context, 42, 7, out _), "Hidden player was exposed.");
        Check(lookup.TryResolve(context, 43, 8, out var state) && state.Pinned && state.Color == "#00FF00" &&
            PlayerVisualLookup.Priority(state) == 3, "Current individual style or priority was lost.");
        Check(!lookup.TryResolve(context, 99, 8, out _) && !lookup.TryResolve(nextContext, 43, 8, out _) &&
            !lookup.TryResolve(context, 43, 99, out _), "An annotation was inherited through an ID/token/context mismatch.");
        Check(!new PlayerVisualLookup(snapshot with { HasCurrentData = false }).TryResolve(context, 43, 8, out _),
            "Unavailable session data still authorized an annotated player draw.");
        Check(lookup.TryResolve("", 0, 8, out var neutral) && neutral == new PlayerVisualState(),
            "A legacy sender lost neutral rendering or acquired an annotation.");
        Check(!lookup.TryResolve("", 43, 8, out _) && !lookup.TryResolve(context, 0, 8, out _) &&
            !lookup.TryResolve("bad-context", 43, 8, out _), "Partial/invalid identity was mistaken for a legacy frame.");
        return Task.CompletedTask;
    }

    public static Task LabelPlacementIsBoundedStableAndPrioritizesMarkedPlayers()
    {
        var viewport = new ProjectionViewport(0, 0, 800, 600);
        var candidates = new[]
        {
            new LabelPlacementCandidate(7, 250, 220, 130, 30, 1),
            new LabelPlacementCandidate(90, 250, 220, 130, 30, 4),
            new LabelPlacementCandidate(3, 250, 220, 130, 30, 2),
            new LabelPlacementCandidate(5, 250, 220, 130, 30, 0)
        };
        var first = LabelPlacement.Place(candidates, viewport);
        var reordered = LabelPlacement.Place(candidates.Reverse(), viewport);
        Check(first.Count == 4 && first[90] == new ProjectionBox(250, 220, 380, 250), "Pinned text lost its original place.");
        foreach (var item in first)
        {
            Check(reordered.TryGetValue(item.Key, out var other) && item.Value == other, "Input ordering made the text jump.");
            Check(Math.Abs(item.Value.Left - 250) <= 96 && Math.Abs(item.Value.Top - 220) <= 96,
                "Placement moved a label farther than its bounded displacement.");
            Check(item.Value.Left >= 0 && item.Value.Right <= 800 && item.Value.Top >= 0 && item.Value.Bottom <= 600,
                "Placed label escaped the viewport.");
            foreach (var peer in first.Where(peer => peer.Key != item.Key))
                Check(!LabelPlacement.Intersects(item.Value, peer.Value, 3), "Text blocks still overlap.");
        }
        var blocked = LabelPlacement.Place(candidates, viewport, new[] { new ProjectionBox(0, 0, 800, 600) });
        Check(blocked.Count == 0, "Text was invented on top of reserved output instead of omitted.");
        Check(LabelPlacement.Place(candidates, viewport, maximumLabels: 1).Keys.SequenceEqual(new[] { 90 }),
            "Label budget ignored priority.");
        return Task.CompletedTask;
    }

    public static Task LabelPlacementRejectsInvalidBlocksAndKeepsReservedRegionsClear()
    {
        var viewport = new ProjectionViewport(100, 50, 300, 200);
        var candidates = new[]
        {
            new LabelPlacementCandidate(1, -50, -50, 100, 25, 2),
            new LabelPlacementCandidate(2, double.NaN, 10, 50, 25),
            new LabelPlacementCandidate(3, 100, 50, 500, 25),
            new LabelPlacementCandidate(-1, 100, 50, 50, 25),
            new LabelPlacementCandidate(4, 100, 50, 50, double.PositiveInfinity),
            new LabelPlacementCandidate(5, 100, 50, 80, 25, 1)
        };
        var reserved = new ProjectionBox(100, 50, 220, 80);
        var placed = LabelPlacement.Place(candidates, viewport, new[] { reserved });
        Check(placed.Count == 2 && placed.Keys.All(id => id is 1 or 5), "Invalid label candidates were laid out.");
        foreach (var box in placed.Values)
            Check(!LabelPlacement.Intersects(box, reserved, 3) && box.Left >= viewport.X && box.Top >= viewport.Y &&
                box.Right <= viewport.Right && box.Bottom <= viewport.Bottom, "Text hit a reserved indicator or escaped camera sub-viewport.");
        Check(LabelPlacement.Place(candidates, new(0, 0, double.NaN, 100)).Count == 0 &&
            LabelPlacement.Place(candidates, viewport, maximumLabels: 0).Count == 0,
            "Invalid viewport or zero budget produced text.");
        return Task.CompletedTask;
    }

    public static Task LabelBudgetPreservesCategoriesAndAllowsArrowOnlyProfiles()
    {
        var settings = new LoaderSettings();
        settings.PlayerEsp.MaxDistance = settings.ZombieEsp.MaxDistance = 500;
        var markers = Enumerable.Range(1, 40).Select(id => new ProjectedMarker(id, "player", "P", id, new(10, 10), null))
            .Concat(Enumerable.Range(100, 40).Select(id => new ProjectedMarker(id, "zombie", "Z", 1, new(20, 20), null))).ToArray();
        var chosen = EspDisplayPolicy.SelectProjectedLabels(settings, markers, 8, marker => marker.EntityId == 40 ? 4 : 0);
        Check(chosen.Count == 8 && chosen.Contains(40) && chosen.Count(id => id < 100) == 4 && chosen.Count(id => id >= 100) == 4,
            "Priority removed category reservations or omitted the pinned player.");
        foreach (var profile in new[] { settings.PlayerEsp, settings.ZombieEsp })
            profile.ShowBoxes = profile.ShowNames = profile.ShowHealth = profile.ShowDistances = profile.ShowTracers = false;
        Check(!EspDisplayPolicy.HasProjectedProfile(settings), "Empty profiles unexpectedly projected content.");
        settings.PlayerFeatures.OffscreenIndicators = true;
        Check(EspDisplayPolicy.HasProjectedProfile(settings) &&
            !EspDisplayPolicy.TryGetVisibleProfile(settings, "player", 10, true, out _) &&
            EspDisplayPolicy.TryGetVisibleProfile(settings, "player", 10, false, out _),
            "Arrow-only settings either disabled arrows or invented on-screen content.");
        settings.PlayerEsp.Enabled = false;
        Check(!EspDisplayPolicy.HasProjectedProfile(settings), "Player switch failed to disable arrow-only output.");
        return Task.CompletedTask;
    }

    private static OffscreenIndicator Arrow(ProjectionView view, ProjectionOutputMapping mapping, LivePosition position)
    {
        Check(OffscreenProjection.TryCreateDirection(view, position, out var direction) &&
            OffscreenProjection.TryPlace(direction, mapping, view.Viewport, 22, out _), "Known off-screen position rejected.");
        OffscreenProjection.TryPlace(direction, mapping, view.Viewport, 22, out var arrow);
        return arrow;
    }

    private static ProjectionView View(int width = 1000, int height = 800, ProjectionViewport? viewport = null)
    {
        float[] matrix = { 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, -11f / 9, -20f / 9, 0, 0, -1, 0 };
        Check(ProjectionMath.TryCreateView(matrix, Point(0, 0, 0), width, height, viewport ?? new(0, 0, width, height),
            ProjectionDepthRange.MinusOneToOne, out var view, out _), "Fixture camera rejected.");
        return view!;
    }

    private static ProjectionOutputMapping Mapping(ProjectionView view, int width, int height, string mode)
    {
        Check(ProjectionOutputMapping.TryCreate(view.SourceWidth, view.SourceHeight, width, height, view.Viewport, mode,
            out var mapping, out _), "Fixture output mapping rejected.");
        return mapping!;
    }

    private static LivePosition Point(float x, float y, float z) => new() { X = x, Y = y, Z = z };
    private static void Close(double actual, double expected)
    {
        if (!double.IsFinite(actual) || Math.Abs(actual - expected) > .00001)
            throw new InvalidOperationException($"Expected {expected:R}, got {actual:R}.");
    }
    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
