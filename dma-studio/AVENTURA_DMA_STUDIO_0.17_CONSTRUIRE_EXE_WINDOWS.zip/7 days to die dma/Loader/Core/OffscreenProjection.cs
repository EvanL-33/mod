#nullable enable
using System;

namespace SevenDaysEsp;

// For points behind the camera, SourcePoint is a direction-bearing virtual
// point, not a visible pixel or a position to reuse for boxes. It uses |w| to
// avoid reversing left/right simply because a player crossed behind the camera.
public readonly record struct OffscreenDirection(ProjectionPoint SourcePoint, bool Behind);
public readonly record struct OffscreenIndicator(ProjectionPoint Position, ProjectionPoint Direction, bool Behind);

public static class OffscreenProjection
{
    private const double MinimumW = 0.0000001;

    public static bool TryCreateDirection(ProjectionView? view, LivePosition? position, out OffscreenDirection direction)
    {
        direction = default;
        if (view == null || position == null || !ValidCoordinate(position.X) ||
            !ValidCoordinate(position.Y) || !ValidCoordinate(position.Z)) return false;
        double x = (double)position.X - view.OriginX;
        double y = (double)position.Y - view.OriginY;
        double z = (double)position.Z - view.OriginZ;
        var m = view.Matrix;
        double cx = m[0] * x + m[1] * y + m[2] * z + m[3];
        double cy = m[4] * x + m[5] * y + m[6] * z + m[7];
        double cz = m[8] * x + m[9] * y + m[10] * z + m[11];
        double cw = m[12] * x + m[13] * y + m[14] * z + m[15];
        if (!double.IsFinite(cx) || !double.IsFinite(cy) || !double.IsFinite(cz) ||
            !double.IsFinite(cw) || Math.Abs(cw) < MinimumW) return false;
        bool behind = cw < 0;
        // Being off to one side does not grant an exception to the forward
        // near/far interval. Behind arrows express direction only.
        if (!behind)
        {
            double minimum = view.DepthRange == ProjectionDepthRange.MinusOneToOne ? -cw : 0;
            double tolerance = Math.Max(1, cw) * 0.000001;
            if (cz < minimum - tolerance || cz > cw + tolerance) return false;
        }
        double nx = cx / Math.Abs(cw), ny = cy / Math.Abs(cw);
        if (!double.IsFinite(nx) || !double.IsFinite(ny)) return false;
        if (behind && Math.Abs(nx) + Math.Abs(ny) < 0.0000001) return false;
        var viewport = view.Viewport;
        var point = new ProjectionPoint(viewport.X + (nx + 1) * viewport.Width / 2,
            viewport.Y + (1 - ny) * viewport.Height / 2);
        if (!double.IsFinite(point.X) || !double.IsFinite(point.Y)) return false;
        direction = new(point, behind);
        return true;
    }

    // Both the return value and margin are physical output pixels. DPI belongs
    // to the renderer and must not be applied again to this geometry.
    public static bool TryPlace(OffscreenDirection direction, ProjectionOutputMapping? mapping,
        ProjectionViewport sourceViewport, double margin, out OffscreenIndicator indicator)
    {
        indicator = default;
        if (mapping == null || !mapping.HasVisibleViewport || !double.IsFinite(margin) || margin < 0 ||
            !double.IsFinite(direction.SourcePoint.X) || !double.IsFinite(direction.SourcePoint.Y) ||
            !ValidViewport(sourceViewport, mapping.SourceWidth, mapping.SourceHeight)) return false;
        var viewport = mapping.ClipViewport;
        double halfWidth = viewport.Width / 2 - margin;
        double halfHeight = viewport.Height / 2 - margin;
        if (halfWidth <= 0 || halfHeight <= 0) return false;
        double centerX = viewport.X + viewport.Width / 2, centerY = viewport.Y + viewport.Height / 2;
        double dx, dy;
        if (direction.Behind)
        {
            dx = (direction.SourcePoint.X - sourceViewport.X - sourceViewport.Width / 2) * mapping.ScaleX;
            dy = (direction.SourcePoint.Y - sourceViewport.Y - sourceViewport.Height / 2) * mapping.ScaleY;
        }
        else
        {
            double mappedX = direction.SourcePoint.X * mapping.ScaleX + mapping.OffsetX;
            double mappedY = direction.SourcePoint.Y * mapping.ScaleY + mapping.OffsetY;
            if (!double.IsFinite(mappedX) || !double.IsFinite(mappedY)) return false;
            if (mappedX >= viewport.X && mappedX <= viewport.Right &&
                mappedY >= viewport.Y && mappedY <= viewport.Bottom) return false;
            dx = mappedX - centerX; dy = mappedY - centerY;
        }
        if (!double.IsFinite(dx) || !double.IsFinite(dy)) return false;
        double length = Math.Sqrt(dx * dx + dy * dy);
        if (!double.IsFinite(length) || length < 0.0000001) return false;
        dx /= length; dy /= length;
        double t = Math.Min(Math.Abs(dx) < 0.0000001 ? double.PositiveInfinity : halfWidth / Math.Abs(dx),
            Math.Abs(dy) < 0.0000001 ? double.PositiveInfinity : halfHeight / Math.Abs(dy));
        if (!double.IsFinite(t) || t <= 0) return false;
        indicator = new(new(centerX + dx * t, centerY + dy * t), new(dx, dy), direction.Behind);
        return true;
    }

    public static bool TryPlaceCaption(OffscreenIndicator indicator, double width, double height,
        ProjectionViewport viewport, double arrowRadius, out ProjectionBox caption)
    {
        caption = default;
        if (!double.IsFinite(width) || !double.IsFinite(height) || width <= 0 || height <= 0 ||
            !double.IsFinite(viewport.X) || !double.IsFinite(viewport.Y) || !double.IsFinite(viewport.Width) ||
            !double.IsFinite(viewport.Height) || width > viewport.Width || height > viewport.Height ||
            !double.IsFinite(viewport.Right) || !double.IsFinite(viewport.Bottom) ||
            !double.IsFinite(arrowRadius) || arrowRadius < 0 ||
            !double.IsFinite(indicator.Position.X) || !double.IsFinite(indicator.Position.Y) ||
            !double.IsFinite(indicator.Direction.X) || !double.IsFinite(indicator.Direction.Y)) return false;
        double length = Math.Sqrt(indicator.Direction.X * indicator.Direction.X + indicator.Direction.Y * indicator.Direction.Y);
        if (!double.IsFinite(length) || Math.Abs(length - 1) > 0.000001 ||
            indicator.Position.X < viewport.X || indicator.Position.X > viewport.Right ||
            indicator.Position.Y < viewport.Y || indicator.Position.Y > viewport.Bottom) return false;
        double separation = arrowRadius + 4 + Math.Sqrt(width * width + height * height) / 2;
        double x = Math.Clamp(indicator.Position.X - indicator.Direction.X * separation - width / 2,
            viewport.X, viewport.Right - width);
        double y = Math.Clamp(indicator.Position.Y - indicator.Direction.Y * separation - height / 2,
            viewport.Y, viewport.Bottom - height);
        var bounds = new ProjectionBox(x, y, x + width, y + height);
        // On a tiny output, clamping can push the caption onto its own arrow.
        // Omit optional text instead of making a misleading combined symbol.
        var arrow = new ProjectionBox(indicator.Position.X - arrowRadius, indicator.Position.Y - arrowRadius,
            indicator.Position.X + arrowRadius, indicator.Position.Y + arrowRadius);
        if (bounds.Left < arrow.Right + 3 && bounds.Right + 3 > arrow.Left &&
            bounds.Top < arrow.Bottom + 3 && bounds.Bottom + 3 > arrow.Top) return false;
        caption = bounds;
        return true;
    }

    private static bool ValidCoordinate(double value) => double.IsFinite(value) &&
        Math.Abs(value) <= ProjectionMath.MaximumCoordinate;

    private static bool ValidViewport(ProjectionViewport r, int width, int height) =>
        double.IsFinite(r.X) && double.IsFinite(r.Y) && double.IsFinite(r.Width) && double.IsFinite(r.Height) &&
        r.X >= 0 && r.Y >= 0 && r.Width > 0 && r.Height > 0 && r.Right <= width && r.Bottom <= height;
}
