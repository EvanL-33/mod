using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using SevenDaysEsp;

namespace SevenDaysLoader.UI;

internal sealed class SettingsPanel : StackPanel
{
    private readonly ILoaderController controller;
    private readonly List<Action> refresh = new();
    private readonly DispatcherTimer saveTimer = new() { Interval = TimeSpan.FromMilliseconds(350) };
    private bool updating;
    private bool pendingSave;
    private Action<string>? selectCategory;
    internal void SelectCategory(string name) => selectCategory?.Invoke(name);
    internal static readonly string[] AllowedKeys = { "Insert", "Home", "F6", "F7", "F8", "F9", "F10", "F11" };
    private static readonly string[] Palette = { "#66DEF2", "#FF9A52", "#9BF0A3", "#F881AA", "#C6A0FF", "#FFE27A", "#FFFFFF" };
    private static readonly CultureInfo French = CultureInfo.GetCultureInfo("fr-FR");

    internal SettingsPanel(ILoaderController controller, bool includePlacement = true, Action? activateFuser = null)
    {
        this.controller = controller;
        var s = controller.Settings;
        var presets = new PresetPanel(controller, Flush, Refresh);
        Children.Add(presets);
        refresh.Add(presets.Refresh);
        Children.Add(Theme.Eyebrow("CONFIGURATION DE L’AFFICHAGE"));
        var master = Toggle("Activer l’affichage général", () => s.EspEnabled, v => s.EspEnabled = v);
        master.FontSize = 16;
        master.FontWeight = FontWeights.SemiBold;
        master.Margin = new Thickness(0, 5, 0, 9);
        Children.Add(master);
        Children.Add(ToggleGrid(
            Toggle("ESP en jeu", () => s.ShowProjectedEsp, v => s.ShowProjectedEsp = v),
            Toggle("Radar", () => s.ShowRadar, v => s.ShowRadar = v)));
        Children.Add(BuildProjectionStatus());

        // Create each view once. Live refreshes update controls in place and do
        // not rebuild the selected tab, steal focus or move the scroll position.
        var tabs = new List<(string Label, UIElement Content)>
        {
            ("Joueurs", BuildPlayers()),
            ("Surveillance", BuildAdminWatch()),
            ("Zombies", BuildEntityProfile(false)),
            ("PvP DMA", BuildPvpSense()),
            ("Partie", BuildGame()),
            ("Général", BuildGeneral())
        };
        if (includePlacement) tabs.Add(("Sortie", BuildPlacement(activateFuser)));
        var strip = new WrapPanel { Margin = new Thickness(0, 8, 0, 19), Orientation = Orientation.Horizontal };
        strip.ToolTip = "Les catégories se réorganisent lorsque le menu est étroit.";
        var host = new ContentControl { HorizontalContentAlignment = HorizontalAlignment.Stretch };
        var buttons = new List<Button>();
        void SelectTab(int selected)
        {
            host.Content = tabs[selected].Content;
            for (int i = 0; i < buttons.Count; i++) Theme.SelectSegment(buttons[i], i == selected);
        }
        for (int i = 0; i < tabs.Count; i++)
        {
            int index = i;
            var button = Theme.Segment(tabs[i].Label, () => SelectTab(index));
            button.Margin = new Thickness(0, 0, 7, 7);
            buttons.Add(button);
            strip.Children.Add(button);
        }
        selectCategory = name =>
        {
            int target = tabs.FindIndex(x => string.Equals(x.Label, name, StringComparison.OrdinalIgnoreCase));
            if (target >= 0) SelectTab(target);
        };
        SelectTab(0);
        Children.Add(strip);
        Children.Add(host);

        saveTimer.Tick += (_, _) => Flush();
        Unloaded += (_, _) => Flush();
        Refresh();
    }

    private UIElement BuildGame()
    {
        var creative = new CreativeMenuPanel(controller);
        refresh.Add(creative.Refresh);
        var character = new PlayerControlPanel(controller);
        refresh.Add(character.Refresh);
        var stats = new PlayerDmaStatsPanel(controller);
        refresh.Add(stats.Refresh);
        var notice = Theme.Text("", 11, Theme.Orange);
        notice.MinHeight = 18;
        var creativeContent = Theme.Stack(creative,
            SectionTitle("RACCOURCI DU CRÉATIF"),
            HotkeySelection("Activer / désactiver le menu créatif", "creative",
                () => controller.Settings.CreativeMenuKey, v => controller.Settings.CreativeMenuKey = v, notice, optional: true),
            notice,
            Theme.Text("La touche agit sur le PC du loader, avec une partie récente et validée. Chaque appui relit l’état puis le bascule une seule fois. Elle reste indépendante des touches d’affichage.", 11, Theme.Muted),
            Theme.Text("Une reconnexion ne réactive pas le créatif. Le résultat apparaît ici et dans le journal.", 11, Theme.Muted));
        var host = new ContentControl { HorizontalContentAlignment = HorizontalAlignment.Stretch, Content = character };
        Button? characterButton = null, creativeButton = null, statsButton = null;
        void Select(int selected)
        {
            host.Content = selected == 0 ? character : selected == 1 ? creativeContent : stats;
            Theme.SelectSegment(characterButton!, selected == 0);
            Theme.SelectSegment(creativeButton!, selected == 1);
            Theme.SelectSegment(statsButton!, selected == 2);
        }
        characterButton = Theme.Segment("Personnage", () => Select(0));
        creativeButton = Theme.Segment("Menu créatif", () => Select(1));
        statsButton = Theme.Segment("Stats DMA", () => Select(2));
        var strip = new Grid { Margin = new Thickness(0, 0, 0, 15) };
        for (int i = 0; i < 3; i++) strip.ColumnDefinitions.Add(new ColumnDefinition());
        characterButton.Margin = new Thickness(0, 0, 5, 0);
        creativeButton.Margin = new Thickness(0, 0, 5, 0);
        Grid.SetColumn(creativeButton, 1); Grid.SetColumn(statsButton, 2);
        strip.Children.Add(characterButton); strip.Children.Add(creativeButton); strip.Children.Add(statsButton);
        Select(0);
        return Theme.Stack(strip, host);
    }

    private UIElement BuildPlayers()
    {
        var players = new PlayerPanel(controller);
        refresh.Add(players.Refresh);
        return Theme.Stack(players, BuildEntityProfile(true), BuildPlayerFeatures());
    }

    private UIElement BuildPlayerFeatures()
    {
        Func<PlayerFeaturesSettings> features = () => controller.Settings.PlayerFeatures;
        var arrows = Toggle("Flèches pour les joueurs hors champ", () => features().OffscreenIndicators, v => features().OffscreenIndicators = v);
        arrows.ToolTip = "Affiche une direction au bord de l’image uniquement avec une caméra récente et validée. La portée du profil joueurs reste appliquée.";
        var pinned = Toggle("Afficher la carte du joueur épinglé", () => features().ShowPinnedCard, v => features().ShowPinnedCard = v);
        pinned.ToolTip = "La carte accompagne l’état de connexion. Active aussi « Afficher l’état de connexion » dans Général pour la voir sur la sortie.";
        var trend = Toggle("Tendance de distance du joueur épinglé", () => features().ShowDistanceTrend, v => features().ShowDistanceTrend = v);
        trend.ToolTip = "Indique si la distance entre vous diminue, reste stable ou augmente. Ton propre déplacement est inclus ; aucune vitesse absolue du joueur n’est déduite.";
        var overlap = Toggle("Éviter le chevauchement des textes ESP", () => features().AvoidLabelOverlap, v => features().AvoidLabelOverlap = v);
        overlap.ToolTip = "Les textes des joueurs épinglés, sélectionnés puis marqués sont prioritaires. Les blocs qui n’ont pas de place sont masqués ; les cadres restent à leur position réelle.";
        var proximity = new Expander
        {
            Header = "Alertes de proximité", IsExpanded = false, Foreground = Theme.Foreground,
            Margin = new Thickness(0, 9, 0, 9),
            Content = Theme.Stack(
                Theme.Text("Signale l’arrivée d’un joueur dans ton rayon à partir de captures récentes. La proximité ne détermine pas s’il est hostile.", 11, Theme.Muted),
                Toggle("Activer les alertes de proximité", () => features().ProximityAlerts, v => features().ProximityAlerts = v),
                SliderRow("Rayon d’alerte", 10, 1000, () => features().AlertDistance, v => features().AlertDistance = (int)Math.Round(v), "m", 1),
                SliderRow("Distance à dépasser pour réarmer", 5, 100, () => features().AlertRearmMargin, v => features().AlertRearmMargin = (int)Math.Round(v), "m", 1),
                Theme.Text("Cette marge s’ajoute au rayon. Elle évite de répéter une alerte quand un joueur reste à la limite.", 10, Theme.Muted),
                SliderRow("Délai entre deux alertes", 3, 120, () => features().AlertCooldownSeconds, v => features().AlertCooldownSeconds = (int)Math.Round(v), "s", 1),
                Toggle("Uniquement les joueurs marqués", () => features().AlertsMarkedOnly, v => features().AlertsMarkedOnly = v),
                Toggle("Jouer un son sur le PC du loader", () => features().AlertSound, v => features().AlertSound = v),
                Theme.Text("Un joueur masqué individuellement ne déclenche pas d’alerte. Le son est désactivé par défaut.", 10, Theme.Muted))
        };
        return Theme.Stack(
            SectionTitle("REPÈRES JOUEURS"), pinned, trend, overlap, arrows,
            Toggle("Afficher la distance près des flèches", () => features().OffscreenDistances, v => features().OffscreenDistances = v),
            SliderRow("Nombre maximal de flèches", 1, 32, () => features().MaximumOffscreenIndicators,
                v => features().MaximumOffscreenIndicators = (int)Math.Round(v), "", 1),
            proximity,
            Theme.Text("Ces options sont enregistrées séparément des préréglages ESP. Les marquages individuels restent propres à la session en cours.", 10, Theme.Muted));
    }

    private UIElement BuildPvpSense()
    {
        var pvp = controller.Settings.PvpSense ??= new PvpSenseSettings();
        return Theme.Stack(
            SectionTitle("ESP PVP AVANCÉ · DMA SEULE"),
            Theme.Text("Lectures facultatives du client. Les objets sont indiqués par leur identifiant technique, pas par un nom d'arme supposé. Les orientations ne prouvent pas qu'un joueur te vise.", 11, Theme.Muted),
            Toggle("Objet tenu par les joueurs (ID)", () => pvp.ShowHeldItemId, v => pvp.ShowHeldItemId = v),
            Toggle("Accroupissement / course / saut des joueurs", () => pvp.ShowMovement, v => pvp.ShowMovement = v),
            Toggle("Signaler l'orientation du corps vers toi", () => pvp.ShowFacing, v => pvp.ShowFacing = v),
            SliderRow("Demi-angle de l'orientation", 10, 90,
                () => pvp.FacingConeDegrees, v => pvp.FacingConeDegrees = (int)Math.Round(v), "°", 1),
            SectionTitle("ZOMBIES ET BLOOD MOON"),
            Toggle("Repérer les zombies dont la cible locale est confirmée", () => pvp.ShowZombieTarget,
                v => pvp.ShowZombieTarget = v),
            Toggle("Son lors d'une nouvelle cible zombie (PC du loader)", () => pvp.ZombieTargetSound,
                v => pvp.ZombieTargetSound = v),
            SliderRow("Délai entre sons zombies", 5, 120,
                () => pvp.SoundCooldownSeconds, v => pvp.SoundCooldownSeconds = (int)Math.Round(v), "s", 1),
            Toggle("Afficher jour / heure / état Blood Moon", () => pvp.ShowBloodMoon,
                v => pvp.ShowBloodMoon = v),
            Theme.Text("Le ciblage des zombies n'est annoncé que si leur pointeur attackTarget correspond à ton personnage. Sinon, l'état est inconnu. Toutes les options sont désactivées par défaut.", 11, Theme.Muted));
    }

    private UIElement BuildAdminWatch()
    {
        var watch = controller.Settings.AdminWatch ??= new AdminWatchSettings();
        var names = new TextBox { Text = watch.Names, AcceptsReturn = true, TextWrapping = TextWrapping.Wrap,
            MinHeight = 65, MaxLength = 2048, ToolTip = "Pseudos exacts, séparés par une virgule ou un saut de ligne." };
        names.TextChanged += (_, _) => { if (!updating) { watch.Names = names.Text; Save(debounce: true); } };
        return Theme.Stack(
            SectionTitle("SURVEILLANCE EXPÉRIMENTALE · DMA"),
            Theme.Text("Surveille uniquement les joueurs dont le pseudo apparaît dans les données du client. Un pseudo ne prouve ni un statut admin, ni une invisibilité. Si le serveur ne transmet pas l'entité, la DMA ne peut pas la détecter.", 11, Theme.Muted),
            Toggle("Activer la liste de surveillance", () => watch.Enabled, v => watch.Enabled = v),
            Theme.Label("Pseudos à suivre (liste manuelle)"), names,
            Toggle("ESP violet sur les joueurs identifiés", () => watch.PurpleEsp, v => watch.PurpleEsp = v),
            Toggle("Alerte sonore sur le PC du loader", () => watch.Sound, v => watch.Sound = v),
            SliderRow("Portée des alertes", 5, 1000, () => watch.AlertRangeMeters,
                v => watch.AlertRangeMeters = (int)Math.Round(v), "m", 1),
            SliderRow("Délai entre alertes", 5, 120, () => watch.CooldownSeconds,
                v => watch.CooldownSeconds = (int)Math.Round(v), "s", 1),
            Theme.Text("La surveillance est désactivée par défaut. Les alertes s'appuient sur les captures DMA fraîches, pas sur les logs ou les commandes du serveur.", 11, Theme.Muted));
    }

    private UIElement BuildEntityProfile(bool players)
    {
        Func<EntityEspSettings> profile = players ? () => controller.Settings.PlayerEsp : () => controller.Settings.ZombieEsp;
        string title = players ? "ESP joueurs" : "ESP zombies";
        string other = players ? "zombies" : "joueurs";
        var heading = Theme.Text(title, 20, null, true);
        heading.Margin = new Thickness(0, 0, 0, 3);
        var description = Theme.Text("Ce profil ne modifie pas les réglages des " + other + ".", 11, Theme.Muted);
        var active = Toggle(players ? "Afficher les joueurs" : "Afficher les zombies", () => profile().Enabled, v => profile().Enabled = v);
        active.FontWeight = FontWeights.SemiBold;
        active.Margin = new Thickness(0, 7, 0, 6);
        var state = Theme.Text("", 11, Theme.Muted);
        state.TextWrapping = TextWrapping.NoWrap;
        state.TextTrimming = TextTrimming.CharacterEllipsis;
        state.Height = 18;
        state.Margin = new Thickness(0, 0, 0, 8);
        var accent = new Border
        {
            BorderBrush = players ? Theme.Cyan : Theme.Orange,
            BorderThickness = new Thickness(3, 0, 0, 0),
            Padding = new Thickness(12, 0, 0, 0),
            Margin = new Thickness(0, 0, 0, 8),
            Child = Theme.Stack(heading, description, active, state)
        };
        refresh.Add(() =>
        {
            var value = profile();
            bool hasProjectedContent = value.HasProjectedContent || (players && controller.Settings.PlayerFeatures.OffscreenIndicators);
            state.Text = !value.Enabled ? "Profil masqué · les réglages restent modifiables."
                : !hasProjectedContent ? "Aucun repère ESP sélectionné dans ce profil."
                : "Profil activé · portée " + value.MaxDistance.ToString(French) + " m";
            state.Foreground = value.Enabled && !hasProjectedContent ? Theme.Orange : Theme.Muted;
        });

        var boxes = Toggle("Afficher les cadres", () => profile().ShowBoxes, v => profile().ShowBoxes = v);
        var names = Toggle("Noms", () => profile().ShowNames, v => profile().ShowNames = v);
        var health = Toggle("Vie (PV)", () => profile().ShowHealth, v => profile().ShowHealth = v);
        health.ToolTip = "Vie lue dans le jeu. Une barre apparaît si le maximum est confirmé ; PV — indique une valeur indisponible.";
        var distance = Toggle("Distances", () => profile().ShowDistances, v => profile().ShowDistances = v);
        var tracers = Toggle("Traits de liaison", () => profile().ShowTracers, v => profile().ShowTracers = v);
        tracers.ToolTip = "Trace un trait depuis le bas de l’image vers chaque entité visible de cette catégorie.";
        return Theme.Stack(
            accent,
            SliderRow("Portée maximale", 25, 5000, () => profile().MaxDistance, v => profile().MaxDistance = (int)Math.Round(v), "m", 1),
            ColorRow("Couleur du profil", () => profile().Color, v => profile().Color = v),
            SectionTitle("CADRES"), boxes,
            SegmentedSelection(new[] { "full", "corners" }, new[] { "Cadre complet", "Coins uniquement" },
                () => profile().BoxStyle, v => profile().BoxStyle = v),
            SectionTitle("INFORMATIONS ET TRAITS"),
            ToggleGrid(names, health, distance, tracers),
            SectionTitle("LISIBILITÉ"),
            SliderRow("Taille du texte", 10, 20, () => profile().FontSize, v => profile().FontSize = Math.Round(v, 1), "", 0.5),
            SliderRow("Épaisseur des traits", 1, 4, () => profile().LineThickness, v => profile().LineThickness = Math.Round(v, 1), "", 0.1),
            BuildDisplayRules(profile, players),
            Theme.Text("L’activation, les couleurs et le filtre de hauteur s’appliquent aussi au radar. Sa portée peut être séparée dans Général. Les cadres et les traits de liaison concernent l’ESP en jeu.", 11, Theme.Muted));
    }

    private UIElement BuildDisplayRules(Func<EntityEspSettings> profile, bool players)
    {
        Func<EntityDisplayRulesSettings> rules = () => profile().Rules;
        var height = Theme.Stack(
            Toggle("Filtrer par différence de hauteur", () => rules().HeightFilterEnabled, v => rules().HeightFilterEnabled = v),
            SliderRow("Hauteur maximale au-dessus / en dessous", 1, 500,
                () => rules().MaxHeightDifferenceMeters, v => rules().MaxHeightDifferenceMeters = (int)Math.Round(v), "m", 1),
            Toggle("Indiquer au-dessus / en dessous", () => rules().ShowHeightIndicator, v => rules().ShowHeightIndicator = v));
        if (players)
            height.Children.Add(Toggle("Garder le joueur épinglé malgré le filtre de hauteur",
                () => rules().ExemptPinnedFromHeightFilter, v => rules().ExemptPinnedFromHeightFilter = v));
        height.Children.Add(Theme.Text("Différence verticale avec ta position. Un joueur masqué reste masqué ; la portée reste appliquée.", 10, Theme.Muted));

        var healthThresholds = Theme.Stack(
            SliderRow("PV faibles : jusqu’à", 1, 99, () => rules().HealthLowPercent,
                v => { rules().HealthLowPercent = (int)Math.Round(v); rules().HealthHighPercent = Math.Max(rules().HealthHighPercent, rules().HealthLowPercent + 1); }, "%", 1),
            SliderRow("PV élevés : à partir de", 2, 100, () => rules().HealthHighPercent,
                v => { rules().HealthHighPercent = (int)Math.Round(v); rules().HealthLowPercent = Math.Min(rules().HealthLowPercent, rules().HealthHighPercent - 1); }, "%", 1),
            Theme.Text("Si la vie ou son maximum n’est pas confirmé, la couleur du profil est conservée.", 10, Theme.Muted));
        var distanceThresholds = Theme.Stack(
            SliderRow("Distance proche : jusqu’à", 0, 4999, () => rules().DistanceNearMeters,
                v => { rules().DistanceNearMeters = (int)Math.Round(v); rules().DistanceFarMeters = Math.Max(rules().DistanceFarMeters, rules().DistanceNearMeters + 1); }, "m", 1),
            SliderRow("Distance lointaine : à partir de", 1, 5000, () => rules().DistanceFarMeters,
                v => { rules().DistanceFarMeters = (int)Math.Round(v); rules().DistanceNearMeters = Math.Min(rules().DistanceNearMeters, rules().DistanceFarMeters - 1); }, "m", 1),
            Theme.Text("L’ESP mesure la distance dans l’espace ; le radar mesure la distance horizontale. Une grande différence de hauteur peut donc donner des couleurs différentes.", 10, Theme.Muted));
        var palette = Theme.Stack(
            ColorRow("PV faibles / proche", () => rules().LowColor, v => rules().LowColor = v),
            ColorRow("Intermédiaire", () => rules().MiddleColor, v => rules().MiddleColor = v),
            ColorRow("PV élevés / loin", () => rules().HighColor, v => rules().HighColor = v));
        refresh.Add(() =>
        {
            healthThresholds.Visibility = rules().ColorMode == "health" ? Visibility.Visible : Visibility.Collapsed;
            distanceThresholds.Visibility = rules().ColorMode == "distance" ? Visibility.Visible : Visibility.Collapsed;
            palette.Visibility = rules().ColorMode == "none" ? Visibility.Collapsed : Visibility.Visible;
        });
        return Theme.Stack(
            new Expander { Header = "Hauteur et étages", Foreground = Theme.Foreground, Margin = new Thickness(0, 12, 0, 8), Content = height },
            new Expander
            {
                Header = "Couleurs automatiques", Foreground = Theme.Foreground, Margin = new Thickness(0, 5, 0, 12),
                Content = Theme.Stack(
                    Selection("Règle de couleur", new[] { "none", "health", "distance" },
                        new[] { "Couleur du profil", "Selon la vie", "Selon la distance" }, () => rules().ColorMode, v => rules().ColorMode = v),
                    healthThresholds, distanceThresholds, palette,
                    Theme.Text(players ? "Une couleur attribuée individuellement à un joueur reste prioritaire." : "Cette règle reste indépendante du profil joueurs.", 10, Theme.Muted))
            });
    }

    private UIElement BuildGeneral()
    {
        var s = controller.Settings;
        return Theme.Stack(
            Theme.Text("Réglages communs", 20, null, true),
            Theme.Text("L’adaptation de l’image et le radar sont communs aux deux profils.", 11, Theme.Muted),
            SectionTitle("IMAGE DU JEU"),
            Selection("Adaptation de l’ESP à la sortie",
                new[] { ProjectionOutputMapping.Fit, ProjectionOutputMapping.Stretch, ProjectionOutputMapping.Fill },
                new[] { ProjectionOutputText.ModeLabel(ProjectionOutputMapping.Fit), ProjectionOutputText.ModeLabel(ProjectionOutputMapping.Stretch), ProjectionOutputText.ModeLabel(ProjectionOutputMapping.Fill) },
                () => s.EspScaleMode, v => s.EspScaleMode = v),
            Theme.Text("Choisis le même mode que ton fuser : proportions conservées, image étirée ou recadrée. Utilise le jeu en plein écran ou sans bordure.", 11, Theme.Muted),
            SectionTitle("RADAR ET ÉTAT"),
            SliderRow("Taille du radar", 180, 520, () => s.RadarSize, v => s.RadarSize = (int)Math.Round(v), "px", 10),
            SliderRow("Opacité du radar", 25, 100, () => s.RadarOpacity * 100, v => s.RadarOpacity = Math.Round(v / 100, 2), "%", 1),
            Toggle("Utiliser une portée radar indépendante de l’ESP", () => s.RadarIndependentRange, v => s.RadarIndependentRange = v),
            SliderRow("Portée indépendante du radar", 25, 5000, () => s.RadarRangeMeters, v => s.RadarRangeMeters = (int)Math.Round(v), "m", 1),
            Toggle("Compteurs de détections par distance", () => s.ShowRadarCounts, v => s.ShowRadarCounts = v),
            Theme.Text("Les compteurs regroupent les points affichés à 0–25, 25–50 et 50–100 m, selon la portée choisie. Ce ne sont pas les effectifs complets du serveur.", 10, Theme.Muted),
            Toggle("Afficher l’état de connexion", () => s.ShowHud, v => s.ShowHud = v),
            SectionTitle("RECONNEXION"),
            Toggle("Rechercher automatiquement le jeu après sa fermeture", () => s.AutoReconnectGame, v => s.AutoReconnectGame = v),
            Theme.Text("Le lecteur ouvre une nouvelle session et attend le jeu. Arrêter annule cette attente. Les commandes du créatif ne sont jamais rejouées.", 11, Theme.Muted));
    }

    private UIElement BuildPlacement(Action? activateFuser)
    {
        var s = controller.Settings;
        var fuser = new FuserOutputControls(controller, activateFuser);
        refresh.Add(fuser.Refresh);
        string[] screens = System.Windows.Forms.Screen.AllScreens.Select(FuserOutputControls.ScreenLabel).ToArray();
        var screenCombo = new ComboBox { ItemsSource = screens, Margin = new Thickness(0, 0, 0, 10) };
        screenCombo.SelectionChanged += (_, _) =>
        {
            if (!updating && screenCombo.SelectedIndex >= 0) { s.MonitorIndex = screenCombo.SelectedIndex; Save(); }
        };
        refresh.Add(() =>
        {
            string[] currentScreens = System.Windows.Forms.Screen.AllScreens.Select(FuserOutputControls.ScreenLabel).ToArray();
            if (!screens.SequenceEqual(currentScreens)) { screens = currentScreens; screenCombo.ItemsSource = screens; }
            if (!screenCombo.IsDropDownOpen)
                screenCombo.SelectedIndex = Math.Clamp(s.MonitorIndex, 0, Math.Max(0, screens.Length - 1));
            screenCombo.IsEnabled = s.OutputMode != "fuser";
        });
        var keyNotice = Theme.Text("", 11, Theme.Orange);
        keyNotice.Height = 38;
        keyNotice.Margin = new Thickness(0, 0, 0, 8);
        keyNotice.LineHeight = 17;
        keyNotice.TextTrimming = TextTrimming.CharacterEllipsis;
        keyNotice.ClipToBounds = true;
        return Theme.Stack(
            Theme.Text("Sortie et raccourcis", 20, null, true),
            Theme.Text("Choisis l’écran de l’affichage et les touches du PC qui exécute le loader.", 11, Theme.Muted),
            SectionTitle("FUSER"), fuser,
            SectionTitle("SUPERPOSITION LOCALE"),
            Theme.Label("Écran de la superposition sur ce PC"), screenCombo,
            Theme.Text("En mode fuser, l’écran se choisit dans « Écran envoyé au fuser » ci-dessus.", 11, Theme.Muted),
            Selection("Position du menu et du radar", new[] { "TopRight", "TopLeft", "BottomRight", "BottomLeft" },
                new[] { "En haut à droite", "En haut à gauche", "En bas à droite", "En bas à gauche" }, () => s.OverlayAnchor, v => s.OverlayAnchor = v),
            SectionTitle("RACCOURCIS"),
            HotkeySelection("Ouvrir / fermer le menu", "menu", () => s.MenuKey, v => s.MenuKey = v, keyNotice),
            HotkeySelection("Afficher / masquer tout l’affichage", "master", () => s.ToggleKey, v => s.ToggleKey = v, keyNotice),
            HotkeySelection("Afficher / masquer les joueurs", "players", () => s.PlayersKey, v => s.PlayersKey = v, keyNotice, optional: true),
            HotkeySelection("Afficher / masquer les zombies", "zombies", () => s.ZombiesKey, v => s.ZombiesKey = v, keyNotice, optional: true),
            HotkeySelection("Afficher / masquer le radar", "radar", () => s.RadarKey, v => s.RadarKey = v, keyNotice, optional: true),
            HotkeySelection("Activer / désactiver le menu créatif", "creative", () => s.CreativeMenuKey, v => s.CreativeMenuKey = v, keyNotice, optional: true),
            keyNotice,
            Theme.Text("Les touches Joueurs, Zombies et Radar sont facultatives. Elles changent leur option sans réactiver l’affichage général s’il est masqué.", 11, Theme.Muted),
            Theme.Text("Les raccourcis restent actifs quand le loader est réduit. Échap ferme le menu ; Ctrl+Alt+F11 quitte la sortie fuser.", 11, Theme.Muted));
    }

    private UIElement HotkeySelection(string title, string binding, Func<string> get, Action<string> set,
        TextBlock notice, bool optional = false)
    {
        string[] values = optional ? new[] { "" }.Concat(AllowedKeys).ToArray() : AllowedKeys;
        string[] labels = values.Select(value => value.Length == 0 ? "Désactivé" : OverlayManager.DisplayKey(value)).ToArray();
        var combo = new ComboBox { ItemsSource = labels, Margin = new Thickness(0, 0, 0, 12) };
        combo.SelectionChanged += (_, _) =>
        {
            if (updating || combo.SelectedIndex < 0) return;
            string value = values[combo.SelectedIndex];
            var s = controller.Settings;
            var assignments = new[]
            {
                ("menu", "au menu", s.MenuKey), ("master", "à l’affichage général", s.ToggleKey),
                ("players", "aux joueurs", s.PlayersKey), ("zombies", "aux zombies", s.ZombiesKey),
                ("radar", "au radar", s.RadarKey), ("creative", "au menu créatif", s.CreativeMenuKey)
            };
            var conflict = assignments.FirstOrDefault(item => item.Item1 != binding && item.Item3 == value);
            if (value.Length > 0 && conflict.Item1 != null)
            {
                notice.Text = "Choix refusé : " + OverlayManager.DisplayKey(value) + " est déjà affectée " + conflict.Item2 + ". Les touches précédentes sont conservées.";
                notice.ToolTip = notice.Text;
                updating = true;
                try { combo.SelectedIndex = Math.Max(0, Array.IndexOf(values, get())); }
                finally { updating = false; }
                return;
            }
            if (get() != value) { set(value); Save(); }
            notice.Text = "";
            notice.ToolTip = null;
            Refresh();
        };
        refresh.Add(() => { if (!combo.IsDropDownOpen) combo.SelectedIndex = Math.Max(0, Array.IndexOf(values, get())); });
        return Theme.Stack(Theme.Label(title), combo);
    }

    private UIElement BuildProjectionStatus()
    {
        var s = controller.Settings;
        var projectionState = Theme.Text("", 11, Theme.Muted);
        projectionState.TextWrapping = TextWrapping.NoWrap;
        projectionState.TextTrimming = TextTrimming.CharacterEllipsis;
        projectionState.Height = 19;
        projectionState.Margin = new Thickness(0);
        var projectionHint = Theme.Text("Survole cet état pour le détail de la caméra.", 10, Theme.Muted);
        projectionHint.TextWrapping = TextWrapping.NoWrap;
        projectionHint.TextTrimming = TextTrimming.CharacterEllipsis;
        projectionHint.Height = 16;
        projectionHint.Margin = new Thickness(0);
        var projectionRegion = new Border
        {
            Height = 49, MinHeight = 49, MaxHeight = 49,
            Margin = new Thickness(0, 5, 0, 8), Padding = new Thickness(10, 6, 10, 6),
            CornerRadius = new CornerRadius(7), ClipToBounds = true,
            Background = Theme.Background, BorderBrush = Theme.Line, BorderThickness = new Thickness(1),
            Child = Theme.Stack(projectionState, projectionHint)
        };
        var projectionPresentation = new MenuStatusPresenter();
        var projectionDetail = Theme.Text("", 12, Theme.Foreground);
        projectionDetail.Margin = new Thickness(0);
        projectionDetail.MaxWidth = 430;
        var projectionTip = new ToolTip
        {
            Background = Theme.Raised, Foreground = Theme.Foreground,
            BorderBrush = Theme.Line, BorderThickness = new Thickness(1), Padding = new Thickness(12),
            Content = new ScrollViewer
            {
                Content = projectionDetail, MaxHeight = 280,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled
            }
        };
        projectionRegion.ToolTip = projectionTip;
        ToolTipService.SetInitialShowDelay(projectionRegion, 250);
        ToolTipService.SetShowDuration(projectionRegion, 20000);
        // Take a diagnostic when the tooltip opens, not on each incoming frame.
        projectionRegion.ToolTipOpening += (_, _) => projectionDetail.Text = projectionPresentation.Detail;
        bool observedMaster = s.EspEnabled, observedProjection = s.ShowProjectedEsp;
        int observedMonitor = s.MonitorIndex;
        string observedScale = s.EspScaleMode;
        refresh.Add(() =>
        {
            var frame = controller.CurrentFrame;
            var camera = frame?.Snapshot.Camera;
            string key = "acquiring";
            string summary = "Caméra : acquisition en cours.";
            string detail = controller.Status.ProjectionMessage ?? "Caméra en attente de lecture.";
            bool immediate = observedMaster != s.EspEnabled || observedProjection != s.ShowProjectedEsp || observedMonitor != s.MonitorIndex || observedScale != s.EspScaleMode;
            observedMaster = s.EspEnabled; observedProjection = s.ShowProjectedEsp; observedMonitor = s.MonitorIndex;
            observedScale = s.EspScaleMode;
            if (camera != null && frame!.AgeMs >= FeedSample.ProjectionLifetimeMs)
                detail = "Données caméra expirées ; attente d’une nouvelle capture.\n" + detail;
            if (camera != null && frame!.TryGetProjectionView(out var view, out _))
            {
                var viewport = view!.Viewport;
                detail += "\nImage source : " + view.SourceWidth + " × " + view.SourceHeight + " px." +
                    "\nViewport caméra : " + FormatPixels(viewport.Width) + " × " + FormatPixels(viewport.Height) +
                    " px à (" + FormatPixels(viewport.X) + ", " + FormatPixels(viewport.Y) + ").";
                var screens = System.Windows.Forms.Screen.AllScreens;
                if (s.MonitorIndex >= 0 && s.MonitorIndex < screens.Length)
                {
                    var bounds = screens[s.MonitorIndex].Bounds;
                    detail += "\nSortie sélectionnée : " + bounds.Width + " × " + bounds.Height + " px.";
                    if (!ProjectionOutputMapping.TryCreate(view.SourceWidth, view.SourceHeight, bounds.Width, bounds.Height,
                        viewport, s.EspScaleMode, out var mapping, out var mappingReason))
                    {
                        key = "mapping"; summary = "ESP suspendu : adaptation indisponible."; immediate = true;
                        detail += "\n" + mappingReason;
                    }
                    else
                    {
                        detail += "\n\nAdaptation : " + ProjectionOutputText.Details(mapping!);
                        if (!mapping!.HasVisibleViewport)
                        {
                            key = "cropped"; summary = "ESP suspendu : caméra hors du recadrage."; immediate = true;
                        }
                        else if (frame.IsProjectionFresh)
                        {
                            key = "received"; summary = "Caméra : captures reçues récemment.";
                        }
                    }
                }
                else { key = "screen"; summary = "ESP suspendu : écran indisponible."; immediate = true; }
            }
            else if (camera != null)
            {
                key = "invalid"; summary = "Caméra : données à vérifier."; immediate = true;
                frame!.TryGetProjectionView(out _, out var reason);
                detail = reason + "\n" + detail;
            }
            if (!s.EspEnabled) { key = "display-off"; summary = "Affichage général désactivé."; immediate = true; }
            else if (!s.ShowProjectedEsp) { key = "esp-off"; summary = "ESP désactivé dans les réglages."; immediate = true; }
            if (projectionPresentation.Update(key, summary, summary + "\n\n" + detail, Environment.TickCount64, immediate))
                projectionState.Text = projectionPresentation.Summary;
        });
        return projectionRegion;
    }

    internal void Refresh()
    {
        if (updating) return;
        updating = true;
        try { foreach (var action in refresh) action(); }
        finally { updating = false; }
    }

    private static TextBlock SectionTitle(string text)
    {
        var title = Theme.Eyebrow(text);
        title.Margin = new Thickness(0, 15, 0, 7);
        return title;
    }

    private static Grid ToggleGrid(params CheckBox[] controls)
    {
        var grid = new Grid();
        grid.ColumnDefinitions.Add(new ColumnDefinition());
        grid.ColumnDefinitions.Add(new ColumnDefinition());
        for (int i = 0; i < controls.Length; i++)
        {
            if (i % 2 == 0) grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            controls[i].Margin = new Thickness(0, 6, i % 2 == 0 ? 8 : 0, 6);
            Grid.SetRow(controls[i], i / 2);
            Grid.SetColumn(controls[i], i % 2);
            grid.Children.Add(controls[i]);
        }
        return grid;
    }

    private static string FormatPixels(double value) => value.ToString("0.##", French);

    private CheckBox Toggle(string text, Func<bool> get, Action<bool> set)
    {
        var label = new TextBlock { Text = text, TextWrapping = TextWrapping.Wrap };
        var box = new CheckBox { Content = label };
        RoutedEventHandler changed = (_, _) =>
        {
            if (!updating) { set(box.IsChecked == true); Save(); Refresh(); }
        };
        box.Checked += changed;
        box.Unchecked += changed;
        refresh.Add(() => box.IsChecked = get());
        return box;
    }

    private UIElement SliderRow(string text, double minimum, double maximum, Func<double> get, Action<double> set, string unit, double step)
    {
        var row = new Grid { Margin = new Thickness(0, 5, 0, 10) };
        row.ColumnDefinitions.Add(new ColumnDefinition());
        row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        row.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        row.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        var title = Theme.Label(text);
        title.Margin = new Thickness(0, 0, 8, 0);
        title.VerticalAlignment = VerticalAlignment.Center;
        var input = new TextBox
        {
            Width = 63, Padding = new Thickness(5, 4, 5, 4), FontSize = 12,
            TextAlignment = TextAlignment.Right, VerticalContentAlignment = VerticalAlignment.Center,
            ToolTip = minimum.ToString(French) + " à " + maximum.ToString(French) + (unit.Length == 0 ? "" : " " + unit)
        };
        System.Windows.Automation.AutomationProperties.SetName(input, text);
        string Format(double value) => value.ToString(step >= 1 ? "0" : "0.##", French);
        var values = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        values.Children.Add(input);
        if (unit.Length > 0)
        {
            var suffix = Theme.Text(unit, 11, Theme.Muted);
            suffix.Margin = new Thickness(5, 0, 0, 0);
            suffix.MinWidth = 19;
            suffix.VerticalAlignment = VerticalAlignment.Center;
            values.Children.Add(suffix);
        }
        Grid.SetColumn(values, 1);
        var slider = new Slider
        {
            Minimum = minimum, Maximum = maximum, Value = get(),
            Margin = new Thickness(0, 6, 0, 0), SmallChange = step,
            LargeChange = Math.Max(step * 5, (maximum - minimum) / 10),
            TickFrequency = step, IsSnapToTickEnabled = true,
            ToolTip = text
        };
        System.Windows.Automation.AutomationProperties.SetName(slider, text);
        Grid.SetRow(slider, 1);
        Grid.SetColumnSpan(slider, 2);
        void CommitInput()
        {
            if (updating) return;
            string entered = input.Text.Trim().Replace(',', '.');
            if (!double.TryParse(entered, NumberStyles.Float, CultureInfo.InvariantCulture, out double value) ||
                !double.IsFinite(value) || value < minimum || value > maximum)
            {
                input.Text = Format(get());
                input.BorderBrush = Theme.Orange;
                input.ToolTip = "Entre une valeur de " + minimum.ToString(French) + " à " + maximum.ToString(French) + ".";
                return;
            }
            value = Math.Clamp(Math.Round(value / step) * step, minimum, maximum);
            input.BorderBrush = Theme.Line;
            if (Math.Abs(value - get()) > 0.00001) { set(value); Save(); }
            input.Text = Format(get());
            Refresh();
        }
        input.LostKeyboardFocus += (_, _) => CommitInput();
        input.KeyDown += (_, e) =>
        {
            if (e.Key == Key.Enter) { CommitInput(); e.Handled = true; }
        };
        slider.ValueChanged += (_, _) =>
        {
            if (updating) return;
            set(slider.Value);
            input.BorderBrush = Theme.Line;
            if (!input.IsKeyboardFocusWithin) input.Text = Format(get());
            Save(debounce: true);
        };
        refresh.Add(() =>
        {
            if (!slider.IsMouseCaptureWithin && !slider.IsKeyboardFocusWithin) slider.Value = get();
            if (!input.IsKeyboardFocusWithin) input.Text = Format(get());
        });
        row.Children.Add(title);
        row.Children.Add(values);
        row.Children.Add(slider);
        return row;
    }

    private UIElement Selection(string title, string[] values, string[] labels, Func<string> get, Action<string> set)
    {
        var combo = new ComboBox { ItemsSource = labels, Margin = new Thickness(0, 0, 0, 12) };
        combo.SelectionChanged += (_, _) =>
        {
            if (!updating && combo.SelectedIndex >= 0) { set(values[combo.SelectedIndex]); Save(); Refresh(); }
        };
        refresh.Add(() => { if (!combo.IsDropDownOpen) combo.SelectedIndex = Math.Max(0, Array.IndexOf(values, get())); });
        return Theme.Stack(Theme.Label(title), combo);
    }

    private UIElement SegmentedSelection(string[] values, string[] labels, Func<string> get, Action<string> set)
    {
        var grid = new Grid { Margin = new Thickness(0, 4, 0, 4) };
        for (int i = 0; i < values.Length; i++)
        {
            string value = values[i];
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            var button = Theme.Segment(labels[i], () => { set(value); Save(); Refresh(); });
            button.Margin = new Thickness(0, 0, i == values.Length - 1 ? 0 : 7, 0);
            refresh.Add(() => Theme.SelectSegment(button, get() == value));
            Grid.SetColumn(button, i);
            grid.Children.Add(button);
        }
        return grid;
    }

    private UIElement ColorRow(string title, Func<string> get, Action<string> set)
    {
        var heading = new DockPanel { Margin = new Thickness(0, 6, 0, 7) };
        var value = Theme.Text("", 11, Theme.Muted);
        value.FontFamily = new FontFamily("Consolas");
        value.Margin = new Thickness(10, 0, 0, 0);
        DockPanel.SetDock(value, Dock.Right);
        heading.Children.Add(value);
        var label = Theme.Label(title);
        label.Margin = new Thickness(0);
        heading.Children.Add(label);
        refresh.Add(() => value.Text = get());
        var row = new WrapPanel { Margin = new Thickness(0, 0, 0, 5) };
        foreach (string color in Palette)
        {
            var button = new Button
            {
                Width = 27, Height = 27, MinHeight = 0, Padding = new Thickness(0),
                Background = Theme.Brush(color), BorderBrush = Theme.Line,
                Margin = new Thickness(0, 0, 4, 4), ToolTip = color
            };
            System.Windows.Automation.AutomationProperties.SetName(button, title + " " + color);
            button.Click += (_, _) => { set(color); Save(); Refresh(); };
            refresh.Add(() =>
            {
                bool selected = string.Equals(get(), color, StringComparison.OrdinalIgnoreCase);
                button.BorderBrush = selected ? Theme.Foreground : Theme.Line;
                button.BorderThickness = new Thickness(selected ? 3 : 1);
            });
            row.Children.Add(button);
        }
        var custom = Theme.Button("+", () =>
        {
            using var dialog = new System.Windows.Forms.ColorDialog
            {
                FullOpen = true, AnyColor = true,
                Color = System.Drawing.ColorTranslator.FromHtml(get())
            };
            var window = Window.GetWindow(this);
            var result = window == null ? dialog.ShowDialog() :
                dialog.ShowDialog(new ColorDialogOwner(new System.Windows.Interop.WindowInteropHelper(window).Handle));
            if (result != System.Windows.Forms.DialogResult.OK) return;
            set("#" + dialog.Color.R.ToString("X2") + dialog.Color.G.ToString("X2") + dialog.Color.B.ToString("X2"));
            Save();
            Refresh();
        });
        custom.Width = 31; custom.Height = 27; custom.MinHeight = 0;
        custom.Padding = new Thickness(0); custom.Margin = new Thickness(1, 0, 0, 4);
        custom.ToolTip = "Choisir une couleur personnalisée";
        System.Windows.Automation.AutomationProperties.SetName(custom, "Choisir une couleur personnalisée");
        row.Children.Add(custom);
        var keyConflict = Theme.Text("Cette couleur correspond au fond fuser : les repères peuvent devenir invisibles.", 11, Theme.Orange);
        keyConflict.Margin = new Thickness(0, 3, 0, 6);
        keyConflict.Visibility = Visibility.Collapsed;
        refresh.Add(() => keyConflict.Visibility = controller.Settings.OutputMode == "fuser" &&
            string.Equals(get(), controller.Settings.FuserKeyColor, StringComparison.OrdinalIgnoreCase)
                ? Visibility.Visible : Visibility.Collapsed);
        return Theme.Stack(heading, row, keyConflict);
    }

    private sealed class ColorDialogOwner : System.Windows.Forms.IWin32Window
    {
        public IntPtr Handle { get; }
        internal ColorDialogOwner(IntPtr handle) => Handle = handle;
    }

    private void Save(bool debounce = false)
    {
        if (updating) return;
        pendingSave = true;
        if (debounce) { saveTimer.Stop(); saveTimer.Start(); }
        else Flush();
    }

    private void Flush()
    {
        saveTimer.Stop();
        if (!pendingSave) return;
        pendingSave = false;
        try { controller.SaveSettings(); }
        catch (Exception e) { controller.Log("Réglages non enregistrés : " + e.Message); }
    }
}
