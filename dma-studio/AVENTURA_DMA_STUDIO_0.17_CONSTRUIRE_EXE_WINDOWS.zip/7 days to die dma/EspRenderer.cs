﻿// Affichage uniquement : ce fichier n'ouvre aucune session DMA et ne lit aucun jeu.
// C# 5 / .NET Framework 4.x, System.Windows.Forms + System.Drawing.
// Les coordonnees normalisees utilisent l'origine en haut a gauche (Y vers le bas).
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;

namespace SevenDaysEsp
{
    public sealed class EntityMarker
    {
        public string Kind { get; set; }
        public string Name { get; set; }
        public float DistanceMeters { get; set; }
        public float BottomX { get; set; }
        public float BottomY { get; set; }
        public float TopX { get; set; }
        public float TopY { get; set; }
        public bool Visible { get; set; }
    }

    public sealed class EspFrame
    {
        // Renseigner l'heure UTC de la lecture, pas celle d'une ancienne image republiee.
        public DateTime CapturedUtc { get; set; }
        public List<EntityMarker> Markers { get; set; }
        public int SourceWidth { get; set; }
        public int SourceHeight { get; set; }
        public string Status { get; set; }

        public EspFrame()
        {
            Markers = new List<EntityMarker>();
            Status = String.Empty;
        }
    }

    public sealed class EspOverlay : Form
    {
        private sealed class Snapshot
        {
            public DateTime CapturedUtc;
            public long ReceivedTicks;
            public int Width;
            public int Height;
            public string Status;
            public EntityMarker[] Markers;
        }

        private sealed class Canvas : Control
        {
            private readonly EspOverlay owner;
            public Canvas(EspOverlay owner)
            {
                this.owner = owner;
                SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                    ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
                TabStop = false;
            }
            protected override void OnPaint(PaintEventArgs e)
            {
                base.OnPaint(e);
                owner.PaintFrame(e.Graphics, ClientRectangle);
            }
        }

        private readonly object frameGate = new object();
        private Snapshot currentFrame;
        private string emptyStatus = "DONNEES ABSENTES - en attente du lecteur";
        private long publishedFrames;
        private long lastRateCount;
        private long lastRateTicks;
        private double framesPerSecond;
        private volatile bool showPlayers = true;
        private volatile bool showZombies = true;
        private volatile float maximumDistance = 300.0f;
        private volatile int staleAfterMilliseconds = 500;
        private bool superposition;
        private Rectangle previousBounds;
        private FormWindowState previousWindowState;
        private readonly Canvas canvas;
        private readonly Panel toolbar;
        private readonly CheckBox players;
        private readonly CheckBox zombies;
        private readonly NumericUpDown distance;
        private readonly ComboBox screenPicker;
        private readonly Button modeButton;
        private readonly System.Windows.Forms.Timer repaint;
        private readonly Font markerFont;
        private readonly Font messageFont;
        private readonly Font statusFont;
        private static readonly Color TransparentColor = Color.FromArgb(255, 0, 255);
        private static readonly Color PlayerColor = Color.FromArgb(72, 220, 245);
        private static readonly Color ZombieColor = Color.FromArgb(255, 172, 65);

        public bool ShowPlayers { get { return showPlayers; } set { showPlayers = value; } }
        public bool ShowZombies { get { return showZombies; } set { showZombies = value; } }
        public float MaximumDistance
        {
            get { return maximumDistance; }
            set
            {
                if (!Finite(value) || value < 1 || value > 5000)
                    throw new ArgumentOutOfRangeException("value", "Distance attendue : 1 a 5000 metres.");
                maximumDistance = value;
            }
        }
        public int StaleAfterMilliseconds
        {
            get { return staleAfterMilliseconds; }
            set
            {
                if (value < 100 || value > 10000)
                    throw new ArgumentOutOfRangeException("value", "Delai attendu : 100 a 10000 ms.");
                staleAfterMilliseconds = value;
            }
        }

        public EspOverlay()
        {
            Text = "7 Days to Die - ESP joueurs et zombies";
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(1100, 700);
            MinimumSize = new Size(940, 520);
            BackColor = Color.Black;
            Font = new Font("Segoe UI", 9.0f);
            KeyPreview = true;
            AutoScaleMode = AutoScaleMode.Dpi;
            markerFont = new Font("Segoe UI", 9.0f, FontStyle.Bold);
            messageFont = new Font("Segoe UI", 17.0f, FontStyle.Bold);
            statusFont = new Font("Segoe UI", 9.0f);

            canvas = new Canvas(this);
            canvas.BackColor = Color.Black;
            Controls.Add(canvas);
            toolbar = new Panel();
            toolbar.Height = 76;
            toolbar.BackColor = Color.FromArgb(30, 34, 40);
            Controls.Add(toolbar);
            Label title = new Label();
            title.Text = "Affichage sur le PC lecteur  |  Echap : fermer  |  Les donnees expirees sont masquees";
            title.ForeColor = Color.FromArgb(195, 203, 212);
            title.Dock = DockStyle.Top;
            title.Height = 26;
            title.Padding = new Padding(10, 6, 0, 0);
            toolbar.Controls.Add(title);
            FlowLayoutPanel controls = new FlowLayoutPanel();
            controls.Dock = DockStyle.Fill;
            controls.Padding = new Padding(8, 6, 4, 0);
            controls.WrapContents = false;
            controls.FlowDirection = FlowDirection.LeftToRight;
            toolbar.Controls.Add(controls);
            controls.BringToFront();
            players = MakeCheckBox("Joueurs", PlayerColor, true);
            zombies = MakeCheckBox("Zombies", ZombieColor, true);
            controls.Controls.Add(players);
            controls.Controls.Add(zombies);
            players.CheckedChanged += delegate { ShowPlayers = players.Checked; };
            zombies.CheckedChanged += delegate { ShowZombies = zombies.Checked; };
            Label distanceLabel = new Label();
            distanceLabel.Text = "Distance (m)";
            distanceLabel.AutoSize = true;
            distanceLabel.ForeColor = Color.WhiteSmoke;
            distanceLabel.Margin = new Padding(8, 6, 3, 0);
            controls.Controls.Add(distanceLabel);
            distance = new NumericUpDown();
            distance.Minimum = 1;
            distance.Maximum = 5000;
            distance.Value = 300;
            distance.Increment = 25;
            distance.Width = 70;
            distance.Margin = new Padding(2, 2, 8, 0);
            distance.ValueChanged += delegate { MaximumDistance = (float)distance.Value; };
            controls.Controls.Add(distance);
            screenPicker = new ComboBox();
            screenPicker.DropDownStyle = ComboBoxStyle.DropDownList;
            screenPicker.Width = 170;
            screenPicker.Margin = new Padding(2, 2, 6, 0);
            foreach (Screen screen in Screen.AllScreens)
                screenPicker.Items.Add(screen.DeviceName + " (" + screen.Bounds.Width + " x " + screen.Bounds.Height + ")");
            if (screenPicker.Items.Count > 0) screenPicker.SelectedIndex = 0;
            controls.Controls.Add(screenPicker);
            modeButton = new Button();
            modeButton.Text = "Superposer sur cet ecran";
            modeButton.AutoSize = true;
            modeButton.Height = 28;
            modeButton.Margin = new Padding(2, 0, 6, 0);
            modeButton.Click += delegate { SetSuperposition(!superposition); };
            controls.Controls.Add(modeButton);
            Button close = new Button();
            close.Text = "Fermer";
            close.Width = 65;
            close.Height = 28;
            close.Margin = new Padding(2, 0, 0, 0);
            close.Click += delegate { Close(); };
            controls.Controls.Add(close);
            KeyDown += delegate(object sender, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.Escape) { e.Handled = true; Close(); }
            };
            lastRateTicks = Stopwatch.GetTimestamp();
            repaint = new System.Windows.Forms.Timer();
            repaint.Interval = 33;
            repaint.Tick += delegate
            {
                long nowTicks = Stopwatch.GetTimestamp();
                double elapsed = (nowTicks - lastRateTicks) / (double)Stopwatch.Frequency;
                if (elapsed >= 1.0)
                {
                    long count = Interlocked.Read(ref publishedFrames);
                    framesPerSecond = (count - lastRateCount) / elapsed;
                    lastRateCount = count;
                    lastRateTicks = nowTicks;
                }
                // Les proprietes peuvent etre modifiees par le worker, les controles par l'UI.
                if (players.Checked != showPlayers) players.Checked = showPlayers;
                if (zombies.Checked != showZombies) zombies.Checked = showZombies;
                decimal requestedDistance = (decimal)maximumDistance;
                if (distance.Value != requestedDistance) distance.Value = requestedDistance;
                canvas.Invalidate();
            };
            repaint.Start();
            LayoutSurfaces();
        }

        private static CheckBox MakeCheckBox(string text, Color color, bool value)
        {
            CheckBox control = new CheckBox();
            control.Text = text;
            control.ForeColor = color;
            control.Checked = value;
            control.AutoSize = true;
            control.Margin = new Padding(3, 5, 10, 0);
            return control;
        }

        // Thread-safe. Copie les donnees afin qu'une modification du producteur
        // ne puisse pas changer l'image deja remise a l'interface.
        public void UpdateFrame(EspFrame frame)
        {
            if (frame == null) { ClearFrame("DONNEES ABSENTES - aucune lecture disponible"); return; }
            if (frame.SourceWidth < 1 || frame.SourceHeight < 1 ||
                frame.SourceWidth > 32768 || frame.SourceHeight > 32768 ||
                frame.CapturedUtc == DateTime.MinValue)
            {
                ClearFrame("DONNEES INVALIDES - resolution ou horodatage manquant");
                return;
            }
            List<EntityMarker> copied = new List<EntityMarker>();
            if (frame.Markers != null)
            {
                int limit = Math.Min(frame.Markers.Count, 4096);
                for (int i = 0; i < limit; i++)
                {
                    EntityMarker marker = frame.Markers[i];
                    if (marker == null || !marker.Visible ||
                        (!String.Equals(marker.Kind, "player", StringComparison.OrdinalIgnoreCase) &&
                         !String.Equals(marker.Kind, "zombie", StringComparison.OrdinalIgnoreCase)) ||
                        !Finite(marker.DistanceMeters) || marker.DistanceMeters < 0 ||
                        !Unit(marker.TopX) || !Unit(marker.TopY) ||
                        !Unit(marker.BottomX) || !Unit(marker.BottomY) || marker.BottomY <= marker.TopY)
                        continue;
                    copied.Add(new EntityMarker {
                        Kind = marker.Kind.ToLowerInvariant(),
                        Name = CleanText(marker.Name, 48),
                        DistanceMeters = marker.DistanceMeters,
                        BottomX = marker.BottomX, BottomY = marker.BottomY,
                        TopX = marker.TopX, TopY = marker.TopY, Visible = true
                    });
                }
            }
            Snapshot snapshot = new Snapshot();
            snapshot.CapturedUtc = frame.CapturedUtc.Kind == DateTimeKind.Utc
                ? frame.CapturedUtc : frame.CapturedUtc.ToUniversalTime();
            snapshot.ReceivedTicks = Stopwatch.GetTimestamp();
            snapshot.Width = frame.SourceWidth;
            snapshot.Height = frame.SourceHeight;
            snapshot.Status = CleanText(frame.Status, 160);
            snapshot.Markers = copied.ToArray();
            lock (frameGate) { currentFrame = snapshot; }
            Interlocked.Increment(ref publishedFrames);
        }

        public void ClearFrame(string reason)
        {
            lock (frameGate)
            {
                currentFrame = null;
                emptyStatus = String.IsNullOrWhiteSpace(reason) ? "DONNEES ABSENTES" : CleanText(reason, 160);
            }
        }

        private static bool Finite(float value) { return !Single.IsNaN(value) && !Single.IsInfinity(value); }
        private static bool Unit(float value) { return Finite(value) && value >= 0 && value <= 1; }
        private static string CleanText(string value, int maximum)
        {
            if (String.IsNullOrEmpty(value)) return String.Empty;
            char[] chars = value.Substring(0, Math.Min(value.Length, maximum)).ToCharArray();
            for (int i = 0; i < chars.Length; i++) if (Char.IsControl(chars[i])) chars[i] = ' ';
            return new String(chars);
        }

        private void SetSuperposition(bool enabled)
        {
            if (superposition == enabled) return;
            if (enabled)
            {
                Screen[] screens = Screen.AllScreens;
                if (screens.Length == 0) return;
                int index = Math.Max(0, Math.Min(screenPicker.SelectedIndex, screens.Length - 1));
                previousBounds = Bounds;
                previousWindowState = WindowState;
                WindowState = FormWindowState.Normal;
                superposition = true;
                FormBorderStyle = FormBorderStyle.None;
                TransparencyKey = TransparentColor;
                BackColor = TransparentColor;
                canvas.BackColor = TransparentColor;
                TopMost = true;
                Bounds = screens[index].Bounds;
                modeButton.Text = "Revenir en fenetre";
                screenPicker.Enabled = false;
            }
            else
            {
                superposition = false;
                TopMost = false;
                TransparencyKey = Color.Empty;
                BackColor = Color.Black;
                canvas.BackColor = Color.Black;
                FormBorderStyle = FormBorderStyle.Sizable;
                Bounds = previousBounds;
                WindowState = previousWindowState;
                modeButton.Text = "Superposer sur cet ecran";
                screenPicker.Enabled = true;
            }
            LayoutSurfaces();
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            LayoutSurfaces();
        }

        private void LayoutSurfaces()
        {
            if (toolbar == null || canvas == null) return;
            toolbar.SetBounds(0, 0, ClientSize.Width, toolbar.Height);
            int top = superposition ? 0 : toolbar.Bottom;
            canvas.SetBounds(0, top, ClientSize.Width, Math.Max(1, ClientSize.Height - top));
            toolbar.BringToFront();
        }

        private void PaintFrame(Graphics graphics, Rectangle area)
        {
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Snapshot frame;
            string absence;
            lock (frameGate) { frame = currentFrame; absence = emptyStatus; }
            DateTime now = DateTime.UtcNow;
            bool stale = false;
            if (frame != null)
            {
                double receiptAge = (Stopwatch.GetTimestamp() - frame.ReceivedTicks) * 1000.0 / Stopwatch.Frequency;
                double captureAge = (now - frame.CapturedUtc).TotalMilliseconds;
                stale = receiptAge > staleAfterMilliseconds || captureAge > staleAfterMilliseconds || captureAge < -1000;
            }
            if (frame == null || stale)
            {
                string heading = stale ? "DONNEES PERIMEES" : "DONNEES ABSENTES";
                string detail = stale ? "Lecture interrompue ou trop ancienne : reperes masques." : absence;
                DrawMessage(graphics, area, heading, detail);
                DrawStatus(graphics, area, "Aucune position affichee | " + framesPerSecond.ToString("0.0", CultureInfo.InvariantCulture) + " images/s recues");
                return;
            }

            float scale = Math.Min(area.Width / (float)frame.Width, area.Height / (float)frame.Height);
            float width = frame.Width * scale;
            float height = frame.Height * scale;
            RectangleF viewport = new RectangleF((area.Width - width) / 2, (area.Height - height) / 2, width, height);
            if (!superposition)
            {
                using (Brush viewportBrush = new SolidBrush(Color.FromArgb(9, 14, 20))) graphics.FillRectangle(viewportBrush, viewport);
                using (Pen outline = new Pen(Color.FromArgb(35, 48, 60))) graphics.DrawRectangle(outline, viewport.X, viewport.Y, viewport.Width - 1, viewport.Height - 1);
            }
            int playerCount = 0;
            int zombieCount = 0;
            using (Pen shadow = new Pen(Color.FromArgb(230, 0, 0, 0), 4))
            using (Pen playerPen = new Pen(PlayerColor, 1.6f))
            using (Pen zombiePen = new Pen(ZombieColor, 1.6f))
            {
                foreach (EntityMarker marker in frame.Markers)
                {
                    bool player = marker.Kind == "player";
                    if ((player && !showPlayers) || (!player && !showZombies) || marker.DistanceMeters > maximumDistance) continue;
                    float top = viewport.Y + marker.TopY * viewport.Height;
                    float bottom = viewport.Y + marker.BottomY * viewport.Height;
                    float boxHeight = bottom - top;
                    if (boxHeight < 2) continue;
                    float center = viewport.X + (marker.TopX + marker.BottomX) * 0.5f * viewport.Width;
                    float boxWidth = Math.Max(5, boxHeight * 0.43f);
                    RectangleF box = new RectangleF(center - boxWidth / 2, top, boxWidth, boxHeight);
                    graphics.DrawRectangle(shadow, box.X, box.Y, box.Width, box.Height);
                    graphics.DrawRectangle(player ? playerPen : zombiePen, box.X, box.Y, box.Width, box.Height);
                    string name = String.IsNullOrWhiteSpace(marker.Name) ? (player ? "Joueur" : "Zombie") : marker.Name;
                    string label = name + "  " + marker.DistanceMeters.ToString("0", CultureInfo.InvariantCulture) + " m";
                    SizeF labelSize = graphics.MeasureString(label, markerFont);
                    float textX = Math.Max(1, Math.Min(area.Width - labelSize.Width - 1, center - labelSize.Width / 2));
                    float textY = Math.Max(1, top - labelSize.Height - 3);
                    DrawText(graphics, label, markerFont, player ? PlayerColor : ZombieColor, textX, textY);
                    if (player) playerCount++; else zombieCount++;
                }
            }
            if (playerCount + zombieCount == 0)
                DrawMessage(graphics, area, "AUCUNE ENTITE VISIBLE", "Aucun repere ne correspond a la vue et aux filtres actuels.");
            string status = playerCount + " joueur(s) | " + zombieCount + " zombie(s) | " +
                framesPerSecond.ToString("0.0", CultureInfo.InvariantCulture) + " images/s recues | " +
                frame.Width + " x " + frame.Height;
            if (!String.IsNullOrWhiteSpace(frame.Status)) status += " | " + frame.Status;
            DrawStatus(graphics, area, status);
        }

        private void DrawMessage(Graphics graphics, Rectangle area, string title, string detail)
        {
            using (StringFormat format = new StringFormat())
            {
                format.Alignment = StringAlignment.Center;
                format.LineAlignment = StringAlignment.Center;
                using (Brush background = new SolidBrush(Color.FromArgb(235, 16, 22, 29)))
                    graphics.FillRectangle(background, new Rectangle(20, Math.Max(1, area.Height / 2 - 54), Math.Max(1, area.Width - 40), 108));
                using (Brush titleBrush = new SolidBrush(Color.WhiteSmoke))
                    graphics.DrawString(title, messageFont, titleBrush, new RectangleF(24, area.Height / 2 - 45, Math.Max(1, area.Width - 48), 45), format);
                using (Brush detailBrush = new SolidBrush(Color.FromArgb(183, 196, 209)))
                    graphics.DrawString(detail, statusFont, detailBrush, new RectangleF(28, area.Height / 2 + 3, Math.Max(1, area.Width - 56), 36), format);
            }
        }

        private void DrawStatus(Graphics graphics, Rectangle area, string text)
        {
            float y = Math.Max(0, area.Height - 29);
            using (Brush background = new SolidBrush(Color.FromArgb(235, 17, 23, 30)))
                graphics.FillRectangle(background, 0, y, area.Width, 29);
            DrawText(graphics, text, statusFont, Color.FromArgb(195, 207, 219), 10, y + 6);
        }

        private static void DrawText(Graphics graphics, string text, Font font, Color color, float x, float y)
        {
            using (Brush shadow = new SolidBrush(Color.Black)) graphics.DrawString(text, font, shadow, x + 1, y + 1);
            using (Brush foreground = new SolidBrush(color)) graphics.DrawString(text, font, foreground, x, y);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (repaint != null) { repaint.Stop(); repaint.Dispose(); }
                if (markerFont != null) markerFont.Dispose();
                if (messageFont != null) messageFont.Dispose();
                if (statusFont != null) statusFont.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    // Hote pour le worker PowerShell : boucle Windows sur un thread STA dedie.
    // Aucun gestionnaire d'evenement n'exige de runspace PowerShell secondaire.
    public static class EspWindow
    {
        private sealed class Host
        {
            public readonly ManualResetEventSlim Ready = new ManualResetEventSlim(false);
            public Thread Thread;
            public EspOverlay Form;
            public Exception Error;
            public int StopRequested;
        }
        private static readonly object gate = new object();
        private static Host host;

        public static bool IsOpen
        {
            get
            {
                lock (gate) return host != null && host.Thread != null && host.Thread.IsAlive &&
                    host.Form != null && !host.Form.IsDisposed && Interlocked.CompareExchange(ref host.StopRequested, 0, 0) == 0;
            }
        }

        public static void Start()
        {
            Host selected;
            lock (gate)
            {
                if (host != null && host.Thread != null && host.Thread.IsAlive) selected = host;
                else
                {
                    selected = new Host();
                    host = selected;
                    Host captured = selected;
                    selected.Thread = new Thread(delegate() { Run(captured); });
                    selected.Thread.Name = "SevenDaysEsp.UI";
                    selected.Thread.IsBackground = true;
                    selected.Thread.SetApartmentState(ApartmentState.STA);
                    selected.Thread.Start();
                }
            }
            if (!selected.Ready.Wait(5000))
            {
                Interlocked.Exchange(ref selected.StopRequested, 1);
                Stop();
                throw new TimeoutException("La fenetre ESP n'a pas demarre dans le delai de 5 secondes.");
            }
            if (selected.Error != null) throw new InvalidOperationException("Affichage ESP indisponible.", selected.Error);
        }

        private static void Run(Host selected)
        {
            try
            {
                using (EspOverlay form = new EspOverlay())
                {
                    lock (gate) selected.Form = form;
                    IntPtr handle = form.Handle;
                    selected.Ready.Set();
                    if (Interlocked.CompareExchange(ref selected.StopRequested, 0, 0) == 0)
                        Application.Run(form);
                }
            }
            catch (Exception ex) { selected.Error = ex; }
            finally
            {
                lock (gate) selected.Form = null;
                selected.Ready.Set();
            }
        }

        public static bool Publish(EspFrame frame)
        {
            EspOverlay form;
            lock (gate) form = host == null ? null : host.Form;
            if (form == null || form.IsDisposed) return false;
            form.UpdateFrame(frame);
            return true;
        }

        public static void Clear(string reason)
        {
            EspOverlay form;
            lock (gate) form = host == null ? null : host.Form;
            if (form != null && !form.IsDisposed) form.ClearFrame(reason);
        }

        public static void Stop()
        {
            Host selected;
            lock (gate) selected = host;
            if (selected == null) return;
            Interlocked.Exchange(ref selected.StopRequested, 1);
            EspOverlay form = selected.Form;
            if (form != null && !form.IsDisposed && form.IsHandleCreated)
            {
                try { form.BeginInvoke((MethodInvoker)delegate { if (!form.IsDisposed) form.Close(); }); }
                catch (InvalidOperationException) { }
            }
            if (selected.Thread != null && selected.Thread != Thread.CurrentThread)
                selected.Thread.Join(2000);
        }
    }
}
