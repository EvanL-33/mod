﻿#requires -Version 5.1
<#
Rapport de compatibilite 7DTD, a lancer sur le PC du jeu ou sur une copie de son dossier.
Lecture seule : aucune installation, injection, execution de DLL du jeu ou transmission.
Les assemblies du jeu sont ouvertes uniquement avec ReflectionOnlyLoadFrom.
Le rapport contient des metadonnees et de l'IL cible, jamais des offsets supposes.

Sources API :
https://learn.microsoft.com/dotnet/api/system.reflection.assembly.reflectiononlyloadfrom
https://learn.microsoft.com/dotnet/api/system.appdomain.reflectiononlyassemblyresolve
https://learn.microsoft.com/dotnet/api/system.reflection.methodbody.getilasbytearray

Codes : 0 rapport complet ; 2 environnement, selection annulee ou dossier invalide ;
3 assembly principale absente ; 4 rapport partiel ; 6 echec sans rapport exploitable.
Utiliser un nouveau processus Windows PowerShell x64 ; ne pas importer le script.
#>
[CmdletBinding()]
param([string]$GameDir = '')

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)

function Write-Info {
    param([string]$State, [string]$Message)
    [Console]::WriteLine(('[{0}] {1}' -f $State, $Message))
    [Console]::Out.Flush()
}

if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT -or [IntPtr]::Size -ne 8 -or $PSVersionTable.PSEdition -ne 'Desktop') {
    Write-Info 'ENVIRONNEMENT' 'Ouvre Collecter-Version.cmd avec Windows PowerShell 64 bits.'
    exit 2
}

try {
    if ([string]::IsNullOrWhiteSpace($GameDir)) {
        if ([Threading.Thread]::CurrentThread.GetApartmentState() -ne [Threading.ApartmentState]::STA) {
            Write-Info 'ENVIRONNEMENT' 'La selection de dossier exige le mode STA. Utilise Collecter-Version.cmd.'
            exit 2
        }
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = [System.Windows.Forms.FolderBrowserDialog]::new()
        try {
            $dialog.Description = 'Choisis le dossier du jeu contenant 7DaysToDie.exe (sur le PC du jeu).'
            $dialog.ShowNewFolderButton = $false
            if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
                Write-Info 'ANNULE' 'Aucun dossier choisi ; aucun rapport cree.'
                exit 2
            }
            $GameDir = $dialog.SelectedPath
        } finally { $dialog.Dispose() }
    }
    if (-not (Test-Path -LiteralPath $GameDir -PathType Container)) {
        Write-Info 'DOSSIER_INVALIDE' 'Le dossier du jeu est introuvable.'
        exit 2
    }
    $gameRoot = (Get-Item -LiteralPath $GameDir).FullName
    $managedRoot = Join-Path $gameRoot '7DaysToDie_Data\Managed'
    $assemblyPath = Join-Path $managedRoot 'Assembly-CSharp.dll'
    if (-not (Test-Path -LiteralPath $assemblyPath -PathType Leaf)) {
        Write-Info 'ASSEMBLY_ABSENTE' 'Choisis le dossier contenant 7DaysToDie.exe et 7DaysToDie_Data\Managed\Assembly-CSharp.dll.'
        exit 3
    }
} catch {
    Write-Info 'DOSSIER_INVALIDE' ('Lecture du dossier impossible ({0}).' -f $_.Exception.GetBaseException().GetType().Name)
    exit 2
}

$inspectorSource = @'
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.InteropServices;

namespace SevenDaysGameInfo
{
    public sealed class AssemblyReport
    {
        public string Name;
        public string Version;
        public string ImageRuntimeVersion;
        public string ModuleVersionId;
        public List<string> References = new List<string>();
    }

    public sealed class FieldReport
    {
        public string Name;
        public string Type;
        public string MetadataToken;
        public string Attributes;
        public bool IsStatic;
        public bool IsLiteral;
        public string Constant;
    }

    public sealed class PropertyReport
    {
        public string Name;
        public string Type;
        public string MetadataToken;
        public string GetterToken;
        public string SetterToken;
    }

    public sealed class InstructionReport
    {
        public string Offset;
        public string OpCode;
        public string Operand;
    }

    public sealed class MethodReport
    {
        public string Name;
        public string Signature;
        public string MetadataToken;
        public string Attributes;
        public string ImplementationFlags;
        public string BodyKind;
        public int IlByteCount;
        public string IlBase64;
        public List<InstructionReport> Instructions = new List<InstructionReport>();
    }

    public sealed class TypeReport
    {
        public string Name;
        public string Assembly;
        public string MetadataToken;
        public string BaseType;
        public string Attributes;
        public bool IsValueType;
        public bool IsEnum;
        public string SelectionReason;
        public List<FieldReport> Fields = new List<FieldReport>();
        public List<PropertyReport> Properties = new List<PropertyReport>();
        public List<MethodReport> Methods = new List<MethodReport>();
    }

    public sealed class InspectionReport
    {
        public string Status = "complete";
        public AssemblyReport GameAssembly;
        public List<TypeReport> Types = new List<TypeReport>();
        public List<string> MissingRequestedTypes = new List<string>();
        public List<string> ResolutionNotes = new List<string>();
        public List<string> Errors = new List<string>();
        public string OffsetNotice = "No runtime field offsets computed. CLR inspection does not establish Mono memory layouts.";
    }

    public sealed class Inspector
    {
        private readonly string managedDirectory;
        private readonly InspectionReport report = new InspectionReport();
        private readonly Dictionary<string, Type> selected = new Dictionary<string, Type>(StringComparer.Ordinal);
        private readonly Dictionary<string, string> reasons = new Dictionary<string, string>(StringComparer.Ordinal);
        private readonly Queue<Type> pending = new Queue<Type>();
        private readonly HashSet<string> notes = new HashSet<string>(StringComparer.Ordinal);
        private readonly Dictionary<short, OpCode> opCodes = new Dictionary<short, OpCode>();
        private readonly HashSet<string> coreNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase) {
            "mscorlib", "System", "System.Core", "System.Xml", "System.Xml.Linq", "System.Data",
            "System.Numerics", "System.Runtime.Serialization", "System.Configuration", "System.Drawing",
            "System.Windows.Forms", "System.Net.Http", "System.Security", "Microsoft.CSharp", "netstandard"
        };
        private readonly HashSet<string> methodNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase) {
            "get_Instance", "get_World", "GetWorld", "GetPrimaryPlayer", "GetPosition", "get_Position",
            "get_EntityName", "get_Health", "IsAlive", "GetLookVector", "getHeadPosition", "GetEyeHeight",
            "get_Camera", "get_playerCamera", "get_MainCamera", "get_main", "get_position", "get_rotation",
            "get_worldToCameraMatrix", "get_projectionMatrix", "get_localToWorldMatrix", "get_worldToLocalMatrix"
        };
        private const BindingFlags Declared = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static | BindingFlags.DeclaredOnly;
        private const int MaximumTypes = 64;
        private const int MaximumIlBytes = 16384;

        public Inspector(string managedDirectory)
        {
            this.managedDirectory = Path.GetFullPath(managedDirectory);
            foreach (FieldInfo field in typeof(OpCodes).GetFields(BindingFlags.Public | BindingFlags.Static)) {
                if (field.FieldType == typeof(OpCode)) {
                    OpCode opcode = (OpCode)field.GetValue(null);
                    opCodes[opcode.Value] = opcode;
                }
            }
        }

        private static string Token(int token) { return "0x" + token.ToString("X8", CultureInfo.InvariantCulture); }
        private static string TypeName(Type type) { return type == null ? null : (type.FullName ?? type.Name); }

        private void Error(string location, Exception exception)
        {
            // Exception messages may contain absolute paths. Keep only class and HRESULT.
            report.Status = "partial";
            report.Errors.Add(location + ": " + exception.GetType().Name + " (" + Token(exception.HResult) + ")");
        }

        private void Note(string message)
        {
            if (notes.Add(message)) report.ResolutionNotes.Add(message);
        }

        private Assembly Resolve(object sender, ResolveEventArgs args)
        {
            AssemblyName requested;
            try { requested = new AssemblyName(args.Name); }
            catch (Exception ex) { Error("assembly_identity", ex); return null; }
            string name = requested.Name;
            if (String.IsNullOrEmpty(name) || name.IndexOfAny(new char[] { '/', '\\', ':' }) >= 0 || name == "." || name == "..") {
                report.Status = "partial";
                Note("Rejected invalid assembly name.");
                return null;
            }
            foreach (Assembly existing in AppDomain.CurrentDomain.ReflectionOnlyGetAssemblies()) {
                if (String.Equals(existing.FullName, args.Name, StringComparison.OrdinalIgnoreCase)) return existing;
            }
            string local = Path.Combine(managedDirectory, name + ".dll");
            if (File.Exists(local)) {
                try { return Assembly.ReflectionOnlyLoadFrom(local); }
                catch (Exception ex) { Error("managed_dependency/" + name + ".dll", ex); }
            }
            if (coreNames.Contains(name)) {
                string runtime = RuntimeEnvironment.GetRuntimeDirectory();
                string core = Path.Combine(runtime, name + ".dll");
                if (!File.Exists(core)) core = Path.Combine(Path.Combine(runtime, "Facades"), name + ".dll");
                if (File.Exists(core)) {
                    try {
                        Note("Framework metadata fallback: " + name + ".dll");
                        return Assembly.ReflectionOnlyLoadFrom(core);
                    } catch (Exception ex) { Error("framework_dependency/" + name + ".dll", ex); }
                }
            }
            report.Status = "partial";
            Note("Unresolved managed dependency: " + name);
            return null;
        }

        private void AddType(Type type, string reason)
        {
            if (type == null || type.IsArray || type.IsPointer || type.IsByRef || type.IsGenericParameter) return;
            string key = type.AssemblyQualifiedName ?? TypeName(type);
            if (selected.ContainsKey(key)) return;
            if (selected.Count >= MaximumTypes) {
                report.Status = "partial";
                Note("Type count limit reached (64); related types omitted.");
                return;
            }
            selected.Add(key, type);
            reasons.Add(key, reason);
            pending.Enqueue(type);
        }

        private static bool RelevantLink(string name)
        {
            string value = name.ToLowerInvariant();
            return value == "entities" || value == "players" || value == "list" || value == "dict" ||
                   value == "world" || value == "instance" || value == "m_instance" ||
                   value.Contains("camera") || value == "<instance>k__backingfield" || value == "<world>k__backingfield";
        }

        private void AddLinkedType(Type type, string reason)
        {
            if (type == null || type.IsPrimitive || type == typeof(string)) return;
            if (type.IsArray) return;
            string fullName = TypeName(type);
            // Only the selected game's fields, collections and camera objects are followed.
            if (fullName.StartsWith("System.", StringComparison.Ordinal) &&
                !fullName.StartsWith("System.Collections.Generic.List`", StringComparison.Ordinal) &&
                !fullName.StartsWith("System.Collections.Generic.Dictionary`", StringComparison.Ordinal)) return;
            AddType(type, reason);
        }

        public InspectionReport Run()
        {
            ResolveEventHandler resolver = new ResolveEventHandler(Resolve);
            AppDomain.CurrentDomain.ReflectionOnlyAssemblyResolve += resolver;
            try {
                Assembly game = Assembly.ReflectionOnlyLoadFrom(Path.Combine(managedDirectory, "Assembly-CSharp.dll"));
                AssemblyName assemblyName = game.GetName();
                report.GameAssembly = new AssemblyReport {
                    Name = assemblyName.Name,
                    Version = assemblyName.Version == null ? null : assemblyName.Version.ToString(),
                    ImageRuntimeVersion = game.ImageRuntimeVersion,
                    ModuleVersionId = game.ManifestModule.ModuleVersionId.ToString()
                };
                foreach (AssemblyName reference in game.GetReferencedAssemblies()) report.GameAssembly.References.Add(reference.FullName);

                string[] requested = { "GameManager", "World", "Entity", "EntityAlive", "EntityPlayer", "EntityPlayerLocal", "EntityEnemy", "EntityZombie", "Origin" };
                foreach (string name in requested) {
                    try {
                        Type type = game.GetType(name, false, false);
                        if (type == null) { report.Status = "partial"; report.MissingRequestedTypes.Add(name); }
                        else AddType(type, "requested_game_type");
                    } catch (Exception ex) { Error("type/" + name, ex); }
                }

                string unityFile = Path.Combine(managedDirectory, "UnityEngine.CoreModule.dll");
                if (!File.Exists(unityFile)) unityFile = Path.Combine(managedDirectory, "UnityEngine.dll");
                if (File.Exists(unityFile)) {
                    try {
                        Assembly unity = Assembly.ReflectionOnlyLoadFrom(unityFile);
                        foreach (string name in new string[] { "UnityEngine.Camera", "UnityEngine.Transform", "UnityEngine.Object", "UnityEngine.Matrix4x4", "UnityEngine.Vector3", "UnityEngine.Quaternion" }) {
                            Type type = unity.GetType(name, false, false);
                            if (type != null) AddType(type, "requested_unity_type");
                            else { report.Status = "partial"; report.MissingRequestedTypes.Add(name); }
                        }
                    } catch (Exception ex) { Error("unity_metadata", ex); }
                } else { report.Status = "partial"; Note("UnityEngine metadata assembly absent."); }

                while (pending.Count > 0) InspectType(pending.Dequeue());
            } catch (Exception ex) { Error("inspection", ex); }
            finally { AppDomain.CurrentDomain.ReflectionOnlyAssemblyResolve -= resolver; }
            return report;
        }

        private void InspectType(Type type)
        {
            string name = TypeName(type);
            TypeReport entry = new TypeReport { Name = name, SelectionReason = reasons[type.AssemblyQualifiedName ?? name] };
            report.Types.Add(entry);
            try {
                entry.Assembly = type.Assembly.GetName().Name;
                entry.MetadataToken = Token(type.MetadataToken);
                entry.Attributes = type.Attributes.ToString();
                entry.IsValueType = type.IsValueType;
                entry.IsEnum = type.IsEnum;
                Type parent = type.BaseType;
                entry.BaseType = TypeName(parent);
                if (parent != null && parent != typeof(object) && parent != typeof(ValueType) && parent != typeof(Enum))
                    AddType(parent, "base_of/" + name);
            } catch (Exception ex) { Error("type_header/" + name, ex); }

            try {
                foreach (FieldInfo field in type.GetFields(Declared)) {
                    FieldReport item = new FieldReport { Name = field.Name };
                    entry.Fields.Add(item);
                    try {
                        item.Type = TypeName(field.FieldType);
                        item.MetadataToken = Token(field.MetadataToken);
                        item.Attributes = field.Attributes.ToString();
                        item.IsStatic = field.IsStatic;
                        item.IsLiteral = field.IsLiteral;
                        if (field.IsLiteral) {
                            object constant = field.GetRawConstantValue();
                            if (constant == null) item.Constant = "null";
                            else if (constant is string) item.Constant = "[string omitted]";
                            else item.Constant = Convert.ToString(constant, CultureInfo.InvariantCulture);
                        }
                        if (RelevantLink(field.Name)) AddLinkedType(field.FieldType, "field/" + name + "." + field.Name);
                    } catch (Exception ex) { Error("field/" + name + "." + field.Name, ex); }
                }
            } catch (Exception ex) { Error("fields/" + name, ex); }

            try {
                foreach (PropertyInfo property in type.GetProperties(Declared)) {
                    PropertyReport item = new PropertyReport { Name = property.Name };
                    entry.Properties.Add(item);
                    try {
                        item.Type = TypeName(property.PropertyType);
                        item.MetadataToken = Token(property.MetadataToken);
                        MethodInfo getter = property.GetGetMethod(true);
                        MethodInfo setter = property.GetSetMethod(true);
                        item.GetterToken = getter == null ? null : Token(getter.MetadataToken);
                        item.SetterToken = setter == null ? null : Token(setter.MetadataToken);
                        if (RelevantLink(property.Name)) AddLinkedType(property.PropertyType, "property/" + name + "." + property.Name);
                    } catch (Exception ex) { Error("property/" + name + "." + property.Name, ex); }
                }
            } catch (Exception ex) { Error("properties/" + name, ex); }

            try {
                foreach (MethodInfo method in type.GetMethods(Declared)) {
                    if (methodNames.Contains(method.Name)) entry.Methods.Add(InspectMethod(method));
                }
            } catch (Exception ex) { Error("methods/" + name, ex); }
        }

        private MethodReport InspectMethod(MethodInfo method)
        {
            MethodReport entry = new MethodReport { Name = method.Name };
            string location = TypeName(method.DeclaringType) + "." + method.Name;
            try {
                entry.Signature = method.ToString();
                entry.MetadataToken = Token(method.MetadataToken);
                entry.Attributes = method.Attributes.ToString();
                entry.ImplementationFlags = method.GetMethodImplementationFlags().ToString();
                MethodBody body = method.GetMethodBody();
                if (body == null) { entry.BodyKind = "no_managed_body"; return entry; }
                byte[] bytes = body.GetILAsByteArray();
                entry.IlByteCount = bytes == null ? 0 : bytes.Length;
                if (bytes == null || bytes.Length == 0) { entry.BodyKind = "empty"; return entry; }
                if (bytes.Length > MaximumIlBytes) {
                    entry.BodyKind = "omitted_size_limit";
                    report.Status = "partial";
                    Note("IL size limit exceeded: " + location);
                    return entry;
                }
                entry.BodyKind = "managed_il";
                entry.IlBase64 = Convert.ToBase64String(bytes);
                DecodeIl(method, bytes, entry.Instructions);
            } catch (Exception ex) { entry.BodyKind = "read_error"; Error("method/" + location, ex); }
            return entry;
        }

        private static int ReadInt32(byte[] bytes, ref int cursor)
        {
            if (cursor < 0 || cursor > bytes.Length - 4) throw new BadImageFormatException();
            int value = BitConverter.ToInt32(bytes, cursor); cursor += 4; return value;
        }

        private string ResolveOperand(MethodInfo method, int token, OperandType operandType)
        {
            if (operandType == OperandType.InlineString) return Token(token) + " [string omitted]";
            if (operandType == OperandType.InlineSig) return Token(token);
            try {
                Type[] typeArguments = method.DeclaringType.IsGenericType ? method.DeclaringType.GetGenericArguments() : null;
                Type[] methodArguments = method.IsGenericMethod ? method.GetGenericArguments() : null;
                MemberInfo member = method.Module.ResolveMember(token, typeArguments, methodArguments);
                if (member == null) return Token(token);
                Type memberType = member as Type;
                if (memberType != null) return Token(token) + " " + TypeName(memberType);
                return Token(token) + " " + TypeName(member.DeclaringType) + "::" + member.ToString();
            } catch (Exception ex) {
                Error("il_token/" + TypeName(method.DeclaringType) + "." + method.Name + "/" + Token(token), ex);
                return Token(token) + " [unresolved]";
            }
        }

        private void DecodeIl(MethodInfo method, byte[] bytes, List<InstructionReport> output)
        {
            int cursor = 0;
            while (cursor < bytes.Length) {
                int start = cursor;
                short value = bytes[cursor++];
                if (value == 0xfe) {
                    if (cursor >= bytes.Length) throw new BadImageFormatException();
                    value = unchecked((short)(0xfe00 | bytes[cursor++]));
                }
                OpCode opcode;
                if (!opCodes.TryGetValue(value, out opcode)) throw new BadImageFormatException();
                string operand = null;
                switch (opcode.OperandType) {
                    case OperandType.InlineNone: break;
                    case OperandType.ShortInlineBrTarget:
                        if (cursor >= bytes.Length) throw new BadImageFormatException();
                        int shortDelta = (sbyte)bytes[cursor++];
                        operand = "IL_" + (cursor + shortDelta).ToString("X4", CultureInfo.InvariantCulture); break;
                    case OperandType.InlineBrTarget:
                        int delta = ReadInt32(bytes, ref cursor);
                        operand = "IL_" + (cursor + delta).ToString("X4", CultureInfo.InvariantCulture); break;
                    case OperandType.InlineSwitch:
                        int count = ReadInt32(bytes, ref cursor);
                        if (count < 0 || count > (bytes.Length - cursor) / 4) throw new BadImageFormatException();
                        int targetBase = cursor + count * 4;
                        List<string> targets = new List<string>();
                        for (int i = 0; i < count; i++) targets.Add("IL_" + (targetBase + ReadInt32(bytes, ref cursor)).ToString("X4", CultureInfo.InvariantCulture));
                        operand = String.Join(", ", targets.ToArray()); break;
                    case OperandType.ShortInlineI:
                        if (cursor >= bytes.Length) throw new BadImageFormatException();
                        operand = ((sbyte)bytes[cursor++]).ToString(CultureInfo.InvariantCulture); break;
                    case OperandType.ShortInlineVar:
                        if (cursor >= bytes.Length) throw new BadImageFormatException();
                        operand = bytes[cursor++].ToString(CultureInfo.InvariantCulture); break;
                    case OperandType.InlineVar:
                        if (cursor > bytes.Length - 2) throw new BadImageFormatException();
                        operand = BitConverter.ToUInt16(bytes, cursor).ToString(CultureInfo.InvariantCulture); cursor += 2; break;
                    case OperandType.InlineI:
                        operand = ReadInt32(bytes, ref cursor).ToString(CultureInfo.InvariantCulture); break;
                    case OperandType.InlineI8:
                        if (cursor > bytes.Length - 8) throw new BadImageFormatException();
                        operand = BitConverter.ToInt64(bytes, cursor).ToString(CultureInfo.InvariantCulture); cursor += 8; break;
                    case OperandType.ShortInlineR:
                        if (cursor > bytes.Length - 4) throw new BadImageFormatException();
                        operand = BitConverter.ToSingle(bytes, cursor).ToString("R", CultureInfo.InvariantCulture); cursor += 4; break;
                    case OperandType.InlineR:
                        if (cursor > bytes.Length - 8) throw new BadImageFormatException();
                        operand = BitConverter.ToDouble(bytes, cursor).ToString("R", CultureInfo.InvariantCulture); cursor += 8; break;
                    case OperandType.InlineField:
                    case OperandType.InlineMethod:
                    case OperandType.InlineType:
                    case OperandType.InlineTok:
                    case OperandType.InlineString:
                    case OperandType.InlineSig:
                        operand = ResolveOperand(method, ReadInt32(bytes, ref cursor), opcode.OperandType); break;
                    default: throw new BadImageFormatException();
                }
                output.Add(new InstructionReport { Offset = "IL_" + start.ToString("X4", CultureInfo.InvariantCulture), OpCode = opcode.Name, Operand = operand });
            }
        }
    }
}
'@

try {
    Write-Info 'VERSION' 'Collecteur de compatibilite 7DTD 0.1 — lecture seule, aucun envoi.'
    Write-Info 'LECTURE' 'Lecture des versions, empreintes et metadonnees ciblees du jeu...'
    $issues = [System.Collections.Generic.List[string]]::new()
    $files = [System.Collections.Generic.List[object]]::new()
    $relativeFiles = @(
        '7DaysToDie.exe',
        'UnityPlayer.dll',
        '7DaysToDie_Data\Managed\Assembly-CSharp.dll',
        '7DaysToDie_Data\Managed\UnityEngine.CoreModule.dll',
        '7DaysToDie_Data\Managed\UnityEngine.dll',
        '7DaysToDie_Data\Managed\mscorlib.dll'
    )
    $monoCandidates = @(
        'MonoBleedingEdge\EmbedRuntime\mono-2.0-bdwgc.dll',
        '7DaysToDie_Data\MonoBleedingEdge\EmbedRuntime\mono-2.0-bdwgc.dll',
        '7DaysToDie_Data\MonoBleedingEdge\mono-2.0-bdwgc.dll'
    )
    $monoFound = $false
    foreach ($relative in $monoCandidates) {
        if (Test-Path -LiteralPath (Join-Path $gameRoot $relative) -PathType Leaf) {
            $relativeFiles += $relative
            $monoFound = $true
        }
    }
    if (-not $monoFound) { $issues.Add('Native Mono runtime absent from the known game-relative locations; runtime ABI remains unidentified.') }

    foreach ($relative in $relativeFiles) {
        $item = [ordered]@{
            RelativePath = $relative.Replace('\', '/')
            Status = 'absent'
            SizeBytes = $null
            FileVersion = $null
            ProductVersion = $null
            SHA256 = $null
        }
        $path = Join-Path $gameRoot $relative
        if (Test-Path -LiteralPath $path -PathType Leaf) {
            try {
                $info = Get-Item -LiteralPath $path
                $version = [Diagnostics.FileVersionInfo]::GetVersionInfo($info.FullName)
                $item.SizeBytes = $info.Length
                $item.FileVersion = $version.FileVersion
                $item.ProductVersion = $version.ProductVersion
                $item.SHA256 = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
                $item.Status = 'read'
            } catch {
                $item.Status = 'read_error'
                $issues.Add(('File read failed: {0} ({1})' -f $item.RelativePath, $_.Exception.GetBaseException().GetType().Name))
            }
        } elseif ($relative -ne '7DaysToDie_Data\Managed\UnityEngine.dll') {
            $issues.Add(('Expected file absent: {0}' -f $item.RelativePath))
        }
        $files.Add([pscustomobject]$item)
    }

    $metadata = $null
    try {
        Add-Type -TypeDefinition $inspectorSource -Language CSharp -ReferencedAssemblies @('System.dll', 'System.Core.dll')
        $inspector = [SevenDaysGameInfo.Inspector]::new($managedRoot)
        $metadata = $inspector.Run()
    } catch {
        $issues.Add(('Metadata inspection failed ({0}).' -f $_.Exception.GetBaseException().GetType().Name))
    }
    $complete = $issues.Count -eq 0 -and $null -ne $metadata -and $metadata.Status -eq 'complete'
    $status = if ($complete) { 'complete' } else { 'partial' }
    $report = [ordered]@{
        Schema = 'seven-days-dma-game-info-v1'
        CollectorVersion = '0.1'
        CreatedUtc = [DateTime]::UtcNow.ToString('o')
        Status = $status
        GameVersionFromMenu = $null
        SteamBranch = $null
        Notes = @(
            'FileVersion/ProductVersion may be engine or executable versions; they are not a verified menu build number.'
            'The report contains metadata and selected managed IL only, not game runtime addresses or validated field offsets.'
            'No game DLL was executed, no game file was modified, and no report was uploaded.'
            'Absolute installation paths, user names, saves and logs are intentionally excluded.'
            'A native Unity camera/transform reader and the target Mono ABI still require validation.'
        )
        Files = $files.ToArray()
        Metadata = $metadata
        Issues = $issues.ToArray()
    }
    $reportDirectory = Join-Path $PSScriptRoot 'rapports'
    if (-not (Test-Path -LiteralPath $reportDirectory -PathType Container)) {
        [void][IO.Directory]::CreateDirectory($reportDirectory)
    }
    $reportName = 'rapport-jeu-{0}-{1}.json' -f [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmssfff'), [Guid]::NewGuid().ToString('N').Substring(0, 6)
    $reportPath = Join-Path $reportDirectory $reportName
    $json = $report | ConvertTo-Json -Depth 30
    [IO.File]::WriteAllText($reportPath, $json, [Text.UTF8Encoding]::new($false))
    $typeCount = if ($null -eq $metadata) { 0 } else { $metadata.Types.Count }
    if ($complete) {
        Write-Info 'RAPPORT_CREE' ('Collecte terminee : {0} types inspectes.' -f $typeCount)
    } else {
        $metadataErrorCount = if ($null -eq $metadata) { 0 } else { $metadata.Errors.Count }
        Write-Info 'RAPPORT_PARTIEL' ('Rapport exploitable avec limites : {0} types ; {1} incidents de fichiers/collecte ; {2} erreurs de metadonnees. Voir Issues, MissingRequestedTypes et ResolutionNotes.' -f $typeCount, $issues.Count, $metadataErrorCount)
    }
    Write-Info 'FICHIER' ('rapports\{0}' -f $reportName)
    Write-Info 'SUITE' 'Joins ce JSON et une capture de la version du menu principal. Le rapport ne prouve pas encore la compatibilite de l''ESP.'
    if ($complete) { exit 0 } else { exit 4 }
} catch {
    Write-Info 'ECHEC_COLLECTE' ('Rapport non enregistre ({0}). Verifie que le dossier du lanceur est accessible en ecriture.' -f $_.Exception.GetBaseException().GetType().Name)
    exit 6
}
