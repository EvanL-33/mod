using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using SevenDaysEsp;
using SevenDaysLoader.Services;

// Uses the production entity reader and control framing, not a second reader.
// All addresses belong to LiveReaderTests' synthetic Mono fixture.
internal static class LiveReadOptionsTests
{
    public static async Task Run()
    {
        await DisabledDetailsDoNotReadTheirGraphs();
        await CategoriesAndDetailsRemainIndependent();
        await UpdatesWaitForTheNextCaptureAndReadFreshValues();
        await DisabledDetailsDoNotBypassIdentityChecks();
        await MailboxesKeepOnlyCopiedLatestPreferences();
        await DuplexControlRemainsOpenUntilStop();
        await InvalidControlClosesCleanly();
        await UpdatesDuringShutdownDoNotThrow();
    }

    public static Task DisabledDetailsDoNotReadTheirGraphs()
    {
        var f = new LiveReaderTests.Fixture();
        f.EnableHealth(); f.EnableNames();
        ulong playerName = f.ManagedString("Nom joueur");
        ulong zombieName = f.ManagedString("Nom zombie");
        f.Memory.U64(f.OtherPlayer + 0x50, playerName);
        f.Memory.U64(f.Zombie + 0x50, zombieName);
        var reader = f.Reader();
        reader.ReadOptions = Options(0);
        var camera = Camera(); reader.CameraCapture = (_, _, _) => camera;
        var auxiliary = new HashSet<ulong>
        {
            f.PlayerStats, f.ZombieStats, f.PlayerHealth, f.ZombieHealth,
            playerName, zombieName, f.RegistryDictionary, f.RegistryClassObject
        };
        int auxiliaryReads = 0;
        f.Memory.BeforeRead = (address, _) => { if (auxiliary.Contains(address)) ++auxiliaryReads; };
        var result = reader.Capture();
        AssertEntities(result);
        Check(auxiliaryReads == 0 && result.Diagnostics.OptionalDetailsReadCalls == 0 &&
            result.Diagnostics.OptionalDetailsReadBytes == 0, "Disabled details still read auxiliary memory.");
        Check(result.Diagnostics.HealthSkipped == 2 && result.Diagnostics.NamesSkipped == 2 &&
            result.Diagnostics.HealthUnavailable == 0, "Disabled reads were reported as failed health acquisition.");
        Check(result.Entities.All(entity => entity.Health == null && entity.MaxHealth == null && entity.NameSource == "fallback"),
            "A disabled detail retained or invented a value.");
        Check(Mask(result.Diagnostics.AppliedReadOptions) == 0 && ReferenceEquals(result.Camera, camera),
            "Applied options or the independent camera capture were lost.");
        return Task.CompletedTask;
    }

    public static Task CategoriesAndDetailsRemainIndependent()
    {
        var f = new LiveReaderTests.Fixture(); f.EnableHealth();
        ulong playerName = f.ManagedString("Joueur choisi"), zombieName = f.ManagedString("Zombie choisi");
        f.Memory.U64(f.OtherPlayer + 0x50, playerName); f.Memory.U64(f.Zombie + 0x50, zombieName);
        var reader = f.Reader();
        var reads = new HashSet<ulong>();
        f.Memory.BeforeRead = (address, _) => reads.Add(address);
        reader.ReadOptions = Options(1 | 8); // Player name, zombie health only.
        var first = reader.Capture(); AssertEntities(first);
        var player = first.Entities.Single(entity => entity.Kind == "player");
        var zombie = first.Entities.Single(entity => entity.Kind == "zombie");
        Check(player.Name == "Joueur choisi" && player.Health == null && zombie.Health == 42 && zombie.NameSource == "fallback",
            "One category/detail switch affected the other category.");
        Check(reads.Contains(playerName) && reads.Contains(f.ZombieHealth) && !reads.Contains(zombieName) && !reads.Contains(f.PlayerStats),
            "The disabled category's name or health graph was still touched.");
        reads.Clear();
        reader.ReadOptions = Options(2 | 4);
        var second = reader.Capture(); AssertEntities(second);
        player = second.Entities.Single(entity => entity.Kind == "player");
        zombie = second.Entities.Single(entity => entity.Kind == "zombie");
        Check(player.Health == 75 && player.NameSource == "fallback" && zombie.Name == "Zombie choisi" && zombie.Health == null,
            "Reversing the switches did not reverse the optional reads.");
        Check(reads.Contains(f.PlayerHealth) && reads.Contains(zombieName) && !reads.Contains(playerName) && !reads.Contains(f.ZombieStats),
            "Reversed preferences retained reads from the preceding capture.");
        return Task.CompletedTask;
    }

    public static Task UpdatesWaitForTheNextCaptureAndReadFreshValues()
    {
        var f = new LiveReaderTests.Fixture(); f.EnableHealth();
        f.Memory.U64(f.OtherPlayer + 0x50, f.ManagedString("Premier nom"));
        var reader = f.Reader();
        var supplied = Options(15);
        reader.ReadOptions = supplied;
        supplied.PlayerNames = supplied.PlayerHealth = supplied.ZombieNames = supplied.ZombieHealth = false;
        var returned = reader.ReadOptions;
        returned.PlayerHealth = false;
        bool changed = false;
        f.Memory.BeforeRead = (address, _) =>
        {
            if (address != f.OtherPlayer || changed) return;
            changed = true;
            reader.ReadOptions = Options(0);
        };
        var first = reader.Capture(); AssertEntities(first);
        Check(changed && Mask(first.Diagnostics.AppliedReadOptions) == 15 && first.Entities.All(entity => entity.Health.HasValue),
            "A caller mutation or a mid-capture update changed the frozen read options.");
        Check(first.Entities.Single(entity => entity.Kind == "player").Name == "Premier nom",
            "The first capture stopped reading names after a mid-capture update.");
        f.Memory.BeforeRead = null;
        f.SetHealth(f.PlayerHealth, 17, 100, 0);
        f.Memory.U64(f.OtherPlayer + 0x50, f.ManagedString("Nom renouvelé"));
        var disabled = reader.Capture(); AssertEntities(disabled);
        Check(Mask(disabled.Diagnostics.AppliedReadOptions) == 0 && disabled.Entities.All(entity => entity.Health == null),
            "The pending options did not apply to the next complete capture.");
        disabled.Diagnostics.AppliedReadOptions.PlayerHealth = true;
        Check(Mask(reader.ReadOptions) == 0, "Mutating the diagnostic changed the reader's preferences.");
        reader.ReadOptions = Options(15);
        var resumed = reader.Capture(); AssertEntities(resumed);
        var player = resumed.Entities.Single(entity => entity.Kind == "player");
        Check(player.Health == 17 && player.Name == "Nom renouvelé", "Re-enabled details used values cached before they were disabled.");
        return Task.CompletedTask;
    }

    public static Task DisabledDetailsDoNotBypassIdentityChecks()
    {
        var f = new LiveReaderTests.Fixture(); var reader = f.Reader(); reader.ReadOptions = Options(0);
        int cameraReads = 0;
        reader.CameraCapture = (_, _, _) => { ++cameraReads; return Camera(); };
        f.Memory.U64(f.Manager + LiveReaderTests.Fixture.ManagerWorldOffset, 0);
        var result = reader.Capture();
        Check(result.Status != "ENTITES_LUES" && !result.Diagnostics.CanPublish && cameraReads == 0,
            "Skipping optional details bypassed the world/identity checks.");
        Check(Mask(result.Diagnostics.AppliedReadOptions) == 0, "A rejected capture lost the applied-read diagnostic.");
        return Task.CompletedTask;
    }

    public static Task MailboxesKeepOnlyCopiedLatestPreferences()
    {
        var pending = new PendingReadOptions();
        var first = Options(1); pending.Replace(first); first.PlayerHealth = true;
        for (int i = 0; i < 1000; ++i) pending.Replace(Options(i % 16));
        var expected = Options(12); pending.Replace(expected); expected.PlayerNames = true;
        var latest = pending.Take();
        Check(latest != null && Mask(latest) == 12 && !pending.HasPending && pending.Take() == null,
            "The one-value mailbox retained old requests or a caller-owned reference.");
        Check(!pending.Replace(Options(12)), "Unchanged needs were queued repeatedly.");
        pending.Replace(Options(3));
        var initial = pending.TakeInitial(Options(15));
        Check(Mask(initial) == 3 && !pending.HasPending, "Startup discarded preferences queued before connection.");
        pending.Clear();
        Check(pending.Replace(Options(3)), "A new session suppressed a request remembered from the previous session.");

        var input = Options(5);
        var state = new WorkerReadOptionsState(input);
        input.PlayerHealth = true;
        var snapshot = state.Snapshot();
        Check(snapshot.Revision == 1 && Mask(snapshot.Options) == 5, "The worker retained startup options by reference.");
        snapshot.Options.PlayerHealth = true;
        state.Update(Options(5));
        Check(state.Snapshot().Revision == 1, "An identical update needlessly advanced the applied revision.");
        state.Update(Options(10));
        Check(state.Snapshot().Revision == 2 && Mask(state.Snapshot().Options) == 10,
            "A new worker revision was not copied atomically.");
        return Task.CompletedTask;
    }

    public static async Task DuplexControlRemainsOpenUntilStop()
    {
        // Exercise the production loop and Wire framing over a bounded duplex
        // byte stream. No IPC socket is required; Windows named pipes themselves
        // are not executed or validated by this portable protocol test.
        var pair = MemoryDuplexStream.CreatePair();
        using var server = pair.First;
        using var client = pair.Second;
        using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(5));
        using var cancelled = new CancellationTokenSource();
        var state = new WorkerReadOptionsState(Options(15));
        Task monitor = WorkerControlLoop.MonitorAsync(server, state, cancelled);
        try
        {
            await Wire.WriteAsync(client, new WorkerControl { Kind = WorkerControl.ReadOptionsKind, ReadOptions = Options(1) }, deadline.Token);
            await WaitForRevision(state, 2, deadline.Token);
            Check(!monitor.IsCompleted && !cancelled.IsCancellationRequested, "An options update closed the control loop.");
            await Wire.WriteAsync(client, new WorkerControl { Kind = WorkerControl.ReadOptionsKind, ReadOptions = Options(8) }, deadline.Token);
            await WaitForRevision(state, 3, deadline.Token);
            Check(Mask(state.Snapshot().Options) == 8 && !monitor.IsCompleted, "The second update was ignored or stopped the worker.");
            await Wire.WriteAsync(client, new WorkerControl { Kind = WorkerControl.StopKind }, deadline.Token);
            await monitor.WaitAsync(deadline.Token);
            Check(cancelled.IsCancellationRequested && state.ControlFailure == null, "A valid stop was reported as a control failure.");
        }
        finally
        {
            cancelled.Cancel();
            await monitor.WaitAsync(TimeSpan.FromSeconds(2));
        }

        // Cancellation must also release a pending read when no stop payload
        // is available, without reporting an ordinary shutdown as a failure.
        var idlePair = MemoryDuplexStream.CreatePair();
        using var idleServer = idlePair.First;
        using var idleClient = idlePair.Second;
        using var idleCancellation = new CancellationTokenSource();
        var idleState = new WorkerReadOptionsState(Options(15));
        Task idleMonitor = WorkerControlLoop.MonitorAsync(idleServer, idleState, idleCancellation);
        Check(!idleMonitor.IsCompleted, "An open, empty duplex stream was mistaken for end-of-stream.");
        idleCancellation.Cancel();
        await idleMonitor.WaitAsync(deadline.Token);
        Check(idleMonitor.IsCompletedSuccessfully && idleState.ControlFailure == null,
            "Cancelling a pending control read did not finish cleanly.");
    }

    public static async Task InvalidControlClosesCleanly()
    {
        foreach (string payload in new[]
        {
            "{\"Kind\":\"unknown\"}",
            "{\"Kind\":\"read-options\"}",
            "{\"Kind\":\"stop\",\"ReadOptions\":{}}",
            "{\"Kind\":true}", "null"
        })
        {
            using var stream = Framed(payload);
            using var cancelled = new CancellationTokenSource();
            var state = new WorkerReadOptionsState(Options(15));
            await WorkerControlLoop.MonitorAsync(stream, state, cancelled);
            Check(cancelled.IsCancellationRequested && !string.IsNullOrEmpty(state.ControlFailure) && state.Snapshot().Revision == 1,
                "An unknown, incomplete or malformed control did not close with an observed failure.");
        }
        using var oversized = new MemoryStream();
        byte[] header = new byte[4]; BinaryPrimitives.WriteInt32LittleEndian(header, Wire.MaxMessageBytes + 1);
        oversized.Write(header); oversized.Position = 0;
        using var stopped = new CancellationTokenSource();
        var badLengthState = new WorkerReadOptionsState(Options(15));
        await WorkerControlLoop.MonitorAsync(oversized, badLengthState, stopped);
        Check(stopped.IsCancellationRequested && badLengthState.ControlFailure != null,
            "Wire's invalid-length exception was not observed by the control loop.");
    }

    public static async Task UpdatesDuringShutdownDoNotThrow()
    {
        // No child is started: this exercises the public lifetime race without
        // loading Windows jobs, MemProcFS or any actual DMA device.
        var host = new WorkerHost();
        int errors = 0; host.ControlError += _ => Interlocked.Increment(ref errors);
        Task updates = Task.Run(() =>
        {
            for (int i = 0; i < 2000; ++i) host.UpdateReadOptions(Options(i % 16));
        });
        Task stop = host.StopAsync();
        Task dispose = host.DisposeAsync().AsTask();
        await Task.WhenAll(updates, stop, dispose).WaitAsync(TimeSpan.FromSeconds(3));
        host.UpdateReadOptions(Options(15));
        Check(errors == 0, "An update racing ordinary shutdown emitted a control failure.");
    }

    private static async Task WaitForRevision(WorkerReadOptionsState state, long revision, CancellationToken token)
    {
        while (state.Snapshot().Revision < revision) await Task.Delay(1, token);
    }

    private static MemoryStream Framed(string payload)
    {
        var bytes = Encoding.UTF8.GetBytes(payload);
        var stream = new MemoryStream();
        byte[] header = new byte[4]; BinaryPrimitives.WriteInt32LittleEndian(header, bytes.Length);
        stream.Write(header); stream.Write(bytes); stream.Position = 0;
        return stream;
    }

    // Each endpoint owns one reader and one writer. The two bounded channels
    // provide backpressure; the stream consumes chunks as bytes, so Wire cannot
    // depend on the transport preserving its header/payload write boundaries.
    private sealed class MemoryDuplexStream : Stream
    {
        private readonly Channel<byte[]> incoming;
        private readonly Channel<byte[]> outgoing;
        private readonly CancellationTokenSource lifetime = new();
        private byte[]? pending;
        private int offset;
        private bool disposed;

        private MemoryDuplexStream(Channel<byte[]> incoming, Channel<byte[]> outgoing)
        {
            this.incoming = incoming;
            this.outgoing = outgoing;
        }

        internal static (MemoryDuplexStream First, MemoryDuplexStream Second) CreatePair()
        {
            static Channel<byte[]> CreateChannel() => Channel.CreateBounded<byte[]>(
                new BoundedChannelOptions(4)
                {
                    SingleReader = true, SingleWriter = true, AllowSynchronousContinuations = false,
                    FullMode = BoundedChannelFullMode.Wait
                });
            var first = CreateChannel();
            var second = CreateChannel();
            return (new MemoryDuplexStream(first, second), new MemoryDuplexStream(second, first));
        }

        public override bool CanRead => !disposed;
        public override bool CanWrite => !disposed;
        public override bool CanSeek => false;
        public override long Length => throw new NotSupportedException();
        public override long Position { get => throw new NotSupportedException(); set => throw new NotSupportedException(); }
        public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
        public override void SetLength(long value) => throw new NotSupportedException();

        public override async ValueTask<int> ReadAsync(Memory<byte> buffer, CancellationToken cancellationToken = default)
        {
            ObjectDisposedException.ThrowIf(disposed, this);
            if (buffer.Length == 0) return 0;
            using var linked = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, lifetime.Token);
            linked.Token.ThrowIfCancellationRequested();
            while (pending == null || offset == pending.Length)
            {
                try { pending = await incoming.Reader.ReadAsync(linked.Token).ConfigureAwait(false); }
                catch (ChannelClosedException) { return 0; }
                offset = 0;
            }
            // Return partial reads even for small controls, exercising the real
            // ReadExactlyAsync path instead of an accidentally message-like API.
            int count = Math.Min(7, Math.Min(buffer.Length, pending.Length - offset));
            pending.AsMemory(offset, count).CopyTo(buffer);
            offset += count;
            return count;
        }

        public override async ValueTask WriteAsync(ReadOnlyMemory<byte> buffer, CancellationToken cancellationToken = default)
        {
            ObjectDisposedException.ThrowIf(disposed, this);
            if (buffer.Length == 0) return;
            using var linked = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, lifetime.Token);
            try { await outgoing.Writer.WriteAsync(buffer.ToArray(), linked.Token).ConfigureAwait(false); }
            catch (ChannelClosedException error) { throw new IOException("The peer closed the in-memory control stream.", error); }
        }

        public override int Read(byte[] buffer, int offset, int count) =>
            ReadAsync(buffer.AsMemory(offset, count)).AsTask().GetAwaiter().GetResult();
        public override void Write(byte[] buffer, int offset, int count) =>
            WriteAsync(buffer.AsMemory(offset, count)).AsTask().GetAwaiter().GetResult();
        public override void Flush() => ObjectDisposedException.ThrowIf(disposed, this);
        public override Task FlushAsync(CancellationToken cancellationToken)
        {
            ObjectDisposedException.ThrowIf(disposed, this);
            cancellationToken.ThrowIfCancellationRequested();
            return Task.CompletedTask;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && !disposed)
            {
                disposed = true;
                incoming.Writer.TryComplete();
                outgoing.Writer.TryComplete();
                lifetime.Cancel();
                lifetime.Dispose();
            }
            base.Dispose(disposing);
        }
    }

    private static LiveReadOptions Options(int mask) => new()
    {
        PlayerNames = (mask & 1) != 0, PlayerHealth = (mask & 2) != 0,
        ZombieNames = (mask & 4) != 0, ZombieHealth = (mask & 8) != 0
    };
    private static int Mask(LiveReadOptions options) => (options.PlayerNames ? 1 : 0) | (options.PlayerHealth ? 2 : 0) |
        (options.ZombieNames ? 4 : 0) | (options.ZombieHealth ? 8 : 0);
    private static LiveCameraFrame Camera() => new()
    {
        ProfileId = "unity-2022.3.62f2-7670c08855a9-native-v1", ClipDepth = "MinusOneToOne", Sequence = 1, CameraEpoch = 1,
        SourceWidth = 1920, SourceHeight = 1080, ViewportWidth = 1920, ViewportHeight = 1080,
        ViewProjection = new float[] { 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 }, ReadDurationMs = 1
    };
    private static void AssertEntities(LiveEntitySnapshot snapshot)
    {
        Check(snapshot.Status == "ENTITES_LUES" && snapshot.Diagnostics.CanPublish && snapshot.Entities.Count == 2 &&
            snapshot.PlayersCount == 1 && snapshot.ZombiesCount == 1 && snapshot.Entities.All(entity => entity.Bounds != null),
            "Optional read preferences changed the valid entity/position/bounds capture.");
    }
    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
