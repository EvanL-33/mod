﻿#requires -Version 5.1
<#
Diagnostic reel de connexion MemProcFS/PCILeech FPGA pour une machine personnelle.
Lancer dans un NOUVEAU processus Windows PowerShell x64, jamais en dot-sourcing.
Le script ne contient aucun moteur ESP, offset de jeu ou appel d'ecriture memoire.

API et options verifiees dans les sources officielles :
https://github.com/ufrisk/MemProcFS/wiki/API_C
https://github.com/ufrisk/MemProcFS/blob/master/includes/vmmdll.h
https://github.com/ufrisk/MemProcFS/wiki/_CommandLine
https://learn.microsoft.com/windows/win32/api/libloaderapi/nf-libloaderapi-loadlibraryexw

Codes sortie : 0 jeu detecte ; 2 environnement/parametres ; 3 dependances ;
4 connexion/initialisation ; 5 jeu non trouve ; 6 erreur pendant le diagnostic.
#>
[CmdletBinding()]
param(
    [string]$VmmDir = '',
    [string]$Device = 'fpga'
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)

function Write-ProbeMessage {
    param([string]$State, [string]$Message)
    [Console]::WriteLine(('[{0}] {1}' -f $State, $Message))
    [Console]::Out.Flush()
}

if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT -or [IntPtr]::Size -ne 8) {
    Write-ProbeMessage 'ERREUR_ENVIRONNEMENT' 'Utilise Windows PowerShell 64 bits sous Windows 10 ou 11.'
    exit 2
}
try {
    if ([string]::IsNullOrWhiteSpace($VmmDir) -or -not (Test-Path -LiteralPath $VmmDir -PathType Container)) {
        throw 'Choisis le dossier de la distribution Windows x64 de MemProcFS contenant vmm.dll.'
    }
    $sdkPath = (Get-Item -LiteralPath $VmmDir).FullName
} catch {
    Write-ProbeMessage 'ERREUR_PARAMETRE' $_.Exception.Message
    exit 2
}
if ($Device -notmatch '\Afpga(?:://[^\s\x00]+)?\z') {
    Write-ProbeMessage 'ERREUR_PARAMETRE' 'Ce diagnostic attend le périphérique fpga ou une URI fpga:// compatible LeechCore.'
    exit 2
}
foreach ($dllName in @('vmm.dll', 'leechcore.dll')) {
    if (-not (Test-Path -LiteralPath (Join-Path $sdkPath $dllName) -PathType Leaf)) {
        Write-ProbeMessage 'DEPENDANCE_ABSENTE' ('Fichier introuvable : {0}. Garde la distribution officielle complète dans le même dossier.' -f $dllName)
        exit 3
    }
}

$nativeSource = @'
using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace SevenDaysDmaDiagnostic
{
    public sealed class NativeSession : IDisposable
    {
        private IntPtr library = IntPtr.Zero;
        private IntPtr directoryCookie = IntPtr.Zero;
        private IntPtr session = IntPtr.Zero;
        private bool disposed;

        [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetDefaultDllDirectories(uint flags);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
        private static extern IntPtr AddDllDirectory(string path);
        [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool RemoveDllDirectory(IntPtr cookie);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
        private static extern IntPtr LoadLibraryExW(string path, IntPtr file, uint flags);
        [DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
        private static extern IntPtr GetProcAddress(IntPtr module, string name);
        [DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool FreeLibrary(IntPtr module);

        // MemProcFS v5 ABI; Windows x64 has one native calling convention.
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate IntPtr InitializeFn(uint argc, IntPtr argv);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate void CloseFn(IntPtr vmm);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private delegate bool PidFromNameFn(IntPtr vmm, IntPtr name, out uint pid);
        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        private delegate ulong ModuleBaseFn(IntPtr vmm, uint pid, IntPtr name);

        private InitializeFn initialize;
        private CloseFn close;
        private PidFromNameFn pidFromName;
        private ModuleBaseFn moduleBase;

        public NativeSession(string sdkDirectory)
        {
            try
            {
                string fullDirectory = Path.GetFullPath(sdkDirectory);
                // Search only System32 and this explicitly selected SDK directory.
                // The policy is local to this disposable worker process.
                if (!SetDefaultDllDirectories(0x00000800 | 0x00000400))
                    throw new Win32Exception(Marshal.GetLastWin32Error(), "Recherche des DLL impossible.");
                directoryCookie = AddDllDirectory(fullDirectory);
                if (directoryCookie == IntPtr.Zero)
                    throw new Win32Exception(Marshal.GetLastWin32Error(), "Dossier SDK inaccessible.");
                library = LoadLibraryExW(Path.Combine(fullDirectory, "vmm.dll"), IntPtr.Zero,
                    0x00000100 | 0x00000800 | 0x00000400);
                if (library == IntPtr.Zero)
                    throw new Win32Exception(Marshal.GetLastWin32Error(), "vmm.dll ou une de ses dependances ne peut pas etre chargee.");
                initialize = Bind<InitializeFn>("VMMDLL_Initialize");
                close = Bind<CloseFn>("VMMDLL_Close");
                pidFromName = Bind<PidFromNameFn>("VMMDLL_PidGetFromName");
                moduleBase = Bind<ModuleBaseFn>("VMMDLL_ProcessGetModuleBaseU");
            }
            catch { Dispose(); throw; }
        }

        private T Bind<T>(string name) where T : class
        {
            IntPtr address = GetProcAddress(library, name);
            if (address == IntPtr.Zero)
                throw new EntryPointNotFoundException("Export MemProcFS absent : " + name);
            return (T)(object)Marshal.GetDelegateForFunctionPointer(address, typeof(T));
        }

        private static IntPtr Utf8(string text)
        {
            if (text == null || text.IndexOf('\0') >= 0)
                throw new ArgumentException("Argument natif invalide.");
            byte[] bytes = Encoding.UTF8.GetBytes(text + "\0");
            IntPtr result = Marshal.AllocHGlobal(bytes.Length);
            try { Marshal.Copy(bytes, 0, result, bytes.Length); return result; }
            catch { Marshal.FreeHGlobal(result); throw; }
        }

        public bool Open(string device)
        {
            if (disposed || session != IntPtr.Zero)
                throw new InvalidOperationException("Etat de session invalide.");
            // No plugin initialization, filesystem mount or memory-write API.
            // No automatic symbol downloads; cached SDK information remains usable.
            string[] arguments = { "", "-device", device, "-memmap", "auto",
                "-waitinitialize", "-disable-symbolserver", "-disable-python" };
            IntPtr array = IntPtr.Zero;
            IntPtr[] strings = new IntPtr[arguments.Length];
            try
            {
                array = Marshal.AllocHGlobal((arguments.Length + 1) * IntPtr.Size);
                for (int i = 0; i < arguments.Length; i++)
                {
                    strings[i] = Utf8(arguments[i]);
                    Marshal.WriteIntPtr(array, i * IntPtr.Size, strings[i]);
                }
                Marshal.WriteIntPtr(array, arguments.Length * IntPtr.Size, IntPtr.Zero);
                session = initialize((uint)arguments.Length, array);
                return session != IntPtr.Zero;
            }
            finally
            {
                foreach (IntPtr pointer in strings)
                    if (pointer != IntPtr.Zero) Marshal.FreeHGlobal(pointer);
                if (array != IntPtr.Zero) Marshal.FreeHGlobal(array);
            }
        }

        public uint FindGame()
        {
            if (disposed || session == IntPtr.Zero)
                throw new InvalidOperationException("Session non ouverte.");
            IntPtr name = Utf8("7DaysToDie.exe");
            try
            {
                uint gamePid;
                return pidFromName(session, name, out gamePid) ? gamePid : 0;
            }
            finally { Marshal.FreeHGlobal(name); }
        }

        public ulong FindGameBase(uint gamePid)
        {
            if (disposed || session == IntPtr.Zero)
                throw new InvalidOperationException("Session non ouverte.");
            IntPtr name = Utf8("7DaysToDie.exe");
            try { return moduleBase(session, gamePid, name); }
            finally { Marshal.FreeHGlobal(name); }
        }

        public void Dispose()
        {
            if (disposed) return;
            disposed = true;
            try
            {
                if (session != IntPtr.Zero && close != null)
                {
                    IntPtr handle = session;
                    session = IntPtr.Zero;
                    close(handle);
                }
            }
            finally
            {
                if (library != IntPtr.Zero)
                {
                    FreeLibrary(library);
                    library = IntPtr.Zero;
                }
                if (directoryCookie != IntPtr.Zero)
                {
                    RemoveDllDirectory(directoryCookie);
                    directoryCookie = IntPtr.Zero;
                }
            }
        }
    }
}
'@

$probe = $null
$stage = 'load'
$resultCode = 6
try {
    Write-ProbeMessage 'INFO' 'Test réel de connexion et de détection du jeu. Aucun affichage ESP ne sera lancé.'
    Write-ProbeMessage 'INFO' ('Périphérique demandé : {0}' -f $Device)
    Add-Type -TypeDefinition $nativeSource -Language CSharp
    $probe = [SevenDaysDmaDiagnostic.NativeSession]::new($sdkPath)
    Write-ProbeMessage 'DEPENDANCES_CHARGEES' 'API native MemProcFS chargée.'
    $stage = 'connect'
    Write-ProbeMessage 'CONNEXION' 'Initialisation de la lecture DMA et identification du système cible en cours…'
    if (-not $probe.Open($Device)) {
        Write-ProbeMessage 'ECHEC_CONNEXION' 'MemProcFS ne peut pas initialiser le périphérique et le système cible.'
        Write-ProbeMessage 'DETAIL' 'Vérifie le modèle de carte, le câble, le pilote USB et les DLL requis par sa documentation. Le programme ne modifie aucun réglage de protection du PC.'
        $resultCode = 4
    } else {
        Write-ProbeMessage 'DMA_INITIALISE' 'Session MemProcFS ouverte sur le périphérique FPGA.'
        $stage = 'lookup'
        [uint32]$gameProcessId = $probe.FindGame()
        if ($gameProcessId -eq 0) {
            Write-ProbeMessage 'JEU_NON_TROUVE' '7DaysToDie.exe n''a pas été trouvé dans la mémoire accessible. Lance ta partie sur le PC cible, puis relance ce test.'
            Write-ProbeMessage 'DETAIL' 'Ce résultat peut aussi venir de données incomplètes ou d''une incompatibilité. Il ne prouve pas que le jeu est fermé.'
            $resultCode = 5
        } else {
            Write-ProbeMessage 'JEU_TROUVE' ('7DaysToDie.exe : PID {0}.' -f $gameProcessId)
            [uint64]$gameBase = $probe.FindGameBase($gameProcessId)
            if ($gameBase -ne 0) {
                Write-ProbeMessage 'MODULE_TROUVE' ('Base de 7DaysToDie.exe : 0x{0:X16}.' -f $gameBase)
            } else {
                Write-ProbeMessage 'MODULE_NON_TROUVE' 'PID détecté, mais adresse du module indisponible. La lecture du jeu n''est pas entièrement validée.'
            }
            Write-ProbeMessage 'RESULTAT' 'Connexion et PID du jeu détectés. Les entités, positions, caméra et affichage ESP restent à implémenter pour la version du jeu.'
            $resultCode = 0
        }
    }
} catch {
    $baseError = $_.Exception.GetBaseException()
    switch ($stage) {
        'load' {
            Write-ProbeMessage 'ERREUR_DEPENDANCE' ('Chargement impossible : {0}' -f $baseError.Message)
            Write-ProbeMessage 'DETAIL' 'Utilise la distribution officielle complète Windows x64 de MemProcFS v5 et ses dépendances compatibles avec ta carte.'
            $resultCode = 3
        }
        'connect' {
            Write-ProbeMessage 'ECHEC_CONNEXION' $baseError.Message
            $resultCode = 4
        }
        default {
            Write-ProbeMessage 'ERREUR_DIAGNOSTIC' $baseError.Message
            $resultCode = 6
        }
    }
} finally {
    if ($null -ne $probe) {
        try {
            $probe.Dispose()
            Write-ProbeMessage 'FERMETURE' 'Session de diagnostic fermée.'
        } catch {
            Write-ProbeMessage 'ERREUR_FERMETURE' ($_.Exception.GetBaseException().Message)
            if ($resultCode -eq 0) { $resultCode = 6 }
        }
    }
}
exit $resultCode
