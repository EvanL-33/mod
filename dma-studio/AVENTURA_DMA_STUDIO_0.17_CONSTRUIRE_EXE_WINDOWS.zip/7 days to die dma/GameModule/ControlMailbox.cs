using System;
using System.Threading;

namespace SevenDaysDmaControl
{
    // Portable mailbox state machine. It never imports Unity or accesses arbitrary addresses.
    // Its caller owns the only game-thread pump and the two fixed-size pinned arrays.
    public sealed class ControlMailbox
    {
        private readonly IGameActions _actions;
        private readonly Guid _sessionId;
        private readonly byte[] _requests;
        private readonly byte[] _state;
        private readonly Func<long> _clock;
        private readonly byte[] _first = new byte[ControlProtocol.RequestSize];
        private readonly byte[] _second = new byte[ControlProtocol.RequestSize];
        private ulong _highWatermark;
        private uint _sequence;
        private int _threadId;
        private long _lastTime = -1;
        private ControlRequest _pending;
        private long _pendingStarted;
        private GameObservation _observation = new GameObservation();
        private ulong _lastRequestId;
        private Guid _lastRequestContextId;
        private ControlOperation _lastOperation;
        private ControlStatus _lastStatus;
        private string _lastMessage = "Module en cours d'initialisation.";
        private bool _releaseOnRecovery;

        public ControlMailbox(IGameActions actions, Guid sessionId, byte[] requests, byte[] state, Func<long> clock)
        {
            _actions = actions ?? throw new ArgumentNullException(nameof(actions));
            _clock = clock ?? throw new ArgumentNullException(nameof(clock));
            if (sessionId == Guid.Empty) throw new ArgumentException("A nonempty session nonce is required.", nameof(sessionId));
            if (requests == null || requests.Length != ControlProtocol.RequestSize) throw new ArgumentException("Invalid request mailbox size.", nameof(requests));
            if (state == null || state.Length != ControlProtocol.StateSize) throw new ArgumentException("Invalid state mailbox size.", nameof(state));
            _sessionId = sessionId; _requests = requests; _state = state;
            Publish();
        }

        public void Tick()
        {
            if (!OnGameThread()) return;
            long now = _clock();
            if (now < 0 || now < _lastTime)
            {
                Fault("HORLOGE_MONOTONE_INVALIDE", now < 0 ? 0 : now); return;
            }
            _lastTime = now;
            try
            {
                _observation = _actions.Observe() ?? throw new InvalidOperationException("Observation absente.");
                _observation.GameTimestampMs = now;
                if (_releaseOnRecovery)
                {
                    _actions.Release(_observation);
                    _releaseOnRecovery = false;
                    _observation = _actions.Observe() ?? throw new InvalidOperationException("Observation absente.");
                    _observation.GameTimestampMs = now;
                }
            }
            catch (Exception error)
            {
                // No stale-object restoration here: Observe failed to establish which world exists.
                Fault("OBSERVATION_ECHOUEE: " + error.Message, now); return;
            }

            bool hadPending = _pending != null;
            if (_pending != null)
            {
                if (!ContextMatches(_pending, _observation))
                {
                    FinishPending(ControlStatus.Refused, "CONTEXTE_CHANGE: action interrompue.", true);
                }
                else if (now - _pendingStarted > ControlProtocol.MaxPendingDurationMs)
                {
                    FinishPending(ControlStatus.Failed, "DELAI_ACTION_DEPASSE: effet local non confirme.", true);
                }
                else
                {
                    try
                    {
                        GameActionResult result = ValidateResult(_actions.Poll(_pending.RequestId, _observation));
                        Record(_pending, result);
                        if (result.Status != ControlStatus.Pending) _pending = null;
                    }
                    catch (Exception error)
                    {
                        FinishPending(ControlStatus.Failed, "SUIVI_ECHOUE: " + error.Message, true);
                    }
                }
            }
            if (hadPending && _pending == null)
            {
                try
                {
                    _observation = _actions.Observe() ?? throw new InvalidOperationException("Observation absente.");
                    _observation.GameTimestampMs = now;
                }
                catch (Exception error) { Fault("RELECTURE_ECHOUEE: " + error.Message, now); return; }
            }

            ControlRequest request;
            if (ReadRequest(out request) && request.SessionId == _sessionId && request.RequestId > _highWatermark)
            {
                // Consume before validation/execution: failed and refused commands cannot replay.
                _highWatermark = request.RequestId;
                string reason = ValidateRequest(request, now);
                if (reason.Length != 0) Record(request, GameActionResult.Refused(reason));
                else if (_pending != null && request.Operation != ControlOperation.RestoreOwned)
                    Record(request, GameActionResult.Refused("ACTION_EN_COURS: attendre son resultat avant une autre demande."));
                else
                {
                    if (_pending != null)
                        FinishPending(ControlStatus.Refused, "ACTION_ANNULEE_PAR_RESTAURATION", true);
                    try
                    {
                        GameActionResult result = ValidateResult(_actions.Execute(request, _observation));
                        Record(request, result);
                        if (result.Status == ControlStatus.Pending) { _pending = request; _pendingStarted = now; }
                    }
                    catch (Exception error)
                    {
                        Record(request, GameActionResult.Failed("ACTION_ECHOUEE: " + error.Message));
                        TryRelease();
                    }
                    // Publish a fresh observation after an action, not a desired UI setting.
                    try
                    {
                        _observation = _actions.Observe() ?? throw new InvalidOperationException("Observation absente.");
                        _observation.GameTimestampMs = now;
                    }
                    catch (Exception error)
                    {
                        Fault("RELECTURE_ECHOUEE: " + error.Message, now); return;
                    }
                }
            }
            Publish();
        }

        // Called by the game's world-shutdown event on the same game thread. The arrays stay
        // pinned for the assembly lifetime, so a stale DMA pointer is never reused for other data.
        public void ReleaseForWorldShutdown()
        {
            if (!OnGameThread()) return;
            TryRelease(); _pending = null;
            _observation = new GameObservation { Availability = BridgeAvailability.NoWorld, GameTimestampMs = _clock(), Message = "Monde ferme." };
            if (_lastStatus == ControlStatus.Pending) { _lastStatus = ControlStatus.Refused; _lastMessage = "MONDE_FERME: action interrompue."; }
            Publish();
        }

        private bool ReadRequest(out ControlRequest request)
        {
            request = null;
            uint before = ControlProtocol.ReadSequence(_requests);
            if (before == 0 || (before & 1) != 0) return false;
            Thread.MemoryBarrier();
            Buffer.BlockCopy(_requests, 0, _first, 0, _first.Length);
            Thread.MemoryBarrier();
            Buffer.BlockCopy(_requests, 0, _second, 0, _second.Length);
            Thread.MemoryBarrier();
            if (before != ControlProtocol.ReadSequence(_requests) || !ControlProtocol.SameCommittedRecord(_first, _second)) return false;
            string error;
            return ControlProtocol.TryDecodeRequest(_second, out request, out error);
        }

        private string ValidateRequest(ControlRequest request, long now)
        {
            if (request.RequestId == 0 || request.RequestId == ulong.MaxValue) return "IDENTIFIANT_DEMANDE_INVALIDE";
            if (!ControlProtocol.IsKnownOperation(request.Operation)) return "OPERATION_INCONNUE";
            if (!ContextMatches(request, _observation)) return "CONTEXTE_INDISPONIBLE_OU_CHANGE";
            if ((_observation.SupportedOperations & ControlProtocol.OperationMask(request.Operation)) == 0) return "OPERATION_NON_PRISE_EN_CHARGE";
            if (request.IssuedGameTimeMs < 0 || request.IssuedGameTimeMs > now) return "HORODATAGE_JEU_INVALIDE";
            if (request.ExpiresGameTimeMs <= request.IssuedGameTimeMs ||
                request.ExpiresGameTimeMs - request.IssuedGameTimeMs > ControlProtocol.MaxRequestLifetimeMs) return "DUREE_DEMANDE_INVALIDE";
            if (now > request.ExpiresGameTimeMs) return "DEMANDE_EXPIREE";
            if (!ControlProtocol.IsFinite(request.Value) || !ControlProtocol.IsFinite(request.PositionX) ||
                !ControlProtocol.IsFinite(request.PositionY) || !ControlProtocol.IsFinite(request.PositionZ)) return "VALEUR_NON_FINIE";
            if (request.Operation == ControlOperation.SetNightBrightness && (request.Value < 0 || request.Value > 1)) return "LUMINOSITE_HORS_LIMITES";
            if (request.Operation == ControlOperation.SetSpeed && (request.Value < 0.1f || request.Value > 15f)) return "VITESSE_HORS_LIMITES";
            return "";
        }

        private static bool ContextMatches(ControlRequest request, GameObservation current)
        {
            return current != null && current.IsReady && current.ContextId != Guid.Empty &&
                request.ContextId == current.ContextId && request.PlayerId == current.PlayerId;
        }

        private static GameActionResult ValidateResult(GameActionResult result)
        {
            if (result == null || result.Status < ControlStatus.Pending || result.Status > ControlStatus.Failed)
                return GameActionResult.Failed("RESULTAT_ACTION_INVALIDE");
            return result;
        }

        private void FinishPending(ControlStatus status, string message, bool release)
        {
            ControlRequest request = _pending; _pending = null;
            if (request != null) Record(request, new GameActionResult(status, message));
            if (release) TryRelease();
        }

        private void TryRelease()
        {
            try { _actions.Release(_observation); }
            catch (Exception error) { _lastStatus = ControlStatus.Failed; _lastMessage = "RESTAURATION_INCOMPLETE: " + error.Message; }
        }

        private void Record(ControlRequest request, GameActionResult result)
        {
            _lastRequestId = request.RequestId; _lastOperation = request.Operation;
            _lastRequestContextId = request.ContextId;
            _lastStatus = result.Status; _lastMessage = result.Message ?? "";
        }

        private bool OnGameThread()
        {
            int current = Thread.CurrentThread.ManagedThreadId;
            if (_threadId == 0) _threadId = current;
            if (_threadId == current) return true;
            // Never make a Unity call when invoked by the wrong thread.
            return false;
        }

        private void Fault(string message, long timestamp)
        {
            _pending = null;
            _releaseOnRecovery = true;
            _observation = new GameObservation { Availability = BridgeAvailability.Faulted, GameTimestampMs = timestamp, Message = message, SupportedOperations = 0 };
            if (_lastRequestId != 0) _lastStatus = ControlStatus.Failed;
            _lastMessage = message; Publish();
        }

        private void Publish()
        {
            _sequence = ControlProtocol.NextSequence(_sequence);
            var snapshot = new ControlSnapshot { SessionId = _sessionId, Observation = _observation,
                LastRequestId = _lastRequestId, LastOperation = _lastOperation, LastStatus = _lastStatus,
                LastRequestContextId = _lastRequestContextId,
                LastMessage = _lastRequestId == 0 && !string.IsNullOrEmpty(_observation.Message) ? _observation.Message : _lastMessage,
                RequestHighWatermark = _highWatermark, PendingRequestId = _pending == null ? 0 : _pending.RequestId };
            byte[] encoded = ControlProtocol.EncodeSnapshot(snapshot, _sequence);
            ControlProtocol.PutUInt32(_state, ControlProtocol.CommitOffset, _sequence - 1);
            Thread.MemoryBarrier();
            Buffer.BlockCopy(encoded, 0, _state, 0, ControlProtocol.CommitOffset);
            Buffer.BlockCopy(encoded, ControlProtocol.CommitOffset + 4, _state, ControlProtocol.CommitOffset + 4, _state.Length - ControlProtocol.CommitOffset - 4);
            Thread.MemoryBarrier();
            ControlProtocol.PutUInt32(_state, ControlProtocol.CommitOffset, _sequence);
            Thread.MemoryBarrier();
        }
    }
}
