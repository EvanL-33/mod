using System;
using System.Collections.Generic;

namespace SevenDaysLoader;

// Settings only. Per-player annotations deliberately live in session memory:
// a game ID or a displayed name is not a persistent account identity.
public sealed class PlayerFeaturesSettings
{
    public bool OffscreenIndicators { get; set; }
    public bool OffscreenDistances { get; set; } = true;
    public bool AvoidLabelOverlap { get; set; } = true;
    public int MaximumOffscreenIndicators { get; set; } = 12;
    public bool ProximityAlerts { get; set; }
    public int AlertDistance { get; set; } = 50;
    public int AlertRearmMargin { get; set; } = 10;
    public int AlertCooldownSeconds { get; set; } = 15;
    public bool AlertsMarkedOnly { get; set; }
    public bool AlertSound { get; set; }
    public bool ShowPinnedCard { get; set; } = true;
    public bool ShowDistanceTrend { get; set; }
}

public readonly record struct PlayerIdentity(string ContextId, long Token, int EntityId)
{
    // Readers produce a random GUID, never a process address. Old packets have
    // no such identity and remain read-only rather than guessing by name/ID.
    public bool IsValid => Token > 0 && EntityId >= 0 && ContextId != null &&
        ContextId.Length <= 64 && Guid.TryParse(ContextId, out _);
}

public sealed record PlayerVisualState
{
    public bool Selected { get; init; }
    public bool Pinned { get; init; }
    public bool Marked { get; init; }
    public bool Hidden { get; init; }
    public string? Color { get; init; }
}

public enum PlayerDistanceTrendState
{
    Unknown,
    Approaching,
    Stable,
    Receding
}

// This is the rate of change of the distance between both players. It includes
// the local player's movement and is neither a target speed nor an intention.
// The default value deliberately means unknown, with no numeric estimate.
public readonly record struct PlayerDistanceTrend(
    PlayerDistanceTrendState State, double? RelativeMetersPerSecond);

public sealed record PlayerRow
{
    public PlayerIdentity Identity { get; init; }
    public string Name { get; init; } = string.Empty;
    public double DistanceMeters { get; init; }
    // Signed vertical difference from the local player, not inferred floor.
    public double HeightMeters { get; init; }
    public int? Health { get; init; }
    public int? MaxHealth { get; init; }
    public PlayerDistanceTrend DistanceTrend { get; init; }
    public PlayerVisualState Visual { get; init; } = new();
    public bool CanAnnotate => Identity.IsValid;
}

public sealed record PlayerProximityNotice
{
    public long Sequence { get; init; }
    public PlayerIdentity Identity { get; init; }
    public string Name { get; init; } = string.Empty;
    public double DistanceMeters { get; init; }
    public string Message { get; init; } = string.Empty;
    public bool PlaySound { get; init; }
}

public sealed record PlayerSessionSnapshot
{
    public long Revision { get; init; }
    public IReadOnlyList<PlayerRow> Rows { get; init; } = Array.Empty<PlayerRow>();
    public PlayerRow? Pinned { get; init; }
    public PlayerProximityNotice? Notice { get; init; }
    public bool HasCurrentData { get; init; }
}
