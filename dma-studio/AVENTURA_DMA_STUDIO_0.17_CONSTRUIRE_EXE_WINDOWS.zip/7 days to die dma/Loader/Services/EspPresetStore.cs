using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;

namespace SevenDaysLoader.Services;

public sealed record EspPresetLoadResult(IReadOnlyList<EspPreset> Presets, string Warning, long Revision);

public sealed class EspPresetStore
{
    public const int MaximumPresets = 32;
    public const int MaximumNameLength = 48;
    public const int MaximumImportBytes = 64 * 1024;
    public const int MaximumCatalogBytes = 256 * 1024;
    public const string ExportFormat = "SevenDaysEsp.Preset/1";
    public const string CatalogFormat = "SevenDaysEsp.PresetCatalog/1";
    private static readonly ConcurrentDictionary<string, SharedState> Shared = new(StringComparer.OrdinalIgnoreCase);
    private static readonly JsonSerializerOptions Json = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = false,
        WriteIndented = true,
        MaxDepth = 12,
        UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow
    };
    private static readonly string[] ProfileFields =
    {
        "enabled", "showBoxes", "showNames", "showHealth", "showDistances", "showTracers",
        "color", "boxStyle", "maxDistance", "fontSize", "lineThickness"
    };
    private readonly SharedState shared;
    public string DirectoryPath { get; }
    public string FilePath => Path.Combine(DirectoryPath, "esp-presets.json");
    public string BackupPath => Path.Combine(DirectoryPath, "esp-presets.backup.json");
    public string RejectedPath => Path.Combine(DirectoryPath, "esp-presets.invalid.json");
    public long Revision => Interlocked.Read(ref shared.Revision);

    public EspPresetStore(string settingsDirectory)
    {
        if (string.IsNullOrWhiteSpace(settingsDirectory)) throw new ArgumentException("Dossier des réglages absent.", nameof(settingsDirectory));
        DirectoryPath = Path.TrimEndingDirectorySeparator(Path.GetFullPath(settingsDirectory));
        shared = Shared.GetOrAdd(DirectoryPath, _ => new SharedState());
    }

    public EspPresetLoadResult Load()
    {
        lock (shared.Gate)
        {
            var loaded = ReadCurrent();
            Observe(loaded.Signature);
            return new EspPresetLoadResult(loaded.Catalog.Presets.Select(p => p.Copy()).ToArray(), loaded.Warning, shared.Revision);
        }
    }

    public EspPreset Create(string name, EspPresetOptions options)
    {
        string normalized = NormalizeName(name);
        var copy = CopyOptions(options);
        return Change(entries =>
        {
            RequireRoom(entries);
            RequireAvailableName(entries, normalized);
            var preset = new EspPreset { Name = normalized, Options = copy };
            entries.Add(preset);
            return preset.Copy();
        });
    }

    public EspPreset Replace(string id, EspPresetOptions options)
    {
        var copy = CopyOptions(options);
        return Change(entries =>
        {
            var preset = Find(entries, id);
            preset.Options = copy;
            return preset.Copy();
        });
    }

    public EspPreset Rename(string id, string name)
    {
        string normalized = NormalizeName(name);
        return Change(entries =>
        {
            var preset = Find(entries, id);
            RequireAvailableName(entries, normalized, id);
            preset.Name = normalized;
            return preset.Copy();
        });
    }

    public EspPreset Duplicate(string id, string? newName = null)
    {
        return Change(entries =>
        {
            RequireRoom(entries);
            var original = Find(entries, id);
            string name = string.IsNullOrWhiteSpace(newName)
                ? UniqueName(Shorten(original.Name, MaximumNameLength - 8) + " (copie)", entries)
                : NormalizeName(newName);
            RequireAvailableName(entries, name);
            var copy = new EspPreset { Name = name, Options = original.Options.Copy() };
            entries.Add(copy);
            return copy.Copy();
        });
    }

    public EspPreset Import(string path)
    {
        byte[] bytes = ReadBounded(path, MaximumImportBytes);
        var document = Parse<ExportDocument>(bytes, catalog: false);
        if (document.Format != ExportFormat) throw new InvalidDataException("Ce fichier n’est pas un préréglage ESP compatible.");
        string name = NormalizeName(document.Name);
        var options = CopyOptions(document.Options);
        return Change(entries =>
        {
            RequireRoom(entries);
            var preset = new EspPreset { Name = UniqueName(name, entries), Options = options };
            entries.Add(preset);
            return preset.Copy();
        });
    }

    public void Export(string id, string path)
    {
        string target = Path.GetFullPath(path);
        string[] protectedFiles =
        {
            FilePath, BackupPath, RejectedPath,
            Path.Combine(DirectoryPath, "loader-settings.json"),
            Path.Combine(DirectoryPath, "loader-settings.backup.json"),
            Path.Combine(DirectoryPath, "loader-settings.invalid.json")
        };
        if (protectedFiles.Any(file => string.Equals(target, file, StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("Choisis un autre fichier d’export : ce chemin contient des réglages du loader.");
        EspPreset preset;
        lock (shared.Gate)
        {
            var loaded = ReadCurrent();
            Observe(loaded.Signature);
            preset = Find(loaded.Catalog.Presets, id).Copy();
        }
        byte[] bytes = JsonSerializer.SerializeToUtf8Bytes(new ExportDocument { Name = preset.Name, Options = preset.Options }, Json);
        if (bytes.Length > MaximumImportBytes) throw new InvalidDataException("Le préréglage exporté dépasse la taille autorisée.");
        WriteAtomic(target, bytes, backup: null);
    }

    public static string NormalizeName(string? name)
    {
        if (name == null || name.Any(char.IsControl)) throw new InvalidDataException("Le nom du préréglage contient un caractère interdit.");
        string normalized = name.Normalize(NormalizationForm.FormC).Trim();
        if (normalized.Length == 0 || normalized.Length > MaximumNameLength)
            throw new InvalidDataException("Donne un nom de 1 à " + MaximumNameLength + " caractères au préréglage.");
        return normalized;
    }

    private T Change<T>(Func<List<EspPreset>, T> change)
    {
        lock (shared.Gate)
        {
            // Every panel reloads the current catalogue under the same path
            // gate before mutation. A stale UI list can never replace it whole.
            var loaded = ReadCurrent();
            Observe(loaded.Signature);
            var entries = loaded.Catalog.Presets.Select(p => p.Copy()).ToList();
            T result = change(entries);
            var document = new CatalogDocument { Presets = entries };
            ValidateCatalog(document);
            byte[] bytes = JsonSerializer.SerializeToUtf8Bytes(document, Json);
            if (bytes.Length > MaximumCatalogBytes) throw new InvalidDataException("Le catalogue dépasse la taille autorisée.");
            string? backup = null;
            if (File.Exists(FilePath))
            {
                try { ReadCatalog(FilePath); backup = BackupPath; }
                catch (InvalidDataException) { backup = RejectedPath; }
            }
            // Replacing a malformed primary archives it separately and leaves
            // the known-good backup untouched, including for oversized files.
            WriteAtomic(FilePath, bytes, backup);
            Observe("primary:" + Signature(bytes));
            return result;
        }
    }

    private LoadedCatalog ReadCurrent()
    {
        Exception? primaryError = null;
        if (File.Exists(FilePath))
        {
            try
            {
                var loaded = ReadCatalog(FilePath);
                return new LoadedCatalog(loaded.Catalog, "", "primary:" + loaded.Signature);
            }
            catch (Exception e) when (IsReadFailure(e)) { primaryError = e; }
        }
        if (File.Exists(BackupPath))
        {
            try
            {
                var loaded = ReadCatalog(BackupPath);
                string warning = primaryError == null
                    ? "Catalogue principal absent : préréglages récupérés depuis la sauvegarde précédente."
                    : "Catalogue principal illisible : préréglages récupérés depuis la sauvegarde précédente.";
                return new LoadedCatalog(loaded.Catalog, warning, "backup:" + loaded.Signature);
            }
            catch (Exception e) when (IsReadFailure(e))
            {
                throw new InvalidDataException("Le catalogue et sa sauvegarde sont illisibles. Aucun fichier de préréglages n’a été remplacé.", e);
            }
        }
        if (primaryError != null)
            throw new InvalidDataException("Le catalogue est illisible et aucune sauvegarde exploitable n’est disponible. Aucun préréglage n’a été remplacé.", primaryError);
        return new LoadedCatalog(new CatalogDocument { Presets = CreateExamples() },
            "Trois exemples disponibles. Aucun n’est appliqué automatiquement.", "examples/1");
    }

    private static LoadedCatalog ReadCatalog(string path)
    {
        byte[] bytes = ReadBounded(path, MaximumCatalogBytes);
        var document = Parse<CatalogDocument>(bytes, catalog: true);
        ValidateCatalog(document);
        return new LoadedCatalog(document, "", Signature(bytes));
    }

    private static void ValidateCatalog(CatalogDocument document)
    {
        if (document.Format != CatalogFormat || document.Presets == null)
            throw new InvalidDataException("Le format du catalogue de préréglages n’est pas reconnu.");
        if (document.Presets.Count > MaximumPresets) throw new InvalidDataException("Le catalogue contient trop de préréglages.");
        var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var ids = new HashSet<string>(StringComparer.Ordinal);
        foreach (var preset in document.Presets)
        {
            if (preset == null || preset.Id == null || !Guid.TryParseExact(preset.Id, "N", out _))
                throw new InvalidDataException("Un identifiant de préréglage est invalide.");
            preset.Id = preset.Id.ToLowerInvariant();
            preset.Name = NormalizeName(preset.Name);
            if (!names.Add(preset.Name) || !ids.Add(preset.Id))
                throw new InvalidDataException("Le catalogue contient des noms ou identifiants en double.");
            CopyOptions(preset.Options);
        }
    }

    private static T Parse<T>(byte[] bytes, bool catalog) where T : class
    {
        try
        {
            int bom = bytes.Length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF ? 3 : 0;
            using var document = JsonDocument.Parse(bytes.AsMemory(bom), new JsonDocumentOptions { MaxDepth = 12 });
            CheckUniqueProperties(document.RootElement);
            if (catalog)
            {
                if (document.RootElement.ValueKind != JsonValueKind.Object ||
                    !document.RootElement.TryGetProperty("presets", out var entries) || entries.ValueKind != JsonValueKind.Array)
                    throw new InvalidDataException("Le catalogue ne contient pas de liste de préréglages.");
                if (entries.GetArrayLength() > MaximumPresets) throw new InvalidDataException("Le catalogue contient trop de préréglages.");
                foreach (var entry in entries.EnumerateArray()) CheckProfileShape(entry);
            }
            else CheckProfileShape(document.RootElement);
            return document.RootElement.Deserialize<T>(Json) ?? throw new InvalidDataException("Le fichier de préréglages est vide.");
        }
        catch (JsonException e)
        {
            throw new InvalidDataException("Le JSON du préréglage est incomplet, mal formé ou contient des champs non pris en charge.", e);
        }
    }

    private static void CheckProfileShape(JsonElement preset)
    {
        if (preset.ValueKind != JsonValueKind.Object || !preset.TryGetProperty("options", out var options) || options.ValueKind != JsonValueKind.Object)
            throw new InvalidDataException("Les options ESP/radar du préréglage sont absentes.");
        foreach (string key in new[] { "playerEsp", "zombieEsp" })
        {
            if (!options.TryGetProperty(key, out var profile) || profile.ValueKind != JsonValueKind.Object ||
                ProfileFields.Any(field => !profile.TryGetProperty(field, out _)))
                throw new InvalidDataException("Le préréglage doit contenir deux profils complets, Joueurs et Zombies.");
        }
    }

    private static void CheckUniqueProperties(JsonElement element)
    {
        if (element.ValueKind == JsonValueKind.Object)
        {
            var names = new HashSet<string>(StringComparer.Ordinal);
            foreach (var property in element.EnumerateObject())
            {
                if (!names.Add(property.Name)) throw new InvalidDataException("Le fichier JSON contient une propriété en double.");
                CheckUniqueProperties(property.Value);
            }
        }
        else if (element.ValueKind == JsonValueKind.Array)
            foreach (var item in element.EnumerateArray()) CheckUniqueProperties(item);
    }

    private static byte[] ReadBounded(string path, int maximumBytes)
    {
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        if (stream.Length <= 0 || stream.Length > maximumBytes)
            throw new InvalidDataException("Le fichier JSON est vide ou dépasse " + maximumBytes / 1024 + " Kio.");
        using var output = new MemoryStream();
        byte[] buffer = new byte[4096];
        int remaining = maximumBytes + 1;
        while (remaining > 0)
        {
            int read = stream.Read(buffer, 0, Math.Min(buffer.Length, remaining));
            if (read == 0) break;
            output.Write(buffer, 0, read);
            remaining -= read;
        }
        if (output.Length > maximumBytes) throw new InvalidDataException("Le fichier dépasse la taille autorisée.");
        return output.ToArray();
    }

    private static void WriteAtomic(string target, byte[] bytes, string? backup)
    {
        string? directory = Path.GetDirectoryName(target);
        if (string.IsNullOrEmpty(directory)) throw new InvalidDataException("Dossier de destination invalide.");
        Directory.CreateDirectory(directory);
        string temporary = target + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                stream.Write(bytes);
                stream.Flush(flushToDisk: true);
            }
            if (File.Exists(target)) File.Replace(temporary, target, backup);
            else File.Move(temporary, target);
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }

    private void Observe(string signature)
    {
        if (shared.Signature == signature) return;
        shared.Signature = signature;
        shared.Revision++;
    }

    private static string Signature(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes));
    private static bool IsReadFailure(Exception e) => e is IOException or InvalidDataException or UnauthorizedAccessException or JsonException or ArgumentException;
    private static EspPresetOptions CopyOptions(EspPresetOptions? options) => options?.Copy()
        ?? throw new InvalidDataException("Les options du préréglage sont absentes.");
    private static EspPreset Find(IEnumerable<EspPreset> entries, string id) => entries.FirstOrDefault(p => p.Id == id)
        ?? throw new InvalidOperationException("Ce préréglage n’existe plus. Actualise la liste.");
    private static void RequireRoom(ICollection<EspPreset> entries)
    {
        if (entries.Count >= MaximumPresets) throw new InvalidOperationException("Le catalogue est limité à " + MaximumPresets + " préréglages. Mets à jour une entrée existante.");
    }
    private static void RequireAvailableName(IEnumerable<EspPreset> entries, string name, string? exceptId = null)
    {
        if (entries.Any(p => p.Id != exceptId && string.Equals(p.Name, name, StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("Ce nom est déjà utilisé. Choisis un autre nom ou mets à jour la sélection.");
    }
    private static string UniqueName(string name, IEnumerable<EspPreset> entries)
    {
        var used = entries.Select(p => p.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
        string candidate = NormalizeName(name);
        for (int n = 2; used.Contains(candidate); n++)
        {
            string suffix = " (" + n + ")";
            candidate = Shorten(name, MaximumNameLength - suffix.Length).TrimEnd() + suffix;
        }
        return candidate;
    }
    private static string Shorten(string text, int maximum)
    {
        if (text.Length <= maximum) return text;
        if (maximum > 0 && char.IsHighSurrogate(text[maximum - 1])) maximum--;
        return text[..maximum];
    }

    private static List<EspPreset> CreateExamples()
    {
        // Stable IDs: these entries may be selected before the first catalogue
        // write, then reloaded inside a later mutation from another panel.
        var exploration = new EspPreset
        {
            Id = "00000000000000000000000000000001", Name = "Exploration", Options = new EspPresetOptions()
        };
        exploration.Options.PlayerEsp.MaxDistance = 600;
        exploration.Options.ZombieEsp.MaxDistance = 250;
        exploration.Options.ZombieEsp.ShowHealth = false;
        var horde = new EspPreset
        {
            Id = "00000000000000000000000000000002", Name = "Horde", Options = new EspPresetOptions()
        };
        horde.Options.ZombieEsp.MaxDistance = 150;
        horde.Options.ZombieEsp.ShowNames = false;
        horde.Options.ZombieEsp.ShowDistances = false;
        horde.Options.ZombieEsp.BoxStyle = "corners";
        var minimal = new EspPreset
        {
            Id = "00000000000000000000000000000003", Name = "Minimal", Options = new EspPresetOptions { ShowRadar = false, ShowHud = false }
        };
        minimal.Options.PlayerEsp.ShowNames = minimal.Options.ZombieEsp.ShowNames = false;
        minimal.Options.PlayerEsp.ShowHealth = minimal.Options.ZombieEsp.ShowHealth = false;
        minimal.Options.PlayerEsp.BoxStyle = minimal.Options.ZombieEsp.BoxStyle = "corners";
        minimal.Options.ZombieEsp.MaxDistance = 100;
        return new List<EspPreset> { exploration, horde, minimal };
    }

    private sealed class SharedState
    {
        internal readonly object Gate = new();
        internal long Revision;
        internal string Signature = "";
    }
    private sealed record LoadedCatalog(CatalogDocument Catalog, string Warning, string Signature);
    private sealed class CatalogDocument
    {
        public CatalogDocument() { }
        [JsonRequired] public string Format { get; set; } = CatalogFormat;
        [JsonRequired] public List<EspPreset> Presets { get; set; } = new();
    }
    private sealed class ExportDocument
    {
        public ExportDocument() { }
        [JsonRequired] public string Format { get; set; } = ExportFormat;
        [JsonRequired] public string Name { get; set; } = "";
        [JsonRequired] public EspPresetOptions Options { get; set; } = new();
    }
}
