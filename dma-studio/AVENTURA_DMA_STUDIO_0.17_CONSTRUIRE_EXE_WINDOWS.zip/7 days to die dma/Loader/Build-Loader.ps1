﻿#requires -Version 5.1
[CmdletBinding()]
param([string]$OutputDirectory = (Join-Path $PSScriptRoot 'publish'))

$ErrorActionPreference = 'Stop'
$project = Join-Path $PSScriptRoot '7DTD-Loader.csproj'
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw 'Installe le SDK .NET 10 x64 pour recompiler. Le .exe fourni fonctionne sans SDK.'
}
& dotnet publish $project -c Release -r win-x64 --self-contained true -o $OutputDirectory --nologo
if ($LASTEXITCODE -ne 0) { throw ('Compilation échouée, code ' + $LASTEXITCODE) }
Write-Host ('Exécutable créé : ' + (Join-Path $OutputDirectory '7DTD-Loader.exe'))
