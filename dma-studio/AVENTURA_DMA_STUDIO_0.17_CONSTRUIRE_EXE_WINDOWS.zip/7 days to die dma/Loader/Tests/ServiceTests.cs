using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using SevenDaysEsp;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class ServiceTests
{
    private static int passed;
    private static int failed;
    private static readonly TimeSpan Deadline = TimeSpan.FromSeconds(15);

    public static async Task<int> Main()
    {
        await Test("0.16: measured yaw is not mistaken for aiming", PvpSenseTests.OrientationMeasuresBodyDirectionOnly);
        await Test("0.16: optional PvP labels never invent values", PvpSenseTests.LabelsNeverInventWeaponOrTarget);
        await Test("0.16: opt-in fields roundtrip to the reader and normalize", PvpSenseTests.SettingsAreOptInAndBounded);
        await Test("0.14: admin watch requires explicit exact listed name", AdminWatchTests.NamesAreExplicitAndNeverInferAdminRole);
        await Test("0.15: DMA-only stats reject unsupported, non-finite and fractional values", PlayerDmaStatTests.ExplicitValidatedOperations);
        await Test("0.15: DMA-only stat intents consume once and cannot replay", PlayerDmaStatTests.NoReplayAndSinglePending);
        await Test("0.13: commands require progressing module and current local feed", PlayerControlTests.RequiresFreshModuleAndCurrentLocalFeed);
        await Test("0.13: transmission is not execution and module result is correlated", PlayerControlTests.TransmissionIsNotExecutionAndAckIsCorrelated);
        await Test("0.13: corruption context and generation cannot reuse an intent", PlayerControlTests.ContextGenerationAndCorruptionCannotReuseIntent);
        await Test("0.13: bounded commands expire without implicit replay", PlayerControlTests.CommandsHaveBoundedValuesAndNoImplicitReplay);
        await Test("0.13: recent refusal survives old ack and read gaps cannot conceal context change", PlayerControlTests.RefusalSurvivesOldAckAndContextChangeAfterReadGap);
        await Test("0.13: binary state survives pipe and inbox consumes once", PlayerControlTests.WireKeepsBinaryStateAndInboxConsumesOnce);
        await Test("0.13: executor binds player identity deadline and native result", PlayerControlTests.ExecutorBindsIdentityExpiryAndNativeResult);
        await Test("0.13: unstarted host cannot queue controls", PlayerControlTests.HostCannotQueueControlsBeforeStartup);
        await Test("0.13: installer preserves previous version and foreign files", PlayerControlTests.InstallerPreservesOldVersionAndRefusesForeignFiles);
        await Test("creative query and idempotent actions perform no memory write", CreativeMenuAccessTests.QueryAndIdempotentRequestsNeverWrite);
        await Test("creative action replaces only its slot without changing shared defaults", CreativeMenuAccessTests.OnlyCreativeSlotChangesAndSharedDefaultsStayImmutable);
        await Test("creative action can replace a private box without mutating its value", CreativeMenuAccessTests.CurrentUnsharedBoxCanBeReplacedWithoutMutatingIt);
        await Test("sandbox overrides null slots and invalid Boolean data refuse creative writes", CreativeMenuAccessTests.SandboxNullAndInvalidValuesRefuseBeforeWrite);
        await Test("wrong game version PID or context never writes creative data", CreativeMenuAccessTests.WrongVersionPidAndContextNeverWrite);
        await Test("changed worlds and rejected captures invalidate creative write context", CreativeMenuAccessTests.ChangedWorldAndRejectedCapturesInvalidateMenuContext);
        await Test("preferences changing during creative validation prevent writes", CreativeMenuAccessTests.PreferencesChangingDuringValidationRefuseWrite);
        await Test("the final creative slot comparison rejects a concurrent preference change", CreativeMenuAccessTests.LastSlotCompareRefusesConcurrentPreferenceChange);
        await Test("native creative failure and failed readback never trigger retries", CreativeMenuAccessTests.NativeRefusalAndPostWriteReadFailureNeverRetry);
        await Test("a world change after creative write stays unconfirmed without restoring an old pointer", CreativeMenuAccessTests.PostWriteWorldChangeIsUnconfirmedWithoutRestore);
        await Test("creative cancellation before and after the native write remains distinct", CreativeMenuAccessTests.CancellationBeforeNativeWriteAndAfterWriteAreDistinct);
        await Test("a read-only memory source can inspect but cannot change the creative option", CreativeMenuAccessTests.ReadOnlySourceCanQueryButCannotChange);
        await Test("an expired creative context requires a new entity capture", CreativeMenuAccessTests.ExpiredContextRequiresNewCapture);
        await Test("slow creative validation reserves readback time before any write", CreativeMenuAccessTests.SlowValidationReservesTimeForReadbackBeforeWriting);
        await Test("ordinary Mono array alignment bytes are not part of the creative array length", CreativeMenuAccessTests.ArrayLengthPaddingDoesNotChangeLengthOrGetOverwritten);
        await Test("creative inbox copies and consumes once while rejecting replay", CreativeMenuControlTests.MailboxCopiesConsumesAndRejectsReplay);
        await Test("creative requests have strict identities and monotonic deadlines", CreativeMenuControlTests.RequestValidationAndMonotonicExpiry);
        await Test("duplex creative commands remain separate from optional read preferences", CreativeMenuControlTests.DuplexCommandsRemainSeparateFromReadOptions);
        await Test("mixed or malformed creative commands close without retained intent", CreativeMenuControlTests.InvalidAndMixedCommandsCloseWithoutQueuedIntent);
        await Test("worker stop discards the pending creative command", CreativeMenuControlTests.StopDiscardsPendingWithoutExecution);
        await Test("creative UI uses a fresh local context without changing the ESP feed", CreativeMenuControlTests.SessionUsesFreshLocalContextAndDoesNotMutateFeed);
        await Test("creative results from another request or generation are ignored", CreativeMenuControlTests.SessionRejectsMismatchedAndPriorGenerationResults);
        await Test("context loss cannot confirm a creative result for a prior party", CreativeMenuControlTests.ContextLossPreservesPendingButCannotConfirmOldParties);
        await Test("creative timeouts remain unknown and never replay commands", CreativeMenuControlTests.TimeoutIsUnknownAndNeverReplays);
        await Test("failed creative sends never assert rollback or accept other requests", CreativeMenuControlTests.FailedSendDoesNotAssertRollbackOrAcceptOtherRequests);
        await Test("malformed creative results cannot publish confirmed flags", CreativeMenuControlTests.InvalidResultsCannotPublishConfirmedFlags);
        await Test("contradictory creative results cannot confirm an option", CreativeMenuControlTests.ContradictoryResultsNeverConfirmStates);
        await Test("creative intents are not queued without a local worker", CreativeMenuControlTests.HostDoesNotQueueIntentsWithoutLocalWorker);
        await Test("eligible creative action runs once with exact result correlation", CreativeMenuExecutorTests.EligibleCommandRunsOnceAndPreservesCorrelation);
        await Test("expired future or other-process creative actions cannot reach memory", CreativeMenuExecutorTests.ExpiredFutureAndOtherProcessesNeverReachMemory);
        await Test("game version capture age and world identity gate creative actions", CreativeMenuExecutorTests.VersionCaptureAgeAndWorldGateTheAction);
        await Test("process loss during validation prevents the creative action", CreativeMenuExecutorTests.AProcessLostDuringValidationCannotWrite);
        await Test("uncertain creative writes are not retried or presented as confirmed", CreativeMenuExecutorTests.UncertainWriteIsNotRetriedOrShownAsConfirmed);
        await Test("creative refresh carries no write intent", CreativeMenuExecutorTests.RefreshRequestsReturnAnObservationWithoutWriteIntent);
        await Test("framing roundtrip survives fragmented reads", FramingRoundtrip);
        await Test("framing rejects zero/negative/oversized length", FramingBounds);
        await Test("framing rejects truncated and invalid JSON payload", FramingInvalid);
        await Test("framing honors cancellation for stalled peer", FramingCancellation);
        await Test("freshness is monotonic and ignores remote UTC", Freshness);
        await Test("invalid entity snapshots are not fresh", InvalidSnapshots);
        await Test("live reader traverses a valid Mono world and entity collection", LiveReaderTests.ValidGraph);
        await Test("a game not started cannot publish positions despite a coherent graph", LiveReaderTests.GameNotStartedDiagnosesOnly);
        await Test("worldCreated zero needs three coherent captures before display", LiveReaderTests.WorldCreatedZeroNeedsRepeatedValidGraph);
        await Test("a rejected capture resets worldCreated zero confirmation", LiveReaderTests.RejectedCaptureResetsConfirmation);
        await Test("world and player identity changes reset readiness confirmation", LiveReaderTests.IdentityChangesResetConfirmation);
        await Test("readiness confirmation expires when captures stop", LiveReaderTests.ConfirmationRequiresRecentCaptures);
        await Test("movement and collection replacement preserve scene confirmation", LiveReaderTests.CollectionAndMovementDoNotResetConfirmation);
        await Test("normal worldCreated path clears fallback confirmation history", LiveReaderTests.TrueWorldFlagDoesNotReuseFallbackConfirmation);
        await Test("invalid game flag bytes cannot publish positions", LiveReaderTests.InvalidFlagsReject);
        await Test("null and inconsistent world/local references cannot publish positions", LiveReaderTests.InvalidReferencesReject);
        await Test("inactive and incorrectly typed local players cannot publish positions", LiveReaderTests.InactiveLocalReject);
        await Test("invalid entity collection cannot publish positions", LiveReaderTests.InvalidCollectionReject);
        await Test("live capture clears failed output and recovers from valid memory", LiveReaderTests.StateResetAndRecovery);
        await Test("game flags changing during capture cannot publish positions", LiveReaderTests.FlagsChangingDuringCaptureReject);
        await Test("camera probe targets six fields without reading 214 unrelated sparse names", CameraProbeTests.SparseLocalFieldsStayBounded);
        await Test("camera probe retains partial metadata at the per-target budget", CameraProbeTests.PartialMetadataSurvivesTargetLimit);
        await Test("camera probe invalidates native pointers when object identity changes", CameraProbeTests.WrongIdentityInvalidatesPointers);
        await Test("managed camera matrices remain unvalidated projection candidates", CameraProbeTests.ManagedMatrixRemainsCandidate);
        await Test("native camera verifies the exact profile and canonical P times V", NativeCameraTests.ExactProfileAndProjection);
        await Test("grouped presentation descriptors and aliased types stay live and fully validated", NativeCameraTests.GroupedPresentationMetadataRemainsLiveAndValidated);
        await Test("grouped presentation reads respect page and span bounds and reject partial data", NativeCameraTests.GroupedPresentationReadsRespectBoundsAndRejectShortData);
        await Test("runtime registrations retain every domain slot and current class pointers", NativeCameraTests.RuntimeRegistrationReadsAllSlotsAndCurrentHeaders);
        await Test("partial runtime headers and suffixes cannot publish a camera", NativeCameraTests.RuntimeHeaderAndSuffixShortReadsFailClosed);
        await Test("changed native executable signatures cannot produce a camera", NativeCameraTests.ProfileMismatchFailsClosed);
        await Test("transient profile IO recovers only through explicit initialization outside capture", NativeCameraTests.InitializationReadFailureRecoversOnlyOutsideCapture);
        await Test("persistent initialization IO respects cooldown after each completed attempt", NativeCameraTests.PersistentInitializationReadsRespectCompletionCooldown);
        await Test("an exhausted initialization budget can recover on a later bounded attempt", NativeCameraTests.InitializationBudgetFailureCanRecover);
        await Test("retried initialization revalidates earlier code and never retries a binary mismatch", NativeCameraTests.RetriedInitializationRevalidatesEarlierCodeAndRejectsMismatch);
        await Test("a null XR manager never requires permanently unreadable unused code", NativeCameraTests.ColdUnusedXrCodeDoesNotBlockProjection);
        await Test("existing and newly appearing XR managers require verified code and stable references", NativeCameraTests.XrManagerRequiresVerifiedGetterAndStableReferences);
        await Test("native camera rejects invalid Mono metadata and object identity", NativeCameraTests.MetadataAndIdentityRejected);
        await Test("unsupported native rendering paths cannot project", NativeCameraTests.UnsupportedRenderingPathsRejected);
        await Test("supported native engine flags preserve usable cameras", NativeCameraTests.SupportedEngineFlagsRemainUsable);
        await Test("native camera rejects invalid matrices dimensions and clips", NativeCameraTests.InvalidMatricesDimensionsAndClipsRejected);
        await Test("native camera rejects capture instability", NativeCameraTests.CaptureInstabilityRejected);
        await Test("native camera requires rendered frame advancement and expires frozen output", NativeCameraTests.RenderedFrameConfirmationAndExpiry);
        await Test("native camera context changes require a new epoch", NativeCameraTests.ContextChangesRequireNewEpoch);
        await Test("normal camera movement between metadata reads does not invalidate a coherent matrix pair", NativeCameraTests.NormalMotionBetweenMetadataReadsIsAccepted);
        await Test("native camera configuration changes outside the paired blocks do not invalidate a coherent capture", NativeCameraTests.NativeConfigurationOutsidePairDoesNotInvalidateCapture);
        await Test("native camera mode and orthographic changes inside paired blocks are rejected with precise diagnostics", NativeCameraTests.PairedConfigurationChangesArePreciselyDiagnosed);
        await Test("a dirty projection cache in either native block prevents publication", NativeCameraTests.DirtyEitherNativeBlockIsRejected);
        await Test("FSR3 and DLSS keep a stable final viewport across internal rendering phases", NativeCameraTests.UpscalerUsesSavedPresentationAcrossNativePhases);
        await Test("real upscaler presentation context changes still require render confirmation", NativeCameraTests.UpscalerContextChangesStillRequireConfirmation);
        await Test("upscaler publication requires the verified owner camera domain and mode", NativeCameraTests.UpscalerOwnershipAndModesAreRequired);
        await Test("changing postprocess graphs cannot publish a camera from an earlier state", NativeCameraTests.UpscalerGraphChangesDuringCaptureAreRejected);
        await Test("invalid saved presentation or non-jittered matrices cannot project", NativeCameraTests.UpscalerRejectsInvalidPresentationAndNonJitteredData);
        await Test("ordinary rendering preserves its native viewport and projection guards", NativeCameraTests.NativeRenderingKeepsItsOwnViewportAndProjection);
        await Test("a disabled or destroyed postprocess component cannot reuse stale upscaler state", NativeCameraTests.DisabledPostProcessingCannotReuseUpscalerState);
        await Test("live bounds follow current metadata without extra entity reads", LiveReaderTests.CollisionBoundsUseCurrentMetadata);
        await Test("missing or invalid collision bounds preserve radar data", LiveReaderTests.UnavailableBoundsPreserveRadar);
        await Test("health follows current Stat metadata and the effective modified maximum", LiveReaderTests.HealthUsesEffectiveStatValuesAndCurrentMetadata);
        await Test("missing or invalid health preserves valid entity and camera captures", LiveReaderTests.UnavailableHealthPreservesEntitiesAndCamera);
        await Test("changing health ownership and values discard only optional metadata", LiveReaderTests.ChangingHealthGraphDiscardsOnlyOptionalValues);
        await Test("zombie names prefer the live name and otherwise use the validated class registry", LiveReaderTests.ZombieNamesUseCurrentNameThenValidatedClassRegistry);
        await Test("invalid or changing zombie class registries never remove valid entities", LiveReaderTests.InvalidClassRegistryNeverRemovesEntities);
        await Test("optional detail budgets preserve the camera and world capture", LiveReaderTests.OptionalDetailBudgetsLeaveCameraAndWorldAvailable);
        await Test("camera callback observes the current world and a copied origin", LiveReaderTests.CameraCaptureUsesCurrentGraph);
        await Test("camera failure does not remove valid radar entities", LiveReaderTests.CameraFailurePreservesRadar);
        await Test("rejected world clears camera and render origin", LiveReaderTests.RejectedGraphClearsCameraAndOrigin);
        await Test("projection maps a known perspective into an offset viewport", ProjectionTests.KnownPerspectiveAndViewport);
        await Test("projection subtracts origin exactly once and owns its inputs", ProjectionTests.OriginIsAppliedOnceAndInputsAreCopied);
        await Test("projection clips near far and side planes with explicit depth convention", ProjectionTests.ClipPlanesAndDepthRanges);
        await Test("real collision bounds are clipped across the near plane", ProjectionTests.ActualBoundsAndNearPlaneClipping);
        await Test("invalid projection views and bounds cannot draw", ProjectionTests.InvalidViewsAndBoundsAreRejected);
        await Test("projected frames use actual entities and never invent bounds", ProjectionTests.FrameUsesActualEntitiesWithoutInventedBounds);
        await Test("invalid entity frames cannot publish projected markers", ProjectionTests.InvalidEntityFramesCannotPublish);
        await Test("output mapping scales known positions and boxes across matching aspect ratios", ProjectionOutputMappingTests.SameAspectResolutionsPreservePositionsAndBoxes);
        await Test("output mapping fits ultrawide and portrait images without distortion", ProjectionOutputMappingTests.FitPreservesAspectAcrossUltrawideAndPortraitOutputs);
        await Test("output mapping supports centered crop and independent-axis stretch", ProjectionOutputMappingTests.FillCropsAndStretchMapsEachAxis);
        await Test("output mapping preserves the position of a partial camera viewport", ProjectionOutputMappingTests.CameraSubViewportKeepsItsPlaceWithinTheImage);
        await Test("cropped markers do not acquire labels at the output edge", ProjectionOutputMappingTests.CropVisibilityDoesNotPinOffscreenMarkersToTheEdge);
        await Test("output mapping rejects invalid dimensions modes and geometry", ProjectionOutputMappingTests.InvalidMappingsAndNonFiniteGeometryAreRejected);
        await Test("health metadata remains optional across the live frame wire contract", EntityHealthContractTests.OptionalHealthRoundtrip);
        await Test("projection copies real health and normalizes only invalid optional values", EntityHealthContractTests.ProjectionPreservesHealthAndUnknownValues);
        await Test("projection freshness is shorter and independent of radar validity", ProjectionFeedFreshness);
        await Test("the reported native camera and partial viewport remain mathematically projectable", ReportedCameraProjection);
        await Test("alternating camera captures keep a readable menu summary", MenuStatusPresenterTests.AlternatingCapturesKeepReadableSummary);
        await Test("a sustained menu status updates after settling", MenuStatusPresenterTests.SustainedStateUpdatesAfterSettling);
        await Test("explicit configuration changes update the menu immediately", MenuStatusPresenterTests.ConfigurationChangesAppearImmediately);
        await Test("menu summary stabilization preserves the complete current diagnostic", MenuStatusPresenterTests.FullCurrentDiagnosticIsPreserved);
        await Test("menu settling restarts after a clock rollback", MenuStatusPresenterTests.ClockRollbackRestartsPendingObservation);
        await Test("diagnostic automatic updates are limited to one per second", DiagnosticReadoutTests.AutomaticUpdatesAreRateLimited);
        await Test("diagnostic pause and reading protection preserve the displayed snapshot", DiagnosticReadoutTests.PauseAndSelectionPreserveTheReadout);
        await Test("last camera dimensions survive intermittence but reset with the session", DiagnosticReadoutTests.LastSourceSurvivesIntermittenceOnlyWithinItsSession);
        await Test("diagnostic manual refresh and clock rollback do not stall future updates", DiagnosticReadoutTests.ClockRollbackAndManualRefreshDoNotStallUpdates);
        await Test("a burst of frame notifications publishes the latest state in one pending UI callback", CoalescedRefreshTests.BurstUsesLatestState);
        await Test("frame notifications arriving during publication are not lost", CoalescedRefreshTests.RequestDuringRefreshIsNotLost);
        await Test("closing the UI cancels pending projection publication", CoalescedRefreshTests.ClosingCancelsPendingWork);
        await Test("failed UI posts and refresh callbacks do not stall later publications", CoalescedRefreshTests.PostingFailureCanRecover);
        await Test("capture cadence waits only for the requested period and never adds delay after overrun", CaptureCadenceTests.RequestedPeriodDoesNotAddDelayAfterOverrun);
        await Test("the faster default cadence migrates once and preserves other user choices", CaptureCadenceTests.CadenceMigrationIsOneTimeAndPreservesOtherChoices);
        await Test("optional detail requests follow independently enabled player and zombie views", ReadPolicyHotkeyTests.OptionalDetailsFollowIndependentViews);
        await Test("radar retains names without requesting unused health while master visibility controls both", ReadPolicyHotkeyTests.RadarKeepsNamesButDoesNotRequestHealth);
        await Test("sharing keeps optional data for remote profiles without changing local preferences", ReadPolicyHotkeyTests.SharingPreservesRemoteDetailsWithoutChangingLocalPreferences);
        await Test("existing menu and master shortcuts take precedence over new optional defaults", ReadPolicyHotkeyTests.ExistingHotkeysWinOverNewOptionalDefaults);
        await Test("disabled custom and conflicting shortcuts normalize and roundtrip safely", ReadPolicyHotkeyTests.DisabledAndConflictingHotkeysRoundtripSafely);
        await Test("disabled optional details do not read their auxiliary memory graphs", LiveReadOptionsTests.DisabledDetailsDoNotReadTheirGraphs);
        await Test("live read switches preserve category and detail independence", LiveReadOptionsTests.CategoriesAndDetailsRemainIndependent);
        await Test("read options apply between captures and reenabling reads fresh values", LiveReadOptionsTests.UpdatesWaitForTheNextCaptureAndReadFreshValues);
        await Test("disabled optional reads cannot bypass world and entity identity checks", LiveReadOptionsTests.DisabledDetailsDoNotBypassIdentityChecks);
        await Test("control mailboxes own copies and retain only the latest preferences", LiveReadOptionsTests.MailboxesKeepOnlyCopiedLatestPreferences);
        await Test("duplex worker control accepts multiple revisions before explicit stop", LiveReadOptionsTests.DuplexControlRemainsOpenUntilStop);
        await Test("invalid worker controls close the channel with an explicit failure", LiveReadOptionsTests.InvalidControlClosesCleanly);
        await Test("option changes racing ordinary worker shutdown do not throw", LiveReadOptionsTests.UpdatesDuringShutdownDoNotThrow);
        await Test("render telemetry deduplicates redraws and capture retransmissions", RenderPerformanceTests.DistinctReceiptsAndRetransmissionsCountOnce);
        await Test("render percentiles preserve the original monotonic receipt timestamps", RenderPerformanceTests.PercentilesUseOriginalMonotonicReceiptTimes);
        await Test("only accepted fresh cameras enter projection performance observations", RenderPerformanceTests.OnlyAcceptedFreshCamerasEnterProjectionMetrics);
        await Test("render telemetry respects the strict projection deadline without rejuvenation", RenderPerformanceTests.ProjectionDeadlineIsStrictAndCannotBeRejuvenated);
        await Test("unavailable camera transitions invalidate pending render telemetry tokens", RenderPerformanceTests.UnavailableTransitionsInvalidatePendingTokens);
        await Test("recent performance windows expire without inventing zero latencies", RenderPerformanceTests.SlidingWindowExpiresMeasuresWithoutInventingZeros);
        await Test("performance resets reject tokens from old generations and mismatched captures", RenderPerformanceTests.ResetRejectsOldGenerationsAndMismatchedTokens);
        await Test("performance storage remains bounded and reports truncated windows", RenderPerformanceTests.StorageIsBoundedAndTruncationIsVisible);
        await Test("concurrent performance observations return coherent bounded snapshots", RenderPerformanceTests.ConcurrentObserversReturnCoherentSnapshots);
        await Test("presets own independent profile copies and preserve connection output and keyboard settings", EspPresetTests.CapturesAndApplicationsOwnTheirProfilesAndPreserveTheEnvironment);
        await Test("invalid preset options cannot partially apply or replace a saved entry", EspPresetTests.InvalidOptionsNeverPartiallyApplyOrReplaceAnEntry);
        await Test("preset examples keep stable identities without writing or applying at startup", EspPresetTests.ExamplesKeepStableIdsWithoutWritingOrApplyingAtStartup);
        await Test("preset save rename duplicate and replace persist without coupling entries", EspPresetTests.SaveRenameDuplicateAndReplaceRoundTripWithoutCoupling);
        await Test("preset import and export contain only display choices and preserve the original entry", EspPresetTests.ExportAndImportContainOnlyDisplayChoicesAndNeverOverwriteTheOriginal);
        await Test("malformed foreign incomplete duplicate and oversized preset imports leave the catalogue unchanged", EspPresetTests.MalformedForeignIncompleteAndOversizedImportsAreRejectedWithoutMutation);
        await Test("preset names and catalogue capacity are bounded without replacing unrelated entries", EspPresetTests.NamesAndMaximumCountAreEnforcedWithoutReplacingOtherEntries);
        await Test("corrupt preset catalogues recover their backup and preserve rejected bytes during repair", EspPresetTests.CorruptPrimaryRecoversItsBackupAndArchivesTheRejectedFile);
        await Test("unreadable preset catalogues remain intact while oversized primaries can recover", EspPresetTests.UnreadableCataloguesArePreservedAndAnOversizedPrimaryCanRecover);
        await Test("separate preset stores serialize updates and publish only actual revisions", EspPresetTests.SharedStoresSerializeMutationsAndOnlyPublishRealRevisionChanges);
        await Test("settings normalize and atomically persist", SettingsPersistence);
        await Test("legacy JSON migrates to separate ESP profiles without changing visibility or output", EspProfileTests.LegacyFileMigratesWithoutChangingVisibilityOrOutput);
        await Test("player and zombie profiles persist independent edits through real settings roundtrips", EspProfileTests.ProfileRoundtripsKeepCategoriesIndependent);
        await Test("ESP profile migration runs once and ignores stale legacy fields afterward", EspProfileTests.MigrationRunsOnceAndIgnoresStaleLegacyFields);
        await Test("null and aliased ESP profiles recover without coupling category preferences", EspProfileTests.NullAndSharedProfilesRecoverWithoutCoupling);
        await Test("invalid ESP colors styles and sizes are normalized before serialization", EspProfileTests.InvalidValuesAreNormalizedBeforePersistence);
        await Test("ESP category activation and distance filters remain independent", EspProfileTests.CategoryAndDistanceFiltersAreIndependent);
        await Test("empty projected profiles retain radar visibility and each drawing feature works alone", EspProfileTests.EmptyProjectedProfilesKeepIndependentRadarVisibility);
        await Test("radar scale follows only the farthest enabled category", EspProfileTests.RadarRangeUsesOnlyActiveCategories);
        await Test("projected labels share a bounded budget fairly between categories using only the current capture", EspProfileTests.ProjectedLabelBudgetIsFairBoundedAndCurrent);
        await Test("projection scale settings migrate and persist with invalid values normalized", ProjectionScaleSettingsPersistence);
        await Test("fuser settings persist while the test pattern stays session only", FuserSettingsPersistence);
        await Test("settings migrate only legacy SDK without editing original", SettingsMigration);
        await Test("settings recover from corrupt, null, oversized files", SettingsRecovery);
        await Test("settings replacement preserves the preceding valid file as backup", SettingsRecoveryTests.ValidReplacementKeepsThePreviousSettings);
        await Test("corrupt primary settings recover independent profiles and retain rejected bytes on repair", SettingsRecoveryTests.CorruptPrimaryRecoversIndependentProfilesAndPreservesEvidence);
        await Test("two unreadable settings files return normalized defaults while preserving both originals", SettingsRecoveryTests.TwoUnreadableFilesReturnNormalizedDefaultsWithoutDeletingEither);
        await Test("concurrent saves on one settings store remain complete and the final explicit save wins", SettingsRecoveryTests.ConcurrentSavesOnOneStoreStayCompleteAndLastExplicitSaveWins);
        await Test("SDK lookup preserves preferred complete installation", SdkPreferred);
        await Test("SDK lookup falls back only to known complete folders", SdkFallback);
        await Test("SDK lookup handles invalid paths without recursive search", SdkBoundedLookup);
        await Test("auto-connect migration preserves explicit user settings", AutoConnectMigration);
        await Test("pairing rejects public hosts and malformed credentials", PairingValidation);
        await Test("TLS pairing rejects wrong certificate and token", PairingRejection);
        await Test("TLS stream sends valid data then clears stale/invalid input", LiveLink);
        await Test("TLS receiver derives projection capability from current camera data", LiveProjectionLink);
        await Test("TLS client ignores contradictory projection flags and rejects mismatched responses", InvalidRemoteResponse);
        await Test("players: old settings use quiet defaults", PlayerFeatureIntegrationTests.OldSettingsUseQuietDefaults);
        await Test("players: feature options are bounded without resetting preferences", PlayerFeatureIntegrationTests.FeatureOptionsAreBoundedWithoutResettingPreferences);
        await Test("players: feature preferences roundtrip with independent profiles", PlayerFeatureIntegrationTests.FeaturePreferencesRoundtripWithIndependentProfiles);
        await Test("players: details consumer requires only player details", PlayerFeatureIntegrationTests.DetailsConsumerRequiresOnlyPlayerDetails);
        await Test("players: notice sounds are consumed once including muted periods", PlayerFeatureIntegrationTests.NoticeSoundsAreConsumedOnceIncludingMutedPeriods);
        await Test("players: actions bind to current opaque instances and stay session only", PlayerSessionTests.ActionsBindToCurrentOpaqueInstancesAndStaySessionOnly);
        await Test("players: accepted absence context and generation break continuity", PlayerSessionTests.AcceptedAbsenceContextAndGenerationBreakContinuity);
        await Test("players: short gaps retain annotations but expiry and replay cannot revive them", PlayerSessionTests.ShortGapsRetainAnnotationsButExpiryAndReplayCannotReviveThem);
        await Test("players: snapshot copies and preference events remain safe", PlayerSessionTests.SnapshotCopiesAndPreferenceEventsRemainSafe);
        await Test("players: alerts require two distinct fresh captures without camera", PlayerSessionTests.AlertsRequireTwoDistinctFreshCapturesWithoutCamera);
        await Test("players: preference changes immediately clear notices and partial confirmations", PlayerSessionTests.PreferenceChangesImmediatelyClearNoticeAndPartialConfirmation);
        await Test("players: proximity uses3d distance hysteresis and per player cooldown", PlayerSessionTests.ProximityUses3dDistanceHysteresisAndPerPlayerCooldown);
        await Test("players: unavailable hidden marked and disabled states suppress alerts", PlayerSessionTests.UnavailableHiddenMarkedAndDisabledStatesSuppressAlerts);
        await Test("players: global cooldown bounds notices and sequence survives reset", PlayerSessionTests.GlobalCooldownBoundsNoticesAndSequenceSurvivesReset);
        await Test("players: clock corrections do not freeze sequenced captures", PlayerSessionTests.ClockCorrectionsDoNotFreezeSequencedCaptures);
        await Test("players: legacy duplicates malformed packets and capacity fail safely", PlayerSessionTests.LegacyDuplicatesMalformedPacketsAndCapacityFailSafely);
        await Test("players: stable instances keep opaque tokens without mutating snapshots", LivePlayerIdentityTests.StableInstancesKeepOpaqueTokensWithoutMutatingSnapshots);
        await Test("players: pointer class and accepted absence replace tokens", LivePlayerIdentityTests.PointerClassAndAcceptedAbsenceReplaceTokens);
        await Test("players: rejected capture cannot commit identity changes", LivePlayerIdentityTests.RejectedCaptureCannotCommitIdentityChanges);
        await Test("players: world local pointer and local id changes replace context", LivePlayerIdentityTests.WorldLocalPointerAndLocalIdChangesReplaceContext);
        await Test("players: readiness confirmation publishes identity only after acceptance", LivePlayerIdentityTests.ReadinessConfirmationPublishesIdentityOnlyAfterAcceptance);
        await Test("players: offscreen arrows use output edges without changing projection", PlayerProjectionTests.OffscreenArrowsUseOutputEdgesWithoutChangingProjection);
        await Test("players: behind arrows keep sides and reject ambiguous or invalid positions", PlayerProjectionTests.BehindArrowsKeepSidesAndRejectAmbiguousOrInvalidPositions);
        await Test("players: offscreen mapping handles fit stretch fill and camera sub viewport", PlayerProjectionTests.OffscreenMappingHandlesFitStretchFillAndCameraSubViewport);
        await Test("players: projected frame copies identity and separate offscreen directions", PlayerProjectionTests.ProjectedFrameCopiesIdentityAndSeparateOffscreenDirections);
        await Test("players: visual annotations never transfer to reused or unknown identities", PlayerProjectionTests.VisualAnnotationsNeverTransferToReusedOrUnknownIdentities);
        await Test("players: label placement is bounded stable and prioritizes marked players", PlayerProjectionTests.LabelPlacementIsBoundedStableAndPrioritizesMarkedPlayers);
        await Test("players: label placement rejects invalid blocks and keeps reserved regions clear", PlayerProjectionTests.LabelPlacementRejectsInvalidBlocksAndKeepsReservedRegionsClear);
        await Test("players: label budget preserves categories and allows arrow only profiles", PlayerProjectionTests.LabelBudgetPreservesCategoriesAndAllowsArrowOnlyProfiles);
        await Test("player list: search matches names and ids without changing rows", PlayerListTests.SearchMatchesNamesAndIdsWithoutChangingRows);
        await Test("player list: interaction holds existing order but removes absent players", PlayerListTests.InteractionHoldsExistingOrderButRemovesAbsentPlayers);
        await Test("player list: reused ids do not inherit held positions", PlayerListTests.ReusedIdsDoNotInheritHeldPositions);
        await Test("player list: sorts have deterministic ties and unknown health last", PlayerListTests.SortsHaveDeterministicTiesAndUnknownHealthLast);
        await Test("player list: legacy duplicates stay visible and read only", PlayerListTests.LegacyDuplicatesStayVisibleAndReadOnly);
        await Test("0.12: rules are opt in and normalize ordered thresholds", DisplayRulesTests.RulesAreOptInAndNormalizeOrderedThresholds);
        await Test("0.12: height filter is symmetric and pinned exemption respects visibility", DisplayRulesTests.HeightFilterIsSymmetricAndPinnedExemptionRespectsVisibility);
        await Test("0.12: height only labels use budget and keep pinned exception", DisplayRulesTests.HeightOnlyLabelsUseBudgetAndKeepPinnedException);
        await Test("0.12: health color needs confirmed maximum and individual color wins", DisplayRulesTests.HealthColorNeedsConfirmedMaximumAndIndividualColorWins);
        await Test("0.12: distance color uses its own thresholds and finite metric", DisplayRulesTests.DistanceColorUsesItsOwnThresholdsAndFiniteMetric);
        await Test("0.12: independent radar uses horizontal range without changing esp", DisplayRulesTests.IndependentRadarUsesHorizontalRangeWithoutChangingEsp);
        await Test("0.12: radar bands are disjoint and clipped to displayed range", DisplayRulesTests.RadarBandsAreDisjointAndClippedToDisplayedRange);
        await Test("0.12: radar counters share hidden height and freshness gates", DisplayRulesTests.RadarCountersShareHiddenHeightAndFreshnessGates);
        await Test("0.12: health rules request only existing visible optional reads", DisplayRulesTests.HealthRulesRequestOnlyExistingVisibleOptionalReads);
        await Test("0.12: projection carries same capture height and health for directions", DisplayRulesTests.ProjectionCarriesSameCaptureHeightAndHealthForDirections);
        await Test("0.12: trend requires distinct captures and minimum duration", PlayerDistanceTrendTests.TrendRequiresDistinctCapturesAndMinimumDuration);
        await Test("0.12: trend uses capture time and includes local movement", PlayerDistanceTrendTests.TrendUsesCaptureTimeAndIncludesLocalMovement);
        await Test("0.12: trend median resists an isolated position jitter", PlayerDistanceTrendTests.TrendMedianResistsAnIsolatedPositionJitter);
        await Test("0.12: trend hysteresis avoids direction flicker", PlayerDistanceTrendTests.TrendHysteresisAvoidsDirectionFlicker);
        await Test("0.12: trend resets for either endpoint teleport even at equal distance", PlayerDistanceTrendTests.TrendResetsForEitherEndpointTeleportEvenAtEqualDistance);
        await Test("0.12: trend rejects age boundary time rollback and long gap", PlayerDistanceTrendTests.TrendRejectsAgeBoundaryTimeRollbackAndLongGap);
        await Test("0.12: trend identity generation and invalid position break history", PlayerDistanceTrendTests.TrendIdentityGenerationAndInvalidPositionBreakHistory);
        await Test("0.12: trend history is bounded without losing high rate measurements", PlayerDistanceTrendTests.TrendHistoryIsBoundedWithoutLosingHighRateMeasurements);
        await Test("0.12: session trend is opt in and confined to pinned visible player", PlayerDistanceTrendTests.SessionTrendIsOptInAndConfinedToPinnedVisiblePlayer);
        await Test("0.12: session pin hide and clear never reuse an old trend", PlayerDistanceTrendTests.SessionPinHideAndClearNeverReuseAnOldTrend);
        await Test("0.12: session loss replay and aged capture restart the trend window", PlayerDistanceTrendTests.SessionLossReplayAndAgedCaptureRestartTheTrendWindow);
        await Test("0.12: session expiry keeps old snapshots immutable and cannot be reversed", PlayerDistanceTrendTests.SessionExpiryKeepsOldSnapshotsImmutableAndCannotBeReversed);
        await Test("0.12: session context instance and generation clear trend and pin", PlayerDistanceTrendTests.SessionContextInstanceAndGenerationClearTrendAndPin);
        await Test("0.12: session trend ignores wall clock and does not reset proximity", PlayerDistanceTrendTests.SessionTrendIgnoresWallClockAndDoesNotResetProximity);
        await Test("0.12: toggle inverts fresh memory and only replaces creative reference", CreativeMenuToggleTests.ToggleInvertsFreshMemoryAndOnlyReplacesCreativeReference);
        await Test("0.12: toggle ignores the previously displayed state", CreativeMenuToggleTests.ToggleIgnoresThePreviouslyDisplayedState);
        await Test("0.12: concurrent changes refuse toggle without retry", CreativeMenuToggleTests.ConcurrentChangesRefuseToggleWithoutRetry);
        await Test("0.12: toggle preserves graph and cancellation guards", CreativeMenuToggleTests.TogglePreservesGraphAndCancellationGuards);
        await Test("0.12: uncertain toggle never retries or confirms avalue", CreativeMenuToggleTests.UncertainToggleNeverRetriesOrConfirmsAValue);
        await Test("0.12: toggle protocol rejects ambiguity and false confirmations", CreativeMenuToggleTests.ToggleProtocolRejectsAmbiguityAndFalseConfirmations);
        await Test("0.12: toggle session correlates operation and does not replay on reset", CreativeMenuToggleTests.ToggleSessionCorrelatesOperationAndDoesNotReplayOnReset);
        await Test("0.12: queued toggle expires without execution", CreativeMenuToggleTests.QueuedToggleExpiresWithoutExecution);
        await Test("0.12: only confirmed process loss can recover automatically", GameReconnectTests.OnlyConfirmedProcessLossCanRecoverAutomatically);
        await Test("0.12: end notifications coalesce and cannot replay an old generation", GameReconnectTests.EndNotificationsCoalesceAndCannotReplayAnOldGeneration);
        await Test("0.12: stop before delay prevents the restart even with an uncooperative delay", GameReconnectTests.StopBeforeDelayPreventsTheRestartEvenWithAnUncooperativeDelay);
        await Test("0.12: cancellation reaches an in progress startup", GameReconnectTests.CancellationReachesAnInProgressStartup);
        await Test("0.12: acancelled task cannot clear the following recovery", GameReconnectTests.ACancelledTaskCannotClearTheFollowingRecovery);
        await Test("0.12: startup failure is reported once without automatic retry", GameReconnectTests.StartupFailureIsReportedOnceWithoutAutomaticRetry);
        await Test("0.12: old settings keep profiles and quiet display defaults", FeatureSettings012Tests.OldSettingsKeepProfilesAndQuietDisplayDefaults);
        await Test("0.12: separate rules and new options roundtrip without creative state", FeatureSettings012Tests.SeparateRulesAndNewOptionsRoundtripWithoutCreativeState);
        await Test("0.12: invalid and shared rules normalize to independent bounded values", FeatureSettings012Tests.InvalidAndSharedRulesNormalizeToIndependentBoundedValues);
        await Test("0.12: new preset rules are deep copied without connection or key changes", FeatureSettings012Tests.NewPresetRulesAreDeepCopiedWithoutConnectionOrKeyChanges);
        await Test("0.12: old presets remain importable and invalid new rules are atomic", FeatureSettings012Tests.OldPresetsRemainImportableAndInvalidNewRulesAreAtomic);
        await Test("0.12: creative shortcut cannot steal other bindings", FeatureSettings012Tests.CreativeShortcutCannotStealOtherBindings);
        Console.WriteLine($"RESULT: {passed} passed; {failed} failed. No Windows UI, DMA hardware, or game execution tested.");
        return failed == 0 ? 0 : 1;
    }

    private static async Task Test(string name, Func<Task> body)
    {
        try { await body().WaitAsync(Deadline); passed++; Console.WriteLine("PASS " + name); }
        catch (Exception ex) { failed++; Console.WriteLine("FAIL " + name + ": " + ex.GetType().Name + " / " + ex.Message); }
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    private static async Task ExpectFailure(Func<Task> body, params Type[] allowed)
    {
        try { await body(); }
        catch (Exception ex)
        {
            foreach (Type type in allowed) if (type.IsAssignableFrom(ex.GetType())) return;
            throw new InvalidOperationException("Unexpected failure " + ex.GetType().Name, ex);
        }
        throw new InvalidOperationException("Expected failure did not occur.");
    }

    private static LiveEntitySnapshot Snapshot(DateTime? captured = null) => new()
    {
        Status = "ENTITES_LUES", CapturedUtc = captured ?? DateTime.UtcNow,
        LocalPosition = new LivePosition { X = 100, Y = 25, Z = -20 }, LocalId = 5,
        PlayersCount = 1, ZombiesCount = 1,
        Entities = new List<LiveEntity>
        {
            new() { Kind = "player", EntityId = 6, Name = "Essai joueur", Position = new() { X = 110, Y = 25, Z = -15 } },
            new() { Kind = "zombie", EntityId = 7, Name = "Essai zombie", Position = new() { X = 90, Y = 30, Z = -20 } }
        }
    };

    private static LiveEntitySnapshot CameraSnapshot()
    {
        var snapshot = Snapshot();
        snapshot.RenderOrigin = new LivePosition();
        snapshot.Camera = new LiveCameraFrame
        {
            Format = "SevenDaysEsp.CameraFrame/1", ProfileId = "unity-2022.3.62f2-7670c08855a9-native-v1",
            ClipDepth = "MinusOneToOne", Sequence = 1, CameraEpoch = 1, ReadDurationMs = 2,
            SourceWidth = 1920, SourceHeight = 1080, ViewportWidth = 1920, ViewportHeight = 1080,
            // A wire-validation fixture, not a claim about a game camera.
            ViewProjection = new float[] { 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1 }
        };
        return snapshot;
    }

    private static Task ProjectionFeedFreshness()
    {
        var snapshot = CameraSnapshot();
        var fresh = new FeedSample(snapshot, 0);
        Check(fresh.IsProjectionFresh, "A complete current projection frame was rejected.");
        var older = new FeedSample(snapshot, FeedSample.ProjectionLifetimeMs + 1);
        Check(older.IsFresh && !older.IsProjectionFresh, "Camera expiry incorrectly removed the radar or kept projected data.");
        snapshot.Camera.ProfileId = "another-binary";
        Check(fresh.IsFresh && !fresh.IsProjectionFresh, "An unknown camera profile was accepted.");
        snapshot.Camera.ProfileId = "unity-2022.3.62f2-7670c08855a9-native-v1";
        snapshot.Camera.ViewProjection[5] = float.NaN;
        Check(fresh.IsFresh && !fresh.IsProjectionFresh, "Non-finite camera data reached projection or removed radar.");
        snapshot.Camera.ViewProjection[5] = 1;
        snapshot.Camera.ReadDurationMs = double.PositiveInfinity;
        Check(!fresh.IsProjectionFresh, "Invalid camera read duration was accepted.");
        snapshot.Camera.ReadDurationMs = 2;
        snapshot.RenderOrigin.X = float.PositiveInfinity;
        Check(fresh.IsFresh && !fresh.IsProjectionFresh, "Invalid render origin was accepted.");
        return Task.CompletedTask;
    }

    private static Task ReportedCameraProjection()
    {
        var snapshot = CameraSnapshot();
        // Values from rapport-live-20261114-225829-c4c7d1.json, not a newly
        // invented game matrix. Zero origin below defines test render space;
        // the point is a numerical fixture, not an observed in-game entity.
        snapshot.Camera.ViewProjection = new float[]
        {
            -0.77456695f, -1.08544846e-7f, 0.42384338f, 12.327972f,
            -0.1486125f, 1.5388527f, -0.27158657f, -14.29533f,
            -0.4706063f, -0.19723095f, -0.86002547f, 8.8618765f,
            -0.47060293f, -0.19722953f, -0.8600193f, 8.881813f
        };
        snapshot.Camera.ViewportY = 180.99998f;
        snapshot.Camera.ViewportWidth = 1599;
        snapshot.Camera.ViewportHeight = 899;
        snapshot.Camera.Sequence = 193;
        snapshot.Camera.CameraEpoch = 98;
        snapshot.Camera.ReadDurationMs = 52.4021;
        var sample = new FeedSample(snapshot, 74);
        Check(sample.IsProjectionFresh && sample.TryGetProjectionView(out _, out _),
            "The actual report's camera was rejected by the display contract.");
        Check(sample.TryGetProjectionView(out var view, out var reason), reason);
        // Independently solve row0=0, row1=0, row3=10 of the reported matrix.
        var point = new LivePosition { X = 10.8599733f, Y = 8.7077039f, Z = -9.2397212f };
        Check(ProjectionMath.TryProjectPoint(view, point, out var pixel), "A known point ahead of this camera was clipped.");
        Check(Math.Abs(pixel.X - 799.5) < 0.01 && Math.Abs(pixel.Y - 630.49998) < 0.01,
            "Reported partial viewport was scaled, recentred or inverted.");
        return Task.CompletedTask;
    }

    private static async Task FramingRoundtrip()
    {
        using var output = new MemoryStream();
        await Wire.WriteAsync(output, new LinkRequest { Type = "poll", Id = 42 }, default);
        using var input = new FragmentedStream(output.ToArray());
        LinkRequest restored = await Wire.ReadAsync<LinkRequest>(input, default);
        Check(restored.Id == 42 && restored.Type == "poll", "Framing changed message.");
    }

    private static async Task FramingBounds()
    {
        foreach (int size in new[] { 0, -1, Wire.MaxMessageBytes + 1, int.MaxValue })
        {
            byte[] header = new byte[4]; BinaryPrimitives.WriteInt32LittleEndian(header, size);
            using var input = new MemoryStream(header);
            await ExpectFailure(async () => await Wire.ReadAsync<LinkRequest>(input, default), typeof(InvalidDataException));
        }
        using var target = new MemoryStream();
        await ExpectFailure(async () => await Wire.WriteAsync(target, new string('x', Wire.MaxMessageBytes), default), typeof(InvalidDataException));
        Check(target.Length == 0, "Oversized write emitted bytes.");
    }

    private static async Task FramingInvalid()
    {
        foreach (byte[] data in new[] { new byte[] { 1, 2 }, new byte[] { 7, 0, 0, 0, 123, 125 } })
        {
            using var input = new MemoryStream(data);
            await ExpectFailure(async () => await Wire.ReadAsync<LinkRequest>(input, default), typeof(EndOfStreamException));
        }
        foreach (string payload in new[] { "null", "{not-json}", "[]" })
        {
            byte[] bytes = Encoding.UTF8.GetBytes(payload);
            using var input = new MemoryStream(); byte[] header = new byte[4];
            BinaryPrimitives.WriteInt32LittleEndian(header, bytes.Length);
            input.Write(header); input.Write(bytes); input.Position = 0;
            await ExpectFailure(async () => await Wire.ReadAsync<LinkRequest>(input, default), typeof(InvalidDataException), typeof(System.Text.Json.JsonException));
        }
    }

    private static async Task FramingCancellation()
    {
        var listener = new TcpListener(IPAddress.Loopback, 0); listener.Start();
        try
        {
            using var sender = new TcpClient();
            var accept = listener.AcceptTcpClientAsync();
            await sender.ConnectAsync(IPAddress.Loopback, ((IPEndPoint)listener.LocalEndpoint).Port);
            using TcpClient receiver = await accept;
            using var cancel = new CancellationTokenSource(120);
            var began = Stopwatch.StartNew();
            await ExpectFailure(async () => await Wire.ReadAsync<LinkRequest>(receiver.GetStream(), cancel.Token), typeof(OperationCanceledException));
            Check(began.Elapsed < TimeSpan.FromSeconds(3), "Stalled message cancellation was unbounded.");
        }
        finally { listener.Stop(); }
    }

    private static async Task Freshness()
    {
        foreach (DateTime timestamp in new[] { DateTime.UtcNow.AddYears(-15), DateTime.UtcNow.AddYears(15), DateTime.MinValue })
            Check(new FeedSample(Snapshot(timestamp), 15).IsFresh, "Display depends on remote UTC.");
        foreach (double age in new[] { (double)FeedSample.LifetimeMs, 10000, double.NaN, double.PositiveInfinity, double.NegativeInfinity })
            Check(!new FeedSample(Snapshot(), age).IsFresh, "Invalid/stale age accepted.");
        var expiring = new FeedSample(Snapshot(), FeedSample.LifetimeMs - 80);
        await Task.Delay(130);
        Check(!expiring.IsFresh, "Old data remained fresh.");
        var changing = new FeedSample(Snapshot(), 0); double before = changing.AgeMs;
        var negativeAge = new FeedSample(Snapshot(), -10);
        await Task.Delay(35);
        Check(changing.AgeMs >= before + 20, "Age did not advance monotonically.");
        Check(!negativeAge.IsFresh, "Negative source age became fresh after waiting.");
    }

    private static Task InvalidSnapshots()
    {
        var cases = new List<LiveEntitySnapshot>();
        var s = Snapshot(); s.Status = "LECTURE_NON_VALIDEE"; cases.Add(s);
        s = Snapshot(); s.LocalId = -1; cases.Add(s);
        s = Snapshot(); s.LocalPosition.X = float.NaN; cases.Add(s);
        s = Snapshot(); s.Entities[0].Position.Y = 1000001; cases.Add(s);
        s = Snapshot(); s.Entities[0].EntityId = s.LocalId; cases.Add(s);
        s = Snapshot(); s.Entities[0].Kind = "npc"; cases.Add(s);
        s = Snapshot(); s.Entities[0].Name = new string('x', 129); cases.Add(s);
        s = Snapshot(); s.Entities = new List<LiveEntity>(new LiveEntity[4097]); cases.Add(s);
        foreach (var invalid in cases) Check(!new FeedSample(invalid, 0).IsFresh, "Invalid entities accepted.");
        return Task.CompletedTask;
    }

    private static async Task SettingsPersistence()
    {
        string directory = TemporaryDirectory();
        try
        {
            var store = new SettingsStore(directory);
            var settings = new LoaderSettings
            {
                Mode = "anything", IntervalMs = -1, MaxDistance = 999999, RadarSize = -2,
                RadarOpacity = double.NaN, MonitorIndex = 500, SharePort = -1,
                MenuKey = "F6", ToggleKey = "F6", PlayerColor = "#abcdef", ZombieColor = "red",
                SdkDirectory = @"C:\test with spaces\MemProcFS", OverlayAnchor = "other"
            };
            store.Save(settings);
            settings.EspEnabled = true; settings.MaxDistance = 350; store.Save(settings);
            var loaded = new SettingsStore(directory).Load();
            Check(loaded.Mode == "reader" && loaded.IntervalMs == 50 && loaded.MaxDistance == 350, "Setting bounds lost.");
            Check(loaded.RadarSize == 180 && loaded.RadarOpacity == .88 && loaded.SharePort == 1024, "Numeric normalization failed.");
            Check(loaded.MenuKey == "F6" && loaded.ToggleKey == "F7", "Hotkey conflict not fixed.");
            Check(loaded.PlayerColor == "#ABCDEF" && loaded.ZombieColor == "#FF9A52" && loaded.EspEnabled, "Persistent settings changed.");
            Check(loaded.SdkDirectory == settings.SdkDirectory && loaded.OverlayAnchor == "TopRight", "Path/anchor changed.");
            Check(Directory.GetFiles(directory, "*.tmp").Length == 0, "Temporary file left after atomic replace.");
            await Task.CompletedTask;
        }
        finally { Directory.Delete(directory, true); }
    }

    private static Task ProjectionScaleSettingsPersistence()
    {
        string directory = TemporaryDirectory();
        try
        {
            var store = new SettingsStore(directory);
            File.WriteAllText(store.FilePath, "{\"EspEnabled\":false,\"OutputMode\":\"fuser\",\"MonitorIndex\":2}");
            var settings = store.Load();
            Check(settings.EspScaleMode == ProjectionOutputMapping.Fit && !settings.EspEnabled &&
                settings.OutputMode == "fuser" && settings.MonitorIndex == 2,
                "Migration changed existing visibility or output settings instead of adding the default fit mode.");
            foreach (string mode in new[] { ProjectionOutputMapping.Fit, ProjectionOutputMapping.Stretch, ProjectionOutputMapping.Fill })
            {
                settings.EspScaleMode = mode;
                store.Save(settings);
                settings = store.Load();
                Check(settings.EspScaleMode == mode && !settings.EspEnabled && settings.OutputMode == "fuser" && settings.MonitorIndex == 2,
                    "The scale mode did not survive an actual settings roundtrip or changed existing output preferences.");
            }
            foreach (string? invalid in new string?[] { null, "", "FIT", "unsupported" })
            {
                settings.EspScaleMode = invalid!;
                File.WriteAllText(store.FilePath, System.Text.Json.JsonSerializer.Serialize(settings, Wire.Json));
                Check(store.Load().EspScaleMode == ProjectionOutputMapping.Fit, "Loading an invalid scale mode did not restore fit.");
                store.Save(settings);
                Check(settings.EspScaleMode == ProjectionOutputMapping.Fit && store.Load().EspScaleMode == ProjectionOutputMapping.Fit,
                    "Saving an invalid scale mode did not restore fit.");
            }
            return Task.CompletedTask;
        }
        finally { Directory.Delete(directory, true); }
    }

    private static Task FuserSettingsPersistence()
    {
        string directory = TemporaryDirectory();
        try
        {
            var store = new SettingsStore(directory);
            File.WriteAllText(store.FilePath, "{\"EspEnabled\":false}");
            var old = store.Load();
            Check(old.OutputMode == "overlay" && old.FuserDeviceName == "" && old.FuserKeyColor == "#000000" && !old.FuserTestPattern && !old.EspEnabled,
                "An old settings file unexpectedly activated the fuser or changed visibility.");
            old.OutputMode = "fuser"; old.FuserKeyColor = "#00ff00"; old.FuserTestPattern = true; old.MonitorIndex = 2;
            old.FuserDeviceName = @"  \\.\DISPLAY3  ";
            store.Save(old);
            Check(old.FuserTestPattern, "Saving disabled the running calibration pattern.");
            var loaded = store.Load();
            Check(loaded.OutputMode == "fuser" && loaded.FuserKeyColor == "#00FF00" && loaded.MonitorIndex == 2 && loaded.FuserDeviceName == @"\\.\DISPLAY3",
                "Fuser output settings did not survive the actual file roundtrip.");
            Check(!loaded.FuserTestPattern && !File.ReadAllText(store.FilePath).Contains("FuserTestPattern", StringComparison.OrdinalIgnoreCase),
                "The calibration pattern was persisted and would reappear on launch.");
            loaded.OutputMode = "unknown"; loaded.FuserKeyColor = "#123456";
            store.Save(loaded); loaded = store.Load();
            Check(loaded.OutputMode == "overlay" && loaded.FuserKeyColor == "#000000", "Invalid output options were accepted.");
            File.WriteAllText(store.FilePath, "{\"OutputMode\":\"fuser\",\"FuserTestPattern\":true}");
            Check(!store.Load().FuserTestPattern, "A hand-written test pattern flag survived deserialization.");
            foreach (string? invalidDevice in new[] { null, new string('x', 129), "DISPLAY\u0001bad" })
            {
                loaded.FuserDeviceName = invalidDevice!;
                store.Save(loaded);
                Check(store.Load().FuserDeviceName == "", "An invalid persisted display identity was accepted.");
            }
            return Task.CompletedTask;
        }
        finally { Directory.Delete(directory, true); }
    }

    private static Task SettingsMigration()
    {
        string directory = TemporaryDirectory();
        try
        {
            var store = new SettingsStore(directory);
            string oldPath = Path.Combine(directory, "settings.json");
            string original = "{\"MemProcFsDirectory\":\"C:\\\\Ancien SDK\",\"ProgramPath\":\"unrelated.exe\"}";
            File.WriteAllText(oldPath, original);
            var loaded = store.Load();
            Check(loaded.SdkDirectory == @"C:\Ancien SDK", "Legacy SDK was not migrated.");
            Check(loaded.AutoConnectDma && loaded.EspEnabled && File.ReadAllText(oldPath) == original, "Legacy import changed its source or lost the new launch defaults.");
            return Task.CompletedTask;
        }
        finally { Directory.Delete(directory, true); }
    }

    private static Task SettingsRecovery()
    {
        string directory = TemporaryDirectory();
        try
        {
            foreach (string text in new[] { "{ invalid json", "null", new string(' ', 65537) })
            {
                var store = new SettingsStore(directory); File.WriteAllText(store.FilePath, text);
                LoaderSettings settings = store.Load();
                Check(settings.Mode == "reader" && settings.AutoConnectDma && settings.EspEnabled && store.LoadWarning != null, "Invalid settings not reset with warning.");
            }
            return Task.CompletedTask;
        }
        finally { Directory.Delete(directory, true); }
    }

    private static void CreateSdk(string path, bool vmm = true, bool leechcore = true)
    {
        Directory.CreateDirectory(path);
        if (vmm) File.WriteAllText(Path.Combine(path, "vmm.dll"), "presence-only fixture");
        if (leechcore) File.WriteAllText(Path.Combine(path, "leechcore.dll"), "presence-only fixture");
    }

    private static Task SdkPreferred()
    {
        string root = TemporaryDirectory();
        try
        {
            string preferred = Path.Combine(root, "custom sdk with spaces");
            string application = Path.Combine(root, "app");
            string desktop = Path.Combine(root, "desktop");
            CreateSdk(preferred);
            CreateSdk(Path.Combine(application, "MemProcFS"));
            CreateSdk(Path.Combine(desktop, "MemProcFS_files_and_binaries-win_x64-latest"));
            Check(SdkLocator.Find(preferred, application, desktop) == preferred, "Known user SDK path was overridden.");
            Check(SdkLocator.Find("  \"" + preferred + "\"  ", application, desktop) == preferred, "Quoted SDK path with spaces was rejected.");
            return Task.CompletedTask;
        }
        finally { Directory.Delete(root, true); }
    }

    private static Task SdkFallback()
    {
        string root = TemporaryDirectory();
        try
        {
            string preferred = Path.Combine(root, "incomplete");
            string application = Path.Combine(root, "app");
            string desktop = Path.Combine(root, "desktop");
            string portable = Path.Combine(application, "MemProcFS");
            string knownDesktop = Path.Combine(desktop, "MemProcFS_files_and_binaries-win_x64-latest");
            CreateSdk(preferred, leechcore: false);
            CreateSdk(portable);
            CreateSdk(knownDesktop);
            Check(SdkLocator.Find(preferred, application, desktop) == portable, "Incomplete preferred installation did not fall back to portable SDK.");
            File.Delete(Path.Combine(portable, "vmm.dll"));
            Check(SdkLocator.Find(preferred, application, desktop) == knownDesktop, "Two incomplete installations obscured complete Desktop SDK.");
            File.Delete(Path.Combine(knownDesktop, "leechcore.dll"));
            Check(SdkLocator.Find(preferred, application, desktop) == null, "SDK missing a required DLL was accepted.");
            string alternate = Path.Combine(application, "MemProcFS_files_and_binaries-win_x64-latest");
            CreateSdk(alternate);
            Check(SdkLocator.Find(null, application, desktop) == alternate, "Known portable distribution folder not found.");
            return Task.CompletedTask;
        }
        finally { Directory.Delete(root, true); }
    }

    private static Task SdkBoundedLookup()
    {
        string root = TemporaryDirectory();
        try
        {
            string application = Path.Combine(root, "app");
            string desktop = Path.Combine(root, "desktop");
            string knownDesktop = Path.Combine(desktop, "MemProcFS_files_and_binaries-win_x64-latest");
            CreateSdk(knownDesktop);
            foreach (string? malformed in new string?[] { null, "", "   ", "\0bad", "\"\"" })
                Check(SdkLocator.Find(malformed, application, desktop) == knownDesktop, "Malformed preferred path prevented a known fallback.");
            Directory.Delete(knownDesktop, true);
            CreateSdk(Path.Combine(application, "nested", "MemProcFS"));
            CreateSdk(Path.Combine(desktop, "unrelated", "MemProcFS_files_and_binaries-win_x64-latest"));
            Check(SdkLocator.Find(null, application, desktop) == null, "Lookup searched unrelated nested folders.");
            Check(SdkLocator.Find(null, "", "") == null, "Lookup found an SDK although all candidates were disabled.");
            return Task.CompletedTask;
        }
        finally { Directory.Delete(root, true); }
    }

    private static Task AutoConnectMigration()
    {
        string directory = TemporaryDirectory();
        try
        {
            var store = new SettingsStore(directory);
            string original = "{\"SchemaVersion\":1,\"Mode\":\"display\",\"EspEnabled\":false,\"SdkDirectory\":\"custom-sdk\"}";
            File.WriteAllText(store.FilePath, original);
            var migrated = store.Load();
            Check(migrated.AutoConnectDma, "Old settings without AutoConnectDma did not receive the enabled default.");
            Check(!migrated.EspEnabled && migrated.SdkDirectory == "custom-sdk", "Migration changed explicit existing display/path choices.");
            Check(File.ReadAllText(store.FilePath) == original, "Read-only migration rewrote the old file.");
            migrated.AutoConnectDma = false;
            store.Save(migrated);
            var reloaded = new SettingsStore(directory).Load();
            Check(!reloaded.AutoConnectDma && !reloaded.EspEnabled, "Explicit disabled automatic launch/display was not retained.");
            store.Save(reloaded);
            Check(!new SettingsStore(directory).Load().AutoConnectDma, "Second save reset a user's disabled auto-connect choice.");
            return Task.CompletedTask;
        }
        finally { Directory.Delete(directory, true); }
    }

    private static Task PairingValidation()
    {
        foreach (string bad in new[] { "", "7DTD1.", "garbage", "7DTD1." + new string('a', 2049) })
        {
            bool failed = false; try { PairingInformation.Parse(bad); } catch (InvalidDataException) { failed = true; }
            Check(failed, "Malformed pairing accepted.");
        }
        foreach (string host in new[] { "8.8.8.8", "example.com", "::1", "0.0.0.0" })
        {
            var pairing = new PairingInformation { Host = host, Port = 27841, Fingerprint = new string('A', 64), Token = Convert.ToBase64String(new byte[32]) };
            bool failed = false; try { PairingInformation.Parse(pairing.Encode()); } catch (InvalidDataException) { failed = true; }
            Check(failed, "Public or unsupported host accepted.");
        }
        return Task.CompletedTask;
    }

    private static async Task PairingRejection()
    {
        await using var server = new DisplayServer(() => null, () => new LoaderStatus());
        string code = server.Start("127.0.0.1", FreePort());
        var wrongPin = PairingInformation.Parse(code); wrongPin.Fingerprint = new string('0', 64);
        await using (var client = new DisplayClient())
            await ExpectFailure(() => client.ConnectAsync(wrongPin.Encode()), typeof(AuthenticationException), typeof(IOException));
        var wrongToken = PairingInformation.Parse(code); wrongToken.Token = Convert.ToBase64String(new byte[32]);
        await using (var client = new DisplayClient())
            await ExpectFailure(() => client.ConnectAsync(wrongToken.Encode()), typeof(AuthenticationException), typeof(IOException));
        await using (var client = new DisplayClient()) await client.ConnectAsync(code);
    }

    private static async Task LiveLink()
    {
        FeedSample? source = new FeedSample(Snapshot(DateTime.UtcNow.AddYears(15)), 123);
        var state = new LoaderStatus { Stage = "ENTITES_LUES", IsConnected = true, IsReader = true, CanProject = true, ReportPath = "/private/report.json", IsSharing = true };
        var channel = Channel.CreateUnbounded<(FeedSample? Sample, LoaderStatus State)>();
        var ended = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
        await using var server = new DisplayServer(() => Volatile.Read(ref source), () => state);
        string code = server.Start("127.0.0.1", FreePort());
        await using var client = new DisplayClient();
        client.Received += (sample, status) => channel.Writer.TryWrite((sample, status));
        client.Ended += text => ended.TrySetResult(text);
        await client.ConnectAsync(code);
        var first = await channel.Reader.ReadAsync().AsTask().WaitAsync(TimeSpan.FromSeconds(2));
        Check(first.Sample?.IsFresh == true && first.Sample.Snapshot.Entities.Count == 2, "Valid TCP frame missing.");
        Check(first.Sample!.InitialAgeMs >= 123, "Source age was dropped.");
        Check(!first.State.IsReader && !first.State.CanProject && first.State.ReportPath == "", "Remote state exposed unsupported capabilities/local path.");
        Volatile.Write(ref source, new FeedSample(Snapshot(), 3000));
        await WaitForNullFrame(channel.Reader);
        var invalid = Snapshot(); invalid.LocalPosition.X = float.NaN;
        Volatile.Write(ref source, new FeedSample(invalid, 0));
        await WaitForNullFrame(channel.Reader);
        Volatile.Write(ref source, new FeedSample(Snapshot(DateTime.UtcNow.AddYears(-15)), 0));
        (FeedSample? Sample, LoaderStatus State) resumed;
        do { resumed = await channel.Reader.ReadAsync().AsTask().WaitAsync(TimeSpan.FromSeconds(2)); } while (resumed.Sample == null);
        Check(resumed.Sample.IsFresh, "Fresh data did not resume after invalid source.");
        await server.DisposeAsync();
        Check(!string.IsNullOrEmpty(await ended.Task.WaitAsync(TimeSpan.FromSeconds(3))), "Server stop did not notify display consumer.");
    }

    private static async Task WaitForNullFrame(ChannelReader<(FeedSample? Sample, LoaderStatus State)> reader)
    {
        using var cancellation = new CancellationTokenSource(2200);
        while ((await reader.ReadAsync(cancellation.Token)).Sample != null) { }
    }

    private static async Task LiveProjectionLink()
    {
        int mode = 0;
        FeedSample Provide()
        {
            var frame = CameraSnapshot();
            int current = Volatile.Read(ref mode);
            if (current == 2) frame.Camera.Format = "unsupported";
            return new FeedSample(frame, current == 1 ? FeedSample.ProjectionLifetimeMs + 1 : 0);
        }
        var channel = Channel.CreateUnbounded<(FeedSample? Sample, LoaderStatus State)>();
        await using var server = new DisplayServer(Provide, () => new LoaderStatus { CanProject = false });
        string code = server.Start("127.0.0.1", FreePort());
        await using var client = new DisplayClient();
        client.Received += (sample, status) => channel.Writer.TryWrite((sample, status));
        await client.ConnectAsync(code);
        using var deadline = new CancellationTokenSource(4000);
        var first = await channel.Reader.ReadAsync(deadline.Token);
        Check(first.Sample?.IsProjectionFresh == true && first.State.CanProject, "Valid camera projection did not survive the wire.");
        Volatile.Write(ref mode, 1);
        (FeedSample? Sample, LoaderStatus State) item;
        do { item = await channel.Reader.ReadAsync(deadline.Token); } while (item.Sample?.InitialAgeMs < FeedSample.ProjectionLifetimeMs);
        Check(item.Sample?.IsFresh == true && !item.State.CanProject, "Old camera data retained projection capability or removed radar.");
        Volatile.Write(ref mode, 2);
        do { item = await channel.Reader.ReadAsync(deadline.Token); } while (item.Sample?.Snapshot.Camera?.Format != "unsupported");
        Check(item.Sample?.IsFresh == true && !item.State.CanProject, "Malformed camera convention was accepted over the wire.");
    }

    private static async Task InvalidRemoteResponse()
    {
        using RSA key = RSA.Create(2048);
        var request = new CertificateRequest("CN=7DTD-Loader", key, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        using var certificate = request.CreateSelfSigned(DateTimeOffset.UtcNow.AddMinutes(-1), DateTimeOffset.UtcNow.AddDays(1));
        var listener = new TcpListener(IPAddress.Loopback, 0); listener.Start();
        using var cancel = new CancellationTokenSource(7000);
        var pairing = new PairingInformation
        {
            Host = "127.0.0.1", Port = ((IPEndPoint)listener.LocalEndpoint).Port,
            Fingerprint = Convert.ToHexString(SHA256.HashData(certificate.RawData)), Token = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32))
        };
        Task fakeServer = Task.Run(async () =>
        {
            using TcpClient accepted = await listener.AcceptTcpClientAsync(cancel.Token);
            using var ssl = new SslStream(accepted.GetStream());
            await ssl.AuthenticateAsServerAsync(new SslServerAuthenticationOptions { ServerCertificate = certificate, EnabledSslProtocols = SslProtocols.Tls12 | SslProtocols.Tls13 }, cancel.Token);
            await Wire.ReadAsync<LinkRequest>(ssl, cancel.Token);
            await Wire.WriteAsync(ssl, new LinkPacket { Type = "ready" }, cancel.Token);
            // Deliberately bypass DisplayServer, which normalizes CanProject
            // before sending. These contradictory wire flags test the client.
            var initial = await Wire.ReadAsync<LinkRequest>(ssl, cancel.Token);
            await Wire.WriteAsync(ssl, new LinkPacket
            {
                Id = initial.Id, Frame = Snapshot(), AgeMs = 0,
                Status = new LoaderStatus { CanProject = true }
            }, cancel.Token);
            var valid = await Wire.ReadAsync<LinkRequest>(ssl, cancel.Token);
            await Wire.WriteAsync(ssl, new LinkPacket
            {
                Id = valid.Id, Frame = CameraSnapshot(), AgeMs = 0,
                Status = new LoaderStatus { CanProject = false }
            }, cancel.Token);
            var old = await Wire.ReadAsync<LinkRequest>(ssl, cancel.Token);
            await Wire.WriteAsync(ssl, new LinkPacket
            {
                Id = old.Id, Frame = CameraSnapshot(), AgeMs = FeedSample.ProjectionLifetimeMs + 1,
                Status = new LoaderStatus { CanProject = true }
            }, cancel.Token);
            var next = await Wire.ReadAsync<LinkRequest>(ssl, cancel.Token);
            await Wire.WriteAsync(ssl, new LinkPacket { Id = next.Id + 100 }, cancel.Token);
            await Task.Delay(400, cancel.Token);
        });
        var ended = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
        var received = Channel.CreateUnbounded<(FeedSample? Sample, LoaderStatus State)>();
        var client = new DisplayClient();
        client.Ended += text => ended.TrySetResult(text);
        client.Received += (sample, state) => received.Writer.TryWrite((sample, state));
        try
        {
            await client.ConnectAsync(pairing.Encode(), cancel.Token);
            var absent = await received.Reader.ReadAsync(cancel.Token);
            Check(absent.Sample?.IsFresh == true && absent.Sample.Snapshot.Camera == null && !absent.State.CanProject,
                "A peer's true projection flag enabled a frame without camera data.");
            var valid = await received.Reader.ReadAsync(cancel.Token);
            Check(valid.Sample?.Snapshot.Camera != null && valid.State.CanProject,
                "A peer's false projection flag disabled complete fresh camera data.");
            var old = await received.Reader.ReadAsync(cancel.Token);
            Check(old.Sample?.IsFresh == true && old.Sample.InitialAgeMs >= FeedSample.ProjectionLifetimeMs && !old.State.CanProject,
                "A peer's true projection flag revived expired camera data or removed valid radar data.");
            await ended.Task.WaitAsync(TimeSpan.FromSeconds(3));
            await fakeServer;
        }
        finally
        {
            cancel.Cancel();
            listener.Stop();
            await client.DisposeAsync();
            try { await fakeServer; }
            catch (Exception ex) when (ex is OperationCanceledException || ex is IOException || ex is SocketException || ex is ObjectDisposedException) { }
        }
    }

    private static int FreePort()
    {
        var listener = new TcpListener(IPAddress.Loopback, 0); listener.Start();
        int port = ((IPEndPoint)listener.LocalEndpoint).Port; listener.Stop(); return port;
    }

    private static string TemporaryDirectory()
    {
        string directory = Path.Combine(Path.GetTempPath(), "7dtd-loader-service-tests-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(directory); return directory;
    }

    private sealed class FragmentedStream : MemoryStream
    {
        public FragmentedStream(byte[] bytes) : base(bytes, false) { }
        public override ValueTask<int> ReadAsync(Memory<byte> buffer, CancellationToken cancellationToken = default)
            => base.ReadAsync(buffer.Slice(0, Math.Min(buffer.Length, 1)), cancellationToken);
    }
}
