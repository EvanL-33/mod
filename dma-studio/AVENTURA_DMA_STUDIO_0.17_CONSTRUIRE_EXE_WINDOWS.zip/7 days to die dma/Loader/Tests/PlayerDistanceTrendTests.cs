using System;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using SevenDaysEsp;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class PlayerDistanceTrendTests
{
    public static Task TrendRequiresDistinctCapturesAndMinimumDuration()
    {
        var f = new TrackerFixture();
        for (int i = 0; i < 5; ++i)
            Check(Unknown(f.Push(i * 0.1, 0, 100 - i * 0.2)),
                "A short history produced a distance trend before half a second.");
        Check(f.Push(0.6, 0, 98.8).State == PlayerDistanceTrendState.Approaching,
            "Enough fresh, distinct captures did not produce a decreasing-distance trend.");
        Check(Unknown(f.Push(0.61, 0, 98.7, sequence: f.Sequence)),
            "A duplicate capture kept an old estimate alive.");
        Check(Unknown(f.Push(0.7, 0, 98.6)), "One observation after a replay reused the old history.");
        Check(Unknown(f.Push(0.8, 0, 98.4, sequence: f.Sequence - 1)),
            "An out-of-order sequence retained the trend.");
        return Task.CompletedTask;
    }

    public static Task TrendUsesCaptureTimeAndIncludesLocalMovement()
    {
        var f = new TrackerFixture();
        double[] ages = { 20, 70, 35, 80, 10, 60, 25, 75, 30, 65 };
        PlayerDistanceTrend trend = default;
        for (int i = 0; i < ages.Length; ++i)
            trend = f.Push(i * 0.1, i * 0.2, 100, age: ages[i]);
        Check(trend.State == PlayerDistanceTrendState.Approaching && Close(trend.RelativeMetersPerSecond, -2),
            "Receipt jitter changed the rate, or local movement was omitted from relative distance.");
        var vertical = new TrackerFixture();
        for (int i = 0; i < 10; ++i)
            trend = vertical.Push(i * 0.1, 0, 0, targetY: 30 + i * 0.1);
        Check(trend.State == PlayerDistanceTrendState.Receding && Close(trend.RelativeMetersPerSecond, 1),
            "The trend used horizontal distance instead of the same three-dimensional distance as the card.");
        return Task.CompletedTask;
    }

    public static Task TrendMedianResistsAnIsolatedPositionJitter()
    {
        var f = new TrackerFixture();
        PlayerDistanceTrend trend = default;
        for (int i = 0; i < 12; ++i)
            trend = f.Push(i * 0.1, 0, 100 - i * 0.2 + (i == 6 ? 1.5 : 0));
        Check(trend.State == PlayerDistanceTrendState.Approaching && Close(trend.RelativeMetersPerSecond, -2),
            "A single small position spike dominated the short median regression.");
        return Task.CompletedTask;
    }

    public static Task TrendHysteresisAvoidsDirectionFlicker()
    {
        var f = new TrackerFixture();
        double distance = 100, seconds = 0;
        PlayerDistanceTrend Phase(double rate)
        {
            PlayerDistanceTrend value = default;
            for (int i = 0; i < 18; ++i)
            {
                seconds += 0.1; distance += rate * 0.1;
                value = f.Push(seconds, 0, distance);
            }
            return value;
        }
        Check(Phase(-1).State == PlayerDistanceTrendState.Approaching, "A sustained decrease was not detected.");
        Check(Phase(-0.4).State == PlayerDistanceTrendState.Approaching,
            "A small rate fluctuation discarded the existing decreasing-distance state.");
        Check(Phase(0).State == PlayerDistanceTrendState.Stable, "A stopped relative movement stayed decreasing.");
        Check(Phase(-0.4).State == PlayerDistanceTrendState.Stable,
            "The entry threshold did not keep low-rate jitter stable.");
        Check(Phase(1).State == PlayerDistanceTrendState.Receding, "A sustained increase was not detected.");
        Check(Phase(0.4).State == PlayerDistanceTrendState.Receding,
            "Positive-rate hysteresis differs from negative-rate hysteresis.");
        Check(Phase(0).State == PlayerDistanceTrendState.Stable, "A stopped increase stayed active.");
        return Task.CompletedTask;
    }

    public static Task TrendResetsForEitherEndpointTeleportEvenAtEqualDistance()
    {
        var local = WarmTracker();
        Check(Unknown(local.Push(1.2, 50, 97.6)), "A local teleport retained the previous trend.");
        var remote = WarmTracker();
        Check(Unknown(remote.Push(1.2, 0, 147.6)), "A remote teleport retained the previous trend.");
        var both = WarmTracker();
        Check(Unknown(both.Push(1.2, 50, 147.6)),
            "Equal displacement of both endpoints concealed a discontinuity.");
        Check(Unknown(both.Push(1.3, 50, 147.4)), "A teleport recovery reused the previous window.");
        return Task.CompletedTask;
    }

    public static Task TrendRejectsAgeBoundaryTimeRollbackAndLongGap()
    {
        var aged = WarmTracker();
        Check(Unknown(aged.Push(1.2, 0, 97.6, age: FeedSample.ProjectionLifetimeMs)),
            "A capture at the freshness boundary retained the trend.");
        var gap = WarmTracker();
        Check(Unknown(gap.Push(1.5, 0, 97)), "A gap without continuous fresh data bridged the old history.");
        var rollback = WarmTracker();
        Check(Unknown(rollback.Push(1.0, 0, 98)), "Backward capture time retained a distance estimate.");
        var simultaneous = WarmTracker();
        Check(Unknown(simultaneous.Push(1.1, 0, 97.8)),
            "A distinct sequence with no elapsed capture time was treated as movement.");
        foreach (double invalidAge in new[] { -1.0, double.NaN, double.PositiveInfinity })
        {
            var invalid = WarmTracker();
            Check(Unknown(invalid.Push(1.2, 0, 97.6, age: invalidAge)), "An invalid capture age was accepted.");
        }
        var future = WarmTracker();
        long received = future.BaseTimestamp + Ticks(1200);
        Check(Unknown(future.Tracker.Observe(future.Identity, 1, ++future.Sequence, received, 0,
            received - 1, new LivePosition(), new LivePosition { X = 98 })),
            "A future receipt timestamp was accepted.");
        return Task.CompletedTask;
    }

    public static Task TrendIdentityGenerationAndInvalidPositionBreakHistory()
    {
        var identity = WarmTracker();
        Check(Unknown(identity.Push(1.2, 0, 97.6, identity: identity.Identity with { Token = 2 })),
            "A reused entity ID inherited the previous opaque instance's trend.");
        var context = WarmTracker();
        Check(Unknown(context.Push(1.2, 0, 97.6,
            identity: context.Identity with { ContextId = Guid.NewGuid().ToString("N") })),
            "A new world inherited a previous trend.");
        var generation = WarmTracker();
        Check(Unknown(generation.Push(1.2, 0, 97.6, generation: 2)),
            "A new reader generation inherited a previous trend.");
        var invalid = WarmTracker();
        Check(Unknown(invalid.Push(1.2, double.NaN, 97.6)), "A non-finite endpoint retained a trend.");
        var legacy = WarmTracker();
        Check(Unknown(legacy.Push(1.2, 0, 97.6, identity: new PlayerIdentity("", 0, 12))),
            "A legacy player without an opaque identity received a trend.");
        return Task.CompletedTask;
    }

    public static Task TrendHistoryIsBoundedWithoutLosingHighRateMeasurements()
    {
        var f = new TrackerFixture();
        PlayerDistanceTrend trend = default;
        for (int i = 0; i < 1000; ++i)
        {
            trend = f.Push(i * 0.005, 0, 100 - i * 0.005);
            Check(f.Tracker.SampleCount <= PlayerDistanceTrendTracker.MaximumSamples, "Trend history grew without a bound.");
        }
        Check(trend.State == PlayerDistanceTrendState.Approaching && Close(trend.RelativeMetersPerSecond, -1),
            "High capture frequency shrank the history below the minimum measurable duration.");
        return Task.CompletedTask;
    }

    public static Task SessionTrendIsOptInAndConfinedToPinnedVisiblePlayer()
    {
        var f = new SessionFixture();
        f.Publish(0); var identity = f.PinFirst(); f.Warm();
        Check(f.Service.ReadSnapshot().Rows.All(row => Unknown(row.DistanceTrend)),
            "The optional feature changed the default player presentation.");
        f.Settings.ShowDistanceTrend = true; f.Apply(); f.Warm();
        var visible = f.Service.ReadSnapshot();
        Check(visible.Pinned is { } pinned && pinned.Identity == identity && Known(pinned.DistanceTrend) &&
            visible.Rows.Where(row => !row.Visual.Pinned).All(row => Unknown(row.DistanceTrend)),
            "Trend estimates were absent from the pin or leaked to all players.");
        f.Settings.ShowDistanceTrend = false; f.Apply();
        Check(f.Service.ReadSnapshot().Rows.All(row => Unknown(row.DistanceTrend)), "Disabling did not clear the estimate immediately.");
        f.Settings.ShowDistanceTrend = true; f.Apply(); f.Warm();
        f.Settings.ShowPinnedCard = false; f.Apply();
        Check(Unknown(f.Service.ReadSnapshot().Pinned!.DistanceTrend), "A disabled pinned card retained a trend.");
        f.Settings.ShowPinnedCard = true; f.Apply(); f.Warm(); f.Apply(allowed: false);
        Check(Unknown(f.Service.ReadSnapshot().Pinned!.DistanceTrend), "Disabling the player HUD retained a trend.");
        return Task.CompletedTask;
    }

    public static Task SessionPinHideAndClearNeverReuseAnOldTrend()
    {
        var f = WarmSession();
        var previous = f.Service.ReadSnapshot();
        var second = previous.Rows.Single(row => row.Identity.EntityId == 13).Identity;
        Check(f.Service.Pin(second) && f.Service.ReadSnapshot().Rows.All(row => Unknown(row.DistanceTrend)),
            "Changing the pin left the previous player's trend visible.");
        f.Warm(); Check(Known(f.Service.ReadSnapshot().Pinned!.DistanceTrend), "The new pin did not acquire its own trend.");
        Check(!f.Service.Pin(second) && Known(f.Service.ReadSnapshot().Pinned!.DistanceTrend),
            "An unchanged pin unnecessarily discarded a valid trend.");
        f.Service.SetHidden(second, true);
        Check(Unknown(f.Service.ReadSnapshot().Pinned!.DistanceTrend), "Hiding the pin retained its trend.");
        f.Service.SetHidden(second, false); f.Publish(100);
        Check(Unknown(f.Service.ReadSnapshot().Pinned!.DistanceTrend), "Unhiding revived pre-hide samples.");
        f.Warm(); f.Service.Clear(second);
        Check(f.Service.ReadSnapshot().Pinned == null && f.Service.ReadSnapshot().Rows.All(row => Unknown(row.DistanceTrend)),
            "Clearing player annotations left a stale trend.");
        f.Service.Pin(second); f.Warm(); f.Service.ClearAll();
        Check(f.Service.ReadSnapshot().Rows.All(row => Unknown(row.DistanceTrend)), "Clearing all annotations retained a trend.");
        return Task.CompletedTask;
    }

    public static Task SessionLossReplayAndAgedCaptureRestartTheTrendWindow()
    {
        var f = WarmSession();
        f.Service.ObserveUnavailable(1);
        Check(!f.Service.ReadSnapshot().HasCurrentData, "An unavailable feed still exposed a pinned trend.");
        f.Publish(100);
        Check(Unknown(f.Service.ReadSnapshot().Pinned!.DistanceTrend), "Recovery reused samples from before a failed read.");
        f.Warm();
        f.Service.Observe(f.Last!, 1, f.Settings, true);
        Check(Unknown(f.Service.ReadSnapshot().Pinned!.DistanceTrend), "A replay left the published trend active.");
        f.Warm();
        var older = f.Last!; f.Publish(100);
        f.Service.Observe(older, 1, f.Settings, true);
        Check(Unknown(f.Service.ReadSnapshot().Pinned!.DistanceTrend), "An out-of-order accepted-feed packet left the trend active.");
        f.Warm(); f.Publish(100, age: FeedSample.ProjectionLifetimeMs);
        Check(f.Service.ReadSnapshot().HasCurrentData && Unknown(f.Service.ReadSnapshot().Pinned!.DistanceTrend),
            "The trend accepted old data just because player rows were still within their two-second lifetime.");
        f.Publish(100);
        Check(Unknown(f.Service.ReadSnapshot().Pinned!.DistanceTrend), "One fresh capture after old data revived an estimate.");
        return Task.CompletedTask;
    }

    public static Task SessionExpiryKeepsOldSnapshotsImmutableAndCannotBeReversed()
    {
        var f = WarmSession();
        var original = f.Service.ReadSnapshot();
        f.Clock += Ticks(FeedSample.ProjectionLifetimeMs);
        var aged = f.Service.ReadSnapshot();
        Check(aged.HasCurrentData && Unknown(aged.Pinned!.DistanceTrend) && Known(original.Pinned!.DistanceTrend),
            "Trend expiry removed fresh-enough rows, mutated an old snapshot, or kept the old estimate.");
        f.Clock -= Ticks(200);
        Check(Unknown(f.Service.ReadSnapshot().Pinned!.DistanceTrend), "A backward clock revived an expired estimate.");
        f.Clock += Ticks(FeedSample.LifetimeMs);
        Check(!f.Service.ReadSnapshot().HasCurrentData, "Full source expiry retained a pinned card.");
        f.Service.Observe(new FeedSample(f.Last!.Snapshot, 0), 1, f.Settings, true);
        Check(!f.Service.ReadSnapshot().HasCurrentData, "Retransmission revived the expired source capture.");
        return Task.CompletedTask;
    }

    public static Task SessionContextInstanceAndGenerationClearTrendAndPin()
    {
        var instance = WarmSession();
        instance.FirstToken = 9; instance.Publish(100);
        Check(instance.Service.ReadSnapshot().Pinned == null &&
            instance.Service.ReadSnapshot().Rows.All(row => Unknown(row.DistanceTrend)),
            "A recycled player instance retained the pin's trend.");
        var context = WarmSession();
        context.Context = Guid.NewGuid().ToString("N"); context.Publish(100);
        Check(context.Service.ReadSnapshot().Pinned == null, "A world change retained a pinned trend.");
        var generation = WarmSession();
        generation.Service.Reset(2);
        generation.Service.Observe(generation.Last!, 1, generation.Settings, true);
        Check(!generation.Service.ReadSnapshot().HasCurrentData, "An old generation republished a trend.");
        generation.Generation = 2; generation.Publish(100);
        Check(generation.Service.ReadSnapshot().Pinned == null, "Reconnect retained a pin or trend.");
        var absence = WarmSession(); absence.IncludeFirst = false; absence.Publish(100);
        absence.IncludeFirst = true; absence.Publish(100);
        Check(absence.Service.ReadSnapshot().Pinned == null, "An accepted absence inherited its previous trend on return.");
        return Task.CompletedTask;
    }

    public static Task SessionTrendIgnoresWallClockAndDoesNotResetProximity()
    {
        var f = WarmSession();
        f.Name = "Nouveau nom"; f.Utc = new DateTime(1995, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        f.Publish(100);
        Check(Known(f.Service.ReadSnapshot().Pinned!.DistanceTrend) &&
            f.Service.ReadSnapshot().Pinned!.Name == "Nouveau nom",
            "A name or UTC clock change was mistaken for an identity or monotonic-time change.");
        var alerts = new SessionFixture();
        alerts.Settings.ProximityAlerts = true; alerts.Settings.AlertDistance = 200;
        alerts.Publish(0); alerts.PinFirst();
        alerts.Settings.ShowDistanceTrend = true; alerts.Apply(); alerts.Publish(100);
        var notice = alerts.Service.ReadSnapshot().Notice;
        Check(notice != null, "Enabling trend broke pending two-capture proximity confirmation.");
        alerts.Settings.ShowDistanceTrend = false; alerts.Apply();
        Check(alerts.Service.ReadSnapshot().Notice?.Sequence == notice!.Sequence,
            "Disabling trend cleared an independent proximity notice.");
        return Task.CompletedTask;
    }

    private static TrackerFixture WarmTracker()
    {
        var f = new TrackerFixture();
        for (int i = 0; i < 12; ++i) f.Push(i * 0.1, 0, 100 - i * 0.2);
        Check(Known(f.Tracker.Current), "The tracker test precondition was not met.");
        return f;
    }

    private static SessionFixture WarmSession()
    {
        var f = new SessionFixture(); f.Settings.ShowDistanceTrend = true;
        f.Publish(0); f.PinFirst(); f.Warm();
        Check(Known(f.Service.ReadSnapshot().Pinned!.DistanceTrend), "The session test precondition was not met.");
        return f;
    }

    private sealed class TrackerFixture
    {
        internal readonly PlayerDistanceTrendTracker Tracker = new();
        internal readonly long BaseTimestamp = Stopwatch.GetTimestamp();
        internal readonly PlayerIdentity Identity = new(Guid.NewGuid().ToString("N"), 1, 12);
        internal long Sequence;
        internal PlayerDistanceTrend Push(double seconds, double localX, double targetX, double age = 0,
            long? sequence = null, int generation = 1, PlayerIdentity? identity = null, double targetY = 0)
        {
            long received = BaseTimestamp + Ticks(seconds * 1000 + (double.IsFinite(age) ? age : 0));
            return Tracker.Observe(identity ?? Identity, generation, sequence ?? ++Sequence,
                received, age, received, new LivePosition { X = (float)localX },
                new LivePosition { X = (float)targetX, Y = (float)targetY });
        }
    }

    private sealed class SessionFixture
    {
        private static readonly FieldInfo ReceiptField = typeof(FeedSample).GetField("<ReceivedTimestamp>k__BackingField",
            BindingFlags.Instance | BindingFlags.NonPublic)!;
        private double seconds;
        private long sequence;
        internal long Clock = Stopwatch.GetTimestamp();
        internal int Generation = 1;
        internal long FirstToken = 1;
        internal bool IncludeFirst = true;
        internal string Context = Guid.NewGuid().ToString("N");
        internal string Name = "Joueur A";
        internal DateTime Utc = new(2026, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        internal readonly PlayerFeaturesSettings Settings = new();
        internal readonly PlayerSessionService Service;
        internal FeedSample? Last;
        internal SessionFixture() { Service = new PlayerSessionService(() => Clock); Service.Reset(Generation); }
        internal PlayerIdentity PinFirst()
        {
            var identity = Service.ReadSnapshot().Rows.First().Identity;
            Check(Service.Pin(identity), "The test could not pin its first player.");
            return identity;
        }
        internal void Apply(bool allowed = true) => Service.UpdatePreferences(Settings, allowed);
        internal void Warm() { for (int i = 0; i < 12; ++i) Publish(100); }
        internal void Publish(double elapsedMilliseconds, double age = 0)
        {
            Clock += Ticks(elapsedMilliseconds); seconds += elapsedMilliseconds / 1000.0;
            var entities = new[]
            {
                new LiveEntity { Kind = "player", EntityId = 12, IdentityToken = FirstToken, Name = Name,
                    Position = new LivePosition { X = (float)(100 - 2 * seconds) } },
                new LiveEntity { Kind = "player", EntityId = 13, IdentityToken = 2, Name = "Joueur B",
                    Position = new LivePosition { X = (float)(110 + seconds) } }
            };
            var snapshot = new LiveEntitySnapshot
            {
                Status = "ENTITES_LUES", LocalId = 1, LocalPosition = new LivePosition(),
                PlayerContextId = Context, PlayerCaptureSequence = ++sequence, CapturedUtc = Utc.AddTicks(sequence),
                Entities = entities.Where(entity => IncludeFirst || entity.EntityId != 12).ToList()
            };
            Last = new FeedSample(snapshot, age);
            ReceiptField.SetValue(Last, Clock);
            Service.Observe(Last, Generation, Settings, true);
        }
    }

    private static bool Unknown(PlayerDistanceTrend value) => value.State == PlayerDistanceTrendState.Unknown &&
        value.RelativeMetersPerSecond == null;
    private static bool Known(PlayerDistanceTrend value) => value.State != PlayerDistanceTrendState.Unknown &&
        value.RelativeMetersPerSecond.HasValue && double.IsFinite(value.RelativeMetersPerSecond.Value);
    private static bool Close(double? actual, double expected) => actual.HasValue && Math.Abs(actual.Value - expected) < 0.001;
    private static long Ticks(double milliseconds) => (long)Math.Round(milliseconds * Stopwatch.Frequency / 1000.0);
    private static void Check(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }
}
