#requires -Version 5.1
[CmdletBinding()]
param(
    [string]$GameDirectory = 'C:\Program Files (x86)\Steam\steamapps\common\7 Days To Die',
    [string]$OutputDirectory = (Join-Path $PSScriptRoot 'Package')
)

$ErrorActionPreference = 'Stop'
$expectedGameHash = 'cb54022ccc862aa673e0ee55dafe67d842b364c80df6916958d171e959656c58'
$managed = Join-Path $GameDirectory '7DaysToDie_Data\Managed'
$gameAssembly = Join-Path $managed 'Assembly-CSharp.dll'
$unityAssembly = Join-Path $managed 'UnityEngine.CoreModule.dll'
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw 'Installe le SDK .NET 10 x64 pour recompiler. Le module fourni est deja compile.'
}
if (-not (Test-Path -LiteralPath $gameAssembly -PathType Leaf) -or -not (Test-Path -LiteralPath $unityAssembly -PathType Leaf)) {
    throw 'Les deux DLL de reference du jeu sont absentes du dossier Managed choisi.'
}
$gameHash = (Get-FileHash -LiteralPath $gameAssembly -Algorithm SHA256).Hash.ToLowerInvariant()
if ($gameHash -ne $expectedGameHash) {
    throw 'Assembly du jeu differente du profil analyse V 3.4.0 (b10). Adapter et verifier le profil avant de recompiler.'
}
$project = Join-Path $PSScriptRoot 'SevenDaysDmaControl.csproj'
& dotnet build $project -c Release '-p:TreatWarningsAsErrors=true' "-p:GameManagedDirectory=$managed" --nologo
if ($LASTEXITCODE -ne 0) { throw ('Compilation echouee, code ' + $LASTEXITCODE) }
$dll = Join-Path $PSScriptRoot 'bin\Release\netstandard2.1\SevenDaysDmaControl.dll'
$info = Join-Path $PSScriptRoot 'Package\ModInfo.xml'
[void][System.IO.Directory]::CreateDirectory($OutputDirectory)
Copy-Item -LiteralPath $dll -Destination (Join-Path $OutputDirectory 'SevenDaysDmaControl.dll') -Force
if ([System.IO.Path]::GetFullPath($OutputDirectory).TrimEnd('\') -ne [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'Package')).TrimEnd('\')) {
    Copy-Item -LiteralPath $info -Destination (Join-Path $OutputDirectory 'ModInfo.xml') -Force
}
$files = [ordered]@{}
foreach ($name in @('SevenDaysDmaControl.dll', 'ModInfo.xml')) {
    $files[$name] = (Get-FileHash -LiteralPath (Join-Path $OutputDirectory $name) -Algorithm SHA256).Hash.ToLowerInvariant()
}
$manifest = [ordered]@{ Format = 'DMA7DTD.ModulePackage/1'; Version = '0.13.0'; GameAssemblySha256 = $expectedGameHash; Files = $files }
$json = $manifest | ConvertTo-Json -Depth 5
[System.IO.File]::WriteAllText((Join-Path $OutputDirectory 'module-package.json'), $json, (New-Object System.Text.UTF8Encoding($false)))
Write-Host ('Module cree : ' + (Join-Path $OutputDirectory 'SevenDaysDmaControl.dll'))
Write-Host 'Le script compile le module. Utilise Installer-module-jeu.cmd pour le copier dans les Mods du PC jeu.'
