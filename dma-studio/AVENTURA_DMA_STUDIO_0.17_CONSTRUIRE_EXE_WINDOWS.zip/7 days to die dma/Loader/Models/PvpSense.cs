using System;

namespace SevenDaysLoader;

// Extra, read-only DMA observations. No world/player memory write is made by
// this module; all options start disabled to preserve legacy capture budgets.
public sealed class PvpSenseSettings
{
    public bool ShowHeldItemId { get; set; }
    public bool ShowMovement { get; set; }
    public bool ShowFacing { get; set; }
    public int FacingConeDegrees { get; set; } = 45;
    public bool ShowZombieTarget { get; set; }
    public bool ZombieTargetSound { get; set; }
    public bool ShowBloodMoon { get; set; }
    public int SoundCooldownSeconds { get; set; } = 15;

    public void Normalize()
    {
        FacingConeDegrees = Math.Clamp(FacingConeDegrees, 10, 90);
        SoundCooldownSeconds = Math.Clamp(SoundCooldownSeconds, 5, 120);
    }
}
