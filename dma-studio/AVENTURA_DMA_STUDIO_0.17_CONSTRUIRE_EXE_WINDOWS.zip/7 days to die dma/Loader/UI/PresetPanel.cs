using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using SevenDaysLoader.Services;

namespace SevenDaysLoader.UI;

internal sealed class PresetPanel : Expander
{
    private readonly ILoaderController controller;
    private readonly Action beforeApply;
    private readonly Action afterApply;
    private readonly EspPresetStore? store;
    private readonly ComboBox selected = new() { DisplayMemberPath = "Name", SelectedValuePath = "Id", Margin = new Thickness(0, 0, 8, 0) };
    private readonly TextBox name = new() { MaxLength = EspPresetStore.MaximumNameLength, Margin = new Thickness(0, 0, 0, 8) };
    private readonly TextBox summary = new()
    {
        IsReadOnly = true, AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, Height = 138,
        FontSize = 11, VerticalScrollBarVisibility = ScrollBarVisibility.Visible,
        HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, Margin = new Thickness(0, 9, 0, 10)
    };
    private readonly TextBlock message = Theme.Text("", 11, Theme.Muted);
    private readonly List<Button> selectionButtons = new();
    private long observedRevision = -1;
    private bool updating;
    private bool busy;

    internal PresetPanel(ILoaderController controller, Action beforeApply, Action afterApply)
    {
        this.controller = controller;
        this.beforeApply = beforeApply;
        this.afterApply = afterApply;
        Header = "Préréglages";
        Foreground = Theme.Foreground;
        IsExpanded = false;
        Margin = new Thickness(0, 4, 0, 14);
        var content = new StackPanel { Margin = new Thickness(0, 10, 0, 0) };
        content.Children.Add(Theme.Text("Choisis une configuration, consulte son résumé puis applique-la. Sélectionner ou importer ne change pas l’affichage.", 11, Theme.Muted));
        var choose = new DockPanel();
        var apply = SelectionButton("Appliquer", Apply, primary: true);
        apply.Margin = new Thickness(0); DockPanel.SetDock(apply, Dock.Right);
        choose.Children.Add(apply); choose.Children.Add(selected);
        content.Children.Add(choose);
        content.Children.Add(summary);
        content.Children.Add(Theme.Text("Conserve la connexion, les écrans/fuser, l’adaptation de l’image, la position, le réseau et les raccourcis.", 10, Theme.Muted));
        content.Children.Add(Theme.Label("Nom pour enregistrer, dupliquer ou renommer"));
        name.ToolTip = "De 1 à 48 caractères. Laisse vide pour dupliquer avec un nom automatique.";
        System.Windows.Automation.AutomationProperties.SetName(name, "Nom du préréglage");
        content.Children.Add(name);
        var edit = new WrapPanel();
        edit.Children.Add(Command("Enregistrer l’actuel", () =>
        {
            var preset = RequireStore().Create(name.Text, EspPresetOptions.Capture(controller.Settings));
            Reload(preset.Id);
            ShowMessage("Préréglage enregistré : « " + preset.Name + " ».");
        }));
        var replace = SelectionButton("Mettre à jour", () =>
        {
            var preset = RequireStore().Replace(Selection().Id, EspPresetOptions.Capture(controller.Settings));
            Reload(preset.Id);
            ShowMessage("Contenu enregistré pour « " + preset.Name + " » à partir des réglages actifs.");
        });
        replace.ToolTip = "Remplace les options du préréglage sélectionné par tes réglages actifs, sans changer son nom.";
        edit.Children.Add(replace);
        edit.Children.Add(SelectionButton("Dupliquer", () =>
        {
            var preset = RequireStore().Duplicate(Selection().Id, name.Text);
            Reload(preset.Id);
            ShowMessage("Copie enregistrée : « " + preset.Name + " ».");
        }));
        edit.Children.Add(SelectionButton("Renommer", () =>
        {
            var preset = RequireStore().Rename(Selection().Id, name.Text);
            Reload(preset.Id);
            ShowMessage("Préréglage renommé : « " + preset.Name + " ».");
        }));
        content.Children.Add(edit);
        var files = new WrapPanel();
        files.Children.Add(SelectionButton("Exporter…", Export));
        files.Children.Add(Command("Importer…", Import));
        files.Children.Add(Command("Actualiser", () => Reload()));
        content.Children.Add(files);
        message.Height = 48;
        message.Margin = new Thickness(0, 2, 0, 0);
        message.LineHeight = 16;
        message.TextTrimming = TextTrimming.CharacterEllipsis;
        message.ClipToBounds = true;
        content.Children.Add(message);
        Content = content;
        selected.SelectionChanged += (_, _) =>
        {
            if (updating) return;
            UpdateSummary(resetScroll: true);
            if (selected.SelectedItem is EspPreset preset)
                ShowMessage("Sélection : « " + preset.Name + " ». Clique sur Appliquer pour l’utiliser.");
        };
        selected.ToolTipOpening += (_, _) => selected.ToolTip = (selected.SelectedItem as EspPreset)?.Name ?? "Choisir un préréglage";
        selected.ToolTip = "Choisir un préréglage";
        try
        {
            store = new EspPresetStore(controller.SettingsDirectory);
            Reload();
        }
        catch (Exception e) { ShowMessage("Préréglages indisponibles : " + e.Message, error: true); UpdateSummary(); }
    }

    internal void Refresh()
    {
        if (store == null || busy || updating || !IsVisible || store.Revision == observedRevision) return;
        // Background catalogue changes must not overwrite a name being typed,
        // an open choice, or the summary the user is reading/copying.
        if (name.IsKeyboardFocusWithin || selected.IsDropDownOpen || summary.IsMouseOver ||
            summary.IsKeyboardFocusWithin || summary.SelectionLength > 0) return;
        try { Reload(); }
        catch (Exception e) { observedRevision = store.Revision; ShowMessage("Catalogue non actualisé : " + e.Message, error: true); }
    }

    private void Reload(string? requestedId = null)
    {
        var loaded = RequireStore().Load();
        string? id = requestedId ?? (selected.SelectedItem as EspPreset)?.Id;
        updating = true;
        try
        {
            selected.ItemsSource = loaded.Presets;
            selected.SelectedItem = loaded.Presets.FirstOrDefault(p => p.Id == id) ?? loaded.Presets.FirstOrDefault();
            observedRevision = loaded.Revision;
            UpdateSummary(resetScroll: requestedId != null);
            ShowMessage(loaded.Warning.Length > 0 ? loaded.Warning : "Catalogue relu. La sélection n’a pas été appliquée.");
        }
        finally { updating = false; }
    }

    private void Apply()
    {
        // Apply exactly the snapshot whose summary is displayed. A background
        // rename/update in another panel must not silently change that choice.
        var preset = Selection().Copy();
        beforeApply();
        preset.Options.ApplyTo(controller.Settings);
        controller.SaveSettings();
        afterApply();
        ShowMessage("« " + preset.Name + " » appliqué aux réglages actifs.");
    }

    private void Import()
    {
        var dialog = new Microsoft.Win32.OpenFileDialog
        {
            Title = "Importer un préréglage ESP/radar", Filter = "Préréglage ESP (*.json)|*.json",
            CheckFileExists = true, Multiselect = false
        };
        var owner = Window.GetWindow(this);
        if ((owner == null ? dialog.ShowDialog() : dialog.ShowDialog(owner)) != true) return;
        var preset = RequireStore().Import(dialog.FileName);
        Reload(preset.Id);
        IsExpanded = true;
        ShowMessage("Importé : « " + preset.Name + " ». Consulte le résumé ; Appliquer reste nécessaire.");
    }

    private void Export()
    {
        var preset = Selection();
        string safeName = string.Concat(preset.Name.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
        var dialog = new Microsoft.Win32.SaveFileDialog
        {
            Title = "Exporter le préréglage sélectionné", Filter = "Préréglage ESP (*.json)|*.json",
            FileName = "7DTD-" + safeName + ".json", DefaultExt = ".json", AddExtension = true,
            OverwritePrompt = true
        };
        var owner = Window.GetWindow(this);
        if ((owner == null ? dialog.ShowDialog() : dialog.ShowDialog(owner)) != true) return;
        RequireStore().Export(preset.Id, dialog.FileName);
        ShowMessage("Préréglage exporté : " + Path.GetFileName(dialog.FileName) + ".");
    }

    private Button SelectionButton(string text, Action action, bool primary = false)
    {
        var button = Command(text, action, primary);
        selectionButtons.Add(button);
        return button;
    }

    private Button Command(string text, Action action, bool primary = false) => Theme.Button(text, () =>
    {
        if (busy) return;
        busy = true;
        try { action(); }
        catch (Exception e) { ShowMessage(e.Message, error: true); }
        finally { busy = false; }
    }, primary);

    private EspPreset Selection() => selected.SelectedItem as EspPreset
        ?? throw new InvalidOperationException("Sélectionne d’abord un préréglage.");
    private EspPresetStore RequireStore() => store ?? throw new InvalidOperationException("Le dossier des préréglages est indisponible.");
    private void ShowMessage(string text, bool error = false)
    {
        message.Text = text;
        message.ToolTip = text;
        message.Foreground = error ? Theme.Orange : Theme.Muted;
    }
    private void UpdateSummary(bool resetScroll = false)
    {
        bool hasSelection = selected.SelectedItem is EspPreset;
        foreach (var button in selectionButtons) button.IsEnabled = hasSelection;
        string text = selected.SelectedItem is EspPreset preset ? Summarize(preset) : "Aucun préréglage sélectionné.";
        double vertical = summary.VerticalOffset;
        if (summary.Text != text) summary.Text = text;
        summary.ScrollToVerticalOffset(resetScroll ? 0 : vertical);
    }

    private static string Summarize(EspPreset preset)
    {
        static string State(bool value) => value ? "oui" : "non";
        static string Number(double value) => value.ToString("0.##", CultureInfo.GetCultureInfo("fr-FR"));
        var options = preset.Options;
        var text = new StringBuilder();
        text.AppendLine(preset.Name);
        text.AppendLine("Affichage général : " + State(options.EspEnabled) + " · ESP : " + State(options.ShowProjectedEsp));
        foreach (var (name, profile) in new[] { ("Joueurs", options.PlayerEsp), ("Zombies", options.ZombieEsp) })
        {
            text.AppendLine(name + " : " + (profile.Enabled ? "activés" : "masqués") + " · " + profile.MaxDistance + " m · " + profile.Color);
            text.AppendLine("  Cadres : " + State(profile.ShowBoxes) + " / " + (profile.BoxStyle == "corners" ? "coins" : "complets") +
                " · noms : " + State(profile.ShowNames) + " · vie : " + State(profile.ShowHealth));
            text.AppendLine("  Distances : " + State(profile.ShowDistances) + " · liaisons : " + State(profile.ShowTracers) +
                " · texte : " + Number(profile.FontSize) + " · épaisseur : " + Number(profile.LineThickness));
        }
        text.Append("Radar : ").Append(State(options.ShowRadar)).Append(" · ").Append(options.RadarSize).Append(" px · ")
            .Append(Number(options.RadarOpacity * 100)).Append(" % · état : ").Append(State(options.ShowHud));
        return text.ToString();
    }
}
