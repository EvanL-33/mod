using System;

namespace SevenDaysLoader;

// All additions are opt-in so older profiles keep their existing appearance.
// The same palette is ordered by the selected measurement: low HP/near,
// intermediate, then high HP/far. A profile never selects two modes at once.
public sealed class EntityDisplayRulesSettings
{
    public bool HeightFilterEnabled { get; set; }
    public int MaxHeightDifferenceMeters { get; set; } = 10;
    public bool ExemptPinnedFromHeightFilter { get; set; }
    public bool ShowHeightIndicator { get; set; }
    public string ColorMode { get; set; } = "none";
    public int HealthLowPercent { get; set; } = 30;
    public int HealthHighPercent { get; set; } = 70;
    public int DistanceNearMeters { get; set; } = 25;
    public int DistanceFarMeters { get; set; } = 100;
    public string LowColor { get; set; } = "#F881AA";
    public string MiddleColor { get; set; } = "#FFE27A";
    public string HighColor { get; set; } = "#9BF0A3";

    public EntityDisplayRulesSettings Copy() => (EntityDisplayRulesSettings)MemberwiseClone();

    public void Normalize()
    {
        MaxHeightDifferenceMeters = Math.Clamp(MaxHeightDifferenceMeters, 1, 500);
        ColorMode = ColorMode?.Trim().ToLowerInvariant() ?? "none";
        if (ColorMode != "none" && ColorMode != "health" && ColorMode != "distance") ColorMode = "none";
        HealthLowPercent = Math.Clamp(HealthLowPercent, 1, 99);
        HealthHighPercent = Math.Clamp(HealthHighPercent, HealthLowPercent + 1, 100);
        DistanceNearMeters = Math.Clamp(DistanceNearMeters, 0, 4999);
        DistanceFarMeters = Math.Clamp(DistanceFarMeters, DistanceNearMeters + 1, 5000);
        LowColor = NormalizeColor(LowColor, "#F881AA");
        MiddleColor = NormalizeColor(MiddleColor, "#FFE27A");
        HighColor = NormalizeColor(HighColor, "#9BF0A3");
    }

    public bool IsValid(out string reason)
    {
        reason = string.Empty;
        if (MaxHeightDifferenceMeters is < 1 or > 500)
            reason = "Le filtre de hauteur doit être compris entre 1 et 500 m.";
        else if (ColorMode != "none" && ColorMode != "health" && ColorMode != "distance")
            reason = "Le mode de couleur doit être none, health ou distance.";
        else if (HealthLowPercent is < 1 or > 99 || HealthHighPercent <= HealthLowPercent || HealthHighPercent > 100)
            reason = "Les seuils de PV doivent être ordonnés entre 1 et 100 %.";
        else if (DistanceNearMeters is < 0 or > 4999 || DistanceFarMeters <= DistanceNearMeters || DistanceFarMeters > 5000)
            reason = "Les seuils de distance doivent être ordonnés entre 0 et 5 000 m.";
        else if (!IsColor(LowColor) || !IsColor(MiddleColor) || !IsColor(HighColor))
            reason = "Les couleurs des règles doivent respecter le format #RRGGBB.";
        return reason.Length == 0;
    }

    internal static bool IsColor(string? value)
    {
        if (value == null || value.Length != 7 || value[0] != '#') return false;
        for (int i = 1; i < value.Length; ++i)
            if (!Uri.IsHexDigit(value[i])) return false;
        return true;
    }

    private static string NormalizeColor(string? value, string fallback) =>
        IsColor(value?.Trim()) ? value!.Trim().ToUpperInvariant() : fallback;
}
