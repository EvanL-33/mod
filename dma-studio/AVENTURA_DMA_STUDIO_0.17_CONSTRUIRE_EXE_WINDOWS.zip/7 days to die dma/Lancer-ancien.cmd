@echo off
setlocal
set "PS_EXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "PS_EXE=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS_EXE%" (
    echo Windows PowerShell est introuvable.
    pause
    exit /b 1
)
rem Bypass ne concerne que ce processus ; aucune strategie globale n'est modifiee.
"%PS_EXE%" -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Launcher.ps1"
set "LAUNCH_EXIT=%ERRORLEVEL%"
if not "%LAUNCH_EXIT%"=="0" (
    echo Le lanceur s'est termine avec une erreur. Lis le message ci-dessus.
    pause
)
exit /b %LAUNCH_EXIT%
