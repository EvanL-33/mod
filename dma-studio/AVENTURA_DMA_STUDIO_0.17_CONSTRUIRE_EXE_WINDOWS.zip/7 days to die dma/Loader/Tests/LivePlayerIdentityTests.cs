using System;
using System.Linq;
using System.Threading.Tasks;
using SevenDaysEsp;

internal static class LivePlayerIdentityTests
{
    public static Task StableInstancesKeepOpaqueTokensWithoutMutatingSnapshots()
    {
        var f = new LiveReaderTests.Fixture();
        var reader = f.Reader();
        var first = Accepted(reader);
        var original = Player(first);
        Check(Guid.TryParse(first.PlayerContextId, out _) && original.IdentityToken > 0,
            "A valid capture did not receive an opaque context/token.");
        Check(first.Entities.Single(entity => entity.Kind == "zombie").IdentityToken == 0,
            "A non-player received a player annotation identity.");
        f.Memory.U64(f.OtherPlayer + 0x50, f.ManagedString("Nom renouvelé"));
        f.Memory.Vector(f.OtherPlayer + 0x1C, 115, 30, -20);
        f.Memory.Vector(f.OtherPlayer + LiveReaderTests.Fixture.BoundsOffset, 115, 31, -20);
        var changed = Accepted(reader);
        Check(changed.PlayerContextId == first.PlayerContextId && Player(changed).IdentityToken == original.IdentityToken,
            "A presentation/position change replaced a stable player's identity.");
        Check(original.Name != Player(changed).Name && original.Position.X == 110,
            "A later capture mutated a previously published entity.");
        return Task.CompletedTask;
    }

    public static Task PointerClassAndAcceptedAbsenceReplaceTokens()
    {
        var f = new LiveReaderTests.Fixture();
        var reader = f.Reader();
        var first = Accepted(reader);
        long original = Player(first).IdentityToken;
        ulong replacement = f.Memory.Allocate(LiveReaderTests.Fixture.EntitySize);
        f.Memory.WriteBytes(replacement, f.Memory.Read(f.OtherPlayer, LiveReaderTests.Fixture.EntitySize));
        f.Memory.U64(f.Array + 0x28, replacement);
        var newPointer = Accepted(reader);
        Check(Player(newPointer).IdentityToken != original && newPointer.PlayerContextId == first.PlayerContextId,
            "Reusing a game ID on another instance inherited the original token.");
        f.Memory.U64(replacement, f.LocalVtable); // Same player ancestry, different actual runtime class.
        var newClass = Accepted(reader);
        Check(Player(newClass).IdentityToken != Player(newPointer).IdentityToken,
            "A runtime class change retained a player's old annotation identity.");
        f.Memory.Byte(replacement + 0x29, 1);
        var absent = Accepted(reader);
        Check(absent.PlayersCount == 0 && absent.PlayerContextId == first.PlayerContextId,
            "An accepted empty player observation changed the whole world context.");
        f.Memory.Byte(replacement + 0x29, 0);
        var returned = Accepted(reader);
        Check(Player(returned).IdentityToken != Player(newClass).IdentityToken,
            "Reappearing after an accepted absence retained annotations.");
        Check(Player(first).IdentityToken == original, "Token reassignment edited an old published snapshot.");
        return Task.CompletedTask;
    }

    public static Task RejectedCaptureCannotCommitIdentityChanges()
    {
        var f = new LiveReaderTests.Fixture();
        var reader = f.Reader();
        var first = Accepted(reader);
        long original = Player(first).IdentityToken;
        ulong replacement = f.Memory.Allocate(LiveReaderTests.Fixture.EntitySize);
        f.Memory.WriteBytes(replacement, f.Memory.Read(f.OtherPlayer, LiveReaderTests.Fixture.EntitySize));
        f.Memory.U64(f.Array + 0x28, replacement);
        reader.CameraCapture = (_, _, _) => { f.MoveOrigin(1, 0, 0); return null; };
        var rejected = reader.Capture();
        Check(rejected.Status != "ENTITES_LUES" && rejected.Entities.Count == 0 && rejected.PlayerContextId == null,
            "A rejected final consistency check exposed candidate identities.");
        reader.CameraCapture = null;
        f.MoveOrigin(0, 0, 0);
        f.Memory.U64(f.Array + 0x28, f.OtherPlayer);
        var restored = Accepted(reader);
        Check(restored.PlayerContextId == first.PlayerContextId && Player(restored).IdentityToken == original,
            "A failed capture committed its candidate identity or removed the previous stable instance.");

        // An incomplete world/local transition must also leave the accepted
        // context untouched when the same coherent context is recovered.
        f.Memory.U64(f.Manager + LiveReaderTests.Fixture.ManagerWorldOffset, 0);
        Check(reader.Capture().PlayerContextId == null, "An unavailable world exposed a context identity.");
        f.Memory.U64(f.Manager + LiveReaderTests.Fixture.ManagerWorldOffset, f.World);
        Check(Accepted(reader).PlayerContextId == first.PlayerContextId,
            "A temporary failed root read changed the accepted context.");
        return Task.CompletedTask;
    }

    public static Task WorldLocalPointerAndLocalIdChangesReplaceContext()
    {
        foreach (Action<LiveReaderTests.Fixture> change in new Action<LiveReaderTests.Fixture>[]
        {
            f => f.ReplaceWorld(), f => f.ReplaceLocalPlayer(), f => f.SetLocalId(101)
        })
        {
            var f = new LiveReaderTests.Fixture();
            var reader = f.Reader();
            var first = Accepted(reader);
            change(f);
            var next = Accepted(reader);
            Check(next.PlayerContextId != first.PlayerContextId && Guid.TryParse(next.PlayerContextId, out _) &&
                Player(next).IdentityToken != Player(first).IdentityToken,
                "A changed world/local reference/local ID retained the old context/token.");
        }
        return Task.CompletedTask;
    }

    public static Task ReadinessConfirmationPublishesIdentityOnlyAfterAcceptance()
    {
        var f = new LiveReaderTests.Fixture(); f.SetFlags(1, 0);
        var reader = f.Reader();
        for (int i = 0; i < 2; ++i)
        {
            var pending = reader.Capture();
            Check(!pending.Diagnostics.CanPublish && pending.PlayerContextId == null && pending.Entities.Count == 0,
                "A pending readiness confirmation allocated a public identity.");
        }
        var accepted = Accepted(reader);
        Check(Guid.TryParse(accepted.PlayerContextId, out _) && Player(accepted).IdentityToken > 0,
            "The fully confirmed capture did not acquire its identity.");
        return Task.CompletedTask;
    }

    private static LiveEntitySnapshot Accepted(LiveEntityReader reader)
    {
        var result = reader.Capture();
        Check(result.Status == "ENTITES_LUES" && result.Diagnostics.CanPublish, "Synthetic capture failed: " + result.Message);
        return result;
    }
    private static LiveEntity Player(LiveEntitySnapshot snapshot) => snapshot.Entities.Single(entity => entity.Kind == "player");
    private static void Check(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }
}
