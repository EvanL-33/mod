using System;
using System.Diagnostics;
using System.IO;

namespace SevenDaysLoader;

// Experimental client-local values. These never grant server authority.
public enum PlayerDmaStatKind { Health = 1, Stamina = 2, Food = 3, Water = 4, SkillPoints = 5, Level = 6 }

public sealed class PlayerDmaStatRequest
{
    public long Sequence { get; set; }
    public string RequestId { get; set; } = "";
    public uint ExpectedProcessId { get; set; }
    public string ExpectedPlayerContextId { get; set; } = "";
    public int ExpectedPlayerId { get; set; } = -1;
    public PlayerDmaStatKind Stat { get; set; }
    public float? DesiredValue { get; set; } // null = observation ONLY
    public long RequestedTimestamp { get; set; }
    public PlayerDmaStatRequest Copy() => (PlayerDmaStatRequest)MemberwiseClone();
}

public sealed class PlayerDmaStatResult
{
    public long Sequence { get; set; }
    public string RequestId { get; set; } = "";
    public uint ProcessId { get; set; }
    public string PlayerContextId { get; set; } = "";
    public PlayerDmaStatKind Stat { get; set; }
    public float? DesiredValue { get; set; }
    public float? ObservedValue { get; set; }
    public float? ObservedMaximum { get; set; }
    public bool WriteAttempted { get; set; }
    public string Code { get; set; } = "INDISPONIBLE";
    public string Message { get; set; } = "Aucune lecture confirmée.";
}

public static class PlayerDmaStatPolicy
{
    public const int MaxAgeMs = 3000;
    public static bool Known(PlayerDmaStatKind k) => k is PlayerDmaStatKind.Health or PlayerDmaStatKind.Stamina or
        PlayerDmaStatKind.Food or PlayerDmaStatKind.Water or PlayerDmaStatKind.SkillPoints or PlayerDmaStatKind.Level;

    public static void Validate(PlayerDmaStatRequest? request)
    {
        if (request == null || request.Sequence <= 0 || !CreativeMenuProtocol.IsGuidN(request.RequestId) ||
            request.ExpectedProcessId == 0 || !CreativeMenuProtocol.IsGuidN(request.ExpectedPlayerContextId) ||
            request.ExpectedPlayerId < 0 || !Known(request.Stat) || request.RequestedTimestamp <= 0 ||
            (request.DesiredValue.HasValue && (!float.IsFinite(request.DesiredValue.Value) ||
                request.DesiredValue.Value < 0 || request.Stat == PlayerDmaStatKind.Level || request.DesiredValue.Value >
                (request.Stat == PlayerDmaStatKind.SkillPoints ? 9999f : 10000f))) ||
            (request.Stat == PlayerDmaStatKind.SkillPoints && request.DesiredValue.HasValue &&
                request.DesiredValue.Value != MathF.Truncate(request.DesiredValue.Value)))
            throw new InvalidDataException("Demande de statistique DMA incorrecte ou hors limites.");
    }

    public static bool IsExpired(PlayerDmaStatRequest request, long now) => request.RequestedTimestamp <= 0 ||
        now < request.RequestedTimestamp || Stopwatch.GetElapsedTime(request.RequestedTimestamp, now).TotalMilliseconds >= MaxAgeMs;

    public static bool IsPlausibleResult(PlayerDmaStatResult? result) => result != null && result.Sequence > 0 &&
        CreativeMenuProtocol.IsGuidN(result.RequestId) && CreativeMenuProtocol.IsGuidN(result.PlayerContextId) &&
        result.ProcessId > 0 && Known(result.Stat) && result.Code != null && result.Code.Length <= 80 &&
        result.Message != null && result.Message.Length <= 1024 &&
        (!result.ObservedValue.HasValue || float.IsFinite(result.ObservedValue.Value)) &&
        (!result.ObservedMaximum.HasValue || float.IsFinite(result.ObservedMaximum.Value));
}
