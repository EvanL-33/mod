using System;

namespace SevenDaysLoader.UI;

// Presentation only. The camera/ESP freshness checks never use this class.
// A rapidly alternating acquisition result keeps one readable summary while
// Detail always exposes the latest exact diagnostic for the tooltip.
internal sealed class MenuStatusPresenter
{
    internal const int SettleMilliseconds = 600;
    private string shownKey = "";
    private string pendingKey = "";
    private long pendingSince;
    private long lastObservation;
    private bool observed;
    internal string Summary { get; private set; } = "";
    internal string Detail { get; private set; } = "";

    internal bool Update(string key, string summary, string detail, long nowMilliseconds, bool immediate = false)
    {
        ArgumentNullException.ThrowIfNull(key);
        ArgumentNullException.ThrowIfNull(summary);
        ArgumentNullException.ThrowIfNull(detail);
        Detail = detail;
        if (observed && nowMilliseconds < lastObservation)
        {
            pendingKey = "";
            pendingSince = nowMilliseconds;
        }
        lastObservation = nowMilliseconds;
        bool first = !observed;
        observed = true;
        if (first || immediate) return Commit(key, summary);
        if (key == shownKey)
        {
            pendingKey = "";
            return false;
        }
        if (pendingKey != key)
        {
            pendingKey = key;
            pendingSince = nowMilliseconds;
            return false;
        }
        if (nowMilliseconds - pendingSince < SettleMilliseconds) return false;
        return Commit(key, summary);
    }

    private bool Commit(string key, string summary)
    {
        bool changed = Summary != summary;
        shownKey = key;
        Summary = summary;
        pendingKey = "";
        return changed;
    }
}
