using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using SevenDaysEsp;
using SevenDaysDmaControl;

namespace SevenDaysLoader.Services;

public static class DmaWorker
{
    public static async Task<int> RunAsync(string pipeName)
    {
        if (string.IsNullOrWhiteSpace(pipeName) || !pipeName.StartsWith("SevenDaysLoader-", StringComparison.Ordinal) ||
            pipeName.Length != 48) return 2;
        using var connection = new NamedPipeClientStream(".", pipeName, PipeDirection.InOut, PipeOptions.Asynchronous);
        using var cancelled = new CancellationTokenSource();
        try
        {
            using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(10));
            await connection.ConnectAsync(deadline.Token).ConfigureAwait(false);
            WorkerStart settings = await Wire.ReadAsync<WorkerStart>(connection, deadline.Token).ConfigureAwait(false);
            if (settings.IntervalMs < 50 || settings.IntervalMs > 2000 ||
                string.IsNullOrWhiteSpace(settings.ReportDirectory) || !Path.IsPathFullyQualified(settings.ReportDirectory)) return 2;
            var controls = new WorkerReadOptionsState(settings.ReadOptions);
            Task monitor = WorkerControlLoop.MonitorAsync(connection, controls, cancelled);
            try { return await ReadGameAsync(connection, settings, controls, cancelled.Token).ConfigureAwait(false); }
            finally
            {
                cancelled.Cancel();
                try { await monitor.ConfigureAwait(false); } catch (OperationCanceledException) { }
            }
        }
        catch (OperationCanceledException) { return 0; }
        catch (Exception) { return 6; }
    }

    private static async Task<int> ReadGameAsync(Stream pipe, WorkerStart settings,
        WorkerReadOptionsState controls, CancellationToken token)
    {
        var report = new SessionReport
        {
            OutputAtConnection = settings.OutputAtConnection,
            RequestedIntervalMs = settings.IntervalMs
        };
        string reportPath = Path.Combine(settings.ReportDirectory,
            "rapport-live-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N")[..6] + ".json");
        DmaMemory? memory = null;
        bool sessionActive = false;
        int code = 6;
        bool cameraAttempted = false;
        NativeCameraReader? nativeCamera = null;
        NativeCameraDiagnostics? countedCameraDiagnostics = null;
        string? nativeCameraInitializationFailure = null;
        string lastReportState = "";
        var reportClock = Stopwatch.StartNew();
        long previousCaptureStarted = 0;

        string CaptureReportState() => report.Status + "\u001f" + report.LastCaptureDiagnostics?.Code +
            "\u001f" + report.LastCaptureDiagnostics?.Stage + "\u001f" + report.AppliedReadOptionsRevision;

        bool CaptureReportDue() => lastReportState != CaptureReportState() || reportClock.ElapsedMilliseconds >= 10000;

        void SetStoppedReport()
        {
            report.ControlFailure = controls.ControlFailure;
            report.Status = report.ControlFailure == null ? "ARRETE" : "ERREUR_CONTROLE";
            report.Message = report.ControlFailure ?? "Lecture arrêtée par le lanceur.";
            if (report.ControlFailure != null) report.Error = report.ControlFailure;
            code = report.ControlFailure != null ? 6 : report.FramesRead > 0 ? 0 : 7;
        }

        async Task SendAsync(string kind, string stage, string message, LiveEntitySnapshot? frame = null, double age = 0, long captureTimestamp = 0,
            CreativeMenuResult? creativeResult = null, PlayerControlObservation? playerObservation = null,
            PlayerControlSubmission? playerSubmission = null, PlayerDmaStatResult? statResult = null)
        {
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(token);
            timeout.CancelAfter(TimeSpan.FromSeconds(2));
            await Wire.WriteAsync(pipe, new WorkerMessage
            {
                Kind = kind, Stage = stage, Message = message,
                HasDmaSession = sessionActive,
                ProcessId = report.ProcessId ?? 0,
                GameVersion = report.GameVersion?.DisplayVersion ?? "",
                MemProcFsVersion = report.MemProcFsVersion ?? "",
                ReportPath = reportPath, Frame = frame, AgeMs = age,
                ProjectionMessage = report.ProjectionMessage,
                CapturedTimestamp = captureTimestamp,
                CreativeResult = creativeResult, PlayerControlObservation = playerObservation, PlayerControlSubmission = playerSubmission,
                PlayerDmaStatResult = statResult
            }, timeout.Token).ConfigureAwait(false);
        }

        void SaveReport()
        {
            string temporary = reportPath + ".tmp";
            try
            {
                report.UpdatedUtc = DateTime.UtcNow;
                report.HasDmaSession = sessionActive;
                report.ReportSaveError = null;
                if (memory != null)
                {
                    report.ReadCalls = memory.ReadCalls;
                    report.ReadBytes = memory.ReadBytes;
                }
                Directory.CreateDirectory(settings.ReportDirectory);
                string json = JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true, MaxDepth = 48 });
                File.WriteAllText(temporary, json, new UTF8Encoding(false));
                File.Move(temporary, reportPath, true);
                report.ReportSaveError = null;
            }
            catch (Exception e) when (e is IOException || e is UnauthorizedAccessException || e is JsonException || e is NotSupportedException)
            {
                report.ReportSaveError = e.GetBaseException().Message;
            }
            finally
            {
                // Pace failed writes as well; a persistent disk error must not
                // trigger another attempt for every unchanged capture.
                lastReportState = CaptureReportState();
                reportClock.Restart();
                try { if (File.Exists(temporary)) File.Delete(temporary); } catch (IOException) { } catch (UnauthorizedAccessException) { }
            }
        }

        try
        {
            report.Status = "CONNEXION";
            report.Message = "Ouverture MemProcFS et recherche de 7DaysToDie.exe…";
            SaveReport();
            if (report.ReportSaveError != null)
                await SendAsync("status", "ERREUR_RAPPORT", "Rapport non enregistré : " + report.ReportSaveError + ". La lecture peut continuer.").ConfigureAwait(false);
            await SendAsync("status", report.Status, report.Message).ConfigureAwait(false);
            token.ThrowIfCancellationRequested();
            // Open the native session once. Waiting for a game must not close and
            // reopen the FPGA every two seconds.
            memory = new DmaMemory(settings.SdkDirectory, settings.Device, false);
            sessionActive = true;
            report.MemProcFsVersion = memory.VmmVersion;
            report.Status = "DMA_CONNECTEE";
            report.Message = "Session DMA ouverte. Recherche automatique du jeu…";
            SaveReport();
            await SendAsync("status", report.Status, report.Message).ConfigureAwait(false);
            while (!memory.TryFindGameProcess())
            {
                token.ThrowIfCancellationRequested();
                report.ProcessId = null;
                bool firstWait = report.Status != "ATTENTE_JEU";
                report.Status = "ATTENTE_JEU";
                report.Message = "DMA ouverte. En attente de 7DaysToDie.exe dans la vue mémoire ; lance le jeu sur le PC cible.";
                if (firstWait) SaveReport();
                await SendAsync("status", report.Status, report.Message).ConfigureAwait(false);
                await Task.Delay(2000, token).ConfigureAwait(false);
            }
            token.ThrowIfCancellationRequested();
            uint gameProcessId = memory.ProcessId;
            report.ProcessId = gameProcessId;
            await SendAsync("status", "JEU_TROUVE", "Jeu détecté : PID " + gameProcessId + ".").ConfigureAwait(false);

            // A process can be visible before Unity/Mono and the managed game
            // classes are ready. Give startup a bounded window, retaining the
            // latest metadata in the report if it never becomes compatible.
            var loadingClock = Stopwatch.StartNew();
            string loadingDetail = "Attente des modules Unity et Mono.";
            LiveEntityReader? reader = null;
            while (reader == null)
            {
                token.ThrowIfCancellationRequested();
                if (!memory.TryFindGameProcess() || memory.ProcessId != gameProcessId)
                    throw new GameProcessLostException("Le processus du jeu a quitté la session ou a changé pendant son chargement.");
                bool modulesReady = memory.ModuleBase("7DaysToDie.exe") != 0 &&
                    memory.ModuleBase("UnityPlayer.dll") != 0 && memory.ModuleBase("mono-2.0-bdwgc.dll") != 0;
                if (modulesReady)
                {
                    await SendAsync("status", "ANALYSE_MONO", "Lecture des métadonnées de cette session…").ConfigureAwait(false);
                    report.Mono = new MonoInspector(memory).Inspect();
                    token.ThrowIfCancellationRequested();
                    report.GameVersion = new MonoGameVersionReader(memory).Inspect(report.Mono);
                    token.ThrowIfCancellationRequested();
                    if (report.GameVersion.Status == "VERSION_JEU_LUE")
                    {
                        if (!string.Equals(report.GameVersion.DisplayVersion, "V 3.4.0 (b10)", StringComparison.Ordinal))
                            throw new IOException("Profil prévu pour V 3.4.0 (b10). Version lue : " + report.GameVersion.DisplayVersion + ". Le rapport permet d'adapter le profil.");
                        try { reader = new LiveEntityReader(memory, report.Mono); }
                        catch (Exception e) when (e is IOException || e is InvalidDataException || e is InvalidOperationException || e is ArgumentException)
                        { loadingDetail = e.GetBaseException().Message; }
                    }
                    else loadingDetail = "Version ou métadonnées non confirmées : " + report.GameVersion.Message;
                }
                if (reader != null) break;
                if (loadingClock.Elapsed >= TimeSpan.FromSeconds(60))
                    throw new IOException("Chargement du jeu non confirmé après 60 secondes. Charge une partie puis clique sur Reconnecter. " + loadingDetail);
                report.Status = "ATTENTE_CHARGEMENT_JEU";
                report.Message = "Jeu détecté, attente du chargement. " + loadingDetail;
                SaveReport();
                await SendAsync("status", report.Status, report.Message).ConfigureAwait(false);
                await Task.Delay(2000, token).ConfigureAwait(false);
            }
            SaveReport();
            await SendAsync("status", report.Mono!.Status, report.Mono.Message).ConfigureAwait(false);
            await SendAsync("status", "VERSION_JEU", report.GameVersion!.DisplayVersion).ConfigureAwait(false);
            token.ThrowIfCancellationRequested();
            report.Status = "ATTENTE_ENTITES";
            report.Message = "Recherche du monde et du joueur local… attente automatique.";
            SaveReport();
            await SendAsync("status", report.Status, report.Message).ConfigureAwait(false);
            code = 0;
            var processCheckClock = Stopwatch.StartNew();
            var controlBridge = new DmaControlBridge(memory, report.Mono!);
            long lastControlObservation = 0;

            while (!token.IsCancellationRequested)
            {
                if (processCheckClock.ElapsedMilliseconds >= 2000)
                {
                    if (!memory.TryFindGameProcess() || memory.ProcessId != gameProcessId)
                        throw new GameProcessLostException("Le jeu a quitté la vue DMA ou son processus a changé. Une nouvelle session de lecture est nécessaire.");
                    processCheckClock.Restart();
                }
                // Freeze one requested revision for the next complete capture.
                // The pipe can receive later changes while native reads run;
                // those changes are not applied until the following capture.
                var captureOptions = controls.Snapshot();
                reader.ReadOptions = captureOptions.Options;
                long started = Stopwatch.GetTimestamp();
                if (previousCaptureStarted != 0)
                    report.Performance.CycleInterval.Observe(Stopwatch.GetElapsedTime(previousCaptureStarted, started).TotalMilliseconds);
                previousCaptureStarted = started;
                bool saveAfterPublication = false;
                LiveEntitySnapshot snapshot = reader.Capture();
                report.AppliedReadOptions = snapshot.Diagnostics.AppliedReadOptions.Copy();
                report.AppliedReadOptionsRevision = captureOptions.Revision;
                token.ThrowIfCancellationRequested();
                report.NativeCamera = nativeCamera?.Diagnostics;
                if (report.NativeCamera != null && !ReferenceEquals(countedCameraDiagnostics, report.NativeCamera))
                {
                    countedCameraDiagnostics = report.NativeCamera;
                    report.NativeCameraCaptureCount++;
                    report.Performance.Camera.Observe(report.NativeCamera.ElapsedMilliseconds);
                    report.Performance.CameraReadCalls += report.NativeCamera.ReadCalls;
                    report.Performance.CameraReadBytes += report.NativeCamera.BytesRead;
                    string outcome = report.NativeCamera.Status;
                    if (report.CameraOutcomeCounts.TryGetValue(outcome, out long count))
                        report.CameraOutcomeCounts[outcome] = count + 1;
                    else if (report.CameraOutcomeCounts.Count < 64)
                        report.CameraOutcomeCounts[outcome] = 1;
                    else report.OtherCameraOutcomeCount++;
                }
                double captureAge = Stopwatch.GetElapsedTime(started).TotalMilliseconds;
                report.Performance.Capture.Observe(captureAge);
                report.CanProjectToGameScreen = new FeedSample(snapshot, captureAge).IsProjectionFresh;
                report.ProjectionMessage = report.NativeCamera?.Message ?? nativeCameraInitializationFailure ?? "Caméra en attente de lecture.";
                if (snapshot.Camera != null)
                {
                    report.LastCamera = snapshot.Camera;
                    report.LastCameraUtc = snapshot.CapturedUtc;
                }
                report.LastReadDurationMs = snapshot.ReadDurationMs;
                report.LastRejectedEntities = snapshot.RejectedEntities;
                report.LastCaptureDiagnostics = snapshot.Diagnostics;
                report.LastCaptureUtc = snapshot.CapturedUtc;
                if (FeedSample.IsValid(snapshot))
                {
                    bool firstSuccess = report.FramesRead == 0;
                    report.FramesRead++;
                    if (snapshot.Camera != null)
                    {
                        report.CameraFramesInAcceptedSnapshots++;
                        if (!report.CanProjectToGameScreen) report.CameraFramesNotFresh++;
                    }
                    report.FirstSuccessUtc ??= snapshot.CapturedUtc;
                    report.LastSuccessUtc = snapshot.CapturedUtc;
                    report.LastPlayersCount = snapshot.PlayersCount;
                    report.LastZombiesCount = snapshot.ZombiesCount;
                    report.Status = "ENTITES_LUES";
                    report.Message = snapshot.PlayersCount + " joueur(s), " + snapshot.ZombiesCount + " zombie(s). Lecture " + snapshot.ReadDurationMs + " ms." +
                        (report.CanProjectToGameScreen ? " ESP : caméra native lue." : " ESP en attente : " + report.ProjectionMessage);
                    // Periodic disk IO follows publication so it cannot age the
                    // current frame before the parent receives it.
                    saveAfterPublication = firstSuccess || CaptureReportDue();
                    bool initialCameraProbe = !cameraAttempted;
                    bool retryCameraInitialization = nativeCamera?.InitializationRetryDue == true;
                    if (initialCameraProbe || retryCameraInitialization)
                    {
                        // Preserve the first validated capture before the probe;
                        // this branch never publishes its preceding snapshot.
                        if (saveAfterPublication) SaveReport();
                        if (initialCameraProbe)
                        {
                            cameraAttempted = true;
                            await SendAsync("status", "SONDE_CAMERA", "Relevé de la caméra ; reprise du radar après une nouvelle capture.").ConfigureAwait(false);
                            report.Camera = new CameraProbe(memory).Inspect(report.Mono, reader.LocalPlayerAddress);
                        }
                        else
                        {
                            await SendAsync("status", "CAMERA_REINITIALISATION",
                                "Nouvelle tentative d'initialisation caméra après une lecture incomplète ou un budget dépassé.").ConfigureAwait(false);
                        }
                        token.ThrowIfCancellationRequested();
                        try
                        {
                            if (initialCameraProbe)
                            {
                                nativeCamera = new NativeCameraReader(memory, report.Mono, report.Camera!);
                                reader.CameraCapture = nativeCamera.Capture;
                            }
                            else
                            {
                                // The reader owns the bounded retry policy. Never
                                // initialize inside the entity/camera capture: it
                                // has a separate, longer operation budget.
                                nativeCamera!.InitializeProfile();
                            }
                            token.ThrowIfCancellationRequested();
                            report.NativeCamera = nativeCamera!.Diagnostics;
                            // An initialization is not a native camera capture.
                            countedCameraDiagnostics = report.NativeCamera;
                            nativeCameraInitializationFailure = null;
                            report.ProjectionMessage = report.NativeCamera.Message;
                        }
                        catch (Exception e) when (e is IOException || e is InvalidDataException || e is InvalidOperationException || e is ArgumentException || e is OverflowException)
                        {
                            nativeCameraInitializationFailure = "Initialisation caméra impossible : " + e.GetBaseException().Message;
                            report.ProjectionMessage = nativeCameraInitializationFailure;
                        }
                        // A validated profile is not yet a current camera frame.
                        // Keep the saved summary consistent with this new state.
                        report.CanProjectToGameScreen = false;
                        report.Message = snapshot.PlayersCount + " joueur(s), " + snapshot.ZombiesCount +
                            " zombie(s). ESP en attente : " + report.ProjectionMessage;
                        SaveReport();
                        string cameraMessage = report.ProjectionMessage;
                        if (report.ReportSaveError != null) cameraMessage += " Rapport non enregistré : " + report.ReportSaveError;
                        await SendAsync("status", "CAMERA_NATIVE", cameraMessage).ConfigureAwait(false);
                        // A probe or profile retry may take seconds. Never
                        // publish the snapshot that preceded it: the next loop
                        // must acquire fresh entities and a fresh camera.
                        continue;
                    }
                    double age = Stopwatch.GetElapsedTime(started).TotalMilliseconds;
                    if (age < FeedSample.LifetimeMs)
                    {
                        report.Performance.PublicationAge.Observe(age);
                        await SendAsync("frame", report.Status, report.Message, snapshot, age, captureTimestamp: started).ConfigureAwait(false);
                    }
                    else
                        await SendAsync("status", "DONNEES_EXPIREES", "Capture trop ancienne ; les repères sont retirés.").ConfigureAwait(false);
                }
                else
                {
                    report.CanProjectToGameScreen = false;
                    report.ProjectionMessage = "Projection retirée : capture des entités non confirmée.";
                    report.FramesRejected++;
                    report.Status = snapshot.Status == "ENTITES_LUES" ? "LECTURE_NON_VALIDEE" : snapshot.Status;
                    report.Message = snapshot.Status == "ENTITES_LUES" ? "Données hors limites ; les repères sont retirés." : snapshot.Message;
                    if (snapshot.Status == "ENTITES_LUES" && snapshot.Diagnostics != null)
                    {
                        snapshot.Diagnostics.Code = "DONNEES_HORS_LIMITES";
                        snapshot.Diagnostics.Stage = "VALIDATION_AFFICHAGE";
                        snapshot.Diagnostics.CanPublish = false;
                        snapshot.Diagnostics.Detail = report.Message;
                    }
                    report.LastCaptureDiagnostics = snapshot.Diagnostics;
                    report.LastFailureDiagnostics = snapshot.Diagnostics;
                    report.LastFailureUtc = snapshot.CapturedUtc;
                    string? diagnosticCode = snapshot.Diagnostics?.Code;
                    string failureCause = (string.IsNullOrWhiteSpace(diagnosticCode) ? report.Status : diagnosticCode) +
                        " / " + (snapshot.Diagnostics?.Stage ?? "NON_RENSEIGNE");
                    if (report.FailureCauseCounts.TryGetValue(failureCause, out long failures))
                        report.FailureCauseCounts[failureCause] = failures + 1;
                    else if (report.FailureCauseCounts.Count < 32)
                        report.FailureCauseCounts.Add(failureCause, 1);
                    else report.OtherFailureCount++;
                    // Every rejection clears the last displayed frame immediately.
                    // Parent/UI logs may coalesce repeats without retaining dots.
                    await SendAsync("status", report.Status, report.Message).ConfigureAwait(false);
                    saveAfterPublication = CaptureReportDue();
                }
                // Consume before execution, never retain a command for another
                // world or replay it after a native failure. This is the sole
                // writer of the child-to-parent pipe, including action results.
                CreativeMenuRequest? creativeRequest = controls.TakeCreativeRequest();
                if (creativeRequest != null)
                {
                    token.ThrowIfCancellationRequested();
                    CreativeMenuResult creativeResult = CreativeMenuExecutor.Execute(creativeRequest,
                        gameProcessId, snapshot, Stopwatch.GetElapsedTime(started).TotalMilliseconds,
                        report.GameVersion!.DisplayVersion,
                        () => memory.TryFindGameProcess() && memory.ProcessId == gameProcessId,
                        () =>
                        {
                            var access = new CreativeMenuAccess(memory, reader, report.Mono!, report.GameVersion!);
                            return creativeRequest.Toggle
                                ? access.ApplyToggle(creativeRequest.ExpectedPlayerContextId, gameProcessId, token)
                                : access.Apply(creativeRequest.ExpectedPlayerContextId, gameProcessId, creativeRequest.DesiredEnabled, token);
                        });
                    report.CreativeMenuRequests++;
                    if (creativeResult.WriteAttempted) report.CreativeMenuWriteAttempts++;
                    report.LastCreativeMenuResult = creativeResult;
                    await SendAsync(WorkerControl.CreativeResultKind, "MENU_CREATIF", creativeResult.Message,
                        creativeResult: creativeResult).ConfigureAwait(false);
                    saveAfterPublication = true;
                }
                PlayerControlRequest? playerRequest = controls.TakePlayerRequest();
                if (playerRequest != null)
                {
                    var submission = PlayerControlExecutor.Execute(playerRequest, gameProcessId, snapshot,
                        Stopwatch.GetElapsedTime(started).TotalMilliseconds,
                        () => memory.TryFindGameProcess() && memory.ProcessId == gameProcessId,
                        () => reader.ExecuteInValidatedContext(playerRequest.ExpectedPlayerContextId, context =>
                            controlBridge.Submit(context, gameProcessId, new ControlCommand
                            {
                                ExpectedSessionId = playerRequest.ExpectedModuleSessionId,
                                ExpectedContextId = playerRequest.ExpectedModuleContextId,
                                ExpectedPlayerId = playerRequest.ExpectedPlayerId,
                                RequestedTimestamp = playerRequest.RequestedTimestamp,
                                Operation = playerRequest.Operation, Enabled = playerRequest.Enabled, Value = playerRequest.Value,
                                PositionX = playerRequest.PositionX, PositionY = playerRequest.PositionY, PositionZ = playerRequest.PositionZ,
                                TargetEntityId = playerRequest.ExpectedPlayerId
                            }, token)), token);
                    report.PlayerControlRequests++;
                    if (submission.WriteAttempted) report.PlayerControlWriteAttempts++;
                    report.LastPlayerControlSubmission = submission;
                    await SendAsync(WorkerControl.PlayerControlSubmissionKind, "PERSONNAGE", submission.Message,
                        playerSubmission: submission).ConfigureAwait(false);
                    saveAfterPublication = true;
                }
                // A one-shot, DMA-only local-stat request. No module DLL is used.
                PlayerDmaStatRequest? statRequest = controls.TakeStatRequest();
                if (statRequest != null)
                {
                    var result = new PlayerDmaStatResult
                    {
                        Sequence = statRequest.Sequence, RequestId = statRequest.RequestId,
                        ProcessId = gameProcessId, PlayerContextId = statRequest.ExpectedPlayerContextId,
                        Stat = statRequest.Stat, DesiredValue = statRequest.DesiredValue,
                        Code = "COMMANDE_NON_CONFIRMEE", Message = "Demande DMA non confirmée."
                    };
                    try
                    {
                        PlayerDmaStatPolicy.Validate(statRequest);
                        token.ThrowIfCancellationRequested();
                        if (PlayerDmaStatPolicy.IsExpired(statRequest, Stopwatch.GetTimestamp()) ||
                            statRequest.ExpectedProcessId != gameProcessId ||
                            !FeedSample.IsValid(snapshot) || snapshot.PlayerContextId != statRequest.ExpectedPlayerContextId ||
                            snapshot.LocalId != statRequest.ExpectedPlayerId ||
                            Stopwatch.GetElapsedTime(started).TotalMilliseconds >= FeedSample.LifetimeMs)
                            throw new IOException("Partie, personnage ou demande de statistique expirée.");
                        var memoryStat = reader.ExecuteInValidatedContext(statRequest.ExpectedPlayerContextId, context =>
                            reader.AccessLocalStat(context, (PlayerStatTarget)statRequest.Stat, statRequest.DesiredValue, token));
                        result.Code = memoryStat.Code;
                        result.Message = memoryStat.Message;
                        result.WriteAttempted = memoryStat.WriteAttempted;
                        result.ObservedValue = memoryStat.Value;
                        result.ObservedMaximum = memoryStat.Maximum;
                    }
                    catch (Exception error) when (error is IOException || error is InvalidDataException ||
                        error is ArgumentException || error is InvalidOperationException || error is OverflowException)
                    {
                        result.Message = error.GetBaseException().Message;
                    }
                    await SendAsync(WorkerControl.PlayerDmaStatResultKind, "STATS_DMA", result.Message,
                        statResult: result).ConfigureAwait(false);
                    saveAfterPublication = true;
                }
                long controlNow = Stopwatch.GetTimestamp();
                if (playerRequest != null || lastControlObservation == 0 ||
                    Stopwatch.GetElapsedTime(lastControlObservation, controlNow).TotalMilliseconds >= controlBridge.RecommendedPollIntervalMs)
                {
                    lastControlObservation = controlNow;
                    var observation = new PlayerControlObservation
                    {
                        ProcessId = gameProcessId, PlayerContextId = snapshot.PlayerContextId ?? "",
                        CapturedTimestamp = controlNow, Code = "PARTIE_NON_PRETE",
                        Message = "En attente d’un personnage et d’un monde confirmés."
                    };
                    if (FeedSample.IsValid(snapshot) && Stopwatch.GetElapsedTime(started).TotalMilliseconds < FeedSample.LifetimeMs)
                    {
                        try
                        {
                            var probe = reader.ExecuteInValidatedContext(snapshot.PlayerContextId, context => controlBridge.Probe(context, gameProcessId, token));
                            observation.Available = probe.Available; observation.Fresh = probe.Fresh;
                            observation.Code = probe.Code; observation.Message = probe.Message;
                            observation.ObservedAgeMs = probe.ObservedAgeMs; observation.PendingRequestId = probe.PendingRequestId;
                            observation.ProbeDurationMs = probe.ProbeDurationMs;
                            observation.ReadCalls = probe.ReadCalls; observation.ReadBytes = probe.ReadBytes;
                            if (probe.Snapshot != null) observation.SnapshotRecord = ControlProtocol.EncodeSnapshot(probe.Snapshot, probe.Snapshot.Sequence);
                        }
                        catch (Exception error) when (error is IOException || error is InvalidDataException || error is InvalidOperationException ||
                            error is ArgumentException || error is OverflowException)
                        {
                            observation.Code = "MODULE_NON_LU";
                            string detail = error.GetBaseException().Message;
                            observation.Message = detail.Length <= 1024 ? detail : detail[..1024];
                        }
                    }
                    // The receipt timestamp includes DMA/probe duration in the
                    // parent freshness calculation; cached snapshots never gain time.
                    await SendAsync(WorkerControl.PlayerControlStateKind, "PERSONNAGE", observation.Message,
                        playerObservation: observation).ConfigureAwait(false);
                    report.LastPlayerControlObservation = observation;
                }
                if (saveAfterPublication) SaveReport();
                double elapsed = Stopwatch.GetElapsedTime(started).TotalMilliseconds;
                int delay = CaptureCadence.RemainingDelayMs(settings.IntervalMs, elapsed);
                report.Performance.LastScheduledDelayMs = delay;
                if (delay > 0) await Task.Delay(delay, token).ConfigureAwait(false);
            }
            SetStoppedReport();
        }
        catch (OperationCanceledException) when (token.IsCancellationRequested)
        {
            sessionActive = false;
            SetStoppedReport();
        }
        catch (Exception e)
        {
            sessionActive = false;
            report.Status = e is GameProcessLostException ? GameReconnectCoordinator.ProcessLostStage : "ERREUR_LECTURE";
            report.Error = e.GetBaseException().Message;
            report.Message = report.Error;
            code = report.Error.Contains("JEU_NON_TROUVE", StringComparison.Ordinal) ? 5 : 6;
            SaveReport();
            string detail = report.Message;
            if (report.ReportSaveError != null) detail += " Rapport non enregistré : " + report.ReportSaveError;
            try { await SendAsync("error", report.Status, detail).ConfigureAwait(false); } catch (Exception) { }
        }
        finally
        {
            sessionActive = false;
            report.CanProjectToGameScreen = false;
            // Preserve the diagnostic before potentially blocking native cleanup.
            SaveReport();
            if (memory != null)
            {
                try { memory.Dispose(); }
                catch (Exception e)
                {
                    report.Status = "ERREUR_FERMETURE";
                    report.Error = e.GetBaseException().Message;
                    report.Message = "Fermeture de la session DMA non confirmée : " + report.Error;
                    code = 6;
                    SaveReport();
                    // This final error supersedes a recoverable process loss.
                    // The parent must not reopen the FPGA on an old status.
                    try { await SendAsync("error", report.Status, report.Message).ConfigureAwait(false); } catch (Exception) { }
                }
            }
        }
        return code;
    }

    private sealed class GameProcessLostException : IOException
    {
        internal GameProcessLostException(string message) : base(message) { }
    }

    private sealed class TimingSummary
    {
        public long Samples { get; private set; }
        public double LastMs { get; private set; }
        public double MinimumMs { get; private set; }
        public double MaximumMs { get; private set; }
        public double TotalMs { get; private set; }
        public double AverageMs => Samples > 0 ? TotalMs / Samples : 0;

        internal void Observe(double milliseconds)
        {
            if (!double.IsFinite(milliseconds) || milliseconds < 0) return;
            MinimumMs = Samples == 0 ? milliseconds : Math.Min(MinimumMs, milliseconds);
            MaximumMs = Math.Max(MaximumMs, milliseconds);
            LastMs = milliseconds;
            Samples++;
            TotalMs += milliseconds;
        }
    }

    private sealed class SessionPerformance
    {
        public TimingSummary CycleInterval { get; } = new();
        public TimingSummary Capture { get; } = new();
        public TimingSummary Camera { get; } = new();
        public TimingSummary PublicationAge { get; } = new();
        public double ObservedCaptureHz => CycleInterval.AverageMs > 0 ? 1000 / CycleInterval.AverageMs : 0;
        public long CameraReadCalls { get; set; }
        public long CameraReadBytes { get; set; }
        public double AverageCameraReadCalls => Camera.Samples > 0 ? (double)CameraReadCalls / Camera.Samples : 0;
        public double AverageCameraReadBytes => Camera.Samples > 0 ? (double)CameraReadBytes / Camera.Samples : 0;
        public int LastScheduledDelayMs { get; set; }
    }

    // Deliberately contains neither LiveEntitySnapshot nor an entity list.
    // Reports can therefore be shared without serializing player positions/names.
    private sealed class SessionReport
    {
        public string Format { get; } = "SevenDaysEsp.LiveSession/4";
        public string ToolVersion { get; } = "0.12.0-dev";
        public DateTime CreatedUtc { get; } = DateTime.UtcNow;
        public DateTime UpdatedUtc { get; set; } = DateTime.UtcNow;
        public string Status { get; set; } = "INITIALISATION";
        public string Message { get; set; } = "";
        public bool CanProjectToGameScreen { get; set; }
        public string ProjectionMessage { get; set; } = "Caméra en attente de lecture.";
        public bool HasDmaSession { get; set; }
        public uint? ProcessId { get; set; }
        public string? MemProcFsVersion { get; set; }
        public MonoInspectionReport? Mono { get; set; }
        public GameVersionReport? GameVersion { get; set; }
        public CameraProbeReport? Camera { get; set; }
        public NativeCameraDiagnostics? NativeCamera { get; set; }
        public DisplayConfigurationReport? OutputAtConnection { get; set; }
        public int RequestedIntervalMs { get; set; }
        public LiveReadOptions? AppliedReadOptions { get; set; }
        public long? AppliedReadOptionsRevision { get; set; }
        public string? ControlFailure { get; set; }
        public long CreativeMenuRequests { get; set; }
        public long PlayerControlRequests { get; set; }
        public long PlayerControlWriteAttempts { get; set; }
        public PlayerControlSubmission? LastPlayerControlSubmission { get; set; }
        public PlayerControlObservation? LastPlayerControlObservation { get; set; }
        public long CreativeMenuWriteAttempts { get; set; }
        public CreativeMenuResult? LastCreativeMenuResult { get; set; }
        public SessionPerformance Performance { get; } = new();
        public long NativeCameraCaptureCount { get; set; }
        public Dictionary<string, long> CameraOutcomeCounts { get; } = new(StringComparer.Ordinal);
        public long OtherCameraOutcomeCount { get; set; }
        public long CameraFramesInAcceptedSnapshots { get; set; }
        public long CameraFramesNotFresh { get; set; }
        public LiveCameraFrame? LastCamera { get; set; }
        public DateTime? LastCameraUtc { get; set; }
        public LiveReadDiagnostics? LastCaptureDiagnostics { get; set; }
        public LiveReadDiagnostics? LastFailureDiagnostics { get; set; }
        public DateTime? LastCaptureUtc { get; set; }
        public DateTime? LastFailureUtc { get; set; }
        public Dictionary<string, long> FailureCauseCounts { get; } = new(StringComparer.Ordinal);
        public long OtherFailureCount { get; set; }
        public long FramesRead { get; set; }
        public long FramesRejected { get; set; }
        public DateTime? FirstSuccessUtc { get; set; }
        public DateTime? LastSuccessUtc { get; set; }
        public int LastPlayersCount { get; set; }
        public int LastZombiesCount { get; set; }
        public int LastRejectedEntities { get; set; }
        public long LastReadDurationMs { get; set; }
        public long ReadCalls { get; set; }
        public long ReadBytes { get; set; }
        public string? Error { get; set; }
        public string? ReportSaveError { get; set; }
        public string Note { get; } = "Métadonnées, états, compteurs et matrices caméra ; aucune liste de noms ou de positions des entités.";
    }
}
