﻿// Mathematiques de projection et creation des reperes. Aucun offset de jeu ici.
using System;
using System.Collections.Generic;

namespace SevenDaysEsp
{
    public struct WorldPoint
    {
        public float X;
        public float Y;
        public float Z;
        public WorldPoint(float x, float y, float z) { X = x; Y = y; Z = z; }
    }

    public struct ScreenPoint
    {
        public float X;
        public float Y;
        public ScreenPoint(float x, float y) { X = x; Y = y; }
    }

    public sealed class WorldEntity
    {
        public string Kind { get; set; }
        public string Name { get; set; }
        public WorldPoint Feet { get; set; }
        public WorldPoint Head { get; set; }
        public bool IsLocal { get; set; }
        public bool IsAlive { get; set; }
    }

    public sealed class WorldSnapshot
    {
        public DateTime CapturedUtc { get; set; }
        public WorldPoint LocalPosition { get; set; }
        public WorldPoint FloatingOrigin { get; set; }
        // Row-major view-projection. Multiply M * column(x,y,z,1).
        public float[] ViewProjection { get; set; }
        public int SourceWidth { get; set; }
        public int SourceHeight { get; set; }
        public List<WorldEntity> Entities { get; set; }
        public string Status { get; set; }
        public WorldSnapshot() { Entities = new List<WorldEntity>(); }
    }

    public static class EspProjection
    {
        public static bool IsFinite(float value) { return !Single.IsNaN(value) && !Single.IsInfinity(value); }
        public static bool IsFinite(WorldPoint p) { return IsFinite(p.X) && IsFinite(p.Y) && IsFinite(p.Z); }

        public static bool TryProject(WorldPoint world, WorldPoint origin, float[] matrix, out ScreenPoint screen)
        {
            screen = new ScreenPoint();
            if (matrix == null || matrix.Length != 16 || !IsFinite(world) || !IsFinite(origin)) return false;
            foreach (float value in matrix) if (!IsFinite(value)) return false;
            double x = (double)world.X - origin.X;
            double y = (double)world.Y - origin.Y;
            double z = (double)world.Z - origin.Z;
            double clipX = matrix[0] * x + matrix[1] * y + matrix[2] * z + matrix[3];
            double clipY = matrix[4] * x + matrix[5] * y + matrix[6] * z + matrix[7];
            double clipW = matrix[12] * x + matrix[13] * y + matrix[14] * z + matrix[15];
            if (Double.IsNaN(clipW) || Double.IsInfinity(clipW) || clipW <= 0.01) return false;
            double nx = clipX / clipW;
            double ny = clipY / clipW;
            if (Double.IsNaN(nx) || Double.IsInfinity(nx) || Double.IsNaN(ny) || Double.IsInfinity(ny)) return false;
            // The renderer accepts visible on-screen markers. Do not reflect behind-camera points.
            if (nx < -1 || nx > 1 || ny < -1 || ny > 1) return false;
            screen = new ScreenPoint((float)((nx + 1) * 0.5), (float)((1 - ny) * 0.5));
            return true;
        }

        public static float Distance(WorldPoint a, WorldPoint b)
        {
            if (!IsFinite(a) || !IsFinite(b)) return Single.NaN;
            double x = (double)a.X - b.X, y = (double)a.Y - b.Y, z = (double)a.Z - b.Z;
            double d = Math.Sqrt(x * x + y * y + z * z);
            return d <= Single.MaxValue ? (float)d : Single.NaN;
        }

        public static EspFrame BuildFrame(WorldSnapshot snapshot)
        {
            if (snapshot == null) throw new ArgumentNullException("snapshot");
            if (snapshot.CapturedUtc.Kind != DateTimeKind.Utc || snapshot.SourceWidth < 1 || snapshot.SourceHeight < 1 ||
                snapshot.SourceWidth > 32768 || snapshot.SourceHeight > 32768 || !IsFinite(snapshot.LocalPosition) ||
                !IsFinite(snapshot.FloatingOrigin) || snapshot.ViewProjection == null || snapshot.ViewProjection.Length != 16)
                throw new ArgumentException("Instantane incomplet : horodatage UTC, resolution, origine, position et matrice sont obligatoires.");
            bool nonzero = false;
            foreach (float value in snapshot.ViewProjection)
            {
                if (!IsFinite(value)) throw new ArgumentException("Matrice de camera non finie.");
                if (value != 0) nonzero = true;
            }
            if (!nonzero) throw new ArgumentException("Matrice de camera nulle.");
            if (snapshot.Entities != null && snapshot.Entities.Count > 4096)
                throw new ArgumentException("Instantane trop grand : 4096 entites maximum.");
            EspFrame result = new EspFrame
            {
                CapturedUtc = snapshot.CapturedUtc,
                SourceWidth = snapshot.SourceWidth,
                SourceHeight = snapshot.SourceHeight,
                Status = snapshot.Status ?? "ESP"
            };
            if (snapshot.Entities == null) return result;
            foreach (WorldEntity entity in snapshot.Entities)
            {
                if (entity == null || entity.IsLocal || !entity.IsAlive ||
                    (entity.Kind != "player" && entity.Kind != "zombie")) continue;
                ScreenPoint feet, head;
                if (!TryProject(entity.Feet, snapshot.FloatingOrigin, snapshot.ViewProjection, out feet) ||
                    !TryProject(entity.Head, snapshot.FloatingOrigin, snapshot.ViewProjection, out head)) continue;
                float distance = Distance(snapshot.LocalPosition, entity.Feet);
                if (!IsFinite(distance) || head.Y >= feet.Y) continue;
                result.Markers.Add(new EntityMarker
                {
                    Kind = entity.Kind, Name = entity.Name, DistanceMeters = distance,
                    BottomX = feet.X, BottomY = feet.Y, TopX = head.X, TopY = head.Y, Visible = true
                });
            }
            return result;
        }
    }
}
