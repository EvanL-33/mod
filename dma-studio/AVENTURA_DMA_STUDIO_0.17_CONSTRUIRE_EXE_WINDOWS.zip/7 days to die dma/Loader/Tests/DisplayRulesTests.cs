using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using SevenDaysEsp;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class DisplayRulesTests
{
    public static Task RulesAreOptInAndNormalizeOrderedThresholds()
    {
        var rules = new EntityDisplayRulesSettings();
        Check(!rules.HeightFilterEnabled && !rules.ExemptPinnedFromHeightFilter && !rules.ShowHeightIndicator &&
            rules.ColorMode == "none" && rules.IsValid(out _), "New profiles enabled rules or started invalid.");
        rules.MaxHeightDifferenceMeters = -1;
        rules.ColorMode = " HEALTH ";
        rules.HealthLowPercent = 500;
        rules.HealthHighPercent = -1;
        rules.DistanceNearMeters = 99999;
        rules.DistanceFarMeters = -1;
        rules.LowColor = " #a1b2c3 ";
        rules.MiddleColor = null!;
        rules.HighColor = "not a color";
        Check(!rules.IsValid(out var reason) && reason.Length > 0, "Invalid imported rules were accepted.");
        rules.Normalize();
        Check(rules.IsValid(out _) && rules.MaxHeightDifferenceMeters == 1 && rules.ColorMode == "health" &&
            rules.HealthLowPercent == 99 && rules.HealthHighPercent == 100 && rules.DistanceNearMeters == 4999 &&
            rules.DistanceFarMeters == 5000 && rules.LowColor == "#A1B2C3" && rules.MiddleColor == "#FFE27A" &&
            rules.HighColor == "#9BF0A3", "Normalization did not bound and order the independent rules.");
        string normalized = JsonSerializer.Serialize(rules);
        rules.Normalize();
        Check(JsonSerializer.Serialize(rules) == normalized, "Rule normalization is not idempotent.");
        var copy = rules.Copy();
        copy.ColorMode = "distance";
        copy.MaxHeightDifferenceMeters = 20;
        Check(rules.ColorMode == "health" && rules.MaxHeightDifferenceMeters == 1, "Rule copies share mutable state.");
        rules.ColorMode = "unknown";
        rules.Normalize();
        Check(rules.ColorMode == "none", "An unknown color mode enabled an automatic rule.");
        return Task.CompletedTask;
    }

    public static Task HeightFilterIsSymmetricAndPinnedExemptionRespectsVisibility()
    {
        var settings = Settings();
        settings.PlayerEsp.MaxDistance = 100;
        settings.PlayerEsp.Rules.HeightFilterEnabled = true;
        settings.PlayerEsp.Rules.MaxHeightDifferenceMeters = 10;
        foreach (bool projected in new[] { false, true })
        {
            Check(Visible(10, null) && Visible(-10, null), "The inclusive height boundary is asymmetric.");
            Check(!Visible(10.01, null) && !Visible(-10.01, null) && !Visible(double.NaN, null),
                "Out-of-slice or unknown heights reached a display.");
            var pinned = new PlayerVisualState { Pinned = true };
            Check(!Visible(30, pinned), "Pinning bypassed height before its exemption was enabled.");
            settings.PlayerEsp.Rules.ExemptPinnedFromHeightFilter = true;
            Check(Visible(30, pinned), "An enabled pinned-player exemption did not pass the height filter.");
            Check(!Visible(30, new PlayerVisualState { Pinned = true, Hidden = true }), "A hidden pinned player became visible.");
            Check(!EspDisplayPolicy.TryGetVisibleProfile(settings, "player", 101, projected, out _, 30, pinned),
                "Height exemption bypassed the ESP distance limit.");
            settings.PlayerEsp.Enabled = false;
            Check(!Visible(30, pinned), "A disabled profile was overridden by pinning.");
            settings.PlayerEsp.Enabled = true;
            settings.PlayerEsp.Rules.ExemptPinnedFromHeightFilter = false;
            bool Visible(double height, PlayerVisualState? visual) => EspDisplayPolicy.TryGetVisibleProfile(settings,
                "player", 50, projected, out _, height, visual);
        }
        settings.ZombieEsp.Rules.HeightFilterEnabled = true;
        settings.ZombieEsp.Rules.ExemptPinnedFromHeightFilter = true;
        Check(!EspDisplayPolicy.TryGetVisibleProfile(settings, "zombie", 50, true, out _, 30,
            new PlayerVisualState { Pinned = true }), "The player pin exemption applied to a zombie.");
        settings.PlayerEsp.Rules.HeightFilterEnabled = false;
        Check(EspDisplayPolicy.TryGetVisibleProfile(settings, "player", 50, true, out _),
            "Disabled height rules broke legacy projected metadata.");
        return Task.CompletedTask;
    }

    public static Task HeightOnlyLabelsUseBudgetAndKeepPinnedException()
    {
        var settings = Settings();
        foreach (var profile in new[] { settings.PlayerEsp, settings.ZombieEsp })
        {
            HideElements(profile);
            profile.Rules.ShowHeightIndicator = true;
            profile.Rules.HeightFilterEnabled = true;
            profile.Rules.MaxHeightDifferenceMeters = 10;
        }
        Check(EspDisplayPolicy.HasProjectedProfile(settings), "Height-only profiles were considered empty.");
        var markers = Enumerable.Range(1, 40).Select(id => Marker(id, "player", 5))
            .Concat(Enumerable.Range(101, 40).Select(id => Marker(id, "zombie", -5))).ToArray();
        var selected = EspDisplayPolicy.SelectProjectedLabels(settings, markers);
        Check(selected.Count == 64 && selected.Count(id => id < 100) == 32 && selected.Count(id => id > 100) == 32,
            "Height-only labels did not share the bounded category budget.");
        var outside = Marker(200, "player", 30);
        Check(EspDisplayPolicy.SelectProjectedLabels(settings, new[] { outside }).Count == 0,
            "An out-of-height target consumed a label.");
        settings.PlayerEsp.Rules.ExemptPinnedFromHeightFilter = true;
        Check(EspDisplayPolicy.SelectProjectedLabels(settings, new[] { outside }, visual: _ =>
            new PlayerVisualState { Pinned = true }).Contains(200), "Label selection discarded a valid pinned exception.");
        Check(EspDisplayPolicy.SelectProjectedLabels(settings, new[] { outside }, visual: _ =>
            new PlayerVisualState { Pinned = true, Hidden = true }).Count == 0, "Label selection exposed a hidden player.");
        settings.PlayerEsp.Rules.HeightFilterEnabled = false;
        Check(EspDisplayPolicy.SelectProjectedLabels(settings, new[] { Marker(201, "player", double.NaN) }).Count == 0,
            "An unknown height consumed a label budget despite having no other content.");
        Check(EntityDisplayRules.HeightIndicator(5.2) == "↑ +5 m" && EntityDisplayRules.HeightIndicator(-5.2) == "↓ −5 m" &&
            EntityDisplayRules.HeightIndicator(0) == "↔ 0 m" && EntityDisplayRules.HeightIndicator(double.NaN) == "",
            "Height labels invented a direction or rounded the sign incorrectly.");
        return Task.CompletedTask;
    }

    public static Task HealthColorNeedsConfirmedMaximumAndIndividualColorWins()
    {
        var profile = new EntityEspSettings { Color = "#123456" };
        profile.Rules.ColorMode = "health";
        foreach (var hp in new (int? current, int? maximum)[] { (null, null), (10, null), (null, 100), (10, 0), (-1, 100), (101, 100) })
            Check(EntityDisplayRules.ResolveColor(profile, 5, hp.current, hp.maximum) == profile.Color,
                "Missing or inconsistent HP generated an automatic health percentage.");
        Check(Color(0) == profile.Rules.LowColor && Color(30) == profile.Rules.LowColor &&
            Color(31) == profile.Rules.MiddleColor && Color(69) == profile.Rules.MiddleColor &&
            Color(70) == profile.Rules.HighColor && Color(100) == profile.Rules.HighColor,
            "Health color boundaries or actual zero HP are wrong.");
        Check(EntityDisplayRules.ResolveColor(profile, 5, 10, 100, "#ABCDEF") == "#ABCDEF" &&
            EntityDisplayRules.ResolveColor(profile, 5, null, null, "#ABCDEF") == "#ABCDEF",
            "An automatic rule or unknown HP overwrote an individual color.");
        profile.Rules.LowColor = "invalid";
        Check(Color(0) == profile.Color, "An invalid palette bypassed the profile fallback.");
        string Color(int health) => EntityDisplayRules.ResolveColor(profile, 5, health, 100);
        return Task.CompletedTask;
    }

    public static Task DistanceColorUsesItsOwnThresholdsAndFiniteMetric()
    {
        var profile = new EntityEspSettings { Color = "#123456" };
        profile.Rules.ColorMode = "distance";
        Check(Color(0) == profile.Rules.LowColor && Color(25) == profile.Rules.LowColor &&
            Color(25.01) == profile.Rules.MiddleColor && Color(99.99) == profile.Rules.MiddleColor &&
            Color(100) == profile.Rules.HighColor, "Distance color boundaries are inconsistent.");
        foreach (double invalid in new[] { -1d, double.NaN, double.PositiveInfinity })
            Check(Color(invalid) == profile.Color, "A non-finite or negative distance got an automatic color.");
        Check(EntityDisplayRules.ResolveColor(profile, 500, 0, 100) == profile.Rules.HighColor &&
            EntityDisplayRules.ResolveColor(profile, 500, null, null, "#ABCDEF") == "#ABCDEF",
            "Distance mode mixed in health mode or defeated an individual color.");
        profile.Rules.ColorMode = "none";
        Check(Color(0) == profile.Color, "Disabled color rules changed the base profile.");
        string Color(double distance) => EntityDisplayRules.ResolveColor(profile, distance, null, null);
        return Task.CompletedTask;
    }

    public static Task IndependentRadarUsesHorizontalRangeWithoutChangingEsp()
    {
        var settings = Settings();
        settings.PlayerEsp.MaxDistance = 25;
        settings.ZombieEsp.MaxDistance = 25;
        settings.RadarIndependentRange = true;
        settings.RadarRangeMeters = 100;
        var sample = Sample(Entity(1, "player", 80, 60), Entity(2, "zombie", 101, 0), Entity(3, "zombie", 20, 120));
        var summary = RadarSummary.Create(settings, sample, EmptyVisuals());
        Check(summary.RangeMeters == 100 && summary.Targets.Select(t => t.Entity.EntityId).Order().SequenceEqual(new[] { 1, 3 }),
            "Independent radar inherited an ESP range or used 3D range.");
        Check(summary.Targets.Single(t => t.Entity.EntityId == 1).DistanceMeters == 80 &&
            summary.Targets.Single(t => t.Entity.EntityId == 3).HeightMeters == 120,
            "Radar distances lost their horizontal metric or signed height.");
        Check(!EspDisplayPolicy.TryGetVisibleProfile(settings, "player", 100, true, out _, 60),
            "Expanding radar range expanded projected ESP.");
        settings.PlayerEsp.Enabled = false;
        Check(RadarSummary.Create(settings, sample, EmptyVisuals()).Targets.All(t => t.Entity.Kind != "player"),
            "Independent radar ignored category visibility.");
        settings.PlayerEsp.Enabled = true;
        settings.RadarIndependentRange = false;
        Check(RadarSummary.Create(settings, sample, EmptyVisuals()).Targets.Select(t => t.Entity.EntityId).SequenceEqual(new[] { 3 }),
            "Linked radar did not use each category's horizontal range.");
        settings.RadarIndependentRange = true;
        settings.RadarRangeMeters = int.MaxValue;
        Check(EspDisplayPolicy.RadarRange(settings) == 5000, "Independent radar range exceeded its maximum.");
        return Task.CompletedTask;
    }

    public static Task RadarBandsAreDisjointAndClippedToDisplayedRange()
    {
        var settings = Settings();
        settings.RadarIndependentRange = true;
        settings.RadarRangeMeters = 150;
        var sample = Sample(Entity(1, "player", 0), Entity(2, "zombie", 25), Entity(3, "player", 25.01f),
            Entity(4, "zombie", 50), Entity(5, "player", 50.01f), Entity(6, "zombie", 100), Entity(7, "player", 100.01f));
        var summary = RadarSummary.Create(settings, sample, EmptyVisuals());
        Check(summary.Targets.Count == 7 && summary.Bands.All(b => b.Players == 1 && b.Zombies == 1) &&
            summary.Bands.Sum(b => b.Players + b.Zombies) == 6, "Radar bands overlap, miss boundaries or count beyond 100 m.");
        settings.RadarRangeMeters = 37;
        summary = RadarSummary.Create(settings, sample, EmptyVisuals());
        Check(summary.Targets.Count == 3 && summary.Bands[0].Players == 1 && summary.Bands[0].Zombies == 1 &&
            summary.Bands[1].ToMeters == 37 && summary.Bands[1].Players == 1 && summary.Bands[1].Zombies == 0 &&
            !summary.Bands[2].IsAvailable, "Counters exceeded the drawn radar radius.");
        settings.RadarRangeMeters = 25;
        summary = RadarSummary.Create(settings, sample, EmptyVisuals());
        Check(summary.Targets.Count == 2 && summary.Bands[0].Zombies == 1 &&
            !summary.Bands[1].IsAvailable && !summary.Bands[2].IsAvailable,
            "A point on the range boundary entered an unavailable band.");
        settings.PlayerEsp.Enabled = false;
        summary = RadarSummary.Create(settings, sample, EmptyVisuals());
        Check(summary.Bands[0].Players == 0 && summary.Bands[0].Zombies == 1, "Counters included a disabled category.");
        return Task.CompletedTask;
    }

    public static Task RadarCountersShareHiddenHeightAndFreshnessGates()
    {
        var settings = Settings();
        settings.PlayerEsp.Rules.HeightFilterEnabled = true;
        settings.PlayerEsp.Rules.ExemptPinnedFromHeightFilter = true;
        settings.ZombieEsp.Rules.HeightFilterEnabled = true;
        string context = Guid.NewGuid().ToString();
        var entities = new[] { Entity(1, "player", 5, 30, 11), Entity(2, "player", 6, 30, 12),
            Entity(3, "player", 7, 30, 13), Entity(4, "player", 8, 2, 14), Entity(5, "zombie", 9, 30) };
        var sample = Sample(entities);
        sample.Snapshot.PlayerContextId = context;
        var visuals = new PlayerVisualLookup(new PlayerSessionSnapshot
        {
            HasCurrentData = true,
            Rows = new[]
            {
                Row(1, 11, new() { Pinned = true, Hidden = true }), Row(2, 12, new() { Pinned = true }),
                Row(3, 13, new()), Row(4, 14, new())
            }
        });
        var summary = RadarSummary.Create(settings, sample, visuals);
        Check(summary.Targets.Select(t => t.Entity.EntityId).SequenceEqual(new[] { 2, 4 }) &&
            summary.Bands[0].Players == 2 && summary.Bands[0].Zombies == 0,
            "Radar counters disagreed with hidden, pinned or height-filtered dots.");
        var expired = new FeedSample(sample.Snapshot, FeedSample.LifetimeMs);
        var stale = RadarSummary.Create(settings, expired, visuals);
        Check(!stale.HasCurrentData && stale.Targets.Count == 0 && stale.Bands.All(b => b.Players == 0 && b.Zombies == 0),
            "An expired sample left dots or counters behind.");
        settings.EspEnabled = false;
        Check(!RadarSummary.Create(settings, sample, visuals).HasCurrentData, "Master-off radar retained visible data.");
        settings.EspEnabled = true;
        settings.ShowRadar = false;
        Check(RadarSummary.Create(settings, sample, visuals).Targets.Count == 0, "Hidden radar retained visible data.");
        PlayerRow Row(int id, long token, PlayerVisualState visual) => new()
        { Identity = new(context, token, id), Visual = visual };
        return Task.CompletedTask;
    }

    public static Task HealthRulesRequestOnlyExistingVisibleOptionalReads()
    {
        var settings = Settings();
        settings.ShowProjectedEsp = false;
        settings.PlayerEsp.ShowHealth = settings.ZombieEsp.ShowHealth = false;
        settings.PlayerEsp.Rules.ColorMode = "health";
        Check(Reads().PlayerHealth && !Reads().ZombieHealth, "Visible radar health colors did not request category-specific HP.");
        settings.PlayerEsp.Rules.ColorMode = "distance";
        Check(!Reads().PlayerHealth, "Distance colors requested unused HP.");
        settings.PlayerEsp.Rules.ColorMode = "health";
        settings.PlayerEsp.Enabled = false;
        Check(!Reads().PlayerHealth, "A disabled profile requested health for its colors.");
        settings.PlayerEsp.Enabled = true;
        settings.ShowRadar = false;
        settings.ShowProjectedEsp = true;
        HideElements(settings.PlayerEsp);
        Check(!Reads().PlayerHealth, "A profile with no visible output requested color HP.");
        settings.PlayerEsp.Rules.ShowHeightIndicator = true;
        Check(Reads().PlayerHealth, "Height-only projected labels did not request their health color.");
        settings.PlayerEsp.Rules.ShowHeightIndicator = false;
        settings.PlayerFeatures.OffscreenIndicators = true;
        Check(Reads().PlayerHealth, "Health-colored off-screen arrows did not request HP.");
        settings.EspEnabled = false;
        Check(!Reads().PlayerHealth, "Master-off profiles requested color HP.");
        Check(LiveReadPolicy.FromSettings(settings, false, playerDetails: true).PlayerHealth &&
            LiveReadPolicy.FromSettings(settings, true).ZombieHealth, "Existing player-detail or sharing requirements were lost.");
        LiveReadOptions Reads() => LiveReadPolicy.FromSettings(settings, false);
        return Task.CompletedTask;
    }

    public static Task ProjectionCarriesSameCaptureHeightAndHealthForDirections()
    {
        float[] identity = { 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 };
        var origin = Position(100, 120, 200);
        Check(ProjectionMath.TryCreateView(identity, origin, 100, 100, new(0, 0, 100, 100),
            ProjectionDepthRange.MinusOneToOne, out var view, out _), "The projection fixture is invalid.");
        var local = Position(100, 118, 200);
        var visible = new LiveEntity { EntityId = 1, Kind = "player", Name = "Visible", Position = Position(100, 120.25f, 200.5f),
            Health = 50, MaxHealth = 100, IdentityToken = 11 };
        var outside = new LiveEntity { EntityId = 2, Kind = "player", Name = "Outside", Position = Position(103, 120.75f, 200.5f),
            Health = null, MaxHealth = 200, IdentityToken = 12 };
        Check(ProjectionMath.TryBuildFrame(view, local, 0, new[] { visible, outside }, null, out var frame, out _),
            "Adding rule metadata invalidated a coherent frame.");
        var marker = frame!.Markers.Single();
        var direction = frame.PlayerDirections.Single(p => p.EntityId == 2);
        Check(marker.HeightMeters == 2.25 && marker.Health == 50 && marker.MaxHealth == 100 && marker.IdentityToken == 11,
            "Projected markers lost their captured height or health.");
        Check(direction.HeightMeters == 2.75 && direction.Health == null && direction.MaxHealth == 200 && direction.IdentityToken == 12,
            "Off-screen rules require a different capture or invent missing health.");
        Check(Math.Abs(marker.DistanceMeters - Math.Sqrt(2.25 * 2.25 + .5 * .5)) < .00001,
            "Passing height metadata changed projected 3D distance.");
        return Task.CompletedTask;
    }

    private static LoaderSettings Settings() => new() { EspProfilesVersion = 1, EspEnabled = true, ShowRadar = true };
    private static PlayerVisualLookup EmptyVisuals() => new(new PlayerSessionSnapshot());
    private static LiveEntity Entity(int id, string kind, float x, float y = 0, long token = 0) => new()
    { EntityId = id, Kind = kind, Name = kind + id, Position = Position(x, y, 0), IdentityToken = token };
    private static LivePosition Position(float x, float y, float z) => new() { X = x, Y = y, Z = z };
    private static FeedSample Sample(params LiveEntity[] entities) => new(new LiveEntitySnapshot
    { Status = "ENTITES_LUES", LocalId = 999, LocalPosition = Position(0, 0, 0), Entities = new List<LiveEntity>(entities) }, 0);
    private static ProjectedMarker Marker(int id, string kind, double height) => new(id, kind, "Target", 50,
        new(20, 20), null, HeightMeters: height);
    private static void HideElements(EntityEspSettings profile) =>
        profile.ShowBoxes = profile.ShowNames = profile.ShowHealth = profile.ShowDistances = profile.ShowTracers = false;
    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
