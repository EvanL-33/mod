using System;
using System.Threading.Tasks;
using SevenDaysLoader;

internal static class AdminWatchTests
{
    internal static Task NamesAreExplicitAndNeverInferAdminRole()
    {
        var config = new AdminWatchSettings { Enabled = true, Names = "Alice; Bob\nCharlie" };
        Check(AdminWatchMatcher.IsListed(config, "Alice"), "Exact listed name missing");
        Check(AdminWatchMatcher.IsListed(config, " bob "), "Whitespace/case normalization failed");
        Check(AdminWatchMatcher.IsListed(config, "Charlie"), "Newline separator failed");
        Check(!AdminWatchMatcher.IsListed(config, "Alicee"), "Substring matching would cause false positives");
        Check(!AdminWatchMatcher.IsListed(config, "Guest"), "Unlisted account was incorrectly classified");
        config.Enabled = false;
        Check(!AdminWatchMatcher.IsListed(config, "Alice"), "Disabled watcher must match nobody");
        Check(AdminWatchMatcher.Nearby(null, config).Count == 0, "No DMA snapshot must produce no matches");
        return Task.CompletedTask;
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
