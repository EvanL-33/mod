using System;
using System.Collections.Generic;

namespace SevenDaysLoader.Services;

// One immutable session snapshot per draw. No rendering path needs a service
// lock for every entity, and an old entity ID cannot inherit a new annotation.
public sealed class PlayerVisualLookup
{
    private static readonly PlayerVisualState Neutral = new();
    private readonly Dictionary<PlayerIdentity, PlayerVisualState> states = new();
    public long Revision { get; }

    public PlayerVisualLookup(PlayerSessionSnapshot snapshot)
    {
        Revision = snapshot.Revision;
        if (!snapshot.HasCurrentData) return;
        foreach (var row in snapshot.Rows)
        {
            if (states.Count >= 4096) break;
            if (row.Identity.IsValid) states.TryAdd(row.Identity, row.Visual);
        }
    }

    public bool TryResolve(string? contextId, long token, int entityId, out PlayerVisualState visual)
    {
        visual = Neutral;
        // Older senders remain usable without assigning guessed identities.
        if (string.IsNullOrEmpty(contextId) && token == 0) return true;
        var identity = new PlayerIdentity(contextId ?? string.Empty, token, entityId);
        if (!identity.IsValid || !states.TryGetValue(identity, out var state)) return false;
        visual = state;
        return !state.Hidden;
    }

    public static int Priority(PlayerVisualState visual) => visual.Pinned ? 3 : visual.Selected ? 2 : visual.Marked ? 1 : 0;
}
