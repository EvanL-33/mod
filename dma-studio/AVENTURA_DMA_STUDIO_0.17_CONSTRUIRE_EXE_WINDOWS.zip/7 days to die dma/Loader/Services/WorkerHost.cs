using System;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.IO.Pipes;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using SevenDaysEsp;

namespace SevenDaysLoader.Services;

/// <summary>Owns one reader process; callbacks run on a background thread.</summary>
public sealed class WorkerHost : IAsyncDisposable
{
    private readonly SemaphoreSlim gate = new(1, 1);
    private readonly object controlGate = new();
    private readonly PendingReadOptions pendingReadOptions = new();
    private Process? process;
    private OwnedJob? job;
    private NamedPipeServerStream? pipe;
    private CancellationTokenSource? lifetime;
    private Task? receiveTask;
    private volatile bool stopping;
    private volatile bool disposed;
    private bool controlsReady;
    private bool controlSenderRunning;
    private volatile string? controlFailure;

    public event Action<WorkerMessage>? Message;
    public event Action<string>? Ended;
    public event Action<string>? ControlError;

    public async Task SendPlayerDmaStatAsync(PlayerDmaStatRequest request, CancellationToken cancellationToken = default)
    {
        PlayerDmaStatPolicy.Validate(request);
        var copied = request.Copy();
        await gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        bool started = false;
        try
        {
            lock (controlGate)
            {
                ObjectDisposedException.ThrowIf(disposed, this);
                if (stopping || !controlsReady) throw new InvalidOperationException("Lecteur DMA indisponible.");
            }
            if (pipe == null || !pipe.IsConnected || lifetime == null)
                throw new IOException("Liaison DMA interrompue.");
            if (PlayerDmaStatPolicy.IsExpired(copied, Stopwatch.GetTimestamp()))
                throw new InvalidOperationException("Demande expirée avant l'envoi.");
            using var bounded = CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token, cancellationToken);
            bounded.CancelAfter(TimeSpan.FromSeconds(1));
            started = true;
            await Wire.WriteAsync(pipe, new WorkerControl { Kind = WorkerControl.PlayerDmaStatKind,
                PlayerDmaStat = copied }, bounded.Token).ConfigureAwait(false);
        }
        catch (Exception error) when (started)
        {
            FailControlSend(error);
            throw new IOException("Envoi de statistique non confirmé, aucun nouvel essai automatique.", error);
        }
        finally { gate.Release(); }
    }

    public async Task SendPlayerControlAsync(PlayerControlRequest request, CancellationToken cancellationToken = default)
    {
        PlayerControlPolicy.ValidateRequest(request);
        var copied = request.Copy();
        PlayerControlPolicy.ValidateRequest(copied);
        await gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        bool writeStarted = false;
        try
        {
            lock (controlGate)
            {
                ObjectDisposedException.ThrowIf(disposed, this);
                if (stopping || !controlsReady) throw new InvalidOperationException("Le lecteur DMA local n’est pas disponible.");
            }
            if (pipe == null || !pipe.IsConnected || lifetime == null) throw new IOException("Liaison du lecteur interrompue.");
            if (PlayerControlPolicy.IsExpired(copied, Stopwatch.GetTimestamp()))
                throw new InvalidOperationException("La commande du personnage a expiré avant son envoi.");
            using var bounded = CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token, cancellationToken);
            bounded.CancelAfter(TimeSpan.FromSeconds(1));
            bounded.Token.ThrowIfCancellationRequested();
            writeStarted = true;
            await Wire.WriteAsync(pipe, new WorkerControl { Kind = WorkerControl.PlayerControlKind, PlayerControl = copied }, bounded.Token).ConfigureAwait(false);
        }
        catch (Exception error) when (writeStarted)
        {
            FailControlSend(error);
            throw new IOException("Transmission non confirmée. Aucun nouvel envoi automatique.", error);
        }
        finally { gate.Release(); }
    }

    // One explicit intent, never retained for startup/reconnection and never
    // retried. The common gate keeps its Wire header/payload with the handshake,
    // read-option updates and shutdown command in one ordered byte stream.
    public async Task SendCreativeMenuAsync(CreativeMenuRequest request, CancellationToken cancellationToken = default)
    {
        CreativeMenuProtocol.ValidateRequest(request);
        var copied = request.Copy();
        CreativeMenuProtocol.ValidateRequest(copied);
        await gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        bool writeStarted = false;
        try
        {
            lock (controlGate)
            {
                ObjectDisposedException.ThrowIf(disposed, this);
                if (stopping || !controlsReady)
                    throw new InvalidOperationException("Le lecteur DMA local n’est pas disponible pour cette demande.");
            }
            if (pipe == null || !pipe.IsConnected || lifetime == null)
                throw new IOException("La liaison du lecteur n’est plus disponible.");
            if (CreativeMenuProtocol.IsExpired(copied, Stopwatch.GetTimestamp()))
                throw new InvalidOperationException("La demande de menu créatif a expiré avant son envoi.");
            using var bounded = CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token, cancellationToken);
            bounded.CancelAfter(TimeSpan.FromSeconds(1));
            bounded.Token.ThrowIfCancellationRequested();
            writeStarted = true;
            await Wire.WriteAsync(pipe, new WorkerControl
            {
                Kind = WorkerControl.CreativeMenuKind, CreativeMenu = copied
            }, bounded.Token).ConfigureAwait(false);
        }
        catch (Exception error) when (writeStarted)
        {
            // A failed/partial send may already have reached the worker. Closing
            // the framed stream is safer than resending or pretending it was undone.
            FailControlSend(error);
            throw new IOException("Envoi du menu créatif non confirmé. Aucun nouvel envoi automatique.", error);
        }
        finally { gate.Release(); }
    }

    // UI callers only copy four booleans into a one-value mailbox. They never
    // wait for the pipe or the lifetime gate, including during Stop/Dispose.
    public void UpdateReadOptions(LiveReadOptions options)
    {
        if (options == null) return;
        lock (controlGate)
        {
            if (disposed || stopping) return;
            pendingReadOptions.Replace(options);
        }
        QueueReadOptions();
    }

    private void QueueReadOptions()
    {
        lock (controlGate)
        {
            if (disposed || stopping || !controlsReady || controlSenderRunning || !pendingReadOptions.HasPending) return;
            controlSenderRunning = true;
            // The complete task body observes failures and reports them through
            // ControlError. No exception is left on an unobserved UI fire-and-forget.
            _ = Task.Run(SendPendingReadOptionsAsync);
        }
    }

    private async Task SendPendingReadOptionsAsync()
    {
        try
        {
            while (true)
            {
                // Start's handshake, option writes and Stop's command all own
                // this gate. Wire's header/payload can never be interleaved.
                await gate.WaitAsync().ConfigureAwait(false);
                try
                {
                    LiveReadOptions? next;
                    lock (controlGate)
                    {
                        if (disposed || stopping || !controlsReady) return;
                        next = pendingReadOptions.Take();
                    }
                    if (next == null) return;
                    if (pipe == null || !pipe.IsConnected || lifetime == null)
                        throw new IOException("La liaison du lecteur n’est plus disponible.");
                    using var bounded = CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token);
                    bounded.CancelAfter(TimeSpan.FromSeconds(1));
                    await Wire.WriteAsync(pipe, new WorkerControl
                    {
                        Kind = WorkerControl.ReadOptionsKind, ReadOptions = next
                    }, bounded.Token).ConfigureAwait(false);
                }
                catch (Exception error)
                {
                    FailControlSend(error);
                    return;
                }
                finally { gate.Release(); }
            }
        }
        catch (Exception error) { FailControlSend(error); }
        finally
        {
            lock (controlGate) controlSenderRunning = false;
            // A replacement arriving after the empty-mailbox check is not lost.
            QueueReadOptions();
        }
    }

    private void FailControlSend(Exception error)
    {
        string message = "Commande du lecteur non confirmée : " + error.GetBaseException().Message +
            " La liaison du lecteur a été arrêtée.";
        lock (controlGate)
        {
            if (disposed || stopping || !controlsReady) return;
            controlsReady = false;
            pendingReadOptions.Clear();
            controlFailure = message;
        }
        try { ControlError?.Invoke(message); } catch (Exception) { }
        try { lifetime?.Cancel(); } catch (ObjectDisposedException) { }
        // A partial command cannot be retried on the same framed stream. Closing
        // it also stops the child's control monitor, rather than using old needs.
        try { pipe?.Dispose(); } catch (IOException) { } catch (ObjectDisposedException) { }
    }

    private void PauseControls()
    {
        lock (controlGate) { controlsReady = false; pendingReadOptions.Clear(); }
    }

    [UnconditionalSuppressMessage("SingleFile", "IL3000", Justification = "Assembly.Location is used only for a developer invocation through dotnet; published single-file execution uses Environment.ProcessPath.")]
    public async Task StartAsync(WorkerStart settings, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(settings);
        await gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            ObjectDisposedException.ThrowIf(disposed, this);
            if (process != null) throw new InvalidOperationException("Le lecteur est déjà démarré.");
            stopping = false;
            controlFailure = null;
            lock (controlGate) controlsReady = false;
            lifetime = new CancellationTokenSource();
            string pipeName = "SevenDaysLoader-" + Guid.NewGuid().ToString("N");
            pipe = new NamedPipeServerStream(pipeName, PipeDirection.InOut, 1, PipeTransmissionMode.Byte,
                PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly, 65536, 65536);
            job = new OwnedJob();
            string executable = Environment.ProcessPath ?? throw new IOException("Chemin du lanceur introuvable.");
            var start = new ProcessStartInfo(executable)
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                WorkingDirectory = AppContext.BaseDirectory
            };
            // Also allow the developer's `dotnet 7DTD-Loader.dll` invocation.
            if (string.Equals(Path.GetFileNameWithoutExtension(executable), "dotnet", StringComparison.OrdinalIgnoreCase))
            {
                string assembly = Assembly.GetEntryAssembly()?.Location ?? "";
                if (string.IsNullOrWhiteSpace(assembly)) throw new IOException("Assembly de démarrage introuvable.");
                start.ArgumentList.Add(assembly);
            }
            start.ArgumentList.Add("--worker");
            start.ArgumentList.Add(pipeName);
            process = new Process { StartInfo = start, EnableRaisingEvents = true };
            if (!process.Start()) throw new IOException("Le processus de lecture n'a pas démarré.");
            job.Add(process);
            using var connect = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, lifetime.Token);
            connect.CancelAfter(TimeSpan.FromSeconds(12));
            Task connected = pipe.WaitForConnectionAsync(connect.Token);
            Task exited = process.WaitForExitAsync(connect.Token);
            Task first = await Task.WhenAny(connected, exited).ConfigureAwait(false);
            if (first == exited && process.HasExited)
                throw new IOException("Le lecteur s'est fermé avant sa connexion (code " + process.ExitCode + ").");
            await connected.ConfigureAwait(false);
            settings.ReadOptions = pendingReadOptions.TakeInitial(settings.ReadOptions ?? new LiveReadOptions());
            await Wire.WriteAsync(pipe, settings, connect.Token).ConfigureAwait(false);
            receiveTask = ReceiveAsync(pipe, process, lifetime.Token);
            lock (controlGate) controlsReady = !stopping && !receiveTask.IsCompleted;
            QueueReadOptions();
        }
        catch
        {
            stopping = true;
            await CleanupAsync(false).ConfigureAwait(false);
            throw;
        }
        finally { gate.Release(); }
    }

    private async Task ReceiveAsync(NamedPipeServerStream stream, Process ownedProcess, CancellationToken token)
    {
        string conclusion = "Le lecteur s'est arrêté.";
        try
        {
            while (!token.IsCancellationRequested)
            {
                WorkerMessage message = await Wire.ReadAsync<WorkerMessage>(stream, token).ConfigureAwait(false);
                // Notifications cannot take down the pipe reader if a view closes
                // concurrently. State observers are responsible for their own UI.
                try { Message?.Invoke(message); } catch (Exception) { }
            }
        }
        catch (OperationCanceledException) when (token.IsCancellationRequested) { }
        catch (ObjectDisposedException) when (stopping) { }
        catch (IOException) when (stopping) { }
        catch (Exception e)
        {
            conclusion = "Lecture interrompue : " + e.GetBaseException().Message;
            try
            {
                if (!ownedProcess.HasExited && e is EndOfStreamException)
                {
                    try { await ownedProcess.WaitForExitAsync(token).WaitAsync(TimeSpan.FromMilliseconds(250), token).ConfigureAwait(false); }
                    catch (TimeoutException) { }
                    catch (OperationCanceledException) { }
                }
                if (ownedProcess.HasExited)
                    conclusion = "Le lecteur s'est fermé (code " + ownedProcess.ExitCode + ").";
            }
            catch (InvalidOperationException) { }
        }
        finally
        {
            bool currentSession;
            lock (controlGate)
            {
                currentSession = ReferenceEquals(pipe, stream);
                if (currentSession) { controlsReady = false; pendingReadOptions.Clear(); }
            }
            if (!stopping && currentSession)
                try { Ended?.Invoke(controlFailure ?? conclusion); } catch (Exception) { }
        }
    }

    public async Task StopAsync()
    {
        stopping = true;
        PauseControls();
        await gate.WaitAsync().ConfigureAwait(false);
        try
        {
            stopping = true;
            await CleanupAsync(true).ConfigureAwait(false);
        }
        finally { gate.Release(); }
    }

    private async Task CleanupAsync(bool graceful)
    {
        PauseControls();
        if (graceful && pipe is { IsConnected: true })
        {
            try
            {
                using var brief = new CancellationTokenSource(250);
                await Wire.WriteAsync(pipe, new WorkerControl { Kind = WorkerControl.StopKind }, brief.Token).ConfigureAwait(false);
            }
            catch (Exception) { }
        }
        lifetime?.Cancel();
        try { pipe?.Dispose(); } catch (IOException) { }
        if (process != null)
        {
            try
            {
                if (!process.HasExited)
                {
                    try { await process.WaitForExitAsync().WaitAsync(TimeSpan.FromMilliseconds(graceful ? 1500 : 100)).ConfigureAwait(false); }
                    catch (TimeoutException)
                    {
                        // Never search by process name/PID from configuration.
                        // This Process object is the exact child started above.
                        try { process.Kill(entireProcessTree: true); } catch (InvalidOperationException) { }
                        try { await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(2)).ConfigureAwait(false); }
                        catch (TimeoutException) { }
                    }
                }
            }
            catch (InvalidOperationException) { }
            catch (System.ComponentModel.Win32Exception) { }
        }
        // KILL_ON_JOB_CLOSE is the fallback if the child could not exit normally.
        job?.Dispose();
        job = null;
        if (receiveTask != null)
        {
            try { await receiveTask.WaitAsync(TimeSpan.FromSeconds(1)).ConfigureAwait(false); }
            catch (Exception) { }
        }
        process?.Dispose();
        process = null;
        pipe = null;
        receiveTask = null;
        lifetime?.Dispose();
        lifetime = null;
    }

    public async ValueTask DisposeAsync()
    {
        stopping = true;
        PauseControls();
        await gate.WaitAsync().ConfigureAwait(false);
        try
        {
            if (disposed) return;
            disposed = true;
            stopping = true;
            await CleanupAsync(true).ConfigureAwait(false);
        }
        finally { gate.Release(); }
    }
}
