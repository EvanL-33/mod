﻿// Lecture des ressources RT_VERSION d'une image PE deja mappee dans le processus.
// Aucun acces au disque cible, appel dans le jeu ou scan general de sa memoire.
// Sources :
// https://learn.microsoft.com/windows/win32/debug/pe-format
// https://learn.microsoft.com/windows/win32/menurc/vs-versioninfo
// https://learn.microsoft.com/windows/win32/menurc/string-str
// https://learn.microsoft.com/windows/win32/api/verrsrc/ns-verrsrc-vs_fixedfileinfo
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;

namespace SevenDaysEsp
{
    public sealed class ModuleVersionReport
    {
        public string ModuleName { get; set; }
        public string Status { get; set; }
        public string Message { get; set; }
        public string Source { get; set; }
        public string Confidence { get; set; }
        public bool ExactGameBuildKnown { get { return false; } }
        public string DeclaredFileVersion { get; set; }
        public string DeclaredProductVersion { get; set; }
        public string FixedFileVersion { get; set; }
        public string FixedProductVersion { get; set; }
        public long BytesRead { get; set; }
        public long ElapsedMilliseconds { get; set; }
        public List<VersionResourceEntry> Entries { get; set; }
        public List<string> Warnings { get; set; }

        public ModuleVersionReport()
        {
            Source = "RT_VERSION de l'image PE chargee, lue par DMA";
            Confidence = "Versions declarees du module uniquement ; build exact du jeu non etabli";
            Entries = new List<VersionResourceEntry>();
            Warnings = new List<string>();
        }
    }

    public sealed class VersionResourceEntry
    {
        public string ResourceName { get; set; }
        public string ResourceLanguage { get; set; }
        public uint ResourceCodePage { get; set; }
        public string FixedFileVersion { get; set; }
        public string FixedProductVersion { get; set; }
        public List<VersionStringTable> StringTables { get; set; }
        public VersionResourceEntry() { StringTables = new List<VersionStringTable>(); }
    }

    public sealed class VersionStringTable
    {
        public string LanguageAndCodePage { get; set; }
        public string FileVersion { get; set; }
        public string ProductVersion { get; set; }
        public string ProductName { get; set; }
        public string FileDescription { get; set; }
        public string OriginalFilename { get; set; }
    }

    public sealed class RemoteVersionInspector
    {
        private sealed class LimitException : IOException
        {
            public LimitException(string message) : base(message) { }
        }
        private sealed class ResourceNode
        {
            public uint Name;
            public uint Child;
        }
        private readonly IMemoryReader memory;
        private Stopwatch watch;
        private long bytesRead;
        private ulong moduleBase;
        private uint imageSize;
        private uint resourceRva;
        private uint resourceSize;
        private int directoryCount;
        private int leafCount;
        private bool partial;
        private const int MaximumBytes = 2 * 1024 * 1024;
        private const int MaximumMilliseconds = 5000;
        private const int MaximumDirectoryEntries = 2048;
        private const int MaximumDirectories = 128;
        private const int MaximumVersionResources = 32;
        private static readonly UnicodeEncoding Utf16 = new UnicodeEncoding(false, false, true);

        public RemoteVersionInspector(IMemoryReader reader)
        {
            if (reader == null) throw new ArgumentNullException("reader");
            memory = reader;
        }

        // Call sequentially. Each invocation has an independent bounded read budget.
        public ModuleVersionReport Inspect(string moduleName)
        {
            ModuleVersionReport report = new ModuleVersionReport { ModuleName = moduleName };
            watch = Stopwatch.StartNew();
            bytesRead = 0;
            moduleBase = 0;
            imageSize = 0;
            resourceRva = 0;
            resourceSize = 0;
            directoryCount = 0;
            leafCount = 0;
            partial = false;
            try
            {
                if (String.IsNullOrWhiteSpace(moduleName) || moduleName.IndexOf('\0') >= 0)
                    throw new IOException("Nom de module invalide.");
                moduleBase = memory.ModuleBase(moduleName);
                if (moduleBase == 0)
                    return Finish(report, "MODULE_ABSENT", "Le module n'est pas present dans la vue courante du jeu.");
                RequireRange(moduleBase, 64);
                ReadHeaders();
                if (resourceRva == 0 || resourceSize == 0)
                    return Finish(report, "VERSION_ABSENTE", "Aucun repertoire de ressources PE n'est declare.");

                bool foundType = false;
                List<ResourceNode> root = ReadDirectory(0);
                foreach (ResourceNode type in root)
                {
                    // RT_VERSION is the numeric Windows resource type 16. Do not
                    // inspect unrelated resources or treat a custom name as that type.
                    if ((type.Name & 0x80000000U) != 0 || type.Name != 16U) continue;
                    foundType = true;
                    try
                    {
                        if ((type.Child & 0x80000000U) == 0)
                            throw new IOException("Le type RT_VERSION ne pointe pas vers un repertoire.");
                        HashSet<uint> active = new HashSet<uint>();
                        active.Add(0);
                        WalkVersions(type.Child & 0x7FFFFFFFU, 1, null, null, active, report);
                    }
                    catch (LimitException) { throw; }
                    catch (IOException ex) { partial = true; AddWarning(report, ex.Message); }
                }
                Summarize(report);
                if (!foundType)
                    return Finish(report, "VERSION_ABSENTE", "Aucune ressource standard RT_VERSION n'est declaree.");
                if (report.Entries.Count == 0)
                    return Finish(report, partial ? "VERSION_ILLISIBLE" : "VERSION_ABSENTE", "Aucune ressource de version exploitable n'a ete lue.");
                if (report.DeclaredFileVersion == null && report.DeclaredProductVersion == null &&
                    report.FixedFileVersion == null && report.FixedProductVersion == null)
                    return Finish(report, partial ? "VERSIONS_PARTIELLES" : "VERSION_ABSENTE", "Ressource lue, mais aucun numero de version unique exploitable.");
                return Finish(report, partial ? "VERSIONS_PARTIELLES" : "VERSIONS_LUES",
                    "Versions declarees du binaire relevees. Elles peuvent designer le moteur Unity et ne prouvent pas le numero du menu du jeu.");
            }
            catch (LimitException ex)
            {
                AddWarning(report, ex.Message);
                Summarize(report);
                return Finish(report, "LIMITE_LECTURE", ex.Message);
            }
            catch (Exception ex)
            {
                AddWarning(report, ex.GetType().Name + ": " + ex.Message);
                Summarize(report);
                return Finish(report, report.Entries.Count > 0 ? "VERSIONS_PARTIELLES" : "VERSION_ILLISIBLE",
                    "La ressource distante est absente de la vue lisible, incomplete ou incompatible avec le parseur.");
            }
        }

        private void ReadHeaders()
        {
            byte[] dos = ReadAbsolute(moduleBase, 64);
            if (U16(dos, 0) != 0x5A4D) throw new IOException("Signature MZ absente.");
            uint peOffset = U32(dos, 0x3C);
            if (peOffset < 64 || peOffset > 1024 * 1024) throw new IOException("Offset PE hors limites.");
            byte[] pe = ReadAbsolute(Add(moduleBase, peOffset), 24);
            if (U32(pe, 0) != 0x4550 || U16(pe, 4) != 0x8664)
                throw new IOException("Image PE AMD64 attendue.");
            ushort optionalSize = U16(pe, 20);
            if (optionalSize < 112 || optionalSize > 4096)
                throw new IOException("Taille d'en-tete optionnel invalide.");
            byte[] optional = ReadAbsolute(Add(moduleBase, (ulong)peOffset + 24), optionalSize);
            if (U16(optional, 0) != 0x20B) throw new IOException("En-tete PE32+ attendu.");
            imageSize = U32(optional, 56);
            uint headerSize = U32(optional, 60);
            if (imageSize < 4096 || imageSize > 0x80000000U ||
                headerSize < (ulong)peOffset + 24UL + optionalSize || headerSize > imageSize)
                throw new IOException("Dimensions de l'image PE incoherentes.");
            RequireRange(moduleBase, imageSize);
            uint directories = U32(optional, 108);
            if (directories < 3) return;
            if (optionalSize < 136) throw new IOException("Entree du repertoire de ressources tronquee.");
            resourceRva = U32(optional, 128);
            resourceSize = U32(optional, 132);
            if (resourceRva == 0 && resourceSize == 0) return;
            if (resourceRva == 0 || resourceSize < 16 || resourceRva > imageSize || resourceSize > imageSize - resourceRva)
                throw new IOException("Repertoire de ressources hors de l'image mappee.");
        }

        private List<ResourceNode> ReadDirectory(uint relativeOffset)
        {
            if (++directoryCount > MaximumDirectories)
                throw new LimitException("Limite de repertoires de ressources atteinte.");
            byte[] header = ReadResource(relativeOffset, 16);
            int count = U16(header, 12) + U16(header, 14);
            if (count > MaximumDirectoryEntries)
                throw new LimitException("Trop d'entrees dans un repertoire de ressources.");
            List<ResourceNode> entries = new List<ResourceNode>();
            if (count == 0) return entries;
            byte[] table = ReadResource(CheckedOffset(relativeOffset, 16), checked(count * 8));
            for (int i = 0; i < count; ++i)
                entries.Add(new ResourceNode { Name = U32(table, i * 8), Child = U32(table, i * 8 + 4) });
            return entries;
        }

        private void WalkVersions(uint offset, int depth, string resourceName, string language,
            HashSet<uint> active, ModuleVersionReport report)
        {
            CheckBudget();
            if (depth < 1 || depth > 2 || !active.Add(offset))
                throw new IOException("Arbre RT_VERSION cyclique ou profondeur non standard.");
            try
            {
                foreach (ResourceNode entry in ReadDirectory(offset))
                {
                    CheckBudget();
                    try
                    {
                        string name = ResourceName(entry.Name);
                        if (depth == 1)
                        {
                            if ((entry.Child & 0x80000000U) == 0)
                                throw new IOException("Une ressource RT_VERSION n'a pas de repertoire de langues.");
                            WalkVersions(entry.Child & 0x7FFFFFFFU, 2, name, null, active, report);
                        }
                        else
                        {
                            if ((entry.Child & 0x80000000U) != 0)
                                throw new IOException("Profondeur supplementaire dans une ressource RT_VERSION.");
                            if (++leafCount > MaximumVersionResources)
                                throw new LimitException("Limite de ressources de version atteinte (32).");
                            byte[] data = ReadResource(entry.Child, 16);
                            uint valueRva = U32(data, 0);
                            uint valueSize = U32(data, 4);
                            if (valueSize < 6 || valueSize > 1024 * 1024 || (valueRva & 3) != 0)
                                throw new IOException("Dimensions ou alignement de la ressource de version invalides.");
                            CheckImageRange(valueRva, valueSize);
                            byte[] prefix = ReadImage(valueRva, 6);
                            int actualLength = U16(prefix, 0);
                            if (actualLength < 6 || actualLength > valueSize)
                                throw new IOException("Longueur VS_VERSION_INFO hors de la ressource.");
                            byte[] blob = ReadImage(valueRva, actualLength);
                            VersionResourceEntry item = new VersionBlobParser(blob).Parse();
                            item.ResourceName = resourceName;
                            item.ResourceLanguage = name;
                            item.ResourceCodePage = U32(data, 8);
                            report.Entries.Add(item);
                        }
                    }
                    catch (LimitException) { throw; }
                    catch (IOException ex) { partial = true; AddWarning(report, ex.Message); }
                }
            }
            finally { active.Remove(offset); }
        }

        private string ResourceName(uint value)
        {
            if ((value & 0x80000000U) == 0)
                return "#" + value.ToString(CultureInfo.InvariantCulture);
            uint offset = value & 0x7FFFFFFFU;
            int chars = U16(ReadResource(offset, 2), 0);
            if (chars > 256) throw new IOException("Nom de ressource trop long.");
            if (chars == 0) return String.Empty;
            return DecodeText(ReadResource(CheckedOffset(offset, 2), checked(chars * 2)), 0, chars * 2, false);
        }

        private void Summarize(ModuleVersionReport report)
        {
            List<string> fileStrings = new List<string>();
            List<string> productStrings = new List<string>();
            List<string> fixedFiles = new List<string>();
            List<string> fixedProducts = new List<string>();
            foreach (VersionResourceEntry entry in report.Entries)
            {
                fixedFiles.Add(entry.FixedFileVersion);
                fixedProducts.Add(entry.FixedProductVersion);
                foreach (VersionStringTable table in entry.StringTables)
                {
                    fileStrings.Add(table.FileVersion);
                    productStrings.Add(table.ProductVersion);
                }
            }
            report.DeclaredFileVersion = Unique(fileStrings, "FileVersion", report);
            report.DeclaredProductVersion = Unique(productStrings, "ProductVersion", report);
            report.FixedFileVersion = Unique(fixedFiles, "VS_FIXEDFILEINFO.FileVersion", report);
            report.FixedProductVersion = Unique(fixedProducts, "VS_FIXEDFILEINFO.ProductVersion", report);
        }

        private string Unique(List<string> values, string label, ModuleVersionReport report)
        {
            HashSet<string> distinct = new HashSet<string>(StringComparer.Ordinal);
            foreach (string value in values) if (!String.IsNullOrWhiteSpace(value)) distinct.Add(value.Trim());
            if (distinct.Count > 1)
            {
                partial = true;
                string warning = "Valeurs divergentes pour " + label + " ; consulter chaque langue, aucune valeur choisie automatiquement.";
                AddWarning(report, warning);
                return null;
            }
            foreach (string value in distinct) return value;
            return null;
        }

        private ModuleVersionReport Finish(ModuleVersionReport report, string status, string message)
        {
            report.Status = status;
            report.Message = message;
            report.BytesRead = bytesRead;
            report.ElapsedMilliseconds = watch.ElapsedMilliseconds;
            return report;
        }
        private static void AddWarning(ModuleVersionReport report, string warning)
        {
            if (report.Warnings.Contains(warning)) return;
            if (report.Warnings.Count < 64) report.Warnings.Add(warning);
            else if (report.Warnings.Count == 64) report.Warnings.Add("Autres anomalies omises apres 64 avertissements.");
        }
        private byte[] ReadAbsolute(ulong address, int length)
        {
            CheckBudget();
            RequireRange(address, (ulong)length);
            if (length < 1 || length > 1024 * 1024 || bytesRead > MaximumBytes - length)
                throw new LimitException("Budget de lecture des versions atteint (2 Mio par module).");
            byte[] data = memory.Read(address, length);
            bytesRead += length;
            if (data == null || data.Length != length) throw new IOException("Lecture distante de version incomplete.");
            CheckBudget();
            return data;
        }
        private byte[] ReadImage(uint rva, int length)
        {
            CheckImageRange(rva, (uint)length);
            return ReadAbsolute(Add(moduleBase, rva), length);
        }
        private byte[] ReadResource(uint offset, int length)
        {
            if (length < 1 || offset > resourceSize || (uint)length > resourceSize - offset)
                throw new IOException("Structure de ressources hors du repertoire declare.");
            return ReadImage(CheckedOffset(resourceRva, offset), length);
        }
        private void CheckImageRange(uint rva, uint length)
        {
            if (length == 0 || rva > imageSize || length > imageSize - rva)
                throw new IOException("RVA hors de l'image mappee.");
        }
        private void CheckBudget()
        {
            if (watch.ElapsedMilliseconds > MaximumMilliseconds)
                throw new LimitException("Budget de temps des versions atteint (5 s entre appels natifs). Un appel materiel peut depasser ce delai.");
        }
        private static void RequireRange(ulong address, ulong length)
        {
            if (length == 0 || address < 0x10000 || address > 0x00007FFFFFFFFFFFUL ||
                length - 1 > 0x00007FFFFFFFFFFFUL - address)
                throw new IOException("Plage virtuelle utilisateur invalide.");
        }
        private static ulong Add(ulong address, ulong offset)
        {
            if (offset > UInt64.MaxValue - address) throw new IOException("Depassement d'adresse.");
            return address + offset;
        }
        private static uint CheckedOffset(uint a, uint b)
        {
            if (b > UInt32.MaxValue - a) throw new IOException("Depassement de RVA.");
            return a + b;
        }
        private static ushort U16(byte[] bytes, int offset) { return BitConverter.ToUInt16(bytes, offset); }
        private static uint U32(byte[] bytes, int offset) { return BitConverter.ToUInt32(bytes, offset); }
        private static string DecodeText(byte[] bytes, int offset, int length, bool terminalNull)
        {
            string text;
            try { text = Utf16.GetString(bytes, offset, length); }
            catch (DecoderFallbackException) { throw new IOException("Texte UTF-16 de version invalide."); }
            if (terminalNull)
            {
                if (text.Length == 0 || text[text.Length - 1] != '\0')
                    throw new IOException("Chaine de version sans terminaison NUL.");
                text = text.TrimEnd('\0');
            }
            foreach (char c in text) if (Char.IsControl(c)) throw new IOException("Caractere de controle dans une version.");
            return text;
        }

        private sealed class VersionBlobParser
        {
            private sealed class Node
            {
                public int End;
                public int ValueStart;
                public int ValueBytes;
                public int ChildrenStart;
                public ushort Type;
                public string Key;
            }
            private readonly byte[] bytes;
            private int nodeCount;
            public VersionBlobParser(byte[] resource) { bytes = resource; }

            public VersionResourceEntry Parse()
            {
                VersionResourceEntry result = new VersionResourceEntry();
                Node root = ReadNode(0, bytes.Length);
                if (root.Key != "VS_VERSION_INFO" || root.Type != 0)
                    throw new IOException("Racine VS_VERSION_INFO binaire attendue.");
                if (root.ValueBytes != 0)
                {
                    if (root.ValueBytes != 52 || U32(bytes, root.ValueStart) != 0xFEEF04BDU ||
                        U32(bytes, root.ValueStart + 4) != 0x00010000U)
                        throw new IOException("VS_FIXEDFILEINFO invalide ou version inconnue.");
                    result.FixedFileVersion = Version(U32(bytes, root.ValueStart + 8), U32(bytes, root.ValueStart + 12));
                    result.FixedProductVersion = Version(U32(bytes, root.ValueStart + 16), U32(bytes, root.ValueStart + 20));
                }
                foreach (Node child in Children(root))
                {
                    if (child.Key != "StringFileInfo") continue;
                    if (child.Type != 1 || child.ValueBytes != 0) throw new IOException("StringFileInfo contient un type ou une valeur inattendue.");
                    foreach (Node language in Children(child))
                    {
                        if (!IsLanguageKey(language.Key) || language.Type != 1 || language.ValueBytes != 0)
                            throw new IOException("Table de traduction de version invalide.");
                        VersionStringTable table = new VersionStringTable { LanguageAndCodePage = language.Key };
                        Dictionary<string, string> values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                        foreach (Node field in Children(language))
                        {
                            if (!WantedKey(field.Key)) continue;
                            if (field.Type != 1 || field.ValueBytes > 4096)
                                throw new IOException("Type ou longueur de chaine de version invalide.");
                            string value = field.ValueBytes == 0 ? String.Empty : DecodeText(bytes, field.ValueStart, field.ValueBytes, true);
                            string previous;
                            if (values.TryGetValue(field.Key, out previous) && previous != value)
                                throw new IOException("Valeurs dupliquees contradictoires dans une traduction.");
                            values[field.Key] = value;
                        }
                        table.FileVersion = Value(values, "FileVersion");
                        table.ProductVersion = Value(values, "ProductVersion");
                        table.ProductName = Value(values, "ProductName");
                        table.FileDescription = Value(values, "FileDescription");
                        table.OriginalFilename = Value(values, "OriginalFilename");
                        result.StringTables.Add(table);
                    }
                }
                return result;
            }

            private Node ReadNode(int start, int parentEnd)
            {
                if (++nodeCount > 2048) throw new IOException("Trop de blocs dans une ressource de version.");
                if (start < 0 || parentEnd > bytes.Length || start > parentEnd - 6)
                    throw new IOException("Bloc de version tronque.");
                int length = U16(bytes, start);
                int valueLength = U16(bytes, start + 2);
                ushort type = U16(bytes, start + 4);
                if (length < 8 || length > parentEnd - start || type > 1)
                    throw new IOException("Longueur ou type de bloc de version invalide.");
                int end = start + length;
                int p = start + 6;
                int keyStart = p;
                bool terminated = false;
                for (int n = 0; n < 256 && p <= end - 2; ++n, p += 2)
                {
                    if (U16(bytes, p) == 0) { terminated = true; break; }
                }
                if (!terminated) throw new IOException("Cle de version sans terminaison dans sa borne.");
                string key = DecodeText(bytes, keyStart, p - keyStart, false);
                p += 2;
                int valueStart = Align(p);
                int valueBytes = type == 1 ? checked(valueLength * 2) : valueLength;
                if (valueBytes == 0 && valueStart > end) valueStart = end;
                if (valueStart > end || valueBytes > end - valueStart)
                    throw new IOException("Valeur de version hors du bloc parent.");
                int children = Align(valueStart + valueBytes);
                if (children > end) children = end;
                return new Node { End = end, ValueStart = valueStart, ValueBytes = valueBytes,
                    ChildrenStart = children, Type = type, Key = key };
            }

            private List<Node> Children(Node parent)
            {
                List<Node> result = new List<Node>();
                int p = parent.ChildrenStart;
                while (p < parent.End)
                {
                    bool onlyPadding = true;
                    if (parent.End - p <= 3)
                    {
                        for (int i = p; i < parent.End; ++i) if (bytes[i] != 0) onlyPadding = false;
                        if (onlyPadding) break;
                    }
                    Node node = ReadNode(p, parent.End);
                    result.Add(node);
                    p = Align(node.End);
                }
                return result;
            }
            private static int Align(int value) { return checked((value + 3) & ~3); }
            private static string Version(uint high, uint low)
            {
                return (high >> 16).ToString(CultureInfo.InvariantCulture) + "." + (high & 65535U).ToString(CultureInfo.InvariantCulture) + "." +
                    (low >> 16).ToString(CultureInfo.InvariantCulture) + "." + (low & 65535U).ToString(CultureInfo.InvariantCulture);
            }
            private static bool IsLanguageKey(string key)
            {
                if (key.Length != 8) return false;
                foreach (char c in key)
                    if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'))) return false;
                return true;
            }
            private static bool WantedKey(string key)
            {
                return String.Equals(key, "FileVersion", StringComparison.OrdinalIgnoreCase) ||
                    String.Equals(key, "ProductVersion", StringComparison.OrdinalIgnoreCase) ||
                    String.Equals(key, "ProductName", StringComparison.OrdinalIgnoreCase) ||
                    String.Equals(key, "FileDescription", StringComparison.OrdinalIgnoreCase) ||
                    String.Equals(key, "OriginalFilename", StringComparison.OrdinalIgnoreCase);
            }
            private static string Value(Dictionary<string, string> values, string key)
            {
                string value;
                return values.TryGetValue(key, out value) ? value : null;
            }
        }
    }
}
