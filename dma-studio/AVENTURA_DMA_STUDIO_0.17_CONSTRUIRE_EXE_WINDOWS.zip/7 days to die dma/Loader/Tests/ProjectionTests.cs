using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SevenDaysEsp;

// These tests exercise the production helper with analytic cameras. They do not
// identify the game's native camera. Freshness belongs to the feed/UI layer, so
// no test gives the pure geometry helper an artificial clock or fake game data.
internal static class ProjectionTests
{
    public static Task KnownPerspectiveAndViewport()
    {
        // Analytic 90-degree symmetric projection, near=1, far=10. This is a test
        // fixture only; production never supplies a guessed FOV or near plane.
        var view = Perspective();
        Check(ProjectionMath.TryProjectPoint(view, Point(1, 1, -2), out var projected), "Known visible point rejected.");
        Close(projected.X, 750); Close(projected.Y, 200);
        var offset = View(PerspectiveMatrix(), Point(0, 0, 0), 800, 600, new(100, 50, 400, 200));
        Check(ProjectionMath.TryProjectPoint(offset, Point(1, 1, -2), out projected), "Offset viewport point rejected.");
        Close(projected.X, 400); Close(projected.Y, 100);
        Check(ProjectionMath.TryProjectPoint(offset, Point(-2, 2, -2), out projected), "Viewport corner rejected.");
        Close(projected.X, 100); Close(projected.Y, 50);

        // P * V for a camera translated +2 on X, without moving or transposing
        // coefficients to make the result fit. Camera-space point is (1,1,-2).
        float[] translated = PerspectiveMatrix();
        translated[3] = -2;
        view = View(translated, Point(0, 0, 0));
        Check(ProjectionMath.TryProjectPoint(view, Point(3, 1, -2), out projected), "Translated view rejected.");
        Close(projected.X, 750); Close(projected.Y, 200);
        // Camera faces +X: (world Z, world Y, -world X) is camera space.
        view = View(RotatedPerspectiveMatrix(), Point(0, 0, 0));
        Check(ProjectionMath.TryProjectPoint(view, Point(2, 1, 1), out projected), "Rotated view rejected.");
        Close(projected.X, 750); Close(projected.Y, 200);
        return Task.CompletedTask;
    }

    public static Task OriginIsAppliedOnceAndInputsAreCopied()
    {
        var matrix = Identity();
        matrix[3] = .25f;
        matrix[7] = -.5f;
        var origin = Point(100, 200, -300);
        var view = View(matrix, origin);
        matrix[0] = 1000;
        matrix[3] = 1000;
        origin.X = -1000;
        Check(ProjectionMath.TryProjectPoint(view, Point(100.25f, 200.5f, -300), out var p), "View changed with caller's buffers.");
        Close(p.X, 750); Close(p.Y, 400);

        // Large global coordinates are subtracted before multiplication. A
        // second subtraction or subtraction after projection fails this case.
        view = View(Identity(), Point(999999, -999999, 500000));
        Check(ProjectionMath.TryProjectPoint(view, Point(999999.5f, -999998.5f, 500000), out p), "Global origin rejected.");
        Close(p.X, 750); Close(p.Y, 200);
        return Task.CompletedTask;
    }

    public static Task ClipPlanesAndDepthRanges()
    {
        var view = Perspective();
        foreach (var point in new[] { Point(0, 0, 2), Point(0, 0, 0), Point(0, 0, -.5f),
            Point(0, 0, -10.1f), Point(3, 0, -2), Point(0, 3, -2) })
            Check(!ProjectionMath.TryProjectPoint(view, point, out _), "Point outside a clip plane was displayed.");
        Check(ProjectionMath.TryProjectPoint(view, Point(0, 0, -1), out _), "Near plane boundary rejected.");
        Check(ProjectionMath.TryProjectPoint(view, Point(0, 0, -10), out _), "Far plane boundary rejected.");
        Check(ProjectionMath.TryProjectPoint(view, Point(2, -2, -2), out var corner), "Right/bottom boundary rejected.");
        Close(corner.X, 1000); Close(corner.Y, 800);

        var gl = View(Identity(), Point(0, 0, 0));
        var zeroToOne = View(Identity(), Point(0, 0, 0), depth: ProjectionDepthRange.ZeroToOne);
        Check(ProjectionMath.TryProjectPoint(gl, Point(0, 0, -.5f), out _), "OpenGL clip interval lost its negative half.");
        Check(!ProjectionMath.TryProjectPoint(zeroToOne, Point(0, 0, -.5f), out _), "Zero-to-one depth accepted negative Z.");
        Check(ProjectionMath.TryProjectPoint(zeroToOne, Point(0, 0, 0), out _), "Zero-to-one near boundary rejected.");
        Check(ProjectionMath.TryProjectPoint(zeroToOne, Point(0, 0, 1), out _), "Zero-to-one far boundary rejected.");
        Check(!ProjectionMath.TryProjectPoint(zeroToOne, Point(0, 0, 1.1f), out _), "Zero-to-one far clip absent.");

        var tinyW = Identity(); tinyW[15] = 0.0000002f;
        view = View(tinyW, Point(0, 0, 0));
        Check(!ProjectionMath.TryProjectPoint(view, Point(0.000002f, 0, 0), out _), "Tolerance pinned an offscreen point with small W to the edge.");
        tinyW[15] = 0.00000001f;
        view = View(tinyW, Point(0, 0, 0));
        Check(!ProjectionMath.TryProjectPoint(view, Point(0, 0, 0), out _), "Unstable perspective divide accepted.");
        return Task.CompletedTask;
    }

    public static Task ActualBoundsAndNearPlaneClipping()
    {
        var view = Perspective();
        Check(ProjectionMath.TryProjectBounds(view, Bounds(7, -.5f, -1, -5, .5f, 1, -3), out var box), "Known box rejected.");
        Close(box.Left, 1000.0 * 5 / 12); Close(box.Right, 1000.0 * 7 / 12);
        Close(box.Top, 800.0 / 3); Close(box.Bottom, 1600.0 / 3);

        // Box crosses the near plane. Its projected bounds come from the new
        // intersection face at z=-1, not its out-of-frustum front corners.
        Check(ProjectionMath.TryProjectBounds(view, Bounds(7, -.5f, -.5f, -2, .5f, .5f, -.5f), out box), "Near-plane crossing box disappeared.");
        Close(box.Left, 250); Close(box.Right, 750); Close(box.Top, 200); Close(box.Bottom, 600);

        // Camera and complete frustum are inside this box. Original visible
        // edges alone are insufficient; capped solid clipping must retain it.
        Check(ProjectionMath.TryProjectBounds(view, Bounds(7, -20, -20, -20, 20, 20, 1), out box), "Frustum-containing box disappeared.");
        Close(box.Left, 0); Close(box.Right, 1000); Close(box.Top, 0); Close(box.Bottom, 800);

        Check(ProjectionMath.TryProjectBounds(view, Bounds(7, -5, -.5f, -3, -1, .5f, -2), out box), "Partially visible box disappeared.");
        Close(box.Left, 0); Close(box.Right, 1000.0 / 3); Close(box.Top, 300); Close(box.Bottom, 500);
        Check(!ProjectionMath.TryProjectBounds(view, Bounds(7, 3, 3, -2, 4, 4, -1.5f), out _), "Fully offscreen box pinned to viewport.");
        Check(!ProjectionMath.TryProjectBounds(view, Bounds(7, -.5f, -.5f, 1, .5f, .5f, 2), out _), "Box behind camera accepted.");

        var rotated = View(RotatedPerspectiveMatrix(), Point(0, 0, 0));
        Check(ProjectionMath.TryProjectBounds(rotated, Bounds(7, .5f, -.5f, -.5f, 2, .5f, .5f), out box), "Rotated near-plane cap disappeared.");
        Close(box.Left, 250); Close(box.Right, 750); Close(box.Top, 200); Close(box.Bottom, 600);

        var offset = View(PerspectiveMatrix(), Point(100, 20, 200), 800, 600, new(100, 50, 400, 200));
        Check(ProjectionMath.TryProjectBounds(offset, Bounds(7, 99.5f, 19.5f, 198, 100.5f, 20.5f, 199.5f), out box), "Bounds origin or offset viewport failed.");
        Close(box.Left, 200); Close(box.Right, 400); Close(box.Top, 100); Close(box.Bottom, 200);
        return Task.CompletedTask;
    }

    public static Task InvalidViewsAndBoundsAreRejected()
    {
        var invalidMatrices = new List<float[]?> { null, new float[15], new float[17], new float[16] };
        foreach (float value in new[] { float.NaN, float.PositiveInfinity, float.NegativeInfinity, float.MaxValue })
        {
            float[] matrix = Identity(); matrix[3] = value; invalidMatrices.Add(matrix);
        }
        foreach (var matrix in invalidMatrices)
            Check(!ProjectionMath.TryCreateView(matrix, Point(0, 0, 0), 1000, 800, new(0, 0, 1000, 800),
                ProjectionDepthRange.MinusOneToOne, out var invalidView, out var reason) && invalidView == null && reason.Length > 0,
                "Invalid matrix created a view.");
        foreach (var rect in new[] { new ProjectionViewport(-1, 0, 1000, 800), new(0, 0, 0, 800), new(1, 0, 1000, 800),
            new(0, 1, 1000, 800), new(double.NaN, 0, 1000, 800), new(0, 0, double.PositiveInfinity, 800) })
            Check(!ProjectionMath.TryCreateView(Identity(), Point(0, 0, 0), 1000, 800, rect,
                ProjectionDepthRange.MinusOneToOne, out _, out _), "Invalid viewport accepted.");
        Check(!ProjectionMath.TryCreateView(Identity(), Point(0, 0, 0), 32769, 800, new(0, 0, 1000, 800),
            ProjectionDepthRange.MinusOneToOne, out _, out _), "Oversized image accepted.");
        Check(!ProjectionMath.TryCreateView(Identity(), Point(0, 0, 0), 1000, 800, new(0, 0, 1000, 800),
            (ProjectionDepthRange)99, out _, out _), "Unknown clip interval accepted.");
        Check(!ProjectionMath.TryCreateView(Identity(), Point(float.NaN, 0, 0), 1000, 800, new(0, 0, 1000, 800),
            ProjectionDepthRange.MinusOneToOne, out _, out _), "Invalid origin accepted.");

        var view = Perspective();
        foreach (var b in new[]
        {
            new ProjectionEntityBounds(7, Point(-1,-1,-3), Point(1,1,-2), false),
            Bounds(7, 1, -1, -3, -1, 1, -2), Bounds(7, 0, -1, -3, 0, 1, -2),
            Bounds(7, -1, -1, -3, float.NaN, 1, -2), Bounds(7, -1, -1, -3, 1_000_001, 1, -2),
            new ProjectionEntityBounds(7, null, Point(1,1,-2), true)
        }) Check(!ProjectionMath.TryProjectBounds(view, b, out _), "Unvalidated/invalid bounds were drawn.");
        Check(!ProjectionMath.TryProjectPoint(view, Point(float.NaN, 0, -2), out _), "NaN position accepted.");
        Check(!ProjectionMath.TryProjectPoint(view, Point(1_000_001, 0, -2), out _), "Unbounded world position accepted.");
        return Task.CompletedTask;
    }

    public static Task FrameUsesActualEntitiesWithoutInventedBounds()
    {
        var view = Perspective();
        var first = new LiveEntity { EntityId = 7, Kind = "zombie", Name = "A\nB", Position = Point(0, 0, -2) };
        var entities = new List<LiveEntity> { first };
        Check(ProjectionMath.TryBuildFrame(view, Point(0, 0, 0), 5, entities, null, out var frame, out _), "Valid frame rejected.");
        Check(frame!.Markers.Count == 1 && frame.Markers[0].Name == "AB" && frame.Markers[0].Kind == "zombie", "Entity identity/label changed.");
        Check(frame.Markers[0].Bounds == null && frame.Markers[0].Anchor != null, "Height or silhouette was invented.");
        Close(frame.Markers[0].DistanceMeters, 2);
        Close(frame.Markers[0].Anchor!.Value.X, 500); Close(frame.Markers[0].Anchor!.Value.Y, 400);
        first.Position.X = 100; first.Name = "changed"; entities.Clear();
        Check(frame.Markers.Count == 1 && frame.Markers[0].Name == "AB", "Published frame was mutable through input.");
        Close(frame.Markers[0].Anchor!.Value.X, 500);

        // Actual entity origin is outside the picture, but a verified part of its
        // bounds is visible. Retain only the box, not a fake edge-pinned anchor.
        entities.Add(new LiveEntity { EntityId = 8, Kind = "player", Name = "Visible bounds", Position = Point(4, 0, -2) });
        var bounds = new Dictionary<int, ProjectionEntityBounds> { [8] = Bounds(8, 1, -.5f, -3, 4, .5f, -2) };
        Check(ProjectionMath.TryBuildFrame(view, Point(0, 0, 0), 5, entities, bounds, out frame, out _), "Partial bounds frame rejected.");
        Check(frame!.Markers.Count == 1 && frame.Markers[0].Anchor == null && frame.Markers[0].Bounds != null, "Partial box requires an invented anchor.");
        bounds[8] = Bounds(99, 1, -.5f, -3, 4, .5f, -2);
        Check(ProjectionMath.TryBuildFrame(view, Point(0, 0, 0), 5, entities, bounds, out frame, out _) && frame!.Markers.Count == 0,
            "Bounds from another entity were associated by dictionary key alone.");
        return Task.CompletedTask;
    }

    public static Task InvalidEntityFramesCannotPublish()
    {
        var view = Perspective();
        var entity = new LiveEntity { EntityId = 7, Kind = "zombie", Name = "", Position = Point(0, 0, -2) };
        var entities = new List<LiveEntity> { entity };
        Check(ProjectionMath.TryBuildFrame(view, Point(0, 0, 0), 5, Array.Empty<LiveEntity>(), null, out var empty, out _) && empty!.Markers.Count == 0,
            "Empty valid world was replaced by synthetic markers.");
        foreach (string kind in new[] { "unknown", "", "Zombie" })
        {
            entity.Kind = kind;
            Check(!ProjectionMath.TryBuildFrame(view, Point(0, 0, 0), 5, entities, null, out var failed, out _) && failed == null,
                "Unknown entity class was projected.");
        }
        entity.Kind = "zombie";
        entity.EntityId = 5;
        Check(!ProjectionMath.TryBuildFrame(view, Point(0, 0, 0), 5, entities, null, out _, out _), "Local entity accepted in remote list.");
        entity.EntityId = 7;
        entities.Add(entity);
        Check(!ProjectionMath.TryBuildFrame(view, Point(0, 0, 0), 5, entities, null, out _, out _), "Duplicate entity accepted.");
        entities.RemoveAt(1);
        entity.Position.X = float.NaN;
        Check(!ProjectionMath.TryBuildFrame(view, Point(0, 0, 0), 5, entities, null, out _, out _), "NaN entity accepted.");
        entity.Position.X = 0;
        entity.Name = new string('x', 129);
        Check(!ProjectionMath.TryBuildFrame(view, Point(0, 0, 0), 5, entities, null, out _, out _), "Oversized entity label accepted.");
        entity.Name = "";
        Check(!ProjectionMath.TryBuildFrame(view, Point(float.NaN, 0, 0), 5, entities, null, out _, out _), "Invalid local position accepted.");
        var tooMany = Enumerable.Repeat(entity, ProjectionMath.MaximumEntities + 1).ToArray();
        Check(!ProjectionMath.TryBuildFrame(view, Point(0, 0, 0), 5, tooMany, null, out _, out _), "Oversized entity collection accepted.");
        return Task.CompletedTask;
    }

    private static ProjectionView Perspective() => View(PerspectiveMatrix(), Point(0, 0, 0));
    private static float[] PerspectiveMatrix() => new float[]
    {
        1,0,0,0,
        0,1,0,0,
        0,0,-11f/9,-20f/9,
        0,0,-1,0
    };
    private static float[] RotatedPerspectiveMatrix() => new float[]
    {
        0,0,1,0,
        0,1,0,0,
        11f/9,0,0,-20f/9,
        1,0,0,0
    };
    private static float[] Identity() => new float[] { 1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1 };
    private static LivePosition Point(float x, float y, float z) => new() { X = x, Y = y, Z = z };
    private static ProjectionEntityBounds Bounds(int id, float x1, float y1, float z1, float x2, float y2, float z2) =>
        new(id, Point(x1, y1, z1), Point(x2, y2, z2), true);
    private static ProjectionView View(float[] matrix, LivePosition origin, int width = 1000, int height = 800,
        ProjectionViewport? viewport = null, ProjectionDepthRange depth = ProjectionDepthRange.MinusOneToOne)
    {
        Check(ProjectionMath.TryCreateView(matrix, origin, width, height, viewport ?? new(0, 0, width, height), depth,
            out var view, out var reason), "Test view rejected: " + reason);
        return view!;
    }
    private static void Close(double actual, double expected, double tolerance = .001)
    {
        Check(double.IsFinite(actual) && Math.Abs(actual - expected) <= tolerance,
            "Expected " + expected + ", received " + actual + ".");
    }
    private static void Check(bool value, string reason)
    {
        if (!value) throw new InvalidOperationException(reason);
    }
}
