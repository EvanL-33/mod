using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using SevenDaysEsp;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class RenderPerformanceTests
{
    public static Task DistinctReceiptsAndRetransmissionsCountOnce()
    {
        var original = Sample(1, 80);
        var retransmission = Sample(1, 0);
        var clock = ClockFor(original, retransmission);
        var tracker = Tracker(clock);
        Check(tracker.ObserveReceived(original, 1), "The first accepted capture was not counted.");
        var first = Token(tracker, original);
        Check(!tracker.ObserveReceived(original, 1) && !tracker.ObserveReceived(retransmission, 1),
            "Repeated delivery counted one capture more than once.");
        var alias = Token(tracker, retransmission);
        Check(alias.CaptureId == first.CaptureId, "Retransmission acquired a new capture identity.");
        clock.Advance(20);
        Check(tracker.ObserveDraw(alias), "A completed drawing of a retransmitted capture was not observed.");
        Check(!tracker.ObserveDraw(first) && !tracker.ObserveDraw(alias), "Redrawing one capture inflated the WPF count.");
        var result = tracker.ReadSnapshot();
        Check(result.AcceptedCaptures == 1 && result.FreshCameras == 1 && result.DrawnCaptures == 1,
            "The accepted, camera or drawing counters include duplicate deliveries.");
        Near(result.ReceiveToDrawP50Ms, Elapsed(original.ReceivedTimestamp, clock.Now),
            "Reception-to-drawing latency restarted at retransmission.");
        Near(result.LastAgeAtDrawMs, 80 + Elapsed(original.ReceivedTimestamp, clock.Now),
            "A lower retransmitted age rejuvenated the original capture.");
        Near(result.AcceptedPerSecond, .1, "Capture rate did not use the fixed ten-second window.");
        Near(result.DrawnCapturesPerSecond, .1, "Drawing rate counts redraws rather than distinct captures.");
        return Task.CompletedTask;
    }

    public static Task PercentilesUseOriginalMonotonicReceiptTimes()
    {
        var samples = Enumerable.Range(100, 20).Select(id => Sample(id, 5)).ToArray();
        var clock = ClockFor(samples);
        long start = clock.Now;
        var tracker = Tracker(clock);
        var expectedDelays = new List<double>();
        double expectedLastAge = 0;
        for (int index = 0; index < samples.Length; index++)
        {
            clock.Set(start + Ticks(index * 2));
            Check(tracker.ObserveReceived(samples[index], 1), "A distinct capture was rejected.");
            var token = Token(tracker, samples[index]);
            clock.Set(start + Ticks(index * 2 + 1));
            Check(tracker.ObserveDraw(token), "A completed fresh capture did not enter the sample distribution.");
            double delay = Elapsed(samples[index].ReceivedTimestamp, clock.Now);
            expectedDelays.Add(delay);
            expectedLastAge = delay + 5;
        }
        expectedDelays.Sort();
        var result = tracker.ReadSnapshot();
        Check(result.AcceptedCaptures == 20 && result.FreshCameras == 20 && result.DrawnCaptures == 20,
            "The empirical distribution does not contain exactly the distinct completed captures.");
        Near(result.ReceiveToDrawP50Ms, expectedDelays[9], "p50 is not the observed tenth of twenty ordered delays.");
        Near(result.ReceiveToDrawP95Ms, expectedDelays[18], "p95 is not the observed nineteenth of twenty ordered delays.");
        Near(result.AgeAtDrawP50Ms, expectedDelays[9] + 5, "Source age is missing from the p50 age at drawing.");
        Near(result.AgeAtDrawP95Ms, expectedDelays[18] + 5, "Source age is missing from the p95 age at drawing.");
        Near(result.LastAgeAtDrawMs, expectedLastAge, "The last observation was replaced by a percentile.");
        Near(result.FreshCamerasPerSecond, 2, "Camera cadence did not use the fixed ten-second denominator.");
        Check(result.ExpiredWithoutDraw == 0, "Completed captures were classified as undrawn.");
        // Fixture UTC values are deliberately from 2020. They are identities,
        // not a source of elapsed time or an assumption about synchronized PCs.
        return Task.CompletedTask;
    }

    public static Task OnlyAcceptedFreshCamerasEnterProjectionMetrics()
    {
        var good = Sample(1);
        var radar = Sample(2, camera: false);
        var oldCamera = Sample(3, 300);
        var unsupported = Sample(4);
        unsupported.Snapshot.Camera.ProfileId = "unsupported-profile";
        var invalid = Sample(5);
        invalid.Snapshot.Status = "LECTURE_NON_VALIDEE";
        var notANumber = Sample(6, double.NaN);
        var negative = Sample(7, -1);
        var expired = Sample(8, 2000);
        var missingIdentity = Sample(9);
        missingIdentity.Snapshot.CapturedUtc = DateTime.MinValue;
        var all = new[] { good, radar, oldCamera, unsupported, invalid, notANumber, negative, expired, missingIdentity };
        var clock = ClockFor(all);
        var tracker = Tracker(clock);
        Check(tracker.ObserveReceived(good, 1) && tracker.ObserveReceived(radar, 1) &&
            tracker.ObserveReceived(oldCamera, 1) && tracker.ObserveReceived(unsupported, 1),
            "Valid entity captures were lost merely because their camera was unavailable.");
        foreach (var sample in new[] { invalid, notANumber, negative, expired, missingIdentity })
            Check(!tracker.ObserveReceived(sample, 1), "Invalid or expired entity data entered the accepted-capture rate.");
        Check(!tracker.TryGetDrawToken(radar.ReceivedTimestamp, radar.InitialAgeMs, out _) &&
            !tracker.TryGetDrawToken(oldCamera.ReceivedTimestamp, oldCamera.InitialAgeMs, out _) &&
            !tracker.TryGetDrawToken(unsupported.ReceivedTimestamp, unsupported.InitialAgeMs, out _),
            "A missing, expired or incompatible camera acquired a drawing token.");
        var result = tracker.ReadSnapshot();
        Check(result.AcceptedCaptures == 4 && result.FreshCameras == 1 && result.DrawnCaptures == 0,
            "Entity cadence and fresh-camera cadence were conflated.");
        Check(result.LastAgeAtDrawMs == null && result.ReceiveToDrawP95Ms == null,
            "No actual drawing was reported as a zero-millisecond measurement.");
        return Task.CompletedTask;
    }

    public static Task ProjectionDeadlineIsStrictAndCannotBeRejuvenated()
    {
        Check(FeedSample.ProjectionLifetimeMs == 250, "Telemetry changed the projection validity limit.");
        var beforeBoundary = Sample(1, 125);
        var clock = new ManualClock(beforeBoundary.ReceivedTimestamp);
        var tracker = Tracker(clock);
        tracker.ObserveReceived(beforeBoundary, 1);
        var token = Token(tracker, beforeBoundary);
        clock.Set(beforeBoundary.ReceivedTimestamp + Ticks(125) - 1);
        Check(tracker.ObserveDraw(token), "A drawing strictly before the 250 ms limit was rejected.");
        Check(tracker.ReadSnapshot().LastAgeAtDrawMs < 250, "An accepted drawing reached or exceeded the TTL.");

        var original = Sample(2, 240);
        var retransmission = Sample(2, 0);
        var expiryClock = ClockFor(original, retransmission);
        var expiring = Tracker(expiryClock);
        expiring.ObserveReceived(original, 1);
        var expiringToken = Token(expiring, original);
        expiryClock.Set(original.ReceivedTimestamp + Ticks(10));
        Check(!expiring.ObserveDraw(expiringToken), "A drawing at exactly 250 ms was counted as fresh.");
        Check(!expiring.ObserveReceived(retransmission, 1) &&
            !expiring.TryGetDrawToken(retransmission.ReceivedTimestamp, retransmission.InitialAgeMs, out _),
            "A younger retransmission revived a capture whose original deadline passed.");
        var once = expiring.ReadSnapshot();
        Check(once.AcceptedCaptures == 1 && once.DrawnCaptures == 0 && once.ExpiredWithoutDraw == 1 && once.Interruptions == 1,
            "The expiry boundary did not count one undrawn camera and one availability interruption.");
        expiryClock.Set(original.ReceivedTimestamp); // Faulty injected clock rollback.
        Check(!expiring.ObserveDraw(expiringToken), "A clock rollback made expired geometry fresh again.");
        var repeated = expiring.ReadSnapshot();
        Check(repeated.ExpiredWithoutDraw == 1 && repeated.Interruptions == 1 && !repeated.CameraAvailable,
            "Repeated reads or a clock rollback recounted an expiry or restarted camera availability.");
        return Task.CompletedTask;
    }

    public static Task UnavailableTransitionsInvalidatePendingTokens()
    {
        var first = Sample(1);
        var retransmission = Sample(1);
        var next = Sample(2);
        var clock = ClockFor(first, retransmission, next);
        long start = clock.Now;
        var tracker = Tracker(clock);
        tracker.ObserveReceived(first, 1);
        var token = Token(tracker, first);
        tracker.ObserveUnavailable(1);
        tracker.ObserveUnavailable(1);
        Check(!tracker.ObserveDraw(token), "Invalidated data entered the drawing statistics.");
        Check(!tracker.ObserveReceived(retransmission, 1) &&
            !tracker.TryGetDrawToken(retransmission.ReceivedTimestamp, retransmission.InitialAgeMs, out _),
            "Retransmission reactivated a token invalidated by an unavailable state.");
        Check(tracker.ReadSnapshot().Interruptions == 1, "Every unavailable status was counted as a separate interruption.");
        clock.Advance(10);
        tracker.ObserveReceived(next, 1);
        var nextToken = Token(tracker, next);
        tracker.ObserveUnavailable(0);
        Check(tracker.ReadSnapshot().CameraAvailable && tracker.ObserveDraw(nextToken),
            "An old generation's unavailable callback invalidated the current camera.");
        tracker.ObserveUnavailable(1);
        clock.Set(start + Ticks(300));
        var result = tracker.ReadSnapshot();
        Check(result.AcceptedCaptures == 2 && result.DrawnCaptures == 1 && result.Interruptions == 2,
            "Independent availability episodes or completed captures were miscounted.");
        Check(result.ExpiredWithoutDraw == 1,
            "The undrawn invalidated camera was forgotten, or an already drawn camera was counted as undrawn.");
        return Task.CompletedTask;
    }

    public static Task SlidingWindowExpiresMeasuresWithoutInventingZeros()
    {
        var drawn = Sample(1);
        var undrawn = Sample(2);
        var clock = ClockFor(drawn, undrawn);
        long start = clock.Now;
        var tracker = Tracker(clock);
        tracker.ObserveReceived(drawn, 1); tracker.ObserveReceived(undrawn, 1);
        var token = Token(tracker, drawn);
        clock.Advance(20);
        Check(tracker.ObserveDraw(token), "The initial drawing was not counted.");
        clock.Set(start + Ticks(10_000));
        var edge = tracker.ReadSnapshot();
        Check(edge.AcceptedCaptures == 0 && edge.FreshCameras == 0 && edge.DrawnCaptures == 1,
            "The window used capture time for later drawing events, or retained expired reception events.");
        Check(edge.ExpiredWithoutDraw == 1 && edge.Interruptions == 1,
            "Expiry events used the time of inspection instead of their original deadline.");
        clock.Set(start + Ticks(10_300));
        var empty = tracker.ReadSnapshot();
        Check(empty.AcceptedCaptures == 0 && empty.DrawnCaptures == 0 && empty.ExpiredWithoutDraw == 0 &&
            empty.Interruptions == 0 && empty.BufferedCaptures == 0 && empty.BufferedAliases == 0,
            "The bounded trailing window retained old observations or identity aliases.");
        Check(empty.LastAgeAtDrawMs == null && empty.AgeAtDrawP50Ms == null && empty.AgeAtDrawP95Ms == null &&
            empty.ReceiveToDrawP50Ms == null && empty.ReceiveToDrawP95Ms == null,
            "An empty distribution fabricated a zero or kept an old percentile.");
        return Task.CompletedTask;
    }

    public static Task ResetRejectsOldGenerationsAndMismatchedTokens()
    {
        var sample = Sample(1);
        var clock = ClockFor(sample);
        var tracker = Tracker(clock, generation: 7);
        tracker.ObserveReceived(sample, 7);
        var old = Token(tracker, sample);
        tracker.Reset(8);
        Check(!tracker.ObserveReceived(sample, 7) && !tracker.ObserveDraw(old),
            "An earlier generation repopulated a reset tracker.");
        tracker.ObserveUnavailable(7);
        Check(tracker.ReadSnapshot().AcceptedCaptures == 0, "Reset retained the previous capture window.");
        Check(tracker.ObserveReceived(sample, 8), "The current generation could not establish its own identity.");
        var current = Token(tracker, sample);
        Check(current.Generation == 8 && current.CaptureId != old.CaptureId, "A new session reused the old token.");
        Check(!tracker.ObserveDraw(current with { CaptureId = current.CaptureId + 1000 }) &&
            !tracker.ObserveDraw(current with { ReceivedTimestamp = current.ReceivedTimestamp + 1 }) &&
            !tracker.ObserveDraw(current with { InitialAgeMs = current.InitialAgeMs + 1 }),
            "A mismatched capture identity, receipt or source age acknowledged a drawing.");
        Check(tracker.ObserveDraw(current), "A correct current-generation token was rejected.");
        tracker.Reset(8);
        tracker.ObserveReceived(sample, 8);
        Check(!tracker.ObserveDraw(current), "Resetting the same generation reused a previously issued token.");
        tracker.Reset(7);
        Check(tracker.ReadSnapshot().Generation == 8 && tracker.ReadSnapshot().AcceptedCaptures == 1,
            "An obsolete reset replaced the active generation.");
        return Task.CompletedTask;
    }

    public static Task StorageIsBoundedAndTruncationIsVisible()
    {
        var samples = Enumerable.Range(1, 12).Select(id => Sample(id)).ToArray();
        var clock = ClockFor(samples);
        var tracker = Tracker(clock, capacity: 4);
        RenderPerformanceToken oldest = default;
        foreach (var sample in samples)
        {
            tracker.ObserveReceived(sample, 1);
            var token = Token(tracker, sample);
            if (oldest.CaptureId == 0) oldest = token;
            Check(tracker.ObserveDraw(token), "A fresh capture was not acknowledged before capacity eviction.");
        }
        for (int repeat = 0; repeat < 20; repeat++)
        {
            var alias = Sample(12);
            clock.Set(Math.Max(clock.Now, alias.ReceivedTimestamp));
            Check(!tracker.ObserveReceived(alias, 1), "An alias overflow inflated the accepted-capture count.");
        }
        var bounded = tracker.ReadSnapshot();
        Check(bounded.CaptureCapacity == 4 && bounded.BufferedCaptures <= 4 && bounded.BufferedAliases <= 8 &&
            bounded.DrawnCaptures <= 4 && bounded.IsWindowTruncated,
            "One of the histories grew beyond its bound or failed to disclose discarded observations.");
        Check(!tracker.ObserveDraw(oldest), "An evicted capture identity remained drawable in telemetry.");

        var interruptions = Tracker(clock, capacity: 4);
        foreach (var sample in samples)
        {
            interruptions.ObserveReceived(sample, 1);
            interruptions.ObserveUnavailable(1);
        }
        clock.Advance(300);
        var eventBounds = interruptions.ReadSnapshot();
        Check(eventBounds.Interruptions <= 4 && eventBounds.ExpiredWithoutDraw <= 4 && eventBounds.IsWindowTruncated,
            "Interruption or expiry histories escaped their capacity bound.");
        clock.Advance(10_001);
        var empty = tracker.ReadSnapshot();
        Check(!empty.IsWindowTruncated && empty.BufferedCaptures == 0 && empty.BufferedAliases == 0,
            "An old saturation warning or stale identities persisted outside the recent window.");
        return Task.CompletedTask;
    }

    public static async Task ConcurrentObserversReturnCoherentSnapshots()
    {
        var samples = Enumerable.Range(1, 32).Select(id => Sample(id)).ToArray();
        var clock = ClockFor(samples);
        var tracker = Tracker(clock, capacity: 64);
        var start = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        var tasks = samples.Select(sample => Task.Run(async () =>
        {
            await start.Task;
            Check(tracker.ObserveReceived(sample, 1), "A concurrent distinct capture disappeared.");
            Check(!tracker.ObserveReceived(sample, 1), "Concurrent observation duplicated a capture.");
            var token = Token(tracker, sample);
            Check(tracker.ObserveDraw(token) && !tracker.ObserveDraw(token), "Concurrent drawing was lost or duplicated.");
            for (int read = 0; read < 4; read++)
            {
                var snapshot = tracker.ReadSnapshot();
                Check(snapshot.AcceptedCaptures <= 32 && snapshot.FreshCameras <= snapshot.AcceptedCaptures &&
                    snapshot.DrawnCaptures <= snapshot.FreshCameras && !snapshot.IsWindowTruncated,
                    "A reader observed an inconsistent partial update of the tracker.");
            }
        })).ToArray();
        start.SetResult(true);
        await Task.WhenAll(tasks);
        var result = tracker.ReadSnapshot();
        Check(result.AcceptedCaptures == 32 && result.FreshCameras == 32 && result.DrawnCaptures == 32,
            "Concurrent writers/readers lost or doubled completed distinct captures.");
        Check(result.ExpiredWithoutDraw == 0 && result.Interruptions == 0,
            "Concurrent observation invented a deadline or availability interruption.");
    }

    private static FeedSample Sample(int identity, double age = 0, bool camera = true)
    {
        var snapshot = new LiveEntitySnapshot
        {
            CapturedUtc = new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddTicks(identity),
            Status = "ENTITES_LUES", LocalId = 42, LocalPosition = new LivePosition(), RenderOrigin = new LivePosition(),
            Entities = new List<LiveEntity>(),
            Camera = camera ? new LiveCameraFrame
            {
                ProfileId = "unity-2022.3.62f2-7670c08855a9-native-v1", ClipDepth = "MinusOneToOne",
                Sequence = identity + 1, CameraEpoch = 1, ReadDurationMs = 2,
                SourceWidth = 1920, SourceHeight = 1080, ViewportWidth = 1920, ViewportHeight = 1080,
                ViewProjection = new float[] { 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 }
            } : null!
        };
        return new FeedSample(snapshot, age);
    }

    private static RenderPerformanceTracker Tracker(ManualClock clock, int generation = 1, int capacity = 64)
    {
        var tracker = new RenderPerformanceTracker(() => clock.Now, capacity);
        tracker.Reset(generation);
        return tracker;
    }

    private static ManualClock ClockFor(params FeedSample[] samples) => new(samples.Max(sample => sample.ReceivedTimestamp));

    private static RenderPerformanceToken Token(RenderPerformanceTracker tracker, FeedSample sample)
    {
        Check(tracker.TryGetDrawToken(sample.ReceivedTimestamp, sample.InitialAgeMs, out var token),
            "No token matched the original sample receipt.");
        return token;
    }

    private static long Ticks(double milliseconds) => (long)Math.Ceiling(milliseconds * Stopwatch.Frequency / 1000.0);
    private static double Elapsed(long start, long end) => Stopwatch.GetElapsedTime(start, end).TotalMilliseconds;
    private static void Near(double? actual, double expected, string message) =>
        Check(actual.HasValue && Math.Abs(actual.Value - expected) < .000001, message);
    private static void Check(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }

    private sealed class ManualClock
    {
        private long now;
        internal ManualClock(long timestamp) { now = timestamp; }
        internal long Now => Interlocked.Read(ref now);
        internal void Set(long value) => Interlocked.Exchange(ref now, value);
        internal void Advance(double milliseconds) => Interlocked.Add(ref now, Ticks(milliseconds));
    }
}
