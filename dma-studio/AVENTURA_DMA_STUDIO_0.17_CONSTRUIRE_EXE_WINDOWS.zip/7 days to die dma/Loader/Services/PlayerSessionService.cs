using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using SevenDaysEsp;

namespace SevenDaysLoader.Services;

// Session-only annotations and proximity observations. This consumes accepted
// samples; it neither reads DMA nor changes the base feed/camera validity rules.
public sealed class PlayerSessionService
{
    public const int MaximumPlayers = 4096;
    public const int NoticeLifetimeMilliseconds = 4000;
    public const int GlobalAlertCooldownMilliseconds = 3000;
    private readonly object gate = new();
    private readonly Func<long> timestamp;
    private readonly PlayerDistanceTrendTracker distanceTrend = new();
    private Dictionary<PlayerIdentity, Entry> entries = new();
    private PlayerRow[] legacyRows = Array.Empty<PlayerRow>();
    private int generation;
    private long lastTimestamp;
    private long revision;
    private long nextNoticeSequence;
    private string? orderedContext;
    private long latestCaptureSequence;
    private readonly HashSet<string> retiredContexts = new(StringComparer.Ordinal);
    private readonly Queue<string> retiredContextOrder = new();
    private readonly HashSet<LegacyCapture> legacyCaptures = new();
    private readonly Queue<LegacyCapture> legacyCaptureOrder = new();
    private long sourceReceivedTimestamp;
    private double sourceInitialAgeMs;
    private string? context;
    private bool available;
    private bool hasAcceptedSample;
    private bool distanceTrendEnabled;
    private AlertPolicy policy;
    private long? lastGlobalAlert;
    private PlayerProximityNotice? notice;
    private long noticeTimestamp;
    private PlayerSessionSnapshot? cached;

    // An injected clock uses Stopwatch units. A reader-issued sequence identifies
    // accepted captures; wall-clock corrections cannot freeze player identities.
    public PlayerSessionService(Func<long>? getTimestamp = null)
    {
        timestamp = getTimestamp ?? Stopwatch.GetTimestamp;
        lastTimestamp = timestamp();
    }

    public event Action? PreferencesChanged;

    public void Reset(int newGeneration)
    {
        lock (gate)
        {
            if (newGeneration < generation) return;
            generation = newGeneration;
            ClearSession();
            orderedContext = null;
            latestCaptureSequence = 0;
            retiredContexts.Clear(); retiredContextOrder.Clear();
            legacyCaptures.Clear(); legacyCaptureOrder.Clear();
            policy = default;
            distanceTrendEnabled = false;
            // Keep notice sequence, monotonic fence and global anti-spam fence.
            // A rapid reconnect cannot replay a notice or produce a beep burst.
            ReadTime();
            Changed();
        }
    }

    public void Observe(FeedSample sample, int expectedGeneration, PlayerFeaturesSettings preferences, bool alertsAllowed)
    {
        lock (gate)
        {
            if (expectedGeneration != generation) return;
            long now = ReadTime();
            Advance(now);
            ApplyPolicy(preferences, alertsAllowed);
            if (sample == null || !FeedSample.IsValid(sample.Snapshot) ||
                !TryAge(sample.ReceivedTimestamp, sample.InitialAgeMs, now, out double age) ||
                age >= FeedSample.LifetimeMs)
            {
                Unavailable();
                return;
            }

            var source = sample.Snapshot;
            bool sequenced = ValidContext(source.PlayerContextId) && source.PlayerCaptureSequence > 0;
            if (!AcceptCaptureIdentity(source, sequenced))
            {
                if (ResetDistanceTrend()) Changed();
                return;
            }
            string? acceptedContext = sequenced ? source.PlayerContextId : null;
            var playerIds = new HashSet<int>();
            var tokens = new HashSet<long>();
            foreach (var entity in source.Entities)
            {
                if (entity.Kind != "player") continue;
                if (!playerIds.Add(entity.EntityId) || (entity.IdentityToken > 0 && !tokens.Add(entity.IdentityToken)))
                    acceptedContext = null;
            }
            if (!StringComparer.Ordinal.Equals(context, acceptedContext))
            {
                ClearSession();
                context = acceptedContext;
            }

            var next = new Dictionary<PlayerIdentity, Entry>();
            var readOnly = new List<PlayerRow>();
            Entry? pinnedEntry = null;
            LiveEntity? pinnedEntity = null;
            double localX = source.LocalPosition.X, localY = source.LocalPosition.Y, localZ = source.LocalPosition.Z;
            foreach (var entity in source.Entities)
            {
                if (entity.Kind != "player") continue;
                var identity = new PlayerIdentity(acceptedContext ?? string.Empty, entity.IdentityToken, entity.EntityId);
                double dx = entity.Position.X - localX, dy = entity.Position.Y - localY, dz = entity.Position.Z - localZ;
                bool healthValid = entity.Health.HasValue && entity.MaxHealth.HasValue && entity.Health >= 0 &&
                    entity.MaxHealth > 0 && entity.Health <= entity.MaxHealth;
                var row = new PlayerRow
                {
                    Identity = identity, Name = SafeName(entity.Name, entity.EntityId),
                    DistanceMeters = Math.Sqrt(dx * dx + dy * dy + dz * dz), HeightMeters = dy,
                    Health = healthValid ? entity.Health : null, MaxHealth = healthValid ? entity.MaxHealth : null
                };
                if (!identity.IsValid)
                {
                    readOnly.Add(row);
                    continue;
                }
                if (!entries.TryGetValue(identity, out var entry)) entry = new Entry(row);
                else entry.Row = row;
                next.Add(identity, entry);
                if (entry.Visual.Pinned && !entry.Visual.Hidden)
                {
                    pinnedEntry = entry;
                    pinnedEntity = entity;
                }
            }
            // An absence in an accepted capture removes annotations immediately.
            // A temporary failed capture takes Unavailable(), which retains them
            // privately for at most the original sample's two-second lifetime.
            entries = next;
            legacyRows = readOnly.ToArray();
            sourceReceivedTimestamp = sample.ReceivedTimestamp;
            sourceInitialAgeMs = sample.InitialAgeMs;
            hasAcceptedSample = available = true;
            if (distanceTrendEnabled && pinnedEntry != null && pinnedEntity != null)
            {
                pinnedEntry.Row = pinnedEntry.Row with
                {
                    DistanceTrend = distanceTrend.Observe(pinnedEntry.Row.Identity, expectedGeneration,
                        source.PlayerCaptureSequence, sample.ReceivedTimestamp, sample.InitialAgeMs, now,
                        source.LocalPosition, pinnedEntity.Position)
                };
            }
            else distanceTrend.Reset();
            if (notice != null && (!entries.TryGetValue(notice.Identity, out var noticed) ||
                noticed.Visual.Hidden || (policy.MarkedOnly && !noticed.Visual.Marked))) notice = null;

            ObserveAlerts(now, age, sample.ReceivedTimestamp, sample.InitialAgeMs);
            Changed();
        }
    }

    public void ObserveUnavailable(int expectedGeneration)
    {
        lock (gate)
        {
            if (expectedGeneration != generation) return;
            Advance(ReadTime());
            Unavailable();
        }
    }

    // Settings changes can happen while a source is waiting or unavailable.
    // Apply them immediately, without requiring another DMA capture to remove
    // a notice or break a half-confirmed arrival. Root owns UI notification.
    public void UpdatePreferences(PlayerFeaturesSettings preferences, bool alertsAllowed)
    {
        lock (gate)
        {
            Advance(ReadTime());
            ApplyPolicy(preferences, alertsAllowed);
        }
    }

    public PlayerSessionSnapshot ReadSnapshot()
    {
        lock (gate)
        {
            Advance(ReadTime());
            if (cached != null) return cached;
            if (!available)
                return cached = new PlayerSessionSnapshot { Revision = revision };
            var rows = entries.Values.Select(entry => entry.Row with { Visual = entry.Visual })
                .Concat(legacyRows).OrderBy(row => row.Identity.EntityId).ThenBy(row => row.Identity.Token).ToArray();
            return cached = new PlayerSessionSnapshot
            {
                Revision = revision, Rows = Array.AsReadOnly(rows),
                Pinned = rows.FirstOrDefault(row => row.Visual.Pinned),
                Notice = notice, HasCurrentData = true
            };
        }
    }

    public bool TryGetVisual(PlayerIdentity identity, out PlayerVisualState visual)
    {
        lock (gate)
        {
            Advance(ReadTime());
            if (available && identity.IsValid && entries.TryGetValue(identity, out var entry))
            {
                visual = entry.Visual;
                return true;
            }
            visual = new PlayerVisualState();
            return false;
        }
    }

    public bool Select(PlayerIdentity? identity) => Mutate(() => SetExclusive(identity, false));
    public bool Pin(PlayerIdentity? identity) => Mutate(() => SetExclusive(identity, true));

    public bool SetMarked(PlayerIdentity identity, bool marked) => Mutate(() =>
    {
        if (!TryCurrent(identity, out var entry) || entry.Visual.Marked == marked) return false;
        entry.Visual = entry.Visual with { Marked = marked };
        entry.NearConfirmations = 0;
        if (!marked && policy.MarkedOnly && notice?.Identity == identity) notice = null;
        return true;
    });

    public bool SetHidden(PlayerIdentity identity, bool hidden) => Mutate(() =>
    {
        if (!TryCurrent(identity, out var entry) || entry.Visual.Hidden == hidden) return false;
        entry.Visual = entry.Visual with { Hidden = hidden };
        entry.NearConfirmations = 0;
        if (hidden && notice?.Identity == identity) notice = null;
        return true;
    });

    public bool SetColor(PlayerIdentity identity, string? color)
    {
        if (!TryColor(color, out string? normalized)) return false;
        return Mutate(() =>
        {
            if (!TryCurrent(identity, out var entry) || entry.Visual.Color == normalized) return false;
            entry.Visual = entry.Visual with { Color = normalized };
            return true;
        });
    }

    public bool Clear(PlayerIdentity identity) => Mutate(() =>
    {
        if (!TryCurrent(identity, out var entry) || entry.Visual == new PlayerVisualState()) return false;
        entry.Visual = new PlayerVisualState();
        entry.NearConfirmations = 0;
        if (policy.MarkedOnly && notice?.Identity == identity) notice = null;
        return true;
    });

    public bool ClearAll() => Mutate(() =>
    {
        bool changed = false;
        foreach (var entry in entries.Values)
        {
            if (entry.Visual == new PlayerVisualState()) continue;
            entry.Visual = new PlayerVisualState();
            entry.NearConfirmations = 0;
            changed = true;
        }
        if (changed && policy.MarkedOnly) notice = null;
        return changed;
    });

    private bool Mutate(Func<bool> change)
    {
        Action? handler;
        lock (gate)
        {
            Advance(ReadTime());
            PlayerIdentity? previousPin = CurrentTrendIdentity();
            if (!change()) return false;
            if (previousPin != CurrentTrendIdentity()) ResetDistanceTrend();
            Changed();
            handler = PreferencesChanged;
        }
        // The consumer may notify UI or query this service from another thread.
        // Never invoke it while holding the session state lock.
        handler?.Invoke();
        return true;
    }

    private bool SetExclusive(PlayerIdentity? identity, bool pinned)
    {
        if (identity.HasValue && !TryCurrent(identity.Value, out _)) return false;
        bool changed = false;
        foreach (var pair in entries)
        {
            bool enabled = identity.HasValue && pair.Key == identity.Value;
            if ((pinned ? pair.Value.Visual.Pinned : pair.Value.Visual.Selected) == enabled) continue;
            pair.Value.Visual = pinned ? pair.Value.Visual with { Pinned = enabled } :
                pair.Value.Visual with { Selected = enabled };
            changed = true;
        }
        return changed;
    }

    private bool TryCurrent(PlayerIdentity identity, out Entry entry)
    {
        if (available && identity.IsValid && entries.TryGetValue(identity, out var found))
        { entry = found; return true; }
        entry = null!;
        return false;
    }

    private void ObserveAlerts(long now, double age, long received, double initialAge)
    {
        if (!policy.Enabled || age >= FeedSample.ProjectionLifetimeMs)
        {
            ResetConfirmations();
            return;
        }
        Entry? candidate = null;
        foreach (var entry in entries.Values)
        {
            double distance = entry.Row.DistanceMeters;
            if (distance >= policy.Distance + policy.RearmMargin)
            {
                entry.Armed = true;
                entry.NearConfirmations = 0;
            }
            if (entry.Visual.Hidden || (policy.MarkedOnly && !entry.Visual.Marked) || distance > policy.Distance)
            {
                entry.NearConfirmations = 0;
                continue;
            }
            if (!entry.Armed) continue;
            entry.NearConfirmations = entry.NearConfirmations > 0 && now < entry.PreviousFreshDeadline ?
                Math.Min(2, entry.NearConfirmations + 1) : 1;
            entry.PreviousFreshDeadline = FreshDeadline(received, initialAge);
            if (entry.NearConfirmations < 2) continue;
            // Consume this entrance even when a cooldown suppresses it. Otherwise
            // waiting near the threshold would create delayed arrival alarms.
            entry.Armed = false;
            entry.NearConfirmations = 0;
            bool playerCooldown = entry.LastAlert.HasValue &&
                ElapsedMs(entry.LastAlert.Value, now) < policy.CooldownSeconds * 1000.0;
            bool globalCooldown = lastGlobalAlert.HasValue &&
                ElapsedMs(lastGlobalAlert.Value, now) < GlobalAlertCooldownMilliseconds;
            if (playerCooldown || globalCooldown) continue;
            if (candidate == null || distance < candidate.Row.DistanceMeters ||
                (distance == candidate.Row.DistanceMeters && entry.Row.Identity.EntityId < candidate.Row.Identity.EntityId))
                candidate = entry;
        }
        if (candidate == null) return;
        candidate.LastAlert = lastGlobalAlert = now;
        noticeTimestamp = now;
        notice = new PlayerProximityNotice
        {
            Sequence = ++nextNoticeSequence, Identity = candidate.Row.Identity, Name = candidate.Row.Name,
            DistanceMeters = candidate.Row.DistanceMeters, PlaySound = policy.Sound,
            Message = candidate.Row.Name + " détecté à " + candidate.Row.DistanceMeters.ToString("0", CultureInfo.InvariantCulture) + " m"
        };
    }

    private void Unavailable()
    {
        bool changed = available || notice != null;
        available = false;
        notice = null;
        ResetConfirmations();
        changed |= ResetDistanceTrend();
        if (changed) Changed();
    }

    private void Advance(long now)
    {
        if (hasAcceptedSample)
        {
            if (!TryAge(sourceReceivedTimestamp, sourceInitialAgeMs, now, out double age) || age >= FeedSample.LifetimeMs)
            {
                ClearSession();
                Changed();
            }
            else if (age >= FeedSample.ProjectionLifetimeMs && ResetDistanceTrend()) Changed();
        }
        if (notice != null && ElapsedMs(noticeTimestamp, now) >= NoticeLifetimeMilliseconds)
        {
            notice = null;
            Changed();
        }
    }

    private void ClearSession()
    {
        distanceTrend.Reset();
        entries.Clear();
        legacyRows = Array.Empty<PlayerRow>();
        context = null;
        available = hasAcceptedSample = false;
        notice = null;
    }

    private void ResetConfirmations()
    {
        foreach (var entry in entries.Values) entry.NearConfirmations = 0;
    }

    private void ApplyPolicy(PlayerFeaturesSettings? preferences, bool alertsAllowed)
    {
        bool updatedTrend = alertsAllowed && preferences?.ShowPinnedCard == true && preferences.ShowDistanceTrend;
        if (distanceTrendEnabled != updatedTrend)
        {
            distanceTrendEnabled = updatedTrend;
            if (ResetDistanceTrend()) Changed();
        }
        var updated = AlertPolicy.From(preferences, alertsAllowed);
        if (updated == policy) return;
        policy = updated;
        ResetConfirmations();
        if (notice != null) { notice = null; Changed(); }
    }

    private PlayerIdentity? CurrentTrendIdentity() =>
        entries.Values.FirstOrDefault(entry => entry.Visual.Pinned && !entry.Visual.Hidden)?.Row.Identity;

    private bool ResetDistanceTrend()
    {
        bool hadEstimate = distanceTrend.Current != default;
        distanceTrend.Reset();
        if (!hadEstimate) return false;
        bool changed = false;
        foreach (var entry in entries.Values)
        {
            if (entry.Row.DistanceTrend == default) continue;
            entry.Row = entry.Row with { DistanceTrend = default };
            changed = true;
        }
        return changed;
    }

    private bool AcceptCaptureIdentity(LiveEntitySnapshot source, bool sequenced)
    {
        if (sequenced)
        {
            string incoming = source.PlayerContextId;
            if (StringComparer.Ordinal.Equals(incoming, orderedContext))
            {
                if (source.PlayerCaptureSequence <= latestCaptureSequence) return false;
            }
            else
            {
                if (retiredContexts.Contains(incoming)) return false;
                if (orderedContext != null && retiredContexts.Add(orderedContext))
                    retiredContextOrder.Enqueue(orderedContext);
                while (retiredContextOrder.Count > 64) retiredContexts.Remove(retiredContextOrder.Dequeue());
                orderedContext = incoming;
            }
            latestCaptureSequence = source.PlayerCaptureSequence;
            return true;
        }
        // Old feeds remain read-only. Keep a bounded recent de-duplication set
        // instead of using wall-clock ordering, which could freeze the list when
        // the source clock is corrected. It cannot confer an annotation identity.
        var key = new LegacyCapture(source.CapturedUtc.Ticks, source.LocalId);
        if (key.UtcTicks == 0 || !legacyCaptures.Add(key)) return false;
        legacyCaptureOrder.Enqueue(key);
        while (legacyCaptureOrder.Count > 4096) legacyCaptures.Remove(legacyCaptureOrder.Dequeue());
        return true;
    }

    private void Changed() { ++revision; cached = null; }

    private long ReadTime()
    {
        long now = timestamp();
        if (now > lastTimestamp) lastTimestamp = now;
        return lastTimestamp;
    }

    private static bool TryAge(long received, double initialAge, long now, out double age)
    {
        age = double.NaN;
        if (received <= 0 || received > now || !double.IsFinite(initialAge) || initialAge < 0) return false;
        age = initialAge + ElapsedMs(received, now);
        return double.IsFinite(age) && age >= 0;
    }

    private static long FreshDeadline(long received, double initialAge)
    {
        long ticks = (long)Math.Ceiling(Math.Max(0, FeedSample.ProjectionLifetimeMs - initialAge) * Stopwatch.Frequency / 1000.0);
        return received <= long.MaxValue - ticks ? received + ticks : long.MaxValue;
    }

    private static double ElapsedMs(long from, long to) => Stopwatch.GetElapsedTime(from, to).TotalMilliseconds;
    private static bool ValidContext(string? value) => value != null && value.Length <= 64 && Guid.TryParse(value, out _);

    private static string SafeName(string? value, int id)
    {
        string clean = string.IsNullOrWhiteSpace(value) ? string.Empty :
            new string(value.Select(ch => char.IsControl(ch) ? ' ' : ch).ToArray()).Trim();
        return clean.Length > 0 ? clean : "Joueur " + id.ToString(CultureInfo.InvariantCulture);
    }

    private static bool TryColor(string? value, out string? normalized)
    {
        normalized = null;
        if (value == null) return true;
        if (value.Length != 7 || value[0] != '#') return false;
        for (int i = 1; i < value.Length; ++i)
            if (!Uri.IsHexDigit(value[i])) return false;
        normalized = value.ToUpperInvariant();
        return true;
    }

    private readonly record struct AlertPolicy(bool Enabled, int Distance, int RearmMargin, int CooldownSeconds,
        bool MarkedOnly, bool Sound)
    {
        internal static AlertPolicy From(PlayerFeaturesSettings? value, bool allowed) => new(
            allowed && value?.ProximityAlerts == true, Math.Clamp(value?.AlertDistance ?? 50, 10, 1000),
            Math.Clamp(value?.AlertRearmMargin ?? 10, 5, 100), Math.Clamp(value?.AlertCooldownSeconds ?? 15, 3, 120),
            value?.AlertsMarkedOnly == true, value?.AlertSound == true);
    }

    private readonly record struct LegacyCapture(long UtcTicks, int LocalId);

    private sealed class Entry
    {
        internal PlayerRow Row;
        internal PlayerVisualState Visual = new();
        internal bool Armed = true;
        internal int NearConfirmations;
        internal long PreviousFreshDeadline;
        internal long? LastAlert;
        internal Entry(PlayerRow row) { Row = row; }
    }
}
