@echo off
setlocal
if not exist "%~dp07DTD-Loader.exe" (
  echo Extrais toute l'archive avant de lancer cet installateur.
  pause
  exit /b 2
)
start "" "%~dp07DTD-Loader.exe" --install-module
