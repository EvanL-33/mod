using System;
using System.Globalization;

namespace SevenDaysLoader.Services;

// Pure presentation decisions. No memory access, interpolation or extension of
// sample lifetime is allowed here; callers still own their freshness gates.
public static class EntityDisplayRules
{
    public static bool PassesHeight(EntityEspSettings profile, string kind, double heightMeters,
        PlayerVisualState? visual = null)
    {
        if (visual?.Hidden == true) return false;
        var rules = profile.Rules;
        if (rules?.HeightFilterEnabled != true) return true;
        if (!double.IsFinite(heightMeters)) return false;
        if (kind == "player" && visual?.Pinned == true && rules.ExemptPinnedFromHeightFilter) return true;
        return Math.Abs(heightMeters) <= Math.Clamp(rules.MaxHeightDifferenceMeters, 1, 500);
    }

    public static bool UsesHealthColor(EntityEspSettings? profile) => profile?.Rules?.ColorMode == "health";

    public static string ResolveColor(EntityEspSettings profile, double distanceMeters,
        int? health, int? maximumHealth, string? individualColor = null)
    {
        if (EntityDisplayRulesSettings.IsColor(individualColor)) return individualColor!;
        var rules = profile.Rules;
        if (rules == null) return profile.Color;
        string? selected = null;
        if (rules.ColorMode == "health")
        {
            // Without both measured values there is no reliable percentage.
            // An inconsistent pair must not silently become a full-health dot.
            if (health is not >= 0 || maximumHealth is not > 0 || health > maximumHealth) return profile.Color;
            double percentage = 100d * health.Value / maximumHealth.Value;
            int low = Math.Clamp(rules.HealthLowPercent, 1, 99);
            int high = Math.Clamp(rules.HealthHighPercent, low + 1, 100);
            selected = percentage <= low ? rules.LowColor : percentage >= high ? rules.HighColor : rules.MiddleColor;
        }
        else if (rules.ColorMode == "distance")
        {
            if (!double.IsFinite(distanceMeters) || distanceMeters < 0) return profile.Color;
            int near = Math.Clamp(rules.DistanceNearMeters, 0, 4999);
            int far = Math.Clamp(rules.DistanceFarMeters, near + 1, 5000);
            selected = distanceMeters <= near ? rules.LowColor : distanceMeters >= far ? rules.HighColor : rules.MiddleColor;
        }
        return EntityDisplayRulesSettings.IsColor(selected) ? selected! : profile.Color;
    }

    public static string HeightIndicator(double heightMeters)
    {
        if (!double.IsFinite(heightMeters)) return string.Empty;
        double meters = Math.Round(Math.Abs(heightMeters), 0, MidpointRounding.AwayFromZero);
        if (meters == 0) return "↔ 0 m";
        return (heightMeters > 0 ? "↑ +" : "↓ −") + meters.ToString("0", CultureInfo.GetCultureInfo("fr-FR")) + " m";
    }
}
