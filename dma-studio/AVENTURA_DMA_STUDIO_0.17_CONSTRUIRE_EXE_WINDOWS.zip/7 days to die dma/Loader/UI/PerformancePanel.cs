using System;
using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using SevenDaysLoader.Services;

namespace SevenDaysLoader.UI;

// Refresh is owned by the diagnostic page, so pause/reading protection applies
// to this panel too. The panel never starts a timer or reads memory itself.
internal sealed class PerformancePanel : StackPanel
{
    private readonly ILoaderController controller;
    private readonly TextBlock acceptedRate, cameraRate, drawnRate;
    private readonly TextBlock acceptedCount, cameraCount, drawnCount;
    private readonly TextBlock agePercentiles, receivePercentiles, lastAge, expired, interruptions, sampleCount;
    private readonly TextBlock window;
    private long? refreshedAt;
    internal string SummaryText { get; private set; } = "Performances : aucun relevé affiché.";

    internal PerformancePanel(ILoaderController controller)
    {
        this.controller = controller;
        Children.Add(FixedText("PERFORMANCES RÉCENTES", 11, 20, Theme.Muted, true));
        Children.Add(FixedText("De la capture aux commandes de dessin", 20, 34, Theme.Foreground, true));
        window = FixedText("Fenêtre fixe de 10 s", 12, 28, Theme.Muted);
        Children.Add(window);

        var rates = new Grid { Height = 108, Margin = new Thickness(0, 0, 0, 12) };
        for (int column = 0; column < 3; column++) rates.ColumnDefinitions.Add(new ColumnDefinition());
        AddRate(rates, 0, "Captures acceptées", Theme.Foreground, out acceptedRate, out acceptedCount);
        AddRate(rates, 1, "Caméras fraîches", Theme.Cyan, out cameraRate, out cameraCount);
        AddRate(rates, 2, "Captures dessinées", Theme.Orange, out drawnRate, out drawnCount);
        Children.Add(rates);

        var details = new Grid { Margin = new Thickness(0, 0, 0, 10) };
        details.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(270) });
        details.ColumnDefinitions.Add(new ColumnDefinition());
        agePercentiles = AddRow(details, "Âge au dessin · p50 / p95");
        receivePercentiles = AddRow(details, "Réception → dessin · p50 / p95");
        lastAge = AddRow(details, "Dernier âge au dessin");
        expired = AddRow(details, "Caméras reçues sans dessin à 250 ms");
        interruptions = AddRow(details, "Interruptions de caméra");
        sampleCount = AddRow(details, "Captures distinctes dessinées");
        Children.Add(details);

        var explanation = Theme.Text(
            "Sans dessin peut inclure l’ESP masqué ou un viewport entièrement recadré. Une vue valide vide compte comme traitée. " +
            "Les mesures s’arrêtent aux commandes WPF : elles ne mesurent ni les FPS GPU, ni la latence physique du fuser.", 12, Theme.Muted);
        explanation.Height = explanation.MinHeight = explanation.MaxHeight = 72;
        explanation.LineHeight = 18;
        explanation.LineStackingStrategy = LineStackingStrategy.BlockLineHeight;
        explanation.TextTrimming = TextTrimming.CharacterEllipsis;
        explanation.Margin = new Thickness(0);
        Children.Add(explanation);
        Refresh(force: true);
    }

    internal void Refresh(bool force = false)
    {
        VerifyAccess();
        long now = Stopwatch.GetTimestamp();
        if (!force && refreshedAt is { } previous && now >= previous &&
            Stopwatch.GetElapsedTime(previous, now).TotalMilliseconds < 1000) return;
        refreshedAt = now;
        RenderPerformanceSnapshot snapshot = controller.Performance.ReadSnapshot();
        Set(acceptedRate, Rate(snapshot.AcceptedPerSecond));
        Set(cameraRate, Rate(snapshot.FreshCamerasPerSecond));
        Set(drawnRate, Rate(snapshot.DrawnCapturesPerSecond));
        Set(acceptedCount, snapshot.AcceptedCaptures.ToString(CultureInfo.InvariantCulture) + " sur 10 s");
        Set(cameraCount, snapshot.FreshCameras.ToString(CultureInfo.InvariantCulture) + " sur 10 s");
        Set(drawnCount, snapshot.DrawnCaptures.ToString(CultureInfo.InvariantCulture) + " sur 10 s");
        Set(agePercentiles, Pair(snapshot.AgeAtDrawP50Ms, snapshot.AgeAtDrawP95Ms));
        Set(receivePercentiles, Pair(snapshot.ReceiveToDrawP50Ms, snapshot.ReceiveToDrawP95Ms));
        Set(lastAge, Milliseconds(snapshot.LastAgeAtDrawMs));
        Set(expired, snapshot.ExpiredWithoutDraw.ToString(CultureInfo.InvariantCulture) + " sur 10 s");
        Set(interruptions, snapshot.Interruptions.ToString(CultureInfo.InvariantCulture) + " sur 10 s");
        Set(sampleCount, snapshot.DrawnCaptures.ToString(CultureInfo.InvariantCulture) + " pour les percentiles");
        Set(window, snapshot.IsWindowTruncated
            ? "Fenêtre fixe de 10 s · capacité atteinte : relevé partiel"
            : "Fenêtre fixe de 10 s · moyenne incluant le début de la connexion");
        window.Foreground = snapshot.IsWindowTruncated ? Theme.Orange : Theme.Muted;

        // Copying the diagnostic uses this displayed snapshot, not a newer read.
        SummaryText = "PERFORMANCES — " + window.Text + Environment.NewLine +
            "Captures acceptées : " + acceptedRate.Text + " · " + acceptedCount.Text + Environment.NewLine +
            "Caméras fraîches : " + cameraRate.Text + " · " + cameraCount.Text + Environment.NewLine +
            "Captures distinctes traitées par WPF : " + drawnRate.Text + " · " + drawnCount.Text + Environment.NewLine +
            "Âge au dessin p50 / p95 : " + agePercentiles.Text + Environment.NewLine +
            "Réception → dessin p50 / p95 : " + receivePercentiles.Text + Environment.NewLine +
            "Dernier âge au dessin : " + lastAge.Text + Environment.NewLine +
            "Caméras reçues sans dessin à 250 ms : " + expired.Text + Environment.NewLine +
            "Interruptions de caméra : " + interruptions.Text + Environment.NewLine +
            "Nombre de captures pour les percentiles : " + snapshot.DrawnCaptures.ToString(CultureInfo.InvariantCulture) + Environment.NewLine +
            "Sans dessin inclut l’affichage masqué ; ce nombre ne signifie pas des pertes de données. " +
            "Une vue valide vide compte comme traitée. Mesures WPF, sans mesure des FPS GPU ni de la latence physique du fuser.";
    }

    private static void AddRate(Grid parent, int column, string label, Brush color,
        out TextBlock value, out TextBlock count)
    {
        value = FixedText("—", 25, 38, color, true);
        value.FontFamily = new FontFamily("Consolas");
        count = FixedText("0 sur 10 s", 11, 20, Theme.Muted);
        var content = Theme.Stack(FixedText(label, 11.5, 22, Theme.Muted, true), value, count);
        var card = Theme.Inset(content, new Thickness(13, 10, 13, 10));
        card.Height = 104;
        card.Margin = new Thickness(column == 0 ? 0 : 5, 0, column == 2 ? 0 : 5, 0);
        Grid.SetColumn(card, column);
        parent.Children.Add(card);
    }

    private static TextBlock AddRow(Grid parent, string label)
    {
        int row = parent.RowDefinitions.Count;
        parent.RowDefinitions.Add(new RowDefinition { Height = new GridLength(28) });
        var caption = FixedText(label, 12, 26, Theme.Muted);
        var value = FixedText("—", 12.5, 26, Theme.Foreground);
        value.FontFamily = new FontFamily("Consolas");
        Grid.SetRow(caption, row);
        Grid.SetRow(value, row);
        Grid.SetColumn(value, 1);
        parent.Children.Add(caption);
        parent.Children.Add(value);
        return value;
    }

    private static TextBlock FixedText(string text, double size, double height, Brush color, bool bold = false)
    {
        var value = Theme.Text(text, size, color, bold);
        value.Height = value.MinHeight = value.MaxHeight = height;
        value.TextWrapping = TextWrapping.NoWrap;
        value.TextTrimming = TextTrimming.CharacterEllipsis;
        value.Margin = new Thickness(0);
        value.VerticalAlignment = VerticalAlignment.Center;
        return value;
    }

    private static string Rate(double value) => value.ToString("0.0", CultureInfo.InvariantCulture) + " /s";
    private static string Milliseconds(double? value) => value.HasValue ? value.Value.ToString("0.0", CultureInfo.InvariantCulture) + " ms" : "—";
    private static string Pair(double? first, double? second) => Milliseconds(first) + " / " + Milliseconds(second);
    private static void Set(TextBlock field, string text) { if (field.Text != text) field.Text = text; }
}
