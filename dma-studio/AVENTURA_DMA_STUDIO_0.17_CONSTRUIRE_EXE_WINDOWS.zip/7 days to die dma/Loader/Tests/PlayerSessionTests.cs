using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using SevenDaysEsp;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class PlayerSessionTests
{
    public static Task ActionsBindToCurrentOpaqueInstancesAndStaySessionOnly()
    {
        var f = new Fixture(); f.Publish(f.Next(Player(12, 1), Player(13, 2, 20)));
        var a = f.Service.ReadSnapshot().Rows[0].Identity;
        var b = f.Service.ReadSnapshot().Rows[1].Identity;
        Check(f.Service.Select(a) && f.Service.Pin(a) && f.Service.SetMarked(a, true) &&
            f.Service.SetHidden(a, true) && f.Service.SetColor(a, "#a1B2c3"), "Valid identity actions were rejected.");
        Check(f.Service.TryGetVisual(a, out var visual) && visual.Selected && visual.Pinned && visual.Marked && visual.Hidden &&
            visual.Color == "#A1B2C3", "The individual visual state was not retained/normalized.");
        Check(!f.Service.SetColor(a, "red") && !f.Service.SetColor(a, "#A1B2C3") && !f.Service.SetMarked(a, true),
            "Invalid or unchanged settings were reported as changes.");
        Check(f.Service.Pin(b) && f.Service.Select(b), "Selection/pin could not move to another current player.");
        var moved = f.Service.ReadSnapshot();
        Check(moved.Rows.Count(row => row.Visual.Pinned) == 1 && moved.Pinned?.Identity == b &&
            moved.Rows.Count(row => row.Visual.Selected) == 1, "More than one selection or pinned card remained.");
        f.Publish(f.Next(Player(12, 3), Player(13, 2, 20)));
        var recycled = f.Service.ReadSnapshot().Rows[0];
        Check(!recycled.Visual.Marked && !recycled.Visual.Hidden && recycled.Visual.Color == null &&
            !f.Service.SetMarked(a, true) && !f.Service.TryGetVisual(a, out _),
            "A recycled EntityId inherited the old instance's annotations or accepted its action.");
        Check(f.Service.ClearAll() && f.Service.ReadSnapshot().Rows.All(row => row.Visual == new PlayerVisualState()),
            "Clearing session annotations left a per-player preference.");
        return Task.CompletedTask;
    }

    public static Task AcceptedAbsenceContextAndGenerationBreakContinuity()
    {
        var f = new Fixture(); f.Publish(f.Next(Player(12, 1)));
        var identity = f.Service.ReadSnapshot().Rows.Single().Identity;
        f.Service.SetMarked(identity, true); f.Service.Pin(identity);
        f.Publish(f.Next());
        Check(f.Service.ReadSnapshot().HasCurrentData && f.Service.ReadSnapshot().Rows.Count == 0 &&
            !f.Service.TryGetVisual(identity, out _), "An accepted player absence retained a visible annotation.");
        f.Publish(f.Next(Player(12, 1)));
        Check(!f.Service.ReadSnapshot().Rows.Single().Visual.Marked,
            "A reappearance inherited an annotation despite an accepted absence.");
        f.Service.SetMarked(identity, true);
        string oldContext = f.Context;
        f.Context = Guid.NewGuid().ToString("N");
        f.Publish(f.Next(Player(12, 1)));
        Check(!f.Service.ReadSnapshot().Rows.Single().Visual.Marked && !f.Service.SetMarked(identity, true),
            "A new world context inherited the old player's state.");
        var delayed = f.Next(Player(12, 1)); delayed.Snapshot.PlayerContextId = oldContext;
        f.Publish(delayed);
        Check(f.Service.ReadSnapshot().Rows.Single().Identity.ContextId == f.Context,
            "A delayed packet from a retired world rolled the current context back.");
        f.Service.Reset(2);
        f.Publish(f.Next(Player(12, 1)), generation: 1);
        Check(!f.Service.ReadSnapshot().HasCurrentData, "An old generation republished player data.");
        f.Publish(f.Next(Player(12, 1)), generation: 2);
        f.Service.ObserveUnavailable(1);
        Check(f.Service.ReadSnapshot().HasCurrentData && !f.Service.ReadSnapshot().Rows.Single().Visual.Marked,
            "An old unavailable event changed the new generation, or a reset retained annotations.");
        return Task.CompletedTask;
    }

    public static Task ShortGapsRetainAnnotationsButExpiryAndReplayCannotReviveThem()
    {
        var f = new Fixture(); var original = f.Next(Player(12, 1)); f.Publish(original);
        var identity = f.Service.ReadSnapshot().Rows.Single().Identity;
        f.Service.SetMarked(identity, true);
        f.Advance(100); f.Service.ObserveUnavailable(1);
        var missing = f.Service.ReadSnapshot();
        Check(!missing.HasCurrentData && missing.Rows.Count == 0 && !f.Service.SetColor(identity, "#FFFFFF"),
            "A short failed capture exposed stale values or accepted a stale row action.");
        f.Publish(f.Next(Player(12, 1)));
        Check(f.Service.ReadSnapshot().Rows.Single().Visual.Marked, "A short data gap erased a stable instance's mark.");
        var replay = f.Next(Player(12, 1)); f.Publish(replay);
        f.Advance(2000);
        long expiredRevision = f.Service.ReadSnapshot().Revision;
        Check(!f.Service.ReadSnapshot().HasCurrentData && !f.Service.TryGetVisual(identity, out _),
            "The two-second expiry kept stale players interactive.");
        f.Publish(f.Retransmit(replay));
        Check(!f.Service.ReadSnapshot().HasCurrentData && f.Service.ReadSnapshot().Revision == expiredRevision,
            "A retransmission rejuvenated an expired source capture.");
        f.Clock -= Ticks(1000);
        Check(!f.Service.ReadSnapshot().HasCurrentData, "A backward injected clock revived an expired sample.");
        f.Clock += Ticks(1000);
        f.Publish(f.Next(Player(12, 1)));
        Check(!f.Service.ReadSnapshot().Rows.Single().Visual.Marked,
            "Annotations survived the expiry and reattached to a later observation.");
        return Task.CompletedTask;
    }

    public static Task SnapshotCopiesAndPreferenceEventsRemainSafe()
    {
        var f = new Fixture();
        int changes = 0;
        f.Service.PreferencesChanged += () =>
        {
            ++changes;
            Check(Task.Run(() => f.Service.ReadSnapshot()).Wait(TimeSpan.FromSeconds(2)),
                "PreferencesChanged ran while the session lock was held.");
        };
        var source = f.Next(Player(12, 1)); f.Publish(source);
        var snapshot = f.Service.ReadSnapshot();
        var original = snapshot.Rows.Single();
        source.Snapshot.Entities[0].Name = "Nom modifié après capture";
        source.Snapshot.Entities[0].Position.X = 900;
        source.Snapshot.Entities[0].Health = 0;
        Check(snapshot.Rows.Single().Name == "Joueur test 12" && original.DistanceMeters == 10 && original.Health == 80,
            "A caller-owned entity mutation changed the immutable session snapshot.");
        bool readOnly = false;
        try { ((IList<PlayerRow>)snapshot.Rows)[0] = new PlayerRow(); }
        catch (NotSupportedException) { readOnly = true; }
        Check(readOnly, "The public row collection can be modified by a renderer/UI consumer.");
        Check(f.Service.SetMarked(original.Identity, true), "A current player could not be marked.");
        Check(changes == 1 && !snapshot.Rows.Single().Visual.Marked && f.Service.ReadSnapshot().Rows.Single().Visual.Marked,
            "An annotation changed an old snapshot or emitted the wrong event count.");
        f.Service.SetMarked(original.Identity, true);
        f.Publish(f.Next(Player(12, 1)));
        f.Service.ObserveUnavailable(1); f.Service.Reset(2);
        Check(changes == 1, "Data receipt, no-op, unavailability or reset emitted a user-preference event.");
        return Task.CompletedTask;
    }

    public static Task AlertsRequireTwoDistinctFreshCapturesWithoutCamera()
    {
        var f = new Fixture(); f.Settings.ProximityAlerts = true;
        var first = f.Next(Player(12, 1)); f.Publish(first);
        Check(f.Service.ReadSnapshot().Notice == null, "One capture produced a proximity alert.");
        f.Publish(first); f.Publish(f.Retransmit(first));
        Check(f.Service.ReadSnapshot().Notice == null, "Retransmissions counted as proximity confirmations.");
        f.Advance(20); f.Publish(f.Next(Player(12, 1)));
        var notice = f.Service.ReadSnapshot().Notice;
        Check(notice?.Sequence > 0 && notice.DistanceMeters == 10 && !notice.PlaySound,
            "Two fresh coherent observations without a camera did not produce the expected silent notice.");

        var aged = new Fixture(); aged.Settings.ProximityAlerts = true;
        var boundary = aged.Next(Player(12, 1), age: FeedSample.ProjectionLifetimeMs);
        aged.Publish(boundary); aged.Publish(aged.Next(Player(12, 1)));
        Check(aged.Service.ReadSnapshot().Notice == null, "An exactly 250 ms old capture confirmed a fresh alert.");
        aged.Publish(aged.Next(Player(12, 1)));
        Check(aged.Service.ReadSnapshot().Notice != null, "Fresh observations did not recover after stale data.");

        var separated = new Fixture(); separated.Settings.ProximityAlerts = true;
        separated.Publish(separated.Next(Player(12, 1)));
        separated.Advance(250); separated.Publish(separated.Next(Player(12, 1)));
        Check(separated.Service.ReadSnapshot().Notice == null,
            "A previous capture already at 250 ms confirmed a new proximity alert.");
        return Task.CompletedTask;
    }

    public static Task ProximityUses3dDistanceHysteresisAndPerPlayerCooldown()
    {
        var f = new Fixture(); f.Settings.ProximityAlerts = true; f.Settings.AlertSound = true;
        f.Publish(f.Next(Player(12, 1, 0, 60))); f.Publish(f.Next(Player(12, 1, 0, 60)));
        Check(f.Service.ReadSnapshot().Rows.Single().DistanceMeters == 60 && f.Service.ReadSnapshot().Notice == null,
            "A vertical separation was ignored by the proximity calculation.");
        f.Publish(f.Next(Player(12, 1, 40))); f.Publish(f.Next(Player(12, 1, 40)));
        long initial = f.Service.ReadSnapshot().Notice!.Sequence;
        Check(f.Service.ReadSnapshot().Notice!.PlaySound, "An explicitly enabled sound flag was lost.");
        f.Advance(1000);
        f.Publish(f.Next(Player(12, 1, 55))); f.Publish(f.Next(Player(12, 1, 40))); f.Publish(f.Next(Player(12, 1, 40)));
        Check(f.Service.ReadSnapshot().Notice?.Sequence == initial, "Threshold jitter bypassed the hysteresis margin.");
        f.Publish(f.Next(Player(12, 1, 60))); f.Publish(f.Next(Player(12, 1, 40))); f.Publish(f.Next(Player(12, 1, 40)));
        Check(f.Service.ReadSnapshot().Notice?.Sequence == initial, "A re-entry bypassed the per-player cooldown.");
        // Keep the instance current while monotonic time advances beyond its
        // cooldown. Standing inside must not turn a suppressed entry into a
        // delayed arrival notification.
        for (int i = 0; i < 15; ++i)
        { f.Advance(1000); f.Publish(f.Next(Player(12, 1, 40))); }
        Check(f.Service.ReadSnapshot().Notice == null, "A stationary player retriggered after waiting out cooldown.");
        f.Publish(f.Next(Player(12, 1, 60))); f.Publish(f.Next(Player(12, 1, 40))); f.Publish(f.Next(Player(12, 1, 40)));
        Check(f.Service.ReadSnapshot().Notice?.Sequence > initial, "A new confirmed entry after cooldown did not alert.");
        return Task.CompletedTask;
    }

    public static Task UnavailableHiddenMarkedAndDisabledStatesSuppressAlerts()
    {
        var f = new Fixture(); f.Settings.ProximityAlerts = true; f.Settings.AlertsMarkedOnly = true;
        f.Publish(f.Next(Player(12, 1))); f.Publish(f.Next(Player(12, 1)));
        Check(f.Service.ReadSnapshot().Notice == null, "An unmarked player bypassed the marked-only filter.");
        var identity = f.Service.ReadSnapshot().Rows.Single().Identity;
        f.Service.SetMarked(identity, true); f.Service.SetHidden(identity, true);
        f.Publish(f.Next(Player(12, 1))); f.Publish(f.Next(Player(12, 1)));
        Check(f.Service.ReadSnapshot().Notice == null, "A hidden player generated a proximity notice.");
        f.Service.SetHidden(identity, false);
        f.Publish(f.Next(Player(12, 1)));
        f.Service.ObserveUnavailable(1);
        f.Publish(f.Next(Player(12, 1)));
        Check(f.Service.ReadSnapshot().Notice == null, "An unavailable sample failed to break consecutive confirmation.");
        f.Publish(f.Next(Player(12, 1)));
        Check(f.Service.ReadSnapshot().Notice != null, "An eligible player did not alert after two new observations.");
        f.Service.SetHidden(identity, true);
        Check(f.Service.ReadSnapshot().Notice == null, "Hiding a player did not immediately remove its notice.");
        f.Service.SetHidden(identity, false);
        f.Publish(f.Next(Player(12, 1, 60)), allowed: false);
        f.Publish(f.Next(Player(12, 1)), allowed: false); f.Publish(f.Next(Player(12, 1)), allowed: false);
        Check(f.Service.ReadSnapshot().Notice == null, "The master/display permission gate did not suppress proximity alerts.");
        return Task.CompletedTask;
    }

    public static Task GlobalCooldownBoundsNoticesAndSequenceSurvivesReset()
    {
        var f = new Fixture(); f.Settings.ProximityAlerts = true;
        f.Publish(f.Next(Player(12, 1, 30), Player(13, 2, 10)));
        f.Publish(f.Next(Player(12, 1, 30), Player(13, 2, 10)));
        var first = f.Service.ReadSnapshot().Notice!;
        Check(first.Identity.EntityId == 13, "Simultaneous arrivals did not select the closest notice deterministically.");
        f.Advance(1000);
        f.Publish(f.Next(Player(14, 3, 5))); f.Publish(f.Next(Player(14, 3, 5)));
        Check(f.Service.ReadSnapshot().Notice == null, "A different player bypassed the global cooldown.");
        f.Service.Reset(2);
        f.Publish(f.Next(Player(15, 4, 5)), generation: 2); f.Publish(f.Next(Player(15, 4, 5)), generation: 2);
        Check(f.Service.ReadSnapshot().Notice == null, "A quick reset bypassed the global anti-spam fence.");
        f.Advance(3000);
        f.Publish(f.Next(Player(16, 5, 5)), generation: 2); f.Publish(f.Next(Player(16, 5, 5)), generation: 2);
        var afterReset = f.Service.ReadSnapshot().Notice!;
        Check(afterReset.Sequence > first.Sequence, "Notice sequence was recycled during a reset.");
        for (int i = 0; i < 4; ++i)
        { f.Advance(1000); f.Publish(f.Next(Player(16, 5, 5)), generation: 2); }
        Check(f.Service.ReadSnapshot().HasCurrentData && f.Service.ReadSnapshot().Notice == null,
            "A notice failed to expire while fresh player data continued.");
        return Task.CompletedTask;
    }

    public static Task ClockCorrectionsDoNotFreezeSequencedCaptures()
    {
        var f = new Fixture();
        var first = f.Next(Player(12, 1)); first.Snapshot.CapturedUtc = new DateTime(2050, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        f.Publish(first);
        var identity = f.Service.ReadSnapshot().Rows.Single().Identity;
        f.Service.SetMarked(identity, true);
        var corrected = f.Next(Player(12, 1, 25)); corrected.Snapshot.CapturedUtc = new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        f.Publish(corrected);
        Check(f.Service.ReadSnapshot().Rows.Single().DistanceMeters == 25 && f.Service.ReadSnapshot().Rows.Single().Visual.Marked,
            "A UTC rollback stopped fresh sequenced data or reset stable annotations.");
        f.Publish(f.Retransmit(first));
        Check(f.Service.ReadSnapshot().Rows.Single().DistanceMeters == 25,
            "An older sequence with a later UTC time rolled back the current player data.");
        return Task.CompletedTask;
    }

    public static Task PreferenceChangesImmediatelyClearNoticeAndPartialConfirmation()
    {
        var f = new Fixture(); f.Settings.ProximityAlerts = true;
        int userEvents = 0; f.Service.PreferencesChanged += () => ++userEvents;
        f.Publish(f.Next(Player(12, 1)));
        f.Settings.ProximityAlerts = false;
        f.Service.UpdatePreferences(f.Settings, true);
        f.Settings.ProximityAlerts = true;
        f.Service.UpdatePreferences(f.Settings, true);
        f.Publish(f.Next(Player(12, 1)));
        Check(f.Service.ReadSnapshot().Notice == null,
            "Disabling/re-enabling between captures retained a partial arrival confirmation.");
        f.Publish(f.Next(Player(12, 1)));
        var before = f.Service.ReadSnapshot();
        Check(before.Notice != null, "A current eligible player did not confirm after the preference change.");
        f.Service.UpdatePreferences(f.Settings, false);
        var after = f.Service.ReadSnapshot();
        Check(after.HasCurrentData && after.Rows.Count == 1 && after.Notice == null && after.Revision > before.Revision,
            "Disabling the display gate waited for another capture to clear the notice or erased valid player data.");
        f.Service.UpdatePreferences(f.Settings, true);
        Check(f.Service.ReadSnapshot().Notice == null && userEvents == 0,
            "Re-enabling replayed an old notice or settings application emitted a per-player user event.");
        return Task.CompletedTask;
    }

    public static Task LegacyDuplicatesMalformedPacketsAndCapacityFailSafely()
    {
        var f = new Fixture(); f.Settings.ProximityAlerts = true;
        var legacy = f.Next(Player(12, 0)); legacy.Snapshot.PlayerContextId = null; legacy.Snapshot.PlayerCaptureSequence = 0;
        f.Publish(legacy);
        var row = f.Service.ReadSnapshot().Rows.Single();
        Check(!row.CanAnnotate && !f.Service.Pin(row.Identity) && !f.Service.SetMarked(row.Identity, true),
            "A legacy ID/name was used to invent an annotation identity.");
        var duplicate = f.Next(Player(12, 1), Player(12, 2)); f.Publish(duplicate);
        Check(f.Service.ReadSnapshot().Rows.Count == 2 && f.Service.ReadSnapshot().Rows.All(item => !item.CanAnnotate),
            "Duplicate game IDs were collapsed or allowed ambiguous annotations.");
        f.Publish(f.Next(Player(12, 1), Player(13, 1)));
        Check(f.Service.ReadSnapshot().Rows.All(item => !item.CanAnnotate), "Duplicate tokens remained annotatable.");
        foreach (double age in new[] { double.NaN, -1, 2000, double.PositiveInfinity })
        {
            f.Publish(f.Next(Player(12, 1), age: age));
            Check(!f.Service.ReadSnapshot().HasCurrentData, "An invalid sample age produced current rows.");
        }
        var maximum = Enumerable.Range(2, PlayerSessionService.MaximumPlayers).Select(id => Player(id, id)).ToArray();
        f.Publish(f.Next(maximum));
        Check(f.Service.ReadSnapshot().Rows.Count == PlayerSessionService.MaximumPlayers,
            "The valid bounded collection was truncated or expanded.");
        f.Publish(f.Next(maximum.Append(Player(9000, 9000)).ToArray()));
        Check(!f.Service.ReadSnapshot().HasCurrentData, "An oversized collection bypassed the feed bound.");
        return Task.CompletedTask;
    }

    private static LiveEntity Player(int id, long token, float x = 10, float y = 0, float z = 0) => new()
    {
        Kind = "player", EntityId = id, IdentityToken = token, Name = "Joueur test " + id,
        Health = 80, MaxHealth = 100, Position = new LivePosition { X = x, Y = y, Z = z }
    };

    private sealed class Fixture
    {
        // FeedSample intentionally exposes no mutable clock or test API. This
        // fixture stamps its existing readonly receipt field only in tests, so
        // multi-second cooldown/expiry cases need no sleeps or production hooks.
        private static readonly FieldInfo ReceiptField = typeof(FeedSample).GetField("<ReceivedTimestamp>k__BackingField",
            BindingFlags.Instance | BindingFlags.NonPublic)!;
        private long sequence;
        internal long Clock = Stopwatch.GetTimestamp();
        internal string Context = Guid.NewGuid().ToString("N");
        internal PlayerFeaturesSettings Settings = new();
        internal readonly PlayerSessionService Service;
        internal Fixture() { Service = new PlayerSessionService(() => Clock); Service.Reset(1); }
        internal void Advance(double ms) => Clock += Ticks(ms);
        internal FeedSample Next(params LiveEntity[] entities) => Create(0, entities);
        internal FeedSample Next(LiveEntity entity, double age) => Create(age, new[] { entity });
        private FeedSample Create(double age, LiveEntity[] entities)
        {
            ++sequence;
            var snapshot = new LiveEntitySnapshot
            {
                CapturedUtc = new DateTime(2020, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddTicks(sequence),
                PlayerContextId = Context, PlayerCaptureSequence = sequence,
                Status = "ENTITES_LUES", LocalId = 1, LocalPosition = new LivePosition(),
                Entities = entities.ToList(), PlayersCount = entities.Length
            };
            var result = new FeedSample(snapshot, age);
            ReceiptField.SetValue(result, Clock);
            return result;
        }
        internal FeedSample Retransmit(FeedSample original)
        {
            var result = new FeedSample(original.Snapshot, 0);
            ReceiptField.SetValue(result, Clock);
            return result;
        }
        internal void Publish(FeedSample sample, bool allowed = true, int generation = 1) =>
            Service.Observe(sample, generation, Settings, allowed);
    }

    private static long Ticks(double milliseconds) => (long)Math.Ceiling(milliseconds * Stopwatch.Frequency / 1000.0);
    private static void Check(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }
}
