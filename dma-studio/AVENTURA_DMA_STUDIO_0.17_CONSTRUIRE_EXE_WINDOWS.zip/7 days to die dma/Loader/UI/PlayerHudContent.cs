using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace SevenDaysLoader.UI;

// Fixed-height rows keep an intermittent player read from moving the HUD.
// Geometry and freshness remain owned by the capture/session services.
internal sealed class PlayerHudContent : StackPanel
{
    private readonly ILoaderController controller;
    private readonly StackPanel pin;
    private readonly StackPanel proximity;
    private readonly StackPanel adminWatch;
    private readonly StackPanel pvpSense;
    private readonly TextBlock pvpMoon;
    private readonly TextBlock pvpZombies;
    private readonly TextBlock adminWatchName;
    private readonly TextBlock adminWatchDetail;
    private readonly TextBlock pinName;
    private readonly TextBlock pinDetails;
    private readonly TextBlock pinHealth;
    private readonly TextBlock pinTrend;
    private readonly TextBlock alertTitle;
    private readonly TextBlock alertDetails;

    internal PlayerHudContent(ILoaderController controller)
    {
        this.controller = controller;
        pinName = Line("Aucun joueur épinglé", Theme.Cyan, true);
        pinDetails = Line("Épingle un joueur dans le menu.", Theme.Muted);
        pinHealth = Line("", Theme.Muted);
        pinTrend = Line("Tendance : en attente", Theme.Muted);
        pinTrend.Visibility = Visibility.Collapsed;
        pinTrend.ToolTip = "Variation de la distance entre les deux joueurs, incluant tes propres déplacements.";
        pin = Theme.Stack(pinName, pinDetails, pinHealth, pinTrend);
        pin.Margin = new Thickness(0, 8, 0, 0);
        pin.Height = 60;
        pin.ClipToBounds = true;
        alertTitle = Line("Proximité", Theme.Orange, true);
        alertDetails = Line("Aucune alerte en cours", Theme.Muted);
        proximity = Theme.Stack(alertTitle, alertDetails);
        proximity.Margin = new Thickness(0, 8, 0, 0);
        proximity.Height = 42;
        proximity.ClipToBounds = true;
        adminWatchName = Line("SURVEILLANCE · Aucun joueur désigné", Theme.Brush("#C6A0FF"), true);
        adminWatchDetail = Line("", Theme.Muted);
        adminWatch = Theme.Stack(adminWatchName, adminWatchDetail);
        adminWatch.Margin = new Thickness(0, 8, 0, 0);
        adminWatch.Height = 42;
        adminWatch.ClipToBounds = true;
        Children.Add(pin);
        Children.Add(proximity);
        Children.Add(adminWatch);
        pvpMoon = Line("Blood Moon : en attente", Theme.Orange, true);
        pvpZombies = Line("Ciblage zombie : en attente", Theme.Muted);
        pvpSense = Theme.Stack(pvpMoon, pvpZombies);
        pvpSense.Margin = new Thickness(0, 8, 0, 0);
        pvpSense.Height = 42;
        pvpSense.ClipToBounds = true;
        Children.Add(pvpSense);
        IsHitTestVisible = false;
    }

    internal double ReservedHeight
    {
        get
        {
            var s = controller.Settings;
            if (!s.ShowHud) return 0;
            return (s.PlayerEsp.Enabled ? (s.PlayerFeatures.ShowPinnedCard ? 68 + (s.PlayerFeatures.ShowDistanceTrend ? 19 : 0) : 0) +
                (s.PlayerFeatures.ProximityAlerts ? 50 : 0) + (s.AdminWatch?.Enabled == true ? 50 : 0) : 0) +
                (s.PvpSense.ShowBloodMoon || s.PvpSense.ShowZombieTarget ? 50 : 0);
        }
    }

    internal void Refresh()
    {
        var s = controller.Settings;
        bool hud = s.ShowHud && s.PlayerEsp.Enabled;
        pin.Visibility = hud && s.PlayerFeatures.ShowPinnedCard ? Visibility.Visible : Visibility.Collapsed;
        pinTrend.Visibility = s.PlayerFeatures.ShowDistanceTrend ? Visibility.Visible : Visibility.Collapsed;
        pin.Height = s.PlayerFeatures.ShowDistanceTrend ? 79 : 60;
        proximity.Visibility = hud && s.PlayerFeatures.ProximityAlerts ? Visibility.Visible : Visibility.Collapsed;
        adminWatch.Visibility = hud && s.AdminWatch?.Enabled == true ? Visibility.Visible : Visibility.Collapsed;
        pvpSense.Visibility = s.ShowHud && (s.PvpSense.ShowBloodMoon || s.PvpSense.ShowZombieTarget)
            ? Visibility.Visible : Visibility.Collapsed;
        var fresh = controller.CurrentFrame?.IsFresh == true ? controller.CurrentFrame.Snapshot : null;
        pvpMoon.Visibility = s.PvpSense.ShowBloodMoon ? Visibility.Visible : Visibility.Collapsed;
        pvpZombies.Visibility = s.PvpSense.ShowZombieTarget ? Visibility.Visible : Visibility.Collapsed;
        if (fresh != null && s.PvpSense.ShowBloodMoon)
        {
            string day = fresh.WorldDay?.ToString(CultureInfo.InvariantCulture) ?? "?";
            string hour = fresh.WorldHour.HasValue ? fresh.WorldHour.Value.ToString("00", CultureInfo.InvariantCulture) + "h" : "heure ?";
            string moon = fresh.BloodMoonActive == true ? "ACTIVE" : fresh.BloodMoonActive == false ? "inactive" : "inconnue";
            pvpMoon.Text = "Jour " + day + " · " + hour + " · Blood Moon " + moon;
        }
        else pvpMoon.Text = "Blood Moon : en attente de données";
        if (fresh != null && s.PvpSense.ShowZombieTarget)
        {
            int targets = 0;
            foreach (var entity in fresh.Entities)
                if (entity.Kind == "zombie" && entity.ZombieTargetsLocal == true) targets++;
            pvpZombies.Text = targets > 0 ? "ALERTE · " + targets + " zombie(s) te ciblent" :
                "Aucun ciblage local confirmé (état inconnu)";
        }
        else pvpZombies.Text = "Ciblage zombie : données indisponibles";
        var matches = AdminWatchMatcher.Nearby(hud ? controller.CurrentFrame : null, s.AdminWatch);
        if (matches.Count > 0)
        {
            var chosen = matches[0];
            adminWatchName.Text = "SURVEILLANCE · " + RadarControl.CleanName(chosen.Name);
            adminWatchDetail.Text = "Joueur désigné à " + AdminWatchMatcher.Distance(chosen.Position,
                controller.CurrentFrame!.Snapshot.LocalPosition).ToString("0", CultureInfo.GetCultureInfo("fr-FR")) + " m";
        }
        else
        {
            adminWatchName.Text = "SURVEILLANCE · Aucun joueur désigné";
            adminWatchDetail.Text = controller.CurrentFrame?.IsFresh == true ? "Non observé dans les données client" : "En attente de données DMA";
        }
        var session = controller.Players.ReadSnapshot();
        bool current = session.HasCurrentData && controller.CurrentFrame?.IsFresh == true;
        var row = current ? session.Pinned : null;
        if (row != null && !row.Visual.Hidden)
        {
            pinName.Text = "ÉPINGLÉ · " + RadarControl.CleanName(row.Name);
            pinName.Foreground = Color(row.Visual.Color ?? s.PlayerEsp.Color);
            pinDetails.Text = row.DistanceMeters.ToString("0", CultureInfo.GetCultureInfo("fr-FR")) + " m · Δh " +
                row.HeightMeters.ToString("+0;-0;0", CultureInfo.GetCultureInfo("fr-FR")) + " m";
            pinHealth.Text = row.Health.HasValue
                ? "Vie : " + row.Health.Value + (row.MaxHealth.HasValue ? " / " + row.MaxHealth.Value : " / ?")
                : "Vie indisponible";
            pinTrend.Text = TrendText(row.DistanceTrend);
        }
        else
        {
            pinName.Text = "Aucun joueur épinglé disponible";
            pinName.Foreground = Theme.Muted;
            pinDetails.Text = current ? "Épingle un joueur dans le menu." : "En attente de données récentes";
            pinHealth.Text = "";
            pinTrend.Text = "Tendance : en attente";
        }
        var notice = current ? session.Notice : null;
        alertTitle.Text = notice == null ? "PROXIMITÉ · " + s.PlayerFeatures.AlertDistance + " m" :
            "PROXIMITÉ · " + RadarControl.CleanName(notice.Name);
        alertDetails.Text = notice == null ? (current ? "Aucune alerte en cours" : "En attente de données récentes") :
            "Détecté à " + notice.DistanceMeters.ToString("0", CultureInfo.GetCultureInfo("fr-FR")) + " m";
    }

    private static string TrendText(PlayerDistanceTrend trend)
    {
        if (!trend.RelativeMetersPerSecond.HasValue || !double.IsFinite(trend.RelativeMetersPerSecond.Value))
            return "Tendance : en attente";
        string? label = trend.State switch
        {
            PlayerDistanceTrendState.Approaching => "Distance diminue",
            PlayerDistanceTrendState.Stable => "Distance stable",
            PlayerDistanceTrendState.Receding => "Distance augmente",
            _ => null
        };
        return label == null ? "Tendance : en attente" : label + " · " +
            trend.RelativeMetersPerSecond.Value.ToString("+0.0;-0.0;0.0", CultureInfo.GetCultureInfo("fr-FR")) + " m/s";
    }

    private static Brush Color(string color)
    {
        try { return Theme.Brush(color); }
        catch (FormatException) { return Theme.Cyan; }
    }

    private static TextBlock Line(string text, Brush color, bool bold = false)
    {
        var label = Theme.Text(text, 11, color, bold);
        label.Height = 19;
        label.Margin = new Thickness(0);
        label.LineHeight = 18;
        label.LineStackingStrategy = LineStackingStrategy.BlockLineHeight;
        label.TextWrapping = TextWrapping.NoWrap;
        label.TextTrimming = TextTrimming.CharacterEllipsis;
        label.ClipToBounds = true;
        return label;
    }
}
