using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using SevenDaysLoader.Services;
using SevenDaysEsp;

namespace SevenDaysLoader.UI;

public sealed class MainWindow : Window
{
    private readonly ILoaderController controller;
    private readonly DispatcherTimer timer = new() { Interval = TimeSpan.FromMilliseconds(100) };
    private readonly CoalescedRefresh overlayRefresh;
    private readonly CancellationTokenSource overlayRefreshCancellation = new();
    private readonly ContentControl pageHost = new();
    private readonly ScrollViewer pageScroller = new();
    private readonly TextBlock pageTitle = Theme.Text("", 28, null, true);
    private readonly TextBlock pageSubtitle = Theme.Text("", 13, Theme.Muted);
    private readonly TextBlock statusText = Theme.Text("", 13);
    private readonly TextBlock statusMessage = Theme.Text("", 12, Theme.Muted);
    private readonly TextBlock keyHint = Theme.Text("", 11, Theme.Muted);
    private readonly TextBlock errorText = Theme.Text("", 12, Theme.Orange);
    private readonly List<Action> refreshActions = new();
    private readonly Dictionary<string, UIElement> pages = new();
    private readonly Dictionary<string, Button> navButtons = new();
    private readonly Dictionary<string, Border> navMarkers = new();
    private readonly Dictionary<string, TextBlock> navIcons = new();
    private readonly TextBlock sidebarStatus = Theme.Text("MODULE DMA INACTIF", 11, Theme.Orange, true);
    private readonly TextBlock topStatus = Theme.Text("INITIALISATION", 10.5, Theme.Muted, true);
    private readonly Border sessionAccent = new() { Width = 4, Background = Theme.Orange, CornerRadius = new CornerRadius(3) };
    private readonly List<SettingsPanel> settingPanels = new();
    private SettingsPanel? mainSettingsPanel;
    private readonly List<Button> workButtons = new();
    private OverlayManager? overlay;
    private bool actionRunning;
    private bool refreshing;
    private bool closing;
    private bool startupConsumed;
    private bool initialized;
    private readonly bool displayMode;
    private TextBox? sdkInput;
    private bool checkingSdk;
    private string checkedSdk = "";
    private bool sdkPresent;
    private string currentPage = "Tableau de bord";

    public MainWindow(ILoaderController controller)
    {
        this.controller = controller;
        var refreshCancellation = overlayRefreshCancellation.Token;
        overlayRefresh = new CoalescedRefresh(callback =>
        {
            if (Dispatcher.HasShutdownStarted || Dispatcher.HasShutdownFinished)
                throw new InvalidOperationException("Le dispatcher d’affichage est fermé.");
            Dispatcher.InvokeAsync(callback, DispatcherPriority.Render, refreshCancellation);
        }, RefreshOverlay);
        displayMode = controller.Settings.Mode == "display";
        Title = displayMode ? "AVENTURA  /  7DTD — Studio affichage" : "AVENTURA  /  7DTD — DMA Studio";
        Width = 1370; Height = 920; MinWidth = 1000; MinHeight = 700;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        Theme.Apply(this);
        // Incoming diagnostics vary greatly in length. None of these global
        // readouts may change the height or width available to the current page.
        ConfigureFixedLine(statusText, 23);
        ConfigureFixedLine(statusMessage, 20);
        ConfigureFixedLine(errorText, 18);
        ConfigureFixedLine(keyHint, 18);
        ConfigureFixedLine(pageTitle, 42);
        ConfigureFixedLine(pageSubtitle, 22);
        AttachReadoutTip(statusMessage, () => controller.Status.Message);
        AttachReadoutTip(errorText, () => errorText.Text);
        AttachReadoutTip(keyHint, () => keyHint.Text);
        AttachReadoutTip(pageSubtitle, () => pageSubtitle.Text);
        // Main shell: a real dashboard rather than a stack of diagnostic controls.
        var root = new Grid { Background = Theme.Background };
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(254) });
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        root.Children.Add(BuildSidebar());

        var body = new Grid { Margin = new Thickness(30, 25, 30, 18) };
        Grid.SetColumn(body, 1);
        body.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        body.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        body.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        body.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var masthead = new Grid { Margin = new Thickness(0, 0, 0, 20) };
        masthead.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        masthead.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        var headline = Theme.Stack(Theme.Eyebrow("AVENTURA  /  7 DAYS TO DIE  /  CONTROL CENTER"), pageTitle, pageSubtitle);
        masthead.Children.Add(headline);
        var headerActions = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        topStatus.Margin = new Thickness(0);
        var statusPill = new Border
        {
            Background = Theme.Raised, BorderBrush = Theme.Line, BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(12), Padding = new Thickness(14, 12, 14, 12),
            Child = topStatus, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 12, 0)
        };
        headerActions.Children.Add(statusPill);
        var menuButton = Theme.Button("INSER  ·  MENU EN JEU", ShowMenu, true);
        menuButton.Margin = new Thickness(0); menuButton.MinHeight = 44;
        headerActions.Children.Add(menuButton);
        Grid.SetColumn(headerActions, 1);
        masthead.Children.Add(headerActions);
        Grid.SetRow(masthead, 0); body.Children.Add(masthead);

        var banner = new Grid();
        banner.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        banner.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        banner.Children.Add(sessionAccent);
        var bannerText = Theme.Stack(statusText, statusMessage);
        bannerText.Margin = new Thickness(15, 0, 0, 0);
        Grid.SetColumn(bannerText, 1); banner.Children.Add(bannerText);
        var stateCard = Theme.Card(banner, new Thickness(17, 13, 17, 13));
        stateCard.Background = Theme.Gradient("#1A293A", "#121C2A");
        stateCard.Margin = new Thickness(0, 0, 0, 18);
        Grid.SetRow(stateCard, 1); body.Children.Add(stateCard);

        pageScroller.Content = pageHost;
        pageScroller.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
        pageScroller.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
        pageScroller.Padding = new Thickness(0, 0, 9, 0);
        Grid.SetRow(pageScroller, 2); body.Children.Add(pageScroller);

        var footer = new Grid
        {
            Margin = new Thickness(0, 11, 0, 0),
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        footer.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        footer.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(0.85, GridUnitType.Star) });
        var errorSlot = new Border { BorderBrush = Theme.Line, BorderThickness = new Thickness(0, 1, 0, 0),
            Padding = new Thickness(1, 8, 12, 0), Child = errorText };
        var shortcutsSlot = new Border { BorderBrush = Theme.Line, BorderThickness = new Thickness(0, 1, 0, 0),
            Padding = new Thickness(8, 8, 0, 0), Child = keyHint };
        Grid.SetColumn(shortcutsSlot, 1);
        footer.Children.Add(errorSlot); footer.Children.Add(shortcutsSlot);
        Grid.SetRow(footer, 3); body.Children.Add(footer);
        root.Children.Add(body); Content = root;

        pages["Tableau de bord"] = BuildDashboard();
        pages["Connexion"] = BuildConnection();
        pages["Affichage"] = BuildDisplay();
        pages["Réglages"] = BuildSettings();
        pages["Diagnostic"] = BuildDiagnostic();
        SelectPage("Tableau de bord");
        Loaded += (_, _) =>
        {
            if (initialized) return;
            initialized = true;
            FitToMonitor();
            try { overlay = new OverlayManager(this, controller); if (!displayMode || controller.Settings.OutputMode == "fuser") overlay.Enable(); }
            catch (Exception e) { controller.Log("Superposition indisponible : " + e.Message); errorText.Text = e.Message; }
            timer.Start(); Refresh();
        };
        ContentRendered += (_, _) =>
        {
            // One startup attempt, after the window is visible. Stop or a manual
            // connection consumes it too, so rendering cannot restart the reader.
            if (closing || startupConsumed) return;
            startupConsumed = true;
            if (!displayMode && controller.Settings.AutoConnectDma) Run(ConnectReader);
        };
        Closed += (_, _) =>
        {
            closing = true; startupConsumed = true;
            controller.StateChanged -= RequestOverlayRefresh;
            controller.SettingsChanged -= RequestOverlayRefresh;
            overlayRefresh.Close();
            overlayRefreshCancellation.Cancel();
            overlayRefreshCancellation.Dispose();
            timer.Stop();
            overlay?.Dispose();
        };
        timer.Tick += (_, _) => Refresh();
        controller.StateChanged += RequestOverlayRefresh;
        controller.SettingsChanged += RequestOverlayRefresh;
    }

    private void FitToMonitor()
    {
        var handle = new System.Windows.Interop.WindowInteropHelper(this).Handle;
        var area = System.Windows.Forms.Screen.FromHandle(handle).WorkingArea;
        double scale = Native.GetDpiForWindow(handle) / 96.0;
        if (scale <= 0) scale = 1;
        double availableWidth = Math.Max(480, area.Width / scale - 24);
        double availableHeight = Math.Max(450, area.Height / scale - 24);
        MinWidth = Math.Min(MinWidth, availableWidth); MinHeight = Math.Min(MinHeight, availableHeight);
        Width = Math.Min(Width, availableWidth); Height = Math.Min(Height, availableHeight);
    }

    private UIElement BuildSidebar()
    {
        var dock = new DockPanel { LastChildFill = true, Background = Theme.Surface };
        var brandMark = new Border
        {
            Width = 47, Height = 47, CornerRadius = new CornerRadius(13),
            Background = Theme.Gradient("#FFBC80", "#E87643"),
            Child = new TextBlock { Text = "7", FontFamily = new FontFamily("Segoe UI"),
                FontSize = 27, FontWeight = FontWeights.Bold, Foreground = Theme.Background,
                HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center },
            Margin = new Thickness(0, 0, 12, 0)
        };
        var brand = new StackPanel();
        var brandTitle = Theme.Text("AVENTURA", 16, Theme.Foreground, true);
        brandTitle.Margin = new Thickness(0, 0, 0, 1);
        var brandSubtitle = Theme.Text("7DTD  /  DMA STUDIO", 10, Theme.Cyan, true);
        brandSubtitle.Margin = new Thickness(0);
        brand.Children.Add(brandTitle); brand.Children.Add(brandSubtitle);
        var brandRow = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        brandRow.Children.Add(brandMark); brandRow.Children.Add(brand);
        var top = new StackPanel { Margin = new Thickness(19, 26, 12, 27) };
        top.Children.Add(brandRow);
        DockPanel.SetDock(top, Dock.Top); dock.Children.Add(top);

        var bottom = new StackPanel { Margin = new Thickness(17, 10, 15, 19) };
        var statusLabel = Theme.Eyebrow("ÉTAT DE LA SESSION");
        statusLabel.Margin = new Thickness(0, 0, 0, 10);
        bottom.Children.Add(statusLabel);
        var indicator = new Border { Background = Theme.Background, BorderBrush = Theme.Line,
            BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(12), Padding = new Thickness(12) };
        sidebarStatus.Margin = new Thickness(0);
        indicator.Child = Theme.Stack(sidebarStatus, Theme.Text("CAPTAINDMA  ·  WIN64", 10, Theme.Muted));
        bottom.Children.Add(indicator);
        var version = Theme.Text("STUDIO UI   /   0.17.0-dev", 10, Theme.Muted);
        version.Margin = new Thickness(2, 15, 0, 0);
        bottom.Children.Add(version);
        DockPanel.SetDock(bottom, Dock.Bottom); dock.Children.Add(bottom);

        var nav = new StackPanel { Margin = new Thickness(12, 0, 12, 0) };
        var navigationTitle = Theme.Eyebrow("NAVIGATION");
        navigationTitle.Margin = new Thickness(12, 0, 0, 12);
        nav.Children.Add(navigationTitle);
        var items = new[]
        {
            ("Tableau de bord", "Vue d’ensemble", "\uE80F"),
            ("Connexion", "DMA & MemProcFS", "\uE839"),
            ("Affichage", "Radar & superposition", "\uE714"),
            ("Réglages", "ESP, PvP & personnage", "\uE713"),
            ("Diagnostic", "Santé & rapports", "\uE9CE")
        };
        foreach (var item in items)
        {
            string key = item.Item1;
            var button = Theme.Button(key, () => SelectPage(key));
            button.Background = Theme.Surface;
            button.BorderBrush = Theme.Surface;
            button.HorizontalContentAlignment = HorizontalAlignment.Stretch;
            button.Padding = new Thickness(10, 9, 12, 9);
            button.Margin = new Thickness(0, 0, 0, 4);
            button.MinHeight = 64;
            var row = new Grid();
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(4) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(35) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var marker = new Border { Width = 3, CornerRadius = new CornerRadius(2), Background = Theme.Cyan,
                Visibility = Visibility.Hidden, HorizontalAlignment = HorizontalAlignment.Center };
            navMarkers[key] = marker;
            row.Children.Add(marker);
            var icon = new TextBlock { Text = item.Item3, FontFamily = new FontFamily("Segoe MDL2 Assets"),
                FontSize = 19, Foreground = Theme.Muted, VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0) };
            navIcons[key] = icon;
            Grid.SetColumn(icon, 1); row.Children.Add(icon);
            var label = Theme.Text(key, 13.5, Theme.Foreground, true);
            label.Margin = new Thickness(0, 0, 0, 4);
            var subtitle = Theme.Text(item.Item2, 10.5, Theme.Muted);
            subtitle.Margin = new Thickness(0);
            var text = Theme.Stack(label, subtitle);
            text.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(text, 2); row.Children.Add(text);
            button.Content = row;
            nav.Children.Add(button); navButtons[key] = button;
        }
        nav.Children.Add(new Border { Height = 1, Background = Theme.Line, Margin = new Thickness(9, 19, 9, 19) });
        var commands = Theme.Eyebrow("ACTIONS RAPIDES");
        commands.Margin = new Thickness(12, 0, 0, 12);
        nav.Children.Add(commands);
        var menu = Theme.Button("Ouvrir le menu  ·  INSER", ShowMenu, true);
        menu.Margin = new Thickness(0, 0, 0, 9);
        nav.Children.Add(menu);
        var toggle = Theme.Button("Activer l’ESP", () => { overlay?.Enable(); controller.ToggleEsp(); Refresh(); });
        toggle.Margin = new Thickness(0, 0, 0, 9);
        refreshActions.Add(() => toggle.Content = controller.Settings.EspEnabled ? "Désactiver l’ESP" : "Activer l’ESP");
        nav.Children.Add(toggle);
        var hide = Theme.Button("Masquer la superposition", () =>
        {
            if (controller.Settings.OutputMode == "fuser") overlay?.ReturnToOverlay();
            else overlay?.Disable();
            Refresh();
        });
        hide.Margin = new Thickness(0, 0, 0, 9);
        hide.FontSize = 11.2;
        refreshActions.Add(() => hide.Content = controller.Settings.OutputMode == "fuser" ? "Arrêter la sortie fuser" : "Masquer la superposition");
        nav.Children.Add(hide);
        dock.Children.Add(new ScrollViewer { Content = nav, VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled });
        return new Border { Child = dock, BorderBrush = Theme.Line, BorderThickness = new Thickness(0, 0, 1, 0) };
    }

    private UIElement BuildDashboard()
    {
        var stack = new StackPanel();
        var hero = new Grid();
        hero.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.8, GridUnitType.Star) });
        hero.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        var left = Theme.Stack(
            Theme.Eyebrow("POSTE DE CONTRÔLE  /  SYSTÈME DMA"),
            Theme.Text("Ton univers. Un seul tableau de bord.", 26, Theme.Foreground, true),
            Theme.Text("Retrouve l’état du jeu, la liaison CaptainDMA, le radar et les raccourcis essentiels sans chercher dans les menus.", 13, Theme.Muted));
        var heroActions = new WrapPanel { Margin = new Thickness(0, 16, 0, 0) };
        if (displayMode)
            heroActions.Children.Add(Theme.Button("Configurer l’affichage", () => SelectPage("Réglages"), true));
        else
            heroActions.Children.Add(WorkButton("Connecter / reconnecter", ConnectReader, true));
        heroActions.Children.Add(Theme.Button("Ouvrir le menu", ShowMenu));
        left.Children.Add(heroActions);
        hero.Children.Add(left);
        var heroMode = Theme.Eyebrow("MODE ACTUEL");
        heroMode.Margin = new Thickness(0, 0, 0, 13);
        var currentMode = Theme.Text(displayMode ? "AFFICHAGE DISTANT" : "DMA DIRECTE", 19, Theme.Cyan, true);
        ConfigureFixedLine(currentMode, 28);
        var heroTip = Theme.Text("Configuration pilotée depuis le PC qui exécute le loader.", 11, Theme.Muted);
        var modeCard = Theme.Stack(heroMode, currentMode, heroTip);
        modeCard.Margin = new Thickness(20, 10, 0, 0);
        Grid.SetColumn(modeCard, 1); hero.Children.Add(modeCard);
        var heroBorder = new Border { Child = hero, CornerRadius = new CornerRadius(18),
            BorderBrush = Theme.Line, BorderThickness = new Thickness(1),
            Background = Theme.Gradient("#20384B", "#122335"),
            Padding = new Thickness(27, 23, 27, 19), Margin = new Thickness(0, 0, 0, 16) };
        stack.Children.Add(heroBorder);

        TextBlock MakeMetric(Grid host, int column, string name, string initial, string caption, bool last = false)
        {
            var head = Theme.Eyebrow(name); head.Margin = new Thickness(0, 0, 0, 9);
            var value = Theme.Text(initial, 22, Theme.Foreground, true);
            ConfigureFixedLine(value, 33);
            var sub = Theme.Text(caption, 10.5, Theme.Muted);
            sub.Margin = new Thickness(0); sub.TextWrapping = TextWrapping.NoWrap;
            sub.TextTrimming = TextTrimming.CharacterEllipsis;
            var card = Theme.Card(Theme.Stack(head, value, sub), new Thickness(18, 17, 18, 16));
            card.Margin = new Thickness(0, 0, last ? 0 : 11, 0);
            Grid.SetColumn(card, column); host.Children.Add(card);
            return value;
        }
        var kpis = new Grid { Margin = new Thickness(0, 0, 0, 16) };
        for (int i = 0; i < 3; i++) kpis.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        var dmaValue = MakeMetric(kpis, 0, "CAPTAINDMA  /  USB-C", "En attente", "Lecteur mémoire", false);
        var gameValue = MakeMetric(kpis, 1, "SESSION DU JEU", "Non détectée", "Processus 7DaysToDie", false);
        var outputValue = MakeMetric(kpis, 2, "SORTIE VIDÉO", "Superposition", "Overlay / fuser", true);
        stack.Children.Add(kpis);

        var workspace = new Grid();
        workspace.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.2, GridUnitType.Star) });
        workspace.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(0.8, GridUnitType.Star) });
        workspace.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        workspace.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        var previewRadar = new RadarControl(controller) { Height = 260, MinWidth = 180, Margin = new Thickness(0, 7, 0, 12) };
        var radarCounts = Theme.Text("En attente d’une capture…", 12, Theme.Muted);
        ConfigureFixedLine(radarCounts, 22);
        var radarContent = Theme.Stack(
            Theme.Eyebrow("SURVEILLANCE EN DIRECT"),
            Theme.Text("Radar de proximité", 19, Theme.Foreground, true),
            Theme.Text("Entités présentes dans les données reçues du client.", 11, Theme.Muted),
            previewRadar, radarCounts,
            Theme.Button("Ouvrir le radar et les réglages", () => SelectPage("Affichage")));
        var radarCard = Theme.Card(radarContent);
        radarCard.Margin = new Thickness(0, 0, 13, 15);
        workspace.Children.Add(radarCard);

        var modules = new StackPanel();
        modules.Children.Add(Theme.Eyebrow("ACCÈS RAPIDE AUX MODULES"));
        modules.Children.Add(Theme.Text("Modules du loader", 19, Theme.Foreground, true));
        void ModuleLink(string title, string sub, string destination, string? settingsCategory = null)
        {
            var button = Theme.Button(title, () =>
            {
                if (settingsCategory != null) OpenSettingsCategory(settingsCategory);
                else SelectPage(destination);
            });
            button.Margin = new Thickness(0, 0, 0, 10);
            button.Padding = new Thickness(14, 12, 14, 12);
            button.HorizontalContentAlignment = HorizontalAlignment.Stretch;
            var row = new Grid();
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var head = Theme.Text(title, 12.5, Theme.Foreground, true); head.Margin = new Thickness(0, 0, 0, 3);
            var detail = Theme.Text(sub, 10.5, Theme.Muted); detail.Margin = new Thickness(0);
            row.Children.Add(Theme.Stack(head, detail));
            var arrow = Theme.Text("→", 19, Theme.Cyan, true); arrow.Margin = new Thickness(10, 0, 0, 0);
            arrow.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(arrow, 1); row.Children.Add(arrow);
            button.Content = row;
            modules.Children.Add(button);
        }
        ModuleLink("ESP & radar", "Superposition, fuser et profils", "Affichage");
        ModuleLink("Surveillance & PvP", "Joueurs, admin-watch, zombies", "Réglages", "Surveillance");
        ModuleLink("Personnage & Stats DMA", "Partie et réglages expérimentaux", "Réglages", "Partie");
        ModuleLink("Diagnostics", "Connexion, journaux et lecture", "Diagnostic");
        var moduleCard = Theme.Card(modules);
        Grid.SetColumn(moduleCard, 1); workspace.Children.Add(moduleCard);
        stack.Children.Add(workspace);

        var recentLog = new TextBox { IsReadOnly = true, AcceptsReturn = true, TextWrapping = TextWrapping.NoWrap,
            FontFamily = new FontFamily("Consolas"), FontSize = 11.5, Height = 126, BorderThickness = new Thickness(0),
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled };
        var logHeader = new DockPanel();
        var openLogs = Theme.Button("Voir tous les journaux", () => SelectPage("Diagnostic"));
        openLogs.Margin = new Thickness(0); DockPanel.SetDock(openLogs, Dock.Right);
        logHeader.Children.Add(openLogs);
        logHeader.Children.Add(Theme.Stack(Theme.Eyebrow("ACTIVITÉ"), Theme.Text("Derniers événements", 19, Theme.Foreground, true)));
        stack.Children.Add(Theme.Card(Theme.Stack(logHeader, recentLog)));
        long lastDashboardLogTick = long.MinValue;
        refreshActions.Add(() =>
        {
            var state = controller.Status;
            dmaValue.Text = state.HasDmaSession ? "Connectée" : state.IsBusy ? "Connexion…" : "Hors ligne";
            dmaValue.Foreground = state.HasDmaSession ? Theme.Success : Theme.Orange;
            gameValue.Text = state.ProcessId != 0 ? "PID " + state.ProcessId : "En attente";
            gameValue.Foreground = state.ProcessId != 0 ? Theme.Cyan : Theme.Foreground;
            outputValue.Text = controller.Settings.OutputMode == "fuser" ? "Fuser actif" : "Superposition";
            radarCounts.Text = controller.CurrentFrame is { IsFresh: true } sample
                ? sample.Snapshot.PlayersCount + " joueur(s)  ·  " + sample.Snapshot.ZombiesCount + " zombie(s)  ·  " +
                  Math.Round(sample.AgeMs) + " ms"
                : "Pas de données récentes. Le radar n’invente aucune position.";
            if (currentPage != "Tableau de bord") return;
            previewRadar.InvalidateVisual();
            long now = Environment.TickCount64;
            if (lastDashboardLogTick != long.MinValue && now - lastDashboardLogTick < 750) return;
            lastDashboardLogTick = now;
            if (IsReading(recentLog)) return;
            string[] lines = controller.LogLines.TakeLast(6).ToArray();
            SetReadOnlyText(recentLog, lines.Length == 0 ? "Le journal est vide." : string.Join(Environment.NewLine, lines), followTail: true);
        });
        return stack;
    }

    private UIElement BuildConnection()
    {
        if (displayMode) return BuildRemoteConnection();
        var stack = new StackPanel();
        var dma = Theme.Text("En attente", 19, Theme.Orange, true);
        var game = Theme.Text("Non détecté", 17, null, true);
        var version = Theme.Text("", 12, Theme.Muted);
        ConfigureFixedLine(dma, 29); ConfigureFixedLine(game, 29); ConfigureFixedLine(version, 20);
        var summary = new Grid { Margin = new Thickness(0, 14, 0, 12) };
        summary.ColumnDefinitions.Add(new ColumnDefinition());
        summary.ColumnDefinitions.Add(new ColumnDefinition());
        var dmaColumn = Theme.Inset(Theme.Stack(Theme.Eyebrow("CAPTAINDMA · USB-C"), dma, Theme.Text("Connexion directe", 11, Theme.Muted)));
        dmaColumn.Margin = new Thickness(0, 0, 12, 0);
        summary.Children.Add(dmaColumn);
        var gameColumn = Theme.Inset(Theme.Stack(Theme.Eyebrow("JEU CIBLE"), game, version));
        Grid.SetColumn(gameColumn, 1); summary.Children.Add(gameColumn);
        var buttons = new WrapPanel();
        buttons.Children.Add(WorkButton("Reconnecter", ConnectReader, true));
        buttons.Children.Add(Theme.Button("Arrêter", StopConnection));
        var automatic = Theme.Text("", 12, Theme.Muted);
        stack.Children.Add(Theme.Card(Theme.Stack(
            Theme.Eyebrow("LECTEUR LOCAL"),
            Theme.Text("Connexion DMA", 24, null, true),
            Theme.Text("Le loader se connecte à la carte, détecte le jeu et attend le chargement de ta partie.", 13, Theme.Muted),
            summary, buttons, automatic)));
        stack.Children.Add(BuildFuserOutput());
        stack.Children.Add(BuildSdkSettings());
        var shortcuts = Theme.Text("", 13, Theme.Foreground, true);
        ConfigureFixedLine(shortcuts, 24);
        stack.Children.Add(Theme.Card(Theme.Stack(
            Theme.Eyebrow("ACCÈS RAPIDE"), Theme.Text("Configure l’affichage pendant la partie", 18, null, true), shortcuts,
            Theme.Text("Le menu propose un profil Joueurs et un profil Zombies. Les raccourcis s’utilisent sur le clavier du PC qui exécute le loader.", 12, Theme.Muted),
            Theme.Button("Ouvrir le menu en jeu", ShowMenu))));
        refreshActions.Add(() =>
        {
            var state = controller.Status;
            dma.Text = state.HasDmaSession ? "Connectée" : state.IsBusy ? "Connexion en cours…" : "Déconnectée";
            dma.Foreground = state.HasDmaSession ? Theme.Cyan : Theme.Orange;
            game.Text = state.ProcessId > 0 ? "Détecté · PID " + state.ProcessId : state.HasDmaSession ? "En attente du jeu…" : "En attente de la DMA";
            version.Text = state.ProcessId > 0 ? state.GameVersion : "";
            shortcuts.Text = OverlayManager.DisplayKey(controller.Settings.MenuKey) + "  ·  Menu     /     " +
                OverlayManager.DisplayKey(controller.Settings.ToggleKey) + "  ·  Afficher / masquer";
            automatic.Text = controller.Settings.AutoConnectDma
                ? "Connexion automatique activée à l’ouverture. Arrêter suspend la session jusqu’à Reconnecter ou la prochaine ouverture."
                : "Connexion automatique désactivée dans Réglages. Clique sur Reconnecter pour démarrer.";
        });
        return stack;
    }

    private UIElement BuildFuserOutput()
    {
        var output = new FuserOutputControls(controller, ActivateFuserOutput);
        refreshActions.Add(output.Refresh);
        return Theme.Card(output);
    }

    private void ActivateFuserOutput()
    {
        if (overlay == null) return;
        overlay.Enable();
        // An explicit activation opens the interactive controls once above the
        // opaque output, including when the chosen output is this same monitor.
        overlay.ShowMenu();
        Refresh();
    }

    private UIElement BuildSdkSettings()
    {
        var sdkText = new TextBox { Text = controller.Settings.SdkDirectory, MinWidth = 180 };
        sdkInput = sdkText;
        var row = new DockPanel();
        var browse = Theme.Button("Choisir…", () =>
        {
            var dialog = new Microsoft.Win32.OpenFolderDialog
            {
                Title = "Dossier MemProcFS x64 contenant vmm.dll et leechcore.dll",
                InitialDirectory = sdkPresent ? sdkText.Text : Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
            };
            if (dialog.ShowDialog(this) == true)
            {
                sdkText.Text = dialog.FolderName;
                controller.Settings.SdkDirectory = dialog.FolderName;
                checkedSdk = "";
                SaveSettings();
            }
        });
        browse.Margin = new Thickness(10, 0, 0, 0); DockPanel.SetDock(browse, Dock.Right);
        row.Children.Add(browse); row.Children.Add(sdkText);
        sdkText.LostKeyboardFocus += (_, _) =>
        {
            if (sdkText.IsEnabled && sdkText.Text.Trim() != controller.Settings.SdkDirectory)
            {
                controller.Settings.SdkDirectory = sdkText.Text.Trim();
                SaveSettings();
            }
        };
        var state = Theme.Text("", 12, Theme.Muted); state.Margin = new Thickness(0, 10, 0, 8);
        var expander = new Expander
        {
            Header = "Dossier MemProcFS", IsExpanded = false, Foreground = Theme.Foreground,
            Content = Theme.Stack(Theme.Label("Chemin enregistré"), row, state,
                Theme.Text("Si le dossier est absent, sélectionne-le une fois puis clique sur Reconnecter.", 12, Theme.Muted))
        };
        refreshActions.Add(() =>
        {
            bool locked = controller.Status.HasDmaSession || controller.Status.IsBusy || actionRunning;
            sdkText.IsEnabled = browse.IsEnabled = !locked;
            if (!sdkText.IsKeyboardFocusWithin && sdkText.Text != controller.Settings.SdkDirectory)
                sdkText.Text = controller.Settings.SdkDirectory;
            CheckSdk(sdkText.Text);
            bool checkedCurrent = !checkingSdk && checkedSdk == sdkText.Text;
            state.Text = !checkedCurrent ? "Vérification des fichiers…" : sdkPresent
                ? "MemProcFS trouvé : vmm.dll et leechcore.dll."
                : "Dossier introuvable ou incomplet : sélectionne le dossier MemProcFS x64.";
            state.Foreground = checkedCurrent && !sdkPresent ? Theme.Orange : Theme.Muted;
            if (checkedCurrent && !sdkPresent && !locked) expander.IsExpanded = true;
        });
        return Theme.Card(expander);
    }

    private Task ConnectReader()
    {
        startupConsumed = true;
        if (sdkInput != null) controller.Settings.SdkDirectory = sdkInput.Text.Trim();
        overlay?.Enable();
        return controller.ConnectReaderAsync();
    }

    private UIElement BuildRemoteConnection()
    {
        var incoming = new TextBox { AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, MinHeight = 90, MaxHeight = 160, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        var buttons = new WrapPanel();
        buttons.Children.Add(WorkButton("Connecter l’affichage", async () =>
        {
            await controller.ConnectDisplayAsync(incoming.Text.Trim());
            incoming.Clear(); overlay?.Enable();
        }, true));
        buttons.Children.Add(Theme.Button("Déconnecter", StopConnection));
        buttons.Children.Add(Theme.Button("Ouvrir le menu", ShowMenu));
        return Theme.Card(Theme.Stack(
            Theme.Text("Affichage distant · mode avancé", 22, null, true),
            Theme.Text("Colle le code créé dans les réglages avancés du PC lecteur. Ce mode ne démarre pas de connexion DMA locale.", 13, Theme.Muted),
            Theme.Label("Code de liaison"), incoming, new Border { Height = 14 }, buttons,
            Theme.Text("Le menu et le radar apparaissent sur ce PC. Pour les superposer au jeu, utilise une fenêtre ou le plein écran sans bordure.", 12, Theme.Muted)));
    }

    private UIElement BuildSharingSettings()
    {
        var addresses = NetworkAddresses.GetLocalAddresses();
        var address = new ComboBox { ItemsSource = addresses, MinWidth = 200, Margin = new Thickness(0, 0, 12, 0) };
        address.SelectedItem = addresses.Contains(controller.Settings.ShareAddress) ? controller.Settings.ShareAddress : addresses.FirstOrDefault();
        var code = new TextBox { IsReadOnly = true, AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, MinHeight = 70, MaxHeight = 120, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        var shareState = Theme.Text("Partage arrêté", 12, Theme.Muted);
        var buttons = new WrapPanel();
        buttons.Children.Add(Theme.Button("Actualiser les adresses", () =>
        {
            try
            {
                addresses = NetworkAddresses.GetLocalAddresses(); address.ItemsSource = addresses;
                address.SelectedItem = addresses.Contains(controller.Settings.ShareAddress) ? controller.Settings.ShareAddress : addresses.FirstOrDefault();
            }
            catch (Exception e) { ShowError("Adresses réseau indisponibles : " + e.Message); }
        }));
        buttons.Children.Add(WorkButton("Créer le code de liaison", async () =>
        {
            if (address.SelectedItem is not string ip) throw new InvalidOperationException("Aucune adresse réseau locale disponible.");
            controller.Settings.ShareAddress = ip; SaveSettings();
            code.Text = await controller.StartSharingAsync(ip);
        }));
        buttons.Children.Add(Theme.Button("Copier le code", () => { if (!string.IsNullOrWhiteSpace(code.Text)) CopyText(code.Text); }));
        buttons.Children.Add(Theme.Button("Arrêter le partage", () => Run(async () => { await controller.StopSharingAsync(); code.Clear(); })));
        refreshActions.Add(() =>
        {
            shareState.Text = controller.Status.IsSharing ? (controller.Status.HasDisplayClient ? "Affichage distant connecté" : "Partage ouvert · en attente de l’affichage") : "Partage arrêté";
            if (!controller.Status.IsSharing && !actionRunning) code.Clear();
            address.IsEnabled = !controller.Status.IsSharing && !actionRunning;
        });
        return Theme.Stack(
            Theme.Text("Pour afficher sur un autre PC, ouvre Ouvrir-affichage.cmd sur celui-ci et saisis le code de cette liaison.", 12, Theme.Muted),
            Theme.Label("Adresse locale du PC lecteur"), address, shareState, buttons, code,
            Theme.Text("Le partage reste arrêté tant que tu ne le démarres pas. Le code de session n’est pas enregistré dans les réglages ou le journal.", 11, Theme.Muted));
    }

    private UIElement BuildDisplay()
    {
        var grid = new Grid();
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(0.9, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.1, GridUnitType.Star) });
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        var radar = new RadarControl(controller) { Height = 320, MinWidth = 180, Margin = new Thickness(0, 8, 0, 12) };
        var counts = Theme.Text("", 13, Theme.Muted);
        counts.Height = 43; counts.TextWrapping = TextWrapping.NoWrap; counts.TextTrimming = TextTrimming.CharacterEllipsis;
        var left = Theme.Stack(Theme.Eyebrow("POSITIONS REÇUES"), Theme.Text("Radar en direct", 20, null, true),
            Theme.Text("Vue du dessus · +Z vers le haut · position locale au centre", 11, Theme.Muted), radar, counts);
        var controls = new WrapPanel();
        controls.Children.Add(Theme.Button("Afficher la superposition", () => { overlay?.Enable(); controller.Settings.EspEnabled = true; SaveSettings(); }, true));
        controls.Children.Add(Theme.Button("Menu en jeu", ShowMenu));
        left.Children.Add(controls);
        left.Children.Add(Theme.Text("Les points s’effacent dès que les données expirent. Ce radar ne représente pas la direction de la caméra.", 12, Theme.Muted));
        var leftCard = Theme.Card(left); leftCard.Margin = new Thickness(0, 0, 14, 14); grid.Children.Add(leftCard);
        var panel = new SettingsPanel(controller, includePlacement: false); settingPanels.Add(panel);
        var rightCard = Theme.Card(panel); Grid.SetColumn(rightCard, 1); grid.Children.Add(rightCard);
        bool? wideLayout = null;
        grid.SizeChanged += (_, _) =>
        {
            bool wide = grid.ActualWidth >= 710;
            if (wideLayout == wide) return;
            wideLayout = wide;
            grid.ColumnDefinitions[0].Width = new GridLength(wide ? 0.9 : 1, GridUnitType.Star);
            grid.ColumnDefinitions[1].Width = wide ? new GridLength(1.1, GridUnitType.Star) : new GridLength(0);
            Grid.SetColumn(rightCard, wide ? 1 : 0);
            Grid.SetRow(rightCard, wide ? 0 : 1);
            leftCard.Margin = new Thickness(0, 0, wide ? 14 : 0, 14);
            radar.Height = wide ? 320 : 280;
        };
        refreshActions.Add(() =>
        {
            radar.InvalidateVisual();
            var frame = controller.CurrentFrame;
            counts.Text = frame?.IsFresh == true
                ? frame.Snapshot.PlayersCount + " joueur(s)  ·  " + frame.Snapshot.ZombiesCount + " zombie(s)\nÂge des données : " + Math.Round(frame.AgeMs) + " ms"
                : "Aucune position récente à afficher.";
        });
        return grid;
    }

    private UIElement BuildSettings()
    {
        var panel = new SettingsPanel(controller, activateFuser: ActivateFuserOutput);
        mainSettingsPanel = panel;
        settingPanels.Add(panel);
        var stack = new StackPanel();
        stack.Children.Add(Theme.Card(panel));
        if (!displayMode)
        {
            var automatic = new CheckBox { Content = "Connecter la DMA à l’ouverture du loader" };
            automatic.Checked += (_, _) => { if (!refreshing) { controller.Settings.AutoConnectDma = true; SaveSettings(); } };
            automatic.Unchecked += (_, _) => { if (!refreshing) { controller.Settings.AutoConnectDma = false; SaveSettings(); } };
            refreshActions.Add(() => automatic.IsChecked = controller.Settings.AutoConnectDma);
            var interval = new ComboBox { ItemsSource = new[] { 50, 75, 100, 150, 250, 500, 1000 }, SelectedItem = controller.Settings.IntervalMs, Margin = new Thickness(0, 0, 0, 8) };
            interval.SelectionChanged += (_, _) => { if (!refreshing && interval.SelectedItem is int value) { controller.Settings.IntervalMs = value; SaveSettings(); } };
            refreshActions.Add(() => interval.IsEnabled = !controller.Status.HasDmaSession && !controller.Status.IsBusy);
            var reader = new Expander
            {
                Header = "Démarrage et fréquence de lecture", Foreground = Theme.Foreground, IsExpanded = false,
                Content = Theme.Stack(automatic,
                    Theme.Text("La connexion automatique s’applique à la prochaine ouverture. Une fois arrêté, le lecteur attend Reconnecter.", 12, Theme.Muted),
                    Theme.Label("Intervalle demandé, en millisecondes"), interval,
                    Theme.Text("Appliqué à la prochaine connexion. Le temps réel dépend du matériel et du nombre d’entités. Les cadres sont retirés lorsqu’une capture caméra atteint 250 ms.", 12, Theme.Muted))
            };
            stack.Children.Add(Theme.Card(reader));
            var sharing = new Expander { Header = "Affichage sur un autre PC · avancé", Foreground = Theme.Foreground, IsExpanded = false };
            sharing.Expanded += (_, _) =>
            {
                if (sharing.Content != null) return;
                try { sharing.Content = BuildSharingSettings(); }
                catch (Exception e) { sharing.Content = Theme.Text("Partage indisponible : " + e.Message, 12, Theme.Orange); }
            };
            stack.Children.Add(Theme.Card(sharing));
        }
        return stack;
    }

    private UIElement BuildDiagnostic()
    {
        var viewState = new DiagnosticReadoutState();
        var performance = new PerformancePanel(controller);
        var facts = new Grid { Margin = new Thickness(0, 4, 0, 12) };
        facts.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(190) });
        facts.ColumnDefinitions.Add(new ColumnDefinition());
        TextBlock AddFact(string label)
        {
            int row = facts.RowDefinitions.Count;
            facts.RowDefinitions.Add(new RowDefinition { Height = new GridLength(26) });
            var title = Theme.Text(label, 12, Theme.Muted);
            var value = Theme.Text("—", 13);
            ConfigureFixedLine(title, 24); ConfigureFixedLine(value, 24);
            Grid.SetRow(title, row); Grid.SetRow(value, row); Grid.SetColumn(value, 1);
            AttachReadoutTip(value, () => value.Text);
            facts.Children.Add(title); facts.Children.Add(value);
            return value;
        }
        var session = AddFact("Session DMA");
        var versions = AddFact("Jeu / MemProcFS");
        var process = AddFact("Processus du jeu");
        var output = AddFact("Sortie actuelle");
        var source = AddFact("Source · dernier relevé");
        var resolution = AddFact("Correspondance");
        var acquisition = AddFact("Caméra au relevé");
        var projection = AddFact("Affichage ESP");
        var report = AddFact("Rapport de connexion");

        var stamp = Theme.Text("Aucun relevé affiché.", 11, Theme.Muted);
        ConfigureFixedLine(stamp, 21);
        var details = new TextBox
        {
            IsReadOnly = true, AcceptsReturn = true, FontSize = 12, Height = 126,
            TextWrapping = TextWrapping.Wrap,
            VerticalScrollBarVisibility = ScrollBarVisibility.Visible,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            Margin = new Thickness(0, 0, 0, 12)
        };
        var path = new TextBox { IsReadOnly = true, Text = controller.ReportDirectory, Margin = new Thickness(0, 0, 0, 12) };
        var log = new TextBox
        {
            IsReadOnly = true, AcceptsReturn = true, FontFamily = new FontFamily("Consolas"), FontSize = 12,
            Height = 330, HorizontalScrollBarVisibility = ScrollBarVisibility.Visible,
            VerticalScrollBarVisibility = ScrollBarVisibility.Visible, TextWrapping = TextWrapping.NoWrap
        };
        var frozen = new CheckBox { Content = "Figer le diagnostic", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 18, 8) };
        string capturedText = "Aucun relevé affiché.";

        void RefreshDiagnostic(bool force = false)
        {
            if (force) overlay?.Refresh();
            var state = controller.Status;
            var sample = controller.CurrentFrame;
            bool validCamera = sample != null && sample.TryGetProjectionView(out _, out _);
            var camera = validCamera ? sample!.Snapshot.Camera : null;
            // Observe every acquisition tick, even when the UI is paused. This
            // is a last-known dimension, never a replacement for a fresh camera.
            viewState.ObserveSource(state.ReportPath ?? "", state.ProcessId, camera?.SourceWidth, camera?.SourceHeight);
            if (currentPage != "Diagnostic" && !force) return;
            bool reading = IsReading(details) || IsReading(log);
            if (!viewState.ShouldPublish(Environment.TickCount64, frozen.IsChecked == true, reading, force)) return;
            // The page already owns pause and the one-second cadence. Capture
            // metrics in this same readout, without a second competing timer.
            performance.Refresh(force: true);

            var settings = controller.Settings;
            var screens = System.Windows.Forms.Screen.AllScreens;
            var selected = settings.MonitorIndex >= 0 && settings.MonitorIndex < screens.Length ? screens[settings.MonitorIndex] : null;
            string mode = settings.OutputMode == "fuser" ? "Fuser" : "Superposition locale";
            string outputValue = selected == null ? mode + " · écran indisponible" :
                mode + " · " + selected.DeviceName + " · " + selected.Bounds.Width + " × " + selected.Bounds.Height + " px";
            string sourceValue = viewState.HasSource ? viewState.LastSourceWidth + " × " + viewState.LastSourceHeight + " px" : "Pas encore reçue dans cette connexion";
            string resolutionValue = selected == null ? "Sortie indisponible" : "En attente du premier relevé caméra";
            string mappingDetail = "Mode sélectionné : " + ProjectionOutputText.ModeLabel(settings.EspScaleMode) + ".";
            bool mappingInvalid = selected == null;
            if (selected != null && viewState.HasSource)
            {
                // This describes the mapping of the last-known complete source
                // image. Only the live overlay may validate its camera viewport.
                var sourceImage = new ProjectionViewport(0, 0, viewState.LastSourceWidth, viewState.LastSourceHeight);
                if (ProjectionOutputMapping.TryCreate(viewState.LastSourceWidth, viewState.LastSourceHeight,
                    selected.Bounds.Width, selected.Bounds.Height, sourceImage, settings.EspScaleMode,
                    out var mapping, out var reason))
                {
                    resolutionValue = ProjectionOutputText.Summary(mapping!);
                    mappingDetail = ProjectionOutputText.Details(mapping!);
                }
                else
                {
                    mappingInvalid = true;
                    resolutionValue = "Adaptation indisponible : " + reason;
                    mappingDetail = reason;
                }
            }
            bool cameraFresh = sample?.IsProjectionFresh == true;
            string acquisitionValue = sample == null ? "En attente de positions récentes" : cameraFresh ? "Récente lors du relevé" :
                sample.Snapshot.Camera == null ? "Caméra absente de cette capture" : sample.AgeMs >= FeedSample.ProjectionLifetimeMs ? "Capture caméra expirée" : "Données caméra non validées";
            string projectionValue = DiagnosticReadoutState.ProjectionAtReadout(
                overlay?.ProjectionStatus ?? "Initialisation de l’affichage", cameraFresh);
            string reportValue = string.IsNullOrEmpty(state.ReportPath) ? "Aucun pour cette connexion" : Path.GetFileName(state.ReportPath);
            string time = DateTime.Now.ToString("HH:mm:ss");
            var rows = new[]
            {
                ("Session DMA", state.HasDmaSession ? "Ouverte" : "Fermée"),
                ("Jeu / MemProcFS", state.GameVersion + " / " + state.MemProcFsVersion),
                ("Processus du jeu", state.ProcessId == 0 ? "Non trouvé" : state.ProcessId.ToString()),
                ("Sortie actuelle", outputValue), ("Source · dernier relevé", sourceValue),
                ("Correspondance", resolutionValue), ("Caméra au relevé", acquisitionValue),
                ("Affichage ESP", projectionValue), ("Rapport de connexion", reportValue)
            };
            var fields = new[] { session, versions, process, output, source, resolution, acquisition, projection, report };
            for (int i = 0; i < fields.Length; i++)
                if (fields[i].Text != rows[i].Item2) fields[i].Text = rows[i].Item2;
            resolution.Foreground = mappingInvalid ? Theme.Orange : Theme.Foreground;
            stamp.Text = "Relevé affiché à " + time + (frozen.IsChecked == true ? " · figé" : " · actualisation au plus une fois par seconde");
            string detailText = "Lecture : " + state.Message + "\n\nCaméra : " + state.ProjectionMessage +
                "\n\nAffichage ESP : " + projectionValue;
            detailText += "\n\nAdaptation de l’image source : " + mappingDetail;
            detailText += "\n\nLa source est le dernier relevé reçu dans cette connexion ; elle ne confirme pas qu’une caméra est actuellement fraîche.";
            SetReadOnlyText(details, detailText, followTail: false);
            var complete = new StringBuilder("Relevé affiché à " + time + Environment.NewLine);
            foreach (var row in rows) complete.AppendLine(row.Item1 + " : " + row.Item2);
            complete.AppendLine().AppendLine(detailText).AppendLine().Append("Dossier des rapports : ").Append(controller.ReportDirectory);
            complete.AppendLine().AppendLine().Append(performance.SummaryText);
            capturedText = complete.ToString();
            SetReadOnlyText(log, string.Join(Environment.NewLine, controller.LogLines), followTail: true);
        }

        var readingControls = new WrapPanel();
        readingControls.Children.Add(frozen);
        readingControls.Children.Add(Theme.Button("Actualiser", () => RefreshDiagnostic(force: true)));
        readingControls.Children.Add(Theme.Button("Copier l’état affiché", () => CopyText(capturedText)));
        frozen.Checked += (_, _) =>
        {
            // Keep the exact readout already on screen. Only its presentation
            // label changes; DMA, radar, ESP and their expiry continue normally.
            if (!stamp.Text.EndsWith(" · figé", StringComparison.Ordinal))
                stamp.Text = stamp.Text.Split(" · ", StringSplitOptions.None)[0] + " · figé";
        };
        frozen.Unchecked += (_, _) => RefreshDiagnostic(force: true);
        var buttons = new WrapPanel();
        buttons.Children.Add(Theme.Button("Ouvrir les rapports", () => { try { controller.OpenReportDirectory(); } catch (Exception e) { ShowError(e.Message); } }));
        buttons.Children.Add(Theme.Button("Copier le journal affiché", () => CopyText(log.Text)));
        refreshActions.Add(() => RefreshDiagnostic());
        return Theme.Stack(
            Theme.Card(Theme.Stack(Theme.Eyebrow("RELEVÉ DE LA SESSION"), Theme.Text("État de la lecture et de l’affichage", 20, null, true), readingControls, stamp, facts,
                Theme.Label("Détails du relevé"), details, Theme.Label("Dossier des rapports"), path, buttons)),
            Theme.Card(performance),
            Theme.Card(Theme.Stack(Theme.Text("Journal de connexion", 20, null, true), log)));
    }

    private static void ConfigureFixedLine(TextBlock text, double height)
    {
        text.TextWrapping = TextWrapping.NoWrap;
        text.TextTrimming = TextTrimming.CharacterEllipsis;
        text.Height = text.MinHeight = text.MaxHeight = height;
        text.Margin = new Thickness(0);
        text.VerticalAlignment = VerticalAlignment.Center;
    }

    private static void AttachReadoutTip(FrameworkElement target, Func<string> read)
    {
        var text = Theme.Text("", 12);
        text.MaxWidth = 560; text.Margin = new Thickness(0);
        var tip = new ToolTip
        {
            Background = Theme.Raised, Foreground = Theme.Foreground, BorderBrush = Theme.Line,
            BorderThickness = new Thickness(1), Padding = new Thickness(12),
            Content = new ScrollViewer { Content = text, MaxHeight = 260, VerticalScrollBarVisibility = ScrollBarVisibility.Auto }
        };
        target.ToolTip = tip;
        target.ToolTipOpening += (_, _) => text.Text = read();
        ToolTipService.SetShowDuration(target, 20000);
    }

    private static bool IsReading(TextBox text) => text.IsMouseOver || text.IsKeyboardFocusWithin || text.SelectionLength > 0;

    private static void SetReadOnlyText(TextBox text, string value, bool followTail)
    {
        if (text.Text == value) return;
        double vertical = text.VerticalOffset, horizontal = text.HorizontalOffset;
        int selectionStart = text.SelectionStart, selectionLength = text.SelectionLength;
        bool atBottom = followTail && selectionLength == 0 && !text.IsKeyboardFocusWithin &&
            vertical >= text.ExtentHeight - text.ViewportHeight - 5;
        text.Text = value;
        selectionStart = Math.Clamp(selectionStart, 0, value.Length);
        // Normal background updates must not move a caret or ask an ancestor
        // ScrollViewer to bring this field into view. Restore only a real
        // selection, which can be present during an explicit manual refresh.
        if (selectionLength > 0)
            text.Select(selectionStart, Math.Min(selectionLength, value.Length - selectionStart));
        if (atBottom) text.ScrollToEnd();
        else text.ScrollToVerticalOffset(vertical);
        text.ScrollToHorizontalOffset(horizontal);
    }

    private Button WorkButton(string label, Func<Task> action, bool primary = false)
    {
        var button = Theme.Button(label, () => Run(action), primary); workButtons.Add(button); return button;
    }
    private async void Run(Func<Task> action)
    {
        if (closing || actionRunning) return;
        actionRunning = true; errorText.Text = ""; Refresh();
        try { await action(); }
        catch (Exception e) { if (!closing) ShowError(e.Message); }
        finally { actionRunning = false; if (!closing) Refresh(); }
    }
    private async void StopConnection()
    {
        // Unlike start/config actions, this must remain callable while a previous
        // connection attempt is pending. The controller cancels it before locking.
        startupConsumed = true;
        try { await controller.DisconnectAsync(); }
        catch (Exception e) { if (!closing) ShowError(e.Message); }
        if (!closing) Refresh();
    }
    private async void CheckSdk(string path)
    {
        if (checkingSdk || path == checkedSdk) return;
        checkingSdk = true;
        checkedSdk = path;
        try
        {
            sdkPresent = await Task.Run(() => File.Exists(Path.Combine(path, "vmm.dll")) && File.Exists(Path.Combine(path, "leechcore.dll")));
        }
        catch { sdkPresent = false; }
        finally { checkingSdk = false; }
    }
    private void SaveSettings()
    {
        try { controller.SaveSettings(); }
        catch (Exception e) { ShowError("Réglages non enregistrés : " + e.Message); }
    }
    private void CopyText(string value)
    {
        try { Clipboard.SetText(value); }
        catch (Exception e) { ShowError("Copie impossible : " + e.Message); }
    }
    private void ShowError(string error) { errorText.Text = error; controller.Log(error); }
    private void ShowMenu()
    {
        if (overlay == null) return;
        overlay.ToggleMenu();
    }
    private void OpenSettingsCategory(string category)
    {
        SelectPage("Réglages");
        mainSettingsPanel?.SelectCategory(category);
    }

    private void SelectPage(string page)
    {
        if (!pages.TryGetValue(page, out var content)) return;
        bool changedPage = currentPage != page;
        currentPage = page; pageHost.Content = content;
        pageTitle.Text = page switch
        {
            "Tableau de bord" => "Tableau de bord",
            "Réglages" => "Configuration ESP",
            "Affichage" => "Affichage en direct",
            "Diagnostic" => "Diagnostics & rapports",
            _ => "Connexion DMA"
        };
        pageSubtitle.Text = page switch
        {
            "Tableau de bord" => "L’essentiel de ta session, réuni au même endroit.",
            "Connexion" => displayMode ? "Réception des données du PC lecteur." : "CaptainDMA, jeu cible et sortie vers le fuser.",
            "Affichage" => "Radar actualisé, profils et superposition.",
            "Réglages" => "Joueurs, zombies, surveillance, PvP et personnage.",
            _ => "État du lecteur, qualité des captures et historique consultable."
        };
        foreach (var pair in navButtons)
        {
            bool active = pair.Key == page;
            pair.Value.Background = active ? Theme.AccentSoft : Theme.Surface;
            pair.Value.BorderBrush = active ? Theme.Line : Theme.Surface;
            pair.Value.Foreground = active ? Theme.Foreground : Theme.Muted;
            if (navMarkers.TryGetValue(pair.Key, out var marker))
                marker.Visibility = active ? Visibility.Visible : Visibility.Hidden;
            if (navIcons.TryGetValue(pair.Key, out var icon))
                icon.Foreground = active ? Theme.Cyan : Theme.Muted;
        }
        if (changedPage) pageScroller.ScrollToTop();
    }

    private void RequestOverlayRefresh() => overlayRefresh.Request();

    private void RefreshOverlay()
    {
        // A frame notification goes straight to the render dispatcher instead
        // of waiting for the next 100 ms page/status tick. Read the latest
        // controller state here; do not retain a frame in the queued callback.
        if (closing || !initialized) return;
        try { overlay?.Refresh(); }
        catch (Exception e)
        {
            // Avoid logging through StateChanged here: a persistent rendering
            // error would otherwise schedule an unbounded self-refresh loop.
            errorText.Text = "Affichage indisponible : " + e.Message;
        }
    }

    private void Refresh()
    {
        if (closing || refreshing) return;
        refreshing = true;
        try
        {
            // Refresh the display decision before recording a diagnostic, so
            // its status is not knowingly taken from the preceding UI tick.
            // A frozen diagnostic never stops this refresh or the ESP expiry.
            RefreshOverlay();
            var state = controller.Status;
            var frame = controller.CurrentFrame;
            string heading = frame?.IsFresh == true ? "●  POSITIONS EN DIRECT"
                : state.HasDmaSession && state.ProcessId == 0 ? "●  DMA CONNECTÉE · EN ATTENTE DU JEU"
                : state.IsBusy ? "●  " + (state.HasDmaSession ? "DMA CONNECTÉE · ANALYSE DU JEU" : "CONNEXION EN COURS")
                : state.HasDmaSession || state.IsConnected ? "●  CONNECTÉ · EN ATTENTE DE POSITIONS"
                : "●  " + state.Stage.Replace('_', ' ');
            statusText.Text = heading;
            bool ready = frame?.IsFresh == true;
            statusText.Foreground = ready ? Theme.Cyan : Theme.Orange;
            sessionAccent.Background = ready ? Theme.Cyan : Theme.Orange;
            sidebarStatus.Text = ready ? "DONNÉES EN DIRECT" : state.HasDmaSession ? "DMA CONNECTÉE" : state.IsBusy ? "CONNEXION…" : "SESSION INACTIVE";
            sidebarStatus.Foreground = ready || state.HasDmaSession ? Theme.Success : Theme.Orange;
            topStatus.Text = ready ? "●  LIVE" : state.HasDmaSession ? "●  DMA ACTIVE" : state.IsBusy ? "●  CONNEXION" : "●  HORS LIGNE";
            topStatus.Foreground = ready || state.HasDmaSession ? Theme.Success : Theme.Orange;
            // The banner is a short session summary. Per-capture camera errors
            // belong in the bounded diagnostic readout and the full tooltip.
            statusMessage.Text = frame?.IsFresh == true
                ? "Positions DMA reçues. L’état de la caméra et de l’affichage est détaillé dans Diagnostic."
                : state.HasDmaSession && state.ProcessId == 0 ? "La DMA est ouverte ; attente du jeu sur le PC cible."
                : state.HasDmaSession || state.IsConnected ? "Lecture en cours ; attente d’une capture cohérente de la partie."
                : state.IsBusy ? "Connexion ou analyse du jeu en cours…" : state.Message;
            foreach (var refresh in refreshActions) refresh();
            foreach (var panel in settingPanels) if (panel.IsVisible) panel.Refresh();
            foreach (var button in workButtons) button.IsEnabled = !actionRunning && !state.IsBusy;
            keyHint.Text = overlay?.HotkeyStatus ?? "Initialisation de l’affichage…";
        }
        finally { refreshing = false; }
    }
}
