using System;
using System.Text.Json;
using System.Threading.Tasks;
using SevenDaysEsp;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class ReadPolicyHotkeyTests
{
    public static Task OptionalDetailsFollowIndependentViews()
    {
        var settings = new LoaderSettings { EspProfilesVersion = 1 };
        Check(All(LiveReadPolicy.FromSettings(settings, false)), "Default views lost optional details.");
        settings.PlayerEsp.ShowNames = false;
        settings.ZombieEsp.ShowHealth = false;
        var options = LiveReadPolicy.FromSettings(settings, false);
        Check(!options.PlayerNames && options.PlayerHealth && options.ZombieNames && !options.ZombieHealth,
            "One category changed the other's independent detail requirements.");
        settings.PlayerEsp.Enabled = false;
        options = LiveReadPolicy.FromSettings(settings, false);
        Check(!options.PlayerNames && !options.PlayerHealth && options.ZombieNames && !options.ZombieHealth,
            "A disabled profile still requested optional details.");
        settings.ZombieEsp.Enabled = false;
        Check(None(LiveReadPolicy.FromSettings(settings, false)), "Disabling both categories did not stop optional reads.");
        settings.PlayerEsp.Enabled = true;
        settings.PlayerEsp.ShowNames = true;
        options = LiveReadPolicy.FromSettings(settings, false);
        Check(options.PlayerNames && options.PlayerHealth && !options.ZombieNames && !options.ZombieHealth,
            "Reactivating players did not request fresh details independently.");
        return Task.CompletedTask;
    }

    public static Task RadarKeepsNamesButDoesNotRequestHealth()
    {
        var settings = new LoaderSettings { EspProfilesVersion = 1, ShowProjectedEsp = false, ShowRadar = true };
        var options = LiveReadPolicy.FromSettings(settings, false);
        Check(options.PlayerNames && options.ZombieNames && !options.PlayerHealth && !options.ZombieHealth,
            "Radar-only mode either lost names or requested unused health.");
        settings.ShowRadar = false;
        Check(None(LiveReadPolicy.FromSettings(settings, false)), "All hidden views still requested optional details.");
        settings.ShowProjectedEsp = true;
        Check(All(LiveReadPolicy.FromSettings(settings, false)), "Enabling projection did not restore names and health.");
        settings.EspEnabled = false;
        Check(None(LiveReadPolicy.FromSettings(settings, false)), "The disabled master display still requested optional details.");
        settings.EspEnabled = true;
        Check(All(LiveReadPolicy.FromSettings(settings, false)), "Restoring the master display did not request fresh details.");
        return Task.CompletedTask;
    }

    public static Task SharingPreservesRemoteDetailsWithoutChangingLocalPreferences()
    {
        var settings = new LoaderSettings { EspProfilesVersion = 1, EspEnabled = false, ShowProjectedEsp = false, ShowRadar = false };
        settings.PlayerEsp.Enabled = settings.ZombieEsp.Enabled = false;
        settings.PlayerEsp.ShowNames = settings.ZombieEsp.ShowHealth = false;
        string before = JsonSerializer.Serialize(settings);
        Check(All(LiveReadPolicy.FromSettings(settings, true)), "Remote display lost optional data due to hidden reader views.");
        Check(None(LiveReadPolicy.FromSettings(settings, false)), "Stopping sharing did not restore local read requirements.");
        Check(before == JsonSerializer.Serialize(settings), "Read policy changed local display settings.");
        return Task.CompletedTask;
    }

    public static Task ExistingHotkeysWinOverNewOptionalDefaults()
    {
        var legacy = JsonSerializer.Deserialize<LoaderSettings>("{\"MenuKey\":\"F7\",\"ToggleKey\":\"F8\"}")!;
        SettingsStore.Normalize(legacy);
        Check(legacy.MenuKey == "F7" && legacy.ToggleKey == "F8", "New keys overwrote old menu/master shortcuts.");
        Check(legacy.PlayersKey == "" && legacy.ZombiesKey == "" && legacy.RadarKey == "F9",
            "Colliding optional defaults were not individually disabled.");
        var fresh = new LoaderSettings();
        SettingsStore.Normalize(fresh);
        Check(fresh.MenuKey == "Insert" && fresh.ToggleKey == "F6" && fresh.PlayersKey == "F7" &&
            fresh.ZombiesKey == "F8" && fresh.RadarKey == "F9", "Fresh shortcuts are not independent.");
        return Task.CompletedTask;
    }

    public static Task DisabledAndConflictingHotkeysRoundtripSafely()
    {
        var settings = new LoaderSettings { PlayersKey = "F10", ZombiesKey = "F10", RadarKey = "Delete" };
        SettingsStore.Normalize(settings);
        Check(settings.PlayersKey == "F10" && settings.ZombiesKey == "" && settings.RadarKey == "",
            "Duplicate or unsupported optional shortcuts survived normalization.");
        settings.PlayersKey = "";
        settings.ZombiesKey = "F11";
        settings.RadarKey = "Home";
        string stored = JsonSerializer.Serialize(settings);
        var loaded = JsonSerializer.Deserialize<LoaderSettings>(stored)!;
        SettingsStore.Normalize(loaded);
        Check(loaded.PlayersKey == "" && loaded.ZombiesKey == "F11" && loaded.RadarKey == "Home",
            "Disabled or custom optional keys were reset on reload.");
        string normalized = JsonSerializer.Serialize(loaded);
        SettingsStore.Normalize(loaded);
        Check(normalized == JsonSerializer.Serialize(loaded), "Shortcut normalization is not idempotent.");
        return Task.CompletedTask;
    }

    private static bool All(LiveReadOptions options) => options.PlayerNames && options.PlayerHealth && options.ZombieNames && options.ZombieHealth;
    private static bool None(LiveReadOptions options) => !options.PlayerNames && !options.PlayerHealth && !options.ZombieNames && !options.ZombieHealth;
    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
