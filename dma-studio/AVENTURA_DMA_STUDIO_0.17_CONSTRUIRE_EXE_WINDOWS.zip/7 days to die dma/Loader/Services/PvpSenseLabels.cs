using System;
using System.Collections.Generic;
using SevenDaysEsp;

namespace SevenDaysLoader.Services;

// String-only presentation; never invent an item name or an attack state.
public static class PvpSenseLabels
{
    public static bool WantsPlayerLabel(PvpSenseSettings? settings) => settings != null &&
        (settings.ShowMovement || settings.ShowFacing || settings.ShowHeldItemId);

    public static bool WantsZombieLabel(PvpSenseSettings? settings) => settings?.ShowZombieTarget == true;

    public static string ForPlayer(PvpSenseSettings settings, bool? running, bool? crouched,
        bool? jumping, int? itemId, double? angleDegrees)
    {
        var details = new List<string>();
        if (settings.ShowMovement)
        {
            if (crouched == true) details.Add("accroupi");
            if (running == true) details.Add("course");
            if (jumping == true) details.Add("saut");
        }
        if (settings.ShowHeldItemId && itemId is >= 1 and <= 100000)
            details.Add("objet #" + itemId.Value);
        if (settings.ShowFacing && angleDegrees is double angle && double.IsFinite(angle) &&
            angle >= 0 && angle <= settings.FacingConeDegrees)
            details.Add("corps orienté vers toi");
        return string.Join(" · ", details);
    }

    public static string ForZombie(PvpSenseSettings settings, bool? targetLocal) =>
        settings.ShowZombieTarget && targetLocal == true ? "CIBLE : TOI" : string.Empty;

    public static string Append(string baseLabel, string detail)
    {
        if (string.IsNullOrWhiteSpace(detail)) return baseLabel ?? string.Empty;
        if (string.IsNullOrWhiteSpace(baseLabel)) return detail;
        return baseLabel + " · " + detail;
    }
}
