﻿#requires -Version 5.1
# Scene explicite de test : aucune connexion DMA, aucun acces au jeu.
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$resultCode = 0
try {
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'Windows est requis.' }
    [Console]::WriteLine('[SIMULATION] Test de rendu uniquement : tous les reperes sont synthetiques. Aucune connexion DMA.')
    $sources = @('EspRenderer.cs', 'EspMath.cs') | ForEach-Object { Join-Path $PSScriptRoot $_ }
    Add-Type -Path $sources -ReferencedAssemblies 'System.dll', 'System.Core.dll', 'System.Windows.Forms.dll', 'System.Drawing.dll'
    [SevenDaysEsp.EspWindow]::Start()
    $watch = [Diagnostics.Stopwatch]::StartNew()
    $lastPhase = -1
    while ([SevenDaysEsp.EspWindow]::IsOpen) {
        $time = $watch.Elapsed.TotalSeconds
        $phase = [int]([Math]::Floor($time) % 12)
        # Two seconds without publishing deliberately exercise stale-data clearing.
        if ($phase -ge 10) {
            if ($lastPhase -lt 10) { [Console]::WriteLine('[SIMULATION] Pause des donnees : les cadres doivent disparaitre apres 500 ms.') }
            $lastPhase = $phase
            Start-Sleep -Milliseconds 33
            continue
        }
        $lastPhase = $phase
        $snapshot = [SevenDaysEsp.WorldSnapshot]::new()
        $snapshot.CapturedUtc = [DateTime]::UtcNow
        $snapshot.SourceWidth = 1920
        $snapshot.SourceHeight = 1080
        $snapshot.Status = 'SIMULATION - AUCUNE LECTURE DMA - reperes synthetiques'
        $snapshot.LocalPosition = [SevenDaysEsp.WorldPoint]::new(0, 0, 0)
        $snapshot.FloatingOrigin = [SevenDaysEsp.WorldPoint]::new(0, 0, 0)
        # Synthetic perspective: clipW=z. This is not a game camera profile.
        $snapshot.ViewProjection = [single[]]@(0.5625,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,1,0)
        $player = [SevenDaysEsp.WorldEntity]::new()
        $player.Kind = 'player'; $player.Name = 'Joueur SIMULE'; $player.IsAlive = $true
        $x = [single](-2 + [Math]::Sin($time * 0.7))
        $player.Feet = [SevenDaysEsp.WorldPoint]::new($x, -1, 10)
        $player.Head = [SevenDaysEsp.WorldPoint]::new($x, 0.8, 10)
        $snapshot.Entities.Add($player)
        $zombie = [SevenDaysEsp.WorldEntity]::new()
        $zombie.Kind = 'zombie'; $zombie.Name = 'Zombie SIMULE'; $zombie.IsAlive = $true
        $x = [single](2 + [Math]::Cos($time * 0.5))
        $zombie.Feet = [SevenDaysEsp.WorldPoint]::new($x, -1, 7)
        $zombie.Head = [SevenDaysEsp.WorldPoint]::new($x, 0.65, 7)
        $snapshot.Entities.Add($zombie)
        [SevenDaysEsp.EspWindow]::Publish([SevenDaysEsp.EspProjection]::BuildFrame($snapshot)) | Out-Null
        Start-Sleep -Milliseconds 33
    }
    [Console]::WriteLine('[SIMULATION_TERMINEE] Fermee. Aucun etat materiel ou jeu n''a ete teste.')
} catch {
    [Console]::Error.WriteLine(('[ERREUR_AFFICHAGE] ' + $_.Exception.GetBaseException().Message))
    $resultCode = 6
} finally {
    if ('SevenDaysEsp.EspWindow' -as [type]) { [SevenDaysEsp.EspWindow]::Stop() }
}
exit $resultCode
