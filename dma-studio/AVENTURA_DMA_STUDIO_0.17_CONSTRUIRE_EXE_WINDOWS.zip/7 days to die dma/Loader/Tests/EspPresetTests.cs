using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class EspPresetTests
{
    public static Task CapturesAndApplicationsOwnTheirProfilesAndPreserveTheEnvironment()
    {
        var source = Settings();
        source.EspEnabled = false;
        source.ShowProjectedEsp = false;
        source.ShowRadar = false;
        source.ShowHud = false;
        source.RadarSize = 410;
        source.RadarOpacity = 0.51;
        source.PlayerEsp = new EntityEspSettings { MaxDistance = 875, Color = "#1234AB", BoxStyle = "corners", ShowHealth = false, FontSize = 17, LineThickness = 2.3 };
        source.ZombieEsp = new EntityEspSettings { Enabled = false, MaxDistance = 65, Color = "#BC8123", ShowNames = false, ShowDistances = false, ShowTracers = true, FontSize = 11, LineThickness = 3.1 };
        var captured = EspPresetOptions.Capture(source);
        string expected = JsonSerializer.Serialize(captured);
        source.PlayerEsp.Color = "#FFFFFF";
        source.ZombieEsp.MaxDistance = 5000;
        source.RadarSize = 520;
        Check(JsonSerializer.Serialize(captured) == expected, "Capturing preferences retained mutable ownership of a live profile.");

        var target = Settings();
        target.Mode = "display";
        target.AutoConnectDma = false;
        target.SdkDirectory = @"D:\private\sdk";
        target.Device = "custom-device";
        target.IntervalMs = 250;
        target.ReadCadenceVersion = 9;
        target.OutputMode = "fuser";
        target.FuserDeviceName = "DISPLAY-KEEP";
        target.FuserKeyColor = "#00FF00";
        target.FuserTestPattern = true;
        target.MonitorIndex = 3;
        target.EspScaleMode = "stretch";
        target.OverlayAnchor = "BottomLeft";
        target.ShareAddress = "192.0.2.10";
        target.SharePort = 31234;
        target.MenuKey = "Home";
        target.ToggleKey = "F10";
        target.PlayersKey = "";
        target.ZombiesKey = "F11";
        target.RadarKey = "F6";
        target.ShowPlayers = false;
        target.ShowNames = false;
        target.PlayerColor = "#ABCDEF";
        string environment = ProtectedState(target);
        captured.ApplyTo(target);
        Check(ProtectedState(target) == environment, "Applying a display preset changed a connection, calibration, output, hotkey or legacy preference.");
        Check(JsonSerializer.Serialize(EspPresetOptions.Capture(target)) == expected, "The preset did not apply all of its display options.");
        Check(target.EspProfilesVersion == 1, "Applying a profile allowed the legacy migration to overwrite it later.");
        target.PlayerEsp.MaxDistance = 25;
        target.ZombieEsp.Color = "#000000";
        Check(JsonSerializer.Serialize(captured) == expected, "The applied settings still alias the stored preset.");
        var sharedProfile = new EntityEspSettings();
        var shared = new EspPresetOptions { PlayerEsp = sharedProfile, ZombieEsp = sharedProfile };
        var independent = shared.Copy();
        independent.PlayerEsp.FontSize = 20;
        Check(independent.ZombieEsp.FontSize == 12 && sharedProfile.FontSize == 12, "Copy did not separate aliased player and zombie profiles.");
        return Task.CompletedTask;
    }

    public static Task InvalidOptionsNeverPartiallyApplyOrReplaceAnEntry()
    {
        using var fixture = new Fixture();
        var target = Settings();
        target.OutputMode = "fuser";
        string before = JsonSerializer.Serialize(target);
        var invalid = EspPresetOptions.Capture(target);
        invalid.EspEnabled = false;
        invalid.ZombieEsp.Color = "not-a-color";
        Throws<InvalidDataException>(() => invalid.ApplyTo(target), "An invalid second profile was applied.");
        Check(JsonSerializer.Serialize(target) == before, "An invalid preset partially changed live options before failing.");
        var saved = fixture.Store.Create("Current", EspPresetOptions.Capture(target));
        byte[] catalogue = File.ReadAllBytes(fixture.Store.FilePath);
        foreach (Action<EspPresetOptions> damage in new Action<EspPresetOptions>[]
        {
            o => o.PlayerEsp.MaxDistance = 5001,
            o => o.ZombieEsp.FontSize = double.NaN,
            o => o.ZombieEsp.LineThickness = double.PositiveInfinity,
            o => o.PlayerEsp.BoxStyle = "unknown",
            o => o.RadarSize = 179,
            o => o.RadarOpacity = 1.1,
            o => o.PlayerEsp = null!
        })
        {
            var bad = EspPresetOptions.Capture(target);
            damage(bad);
            Throws<InvalidDataException>(() => fixture.Store.Replace(saved.Id, bad), "Invalid preset values were written.");
            Check(File.ReadAllBytes(fixture.Store.FilePath).SequenceEqual(catalogue), "A failed replacement changed the catalogue.");
        }
        return Task.CompletedTask;
    }

    public static Task ExamplesKeepStableIdsWithoutWritingOrApplyingAtStartup()
    {
        using var fixture = new Fixture();
        var first = fixture.Store.Load();
        var secondStore = new EspPresetStore(fixture.DirectoryPath + Path.DirectorySeparatorChar);
        var second = secondStore.Load();
        Check(first.Presets.Select(p => p.Id).SequenceEqual(second.Presets.Select(p => p.Id)), "Example IDs changed before the first catalogue save.");
        Check(first.Presets.Select(p => p.Name).SequenceEqual(new[] { "Exploration", "Horde", "Minimal" }), "The initial examples were not available.");
        Check(!File.Exists(fixture.Store.FilePath) && !File.Exists(fixture.Store.BackupPath), "Loading examples wrote preferences or a catalogue.");
        Check(first.Revision == second.Revision && first.Revision == fixture.Store.Revision, "Repeated reads caused an endless revision refresh.");
        first.Presets[0].Options.PlayerEsp.Color = "#000000";
        Check(secondStore.Load().Presets[0].Options.PlayerEsp.Color != "#000000", "A returned example mutated another panel's catalogue.");
        string selected = second.Presets[1].Id;
        var renamed = fixture.Store.Rename(selected, "Horde personnalisée");
        Check(renamed.Id == selected && secondStore.Load().Presets.Any(p => p.Id == selected && p.Name == renamed.Name), "A selection made before saving could not be mutated after reload.");
        return Task.CompletedTask;
    }

    public static Task SaveRenameDuplicateAndReplaceRoundTripWithoutCoupling()
    {
        using var fixture = new Fixture();
        var options = EspPresetOptions.Capture(Settings());
        options.PlayerEsp.MaxDistance = 900;
        options.ZombieEsp.MaxDistance = 75;
        var original = fixture.Store.Create("  Ma partie  ", options);
        options.PlayerEsp.MaxDistance = 25;
        Check(original.Name == "Ma partie" && original.Options.PlayerEsp.MaxDistance == 900, "The store did not normalize the name or copy caller-owned options.");
        var duplicate = fixture.Store.Duplicate(original.Id, "Nuit");
        Check(duplicate.Id != original.Id && JsonSerializer.Serialize(duplicate.Options) == JsonSerializer.Serialize(original.Options), "Duplicating changed the content or reused the identifier.");
        var renamed = fixture.Store.Rename(duplicate.Id, "Défense");
        var replacement = duplicate.Options.Copy();
        replacement.PlayerEsp.ShowTracers = true;
        replacement.ZombieEsp.Enabled = false;
        fixture.Store.Replace(renamed.Id, replacement);
        replacement.PlayerEsp.Color = "#000000";
        var loaded = new EspPresetStore(fixture.DirectoryPath).Load().Presets;
        var kept = loaded.Single(p => p.Id == original.Id);
        var changed = loaded.Single(p => p.Id == duplicate.Id);
        Check(kept.Name == "Ma partie" && !kept.Options.PlayerEsp.ShowTracers && kept.Options.ZombieEsp.Enabled, "Editing a duplicate changed its source.");
        Check(changed.Name == "Défense" && changed.Options.PlayerEsp.ShowTracers && !changed.Options.ZombieEsp.Enabled &&
            changed.Options.PlayerEsp.Color == "#66DEF2", "A committed change did not survive reopening independently.");
        Throws<InvalidOperationException>(() => fixture.Store.Rename(original.Id, " défense "), "A case-insensitive duplicate name was accepted.");
        return Task.CompletedTask;
    }

    public static Task ExportAndImportContainOnlyDisplayChoicesAndNeverOverwriteTheOriginal()
    {
        using var fixture = new Fixture();
        var current = Settings();
        current.SdkDirectory = "private-sdk-sentinel";
        current.ShareAddress = "private-network-sentinel";
        current.EspScaleMode = "fill";
        current.OutputMode = "fuser";
        var saved = fixture.Store.Create("Session", EspPresetOptions.Capture(current));
        string path = Path.Combine(fixture.Root, "export.json");
        fixture.Store.Export(saved.Id, path);
        string json = File.ReadAllText(path);
        using (var document = JsonDocument.Parse(json))
        {
            var options = document.RootElement.GetProperty("options");
            string[] allowed = { "espEnabled", "showProjectedEsp", "showRadar", "showHud", "radarSize", "radarOpacity", "radarIndependentRange", "radarRangeMeters", "showRadarCounts", "playerEsp", "zombieEsp" };
            Check(options.EnumerateObject().Select(p => p.Name).OrderBy(x => x).SequenceEqual(allowed.OrderBy(x => x)), "The export contains options outside its display contract.");
            Check(document.RootElement.GetProperty("format").GetString() == EspPresetStore.ExportFormat, "Export format marker is missing.");
        }
        Check(!json.Contains("private-sdk-sentinel", StringComparison.Ordinal) && !json.Contains("private-network-sentinel", StringComparison.Ordinal), "Private environment data leaked into an export.");
        string before = JsonSerializer.Serialize(current);
        var imported = fixture.Store.Import(path);
        Check(imported.Id != saved.Id && imported.Name == "Session (2)", "Import overwrote an existing preset or reused its identifier.");
        Check(JsonSerializer.Serialize(current) == before, "Import applied options without an explicit application.");
        Check(JsonSerializer.Serialize(imported.Options) == JsonSerializer.Serialize(saved.Options), "The import/export round trip changed display choices.");
        imported.Options.ZombieEsp.Color = "#000000";
        Check(fixture.Store.Load().Presets.Single(p => p.Id == imported.Id).Options.ZombieEsp.Color == "#FF9A52", "A returned import still owns mutable persisted state.");
        string settingsFile = Path.Combine(fixture.DirectoryPath, "loader-settings.json");
        File.WriteAllText(settingsFile, "protected-settings");
        foreach (string protectedPath in new[] { fixture.Store.FilePath, fixture.Store.BackupPath, fixture.Store.RejectedPath, settingsFile })
            Throws<InvalidOperationException>(() => fixture.Store.Export(saved.Id, protectedPath), "Export could overwrite an internal catalogue or loader preference file.");
        Check(File.ReadAllText(settingsFile) == "protected-settings", "Export changed the protected preference file.");
        return Task.CompletedTask;
    }

    public static Task MalformedForeignIncompleteAndOversizedImportsAreRejectedWithoutMutation()
    {
        using var fixture = new Fixture();
        var saved = fixture.Store.Create("Valid", EspPresetOptions.Capture(Settings()));
        string path = Path.Combine(fixture.Root, "valid.json");
        fixture.Store.Export(saved.Id, path);
        string valid = File.ReadAllText(path);
        byte[] before = File.ReadAllBytes(fixture.Store.FilePath);
        var badDocuments = new System.Collections.Generic.List<string>();
        string Changed(Action<JsonObject> change)
        {
            var node = JsonNode.Parse(valid)!.AsObject();
            change(node);
            return node.ToJsonString();
        }
        badDocuments.Add(Changed(n => n["format"] = "SevenDaysEsp.Preset/99"));
        badDocuments.Add(Changed(n => n["sdkDirectory"] = @"D:\unexpected"));
        badDocuments.Add(Changed(n => n["options"]!["monitorIndex"] = 2));
        badDocuments.Add(Changed(n => n["options"]!["playerEsp"]!.AsObject().Remove("enabled")));
        badDocuments.Add(Changed(n => n["options"]!.AsObject().Remove("radarSize")));
        badDocuments.Add(Changed(n => n["options"]!["zombieEsp"] = null));
        badDocuments.Add(Changed(n => n["options"]!["zombieEsp"]!["maxDistance"] = 5001));
        badDocuments.Add(Changed(n => n["name"] = new string('x', EspPresetStore.MaximumNameLength + 1)));
        badDocuments.Add(Changed(n => n["name"] = "line\nbreak"));
        badDocuments.Add(valid.Replace("\"name\": \"Valid\"", "\"name\": \"First\", \"name\": \"Second\"", StringComparison.Ordinal));
        badDocuments.Add("{broken-json");
        badDocuments.Add(new string(' ', EspPresetStore.MaximumImportBytes + 1) + valid);
        foreach (string invalid in badDocuments)
        {
            File.WriteAllText(path, invalid, new UTF8Encoding(false));
            Throws<InvalidDataException>(() => fixture.Store.Import(path), "A malformed, foreign, incomplete or oversized import was accepted.");
            Check(File.ReadAllBytes(fixture.Store.FilePath).SequenceEqual(before), "Rejected import modified the catalogue.");
        }
        return Task.CompletedTask;
    }

    public static Task NamesAndMaximumCountAreEnforcedWithoutReplacingOtherEntries()
    {
        using var fixture = new Fixture();
        var options = EspPresetOptions.Capture(Settings());
        var canonical = fixture.Store.Create("Été", options);
        Throws<InvalidOperationException>(() => fixture.Store.Create("E\u0301té", options), "Canonically equivalent names were accepted twice.");
        foreach (string invalid in new[] { "", "  ", "bad\tname", new string('x', 49) })
            Throws<InvalidDataException>(() => fixture.Store.Create(invalid, options), "An invalid name was accepted.");
        int present = fixture.Store.Load().Presets.Count;
        for (int i = present; i < EspPresetStore.MaximumPresets; i++) fixture.Store.Create("Preset " + i, options);
        byte[] full = File.ReadAllBytes(fixture.Store.FilePath);
        Throws<InvalidOperationException>(() => fixture.Store.Create("Too many", options), "The preset count limit was exceeded.");
        Throws<InvalidOperationException>(() => fixture.Store.Duplicate(canonical.Id), "Duplicate bypassed the preset count limit.");
        Check(File.ReadAllBytes(fixture.Store.FilePath).SequenceEqual(full), "Reaching the count limit replaced existing entries.");
        fixture.Store.Rename(canonical.Id, "Été renommé");
        Check(fixture.Store.Load().Presets.Count == EspPresetStore.MaximumPresets, "Renaming at capacity changed the entry count.");
        return Task.CompletedTask;
    }

    public static Task CorruptPrimaryRecoversItsBackupAndArchivesTheRejectedFile()
    {
        using var fixture = new Fixture();
        var first = fixture.Store.Create("First", EspPresetOptions.Capture(Settings()));
        fixture.Store.Create("Second", EspPresetOptions.Capture(Settings()));
        byte[] goodBackup = File.ReadAllBytes(fixture.Store.BackupPath);
        const string corrupt = "{ malformed principal";
        File.WriteAllText(fixture.Store.FilePath, corrupt);
        var recovered = fixture.Store.Load();
        Check(recovered.Warning.Contains("récupérés", StringComparison.Ordinal) && recovered.Presets.Any(p => p.Id == first.Id) &&
            recovered.Presets.All(p => p.Name != "Second"), "A corrupt primary did not recover the previous catalogue.");
        fixture.Store.Rename(first.Id, "Recovered");
        Check(File.ReadAllText(fixture.Store.RejectedPath) == corrupt, "Recovery discarded the rejected primary file.");
        Check(File.ReadAllBytes(fixture.Store.BackupPath).SequenceEqual(goodBackup), "Recovery overwrote the known-good backup with corruption.");
        Check(fixture.Store.Load().Warning.Length == 0 && fixture.Store.Load().Presets.Any(p => p.Name == "Recovered"), "A recovered mutation did not become the valid primary catalogue.");
        Check(!Directory.EnumerateFiles(fixture.DirectoryPath, "*.tmp").Any(), "An atomic save left temporary files behind.");
        return Task.CompletedTask;
    }

    public static Task UnreadableCataloguesArePreservedAndAnOversizedPrimaryCanRecover()
    {
        using (var fixture = new Fixture())
        {
            fixture.Store.Create("First", EspPresetOptions.Capture(Settings()));
            fixture.Store.Create("Second", EspPresetOptions.Capture(Settings()));
            File.WriteAllText(fixture.Store.FilePath, "bad primary");
            File.WriteAllText(fixture.Store.BackupPath, "bad backup");
            Throws<InvalidDataException>(() => fixture.Store.Load(), "Two unreadable catalogues silently reset the user's entries.");
            Throws<InvalidDataException>(() => fixture.Store.Create("New", EspPresetOptions.Capture(Settings())), "A mutation replaced unreadable catalogues with defaults.");
            Check(File.ReadAllText(fixture.Store.FilePath) == "bad primary" && File.ReadAllText(fixture.Store.BackupPath) == "bad backup", "Unreadable catalogues were destroyed.");
        }
        using (var fixture = new Fixture())
        {
            var first = fixture.Store.Create("First", EspPresetOptions.Capture(Settings()));
            fixture.Store.Create("Second", EspPresetOptions.Capture(Settings()));
            byte[] backup = File.ReadAllBytes(fixture.Store.BackupPath);
            string oversized = new('x', EspPresetStore.MaximumCatalogBytes + 1);
            File.WriteAllText(fixture.Store.FilePath, oversized);
            Check(fixture.Store.Load().Warning.Length > 0, "An oversized primary was read as a valid catalogue.");
            fixture.Store.Rename(first.Id, "Recovered oversized");
            Check(new FileInfo(fixture.Store.RejectedPath).Length == oversized.Length &&
                File.ReadAllBytes(fixture.Store.BackupPath).SequenceEqual(backup), "Oversized recovery did not preserve the rejected file and valid backup.");
        }
        return Task.CompletedTask;
    }

    public static async Task SharedStoresSerializeMutationsAndOnlyPublishRealRevisionChanges()
    {
        using var fixture = new Fixture();
        var other = new EspPresetStore(Path.Combine(fixture.DirectoryPath, "."));
        var initial = fixture.Store.Load();
        Check(other.Load().Revision == initial.Revision, "Equivalent paths did not share catalogue revision state.");
        var tasks = Enumerable.Range(0, 12).Select(i => Task.Run(() =>
        {
            var options = EspPresetOptions.Capture(Settings());
            options.PlayerEsp.MaxDistance = 100 + i;
            return (i % 2 == 0 ? fixture.Store : other).Create("Concurrent " + i, options);
        })).ToArray();
        var created = await Task.WhenAll(tasks);
        var loaded = other.Load();
        Check(loaded.Presets.Count == initial.Presets.Count + created.Length && created.All(p => loaded.Presets.Any(q => q.Id == p.Id)),
            "Concurrent panels lost an entry created by another store.");
        long revision = loaded.Revision;
        Check(fixture.Store.Load().Revision == revision && other.Load().Revision == revision, "Unchanged reads continuously incremented the revision.");
        var file = JsonNode.Parse(File.ReadAllText(fixture.Store.FilePath))!.AsObject();
        file["presets"]![0]!["name"] = "External rename";
        File.WriteAllText(fixture.Store.FilePath, file.ToJsonString());
        var refreshed = fixture.Store.Load();
        Check(refreshed.Revision > revision && other.Revision == refreshed.Revision && other.Load().Revision == refreshed.Revision,
            "An explicit reload did not publish an external file change once to the other panels.");
        other.Duplicate(created[0].Id, "Copy after concurrent changes");
        Check(fixture.Store.Load().Presets.Any(p => p.Name == "External rename"), "A later mutation overwrote an external rename from a stale UI snapshot.");
    }

    private static LoaderSettings Settings() => new() { EspProfilesVersion = 1 };
    private static string ProtectedState(LoaderSettings s) => JsonSerializer.Serialize(new
    {
        s.SchemaVersion, s.Mode, s.AutoConnectDma, s.SdkDirectory, s.Device, s.IntervalMs, s.ReadCadenceVersion,
        s.EspScaleMode, s.MonitorIndex, s.OutputMode, s.FuserDeviceName, s.FuserKeyColor, s.FuserTestPattern, s.OverlayAnchor,
        s.ShareAddress, s.SharePort, s.MenuKey, s.ToggleKey, s.PlayersKey, s.ZombiesKey, s.RadarKey,
        s.ShowPlayers, s.ShowZombies, s.ShowNames, s.ShowHealth, s.ShowDistances, s.PlayerColor, s.ZombieColor, s.MaxDistance
    });
    private static void Check(bool condition, string message)
    {
        if (!condition) throw new Exception(message);
    }
    private static void Throws<T>(Action action, string message) where T : Exception
    {
        try { action(); }
        catch (T) { return; }
        throw new Exception(message);
    }
    private sealed class Fixture : IDisposable
    {
        internal string Root { get; } = Path.Combine(Path.GetTempPath(), "7dtd-presets-" + Guid.NewGuid().ToString("N"));
        internal string DirectoryPath => Path.Combine(Root, "settings");
        internal EspPresetStore Store { get; }
        internal Fixture()
        {
            Directory.CreateDirectory(DirectoryPath);
            Store = new EspPresetStore(DirectoryPath);
        }
        public void Dispose() { if (Directory.Exists(Root)) Directory.Delete(Root, recursive: true); }
    }
}
