// Logic-test doubles only. No Unity or game assembly is loaded by this test
// project. Public signatures are separately compiled against the real DLLs.
using System;

namespace UnityEngine
{
    public sealed class Transform { public Transform parent; }
    public static class Time { public static int frameCount; }
    public struct Vector3
    {
        public float x, y, z;
        public Vector3(float x, float y, float z) { this.x = x; this.y = y; this.z = z; }
        public static Vector3 zero { get { return new Vector3(); } }
        public float sqrMagnitude { get { return x * x + y * y + z * z; } }
        public static Vector3 operator -(Vector3 a, Vector3 b) { return new Vector3(a.x - b.x, a.y - b.y, a.z - b.z); }
        public static bool operator ==(Vector3 a, Vector3 b) { return a.Equals(b); }
        public static bool operator !=(Vector3 a, Vector3 b) { return !a.Equals(b); }
        public override bool Equals(object other) { return other is Vector3 v && x.Equals(v.x) && y.Equals(v.y) && z.Equals(v.z); }
        public override int GetHashCode() { return HashCode.Combine(x, y, z); }
    }
}

public struct Vector3i { public int x, y, z; public Vector3i(int x, int y, int z) { this.x = x; this.y = y; this.z = z; } }
public sealed class DataItem<T> { public T Value { get; set; } }
public sealed class MovementInput { public bool bDetachedCameraMove; }
public sealed class vp_FPController { public EntityPlayerLocal localPlayer; }
public sealed class vp_FPCamera
{
    public vp_FPController FPController;
    public bool Locked3rdPerson;
    public UnityEngine.Vector3 PositionOnDeath;
}
public sealed class EModelBase { public bool visible = true; public bool IsRagdollOn; }
public sealed class WorldEnvironment
{
    public World world;
    public EntityPlayerLocal localPlayer;
    public float nightVisionBrightness = 0.08f;
    public int NightCalls;
    public void SetNightVision(float value) { NightCalls++; nightVisionBrightness = value * 0.4f; }
}
public sealed class World
{
    public EntityPlayerLocal PrimaryPlayer;
    public WorldEnvironment m_WorldEnvironment;
    public bool Remote;
    public bool HasExtent = true;
    public EntityPlayerLocal GetPrimaryPlayer() { return PrimaryPlayer; }
    public bool IsRemote() { return Remote; }
    public bool GetWorldExtent(out Vector3i min, out Vector3i max)
    { min = new Vector3i(-4000, 0, -4000); max = new Vector3i(4000, 256, 4000); return HasExtent; }
}
public sealed class GameManager { public static GameManager Instance; public World World; }
public sealed class PlayerMoveController
{
    public static PlayerMoveController Instance;
    public EntityPlayerLocal entityPlayerLocal;
    public GameManager gameManager;
    public Action toggleGodMode;
}
public sealed class EntityPlayerLocal
{
    public World world;
    public int entityId = 1;
    public bool isEntityRemote, Dead;
    public bool Spawned = true;
    public DataItem<bool> IsFlyMode = new DataItem<bool>();
    public DataItem<bool> IsGodMode = new DataItem<bool>();
    public DataItem<bool> IsNoCollisionMode = new DataItem<bool>();
    public float GodModeSpeedModifier = 1f;
    public bool bEntityAliveFlagsChanged, isIgnoredByAI;
    public bool bFirstPersonView = true, bModelVisible = true;
    public EModelBase emodel = new EModelBase();
    public PlayerMoveController moveController;
    public vp_FPController m_vp_FPController;
    public vp_FPCamera vp_FPCamera;
    public MovementInput movementInput = new MovementInput();
    public UnityEngine.Transform cameraContainerTransform = new UnityEngine.Transform();
    public UnityEngine.Transform cameraTransform = new UnityEngine.Transform();
    public UnityEngine.Vector3 position = new UnityEngine.Vector3(0, 60, 0);
    public object AttachedToEntity;
    public int NativeGodCalls, NativeSpectatorCalls, TeleportCalls, ClearMovementCalls, CameraCalls;
    public bool LastCameraAttached;
    private bool spectator;
    public bool IsSpectator
    {
        get { return spectator; }
        set { NativeSpectatorCalls++; spectator = value; isIgnoredByAI = value; SetVisible(bModelVisible); }
    }
    public void SetVisible(bool value) { emodel.visible = !spectator && value; }
    public bool IsDead() { return Dead; }
    public void ClearMovementInputs() { ClearMovementCalls++; }
    public void SetCameraAttachedToPlayer(bool attached, bool locked)
    {
        CameraCalls++; LastCameraAttached = attached;
        cameraTransform.parent = attached ? cameraContainerTransform : null;
        vp_FPCamera.Locked3rdPerson = !attached && locked;
        if (attached) movementInput.bDetachedCameraMove = false;
    }
    public void TeleportToPosition(UnityEngine.Vector3 target, bool onlyIfNotFlying, UnityEngine.Vector3? direction)
    { TeleportCalls++; position = target; Spawned = false; }
}
