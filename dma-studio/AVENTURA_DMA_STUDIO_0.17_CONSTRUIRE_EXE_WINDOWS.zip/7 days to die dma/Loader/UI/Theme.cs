using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Media;

namespace SevenDaysLoader.UI;

internal static class Theme
{
    internal static readonly SolidColorBrush Background = Brush("#0A101B");
    internal static readonly SolidColorBrush Surface = Brush("#141E2C");
    internal static readonly SolidColorBrush Raised = Brush("#202E42");
    internal static readonly SolidColorBrush Line = Brush("#2D3D53");
    internal static readonly SolidColorBrush Foreground = Brush("#F1F6FD");
    internal static readonly SolidColorBrush Muted = Brush("#A2B2C7");
    internal static readonly SolidColorBrush Orange = Brush("#FFAA6C");
    internal static readonly SolidColorBrush Cyan = Brush("#67D8F2");
    internal static readonly SolidColorBrush Success = Brush("#68E5AC");
    internal static readonly SolidColorBrush Danger = Brush("#FF7D8C");
    internal static readonly SolidColorBrush AccentSoft = Brush("#1B3B51");
    internal static SolidColorBrush Brush(string color)
    {
        var brush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(color));
        brush.Freeze();
        return brush;
    }

    internal static void Apply(Window window)
    {
        window.Background = Background;
        window.Foreground = Foreground;
        window.FontFamily = new FontFamily("Segoe UI");
        window.FontSize = 14;
        window.UseLayoutRounding = true;
        window.SnapsToDevicePixels = true;
        window.Resources = Resources();
        // Keep the native Windows title bar aligned with the graphite theme.
        // Not used for the borderless in-game menu; failures are non-fatal.
        if (window.WindowStyle != WindowStyle.None)
            window.SourceInitialized += (_, _) => TryDarkTitleBar(window);
    }

    [DllImport("dwmapi.dll", ExactSpelling = true)]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int valueSize);

    private static void TryDarkTitleBar(Window window)
    {
        if (!OperatingSystem.IsWindows()) return;
        try
        {
            int enabled = 1;
            DwmSetWindowAttribute(new WindowInteropHelper(window).Handle, 20, ref enabled, sizeof(int));
        }
        catch (DllNotFoundException) { }
        catch (EntryPointNotFoundException) { }
    }

    internal static ResourceDictionary Resources()
    {
        var r = new ResourceDictionary();
        var button = new Style(typeof(Button));
        button.Setters.Add(new Setter(Control.ForegroundProperty, Foreground));
        button.Setters.Add(new Setter(Control.BackgroundProperty, Raised));
        button.Setters.Add(new Setter(Control.BorderBrushProperty, Line));
        button.Setters.Add(new Setter(Control.BorderThicknessProperty, new Thickness(1)));
        button.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(16, 10, 16, 10)));
        button.Setters.Add(new Setter(Control.FontWeightProperty, FontWeights.SemiBold));
        button.Setters.Add(new Setter(Control.FontSizeProperty, 12.5));
        button.Setters.Add(new Setter(Control.HorizontalContentAlignmentProperty, HorizontalAlignment.Center));
        button.Setters.Add(new Setter(FrameworkElement.MinHeightProperty, 40.0));
        button.Setters.Add(new Setter(FrameworkElement.CursorProperty, System.Windows.Input.Cursors.Hand));
        var border = new FrameworkElementFactory(typeof(Border));
        border.SetValue(Border.CornerRadiusProperty, new CornerRadius(10));
        border.SetBinding(Border.BackgroundProperty, new System.Windows.Data.Binding("Background") { RelativeSource = System.Windows.Data.RelativeSource.TemplatedParent });
        border.SetBinding(Border.BorderBrushProperty, new System.Windows.Data.Binding("BorderBrush") { RelativeSource = System.Windows.Data.RelativeSource.TemplatedParent });
        border.SetBinding(Border.BorderThicknessProperty, new System.Windows.Data.Binding("BorderThickness") { RelativeSource = System.Windows.Data.RelativeSource.TemplatedParent });
        border.SetBinding(Border.PaddingProperty, new System.Windows.Data.Binding("Padding") { RelativeSource = System.Windows.Data.RelativeSource.TemplatedParent });
        var content = new FrameworkElementFactory(typeof(ContentPresenter));
        content.SetBinding(ContentPresenter.HorizontalAlignmentProperty, ParentBinding("HorizontalContentAlignment"));
        content.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
        content.SetValue(ContentPresenter.RecognizesAccessKeyProperty, true);
        border.AppendChild(content);
        button.Setters.Add(new Setter(Control.TemplateProperty, new ControlTemplate(typeof(Button)) { VisualTree = border }));
        var hover = new Trigger { Property = UIElement.IsMouseOverProperty, Value = true };
        hover.Setters.Add(new Setter(Control.BorderBrushProperty, Cyan));
        button.Triggers.Add(hover);
        var focus = new Trigger { Property = UIElement.IsKeyboardFocusedProperty, Value = true };
        focus.Setters.Add(new Setter(Control.BorderBrushProperty, Cyan));
        button.Triggers.Add(focus);
        var pressed = new Trigger { Property = ButtonBase.IsPressedProperty, Value = true };
        pressed.Setters.Add(new Setter(UIElement.OpacityProperty, 0.82));
        button.Triggers.Add(pressed);
        var disabled = new Trigger { Property = UIElement.IsEnabledProperty, Value = false };
        disabled.Setters.Add(new Setter(UIElement.OpacityProperty, 0.42));
        button.Triggers.Add(disabled);
        r.Add(typeof(Button), button);

        var input = new Style(typeof(TextBox));
        input.Setters.Add(new Setter(Control.BackgroundProperty, Background));
        input.Setters.Add(new Setter(Control.ForegroundProperty, Foreground));
        input.Setters.Add(new Setter(Control.BorderBrushProperty, Line));
        input.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(12, 10, 12, 10)));
        input.Setters.Add(new Setter(FrameworkElement.MinHeightProperty, 37.0));
        input.Setters.Add(new Setter(TextBox.CaretBrushProperty, Orange));
        input.Setters.Add(new Setter(TextBox.SelectionBrushProperty, Cyan));
        input.Setters.Add(new Setter(TextBox.SelectionOpacityProperty, 0.35));
        input.Setters.Add(new Setter(Control.VerticalContentAlignmentProperty, VerticalAlignment.Center));
        var inputFocus = new Trigger { Property = UIElement.IsKeyboardFocusWithinProperty, Value = true };
        inputFocus.Setters.Add(new Setter(Control.BorderBrushProperty, Cyan));
        input.Triggers.Add(inputFocus);
        r.Add(typeof(TextBox), input);

        AddComboStyles(r);

        var check = new Style(typeof(CheckBox));
        check.Setters.Add(new Setter(Control.ForegroundProperty, Foreground));
        check.Setters.Add(new Setter(Control.FontSizeProperty, 12.0));
        check.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(6, 0, 0, 0)));
        check.Setters.Add(new Setter(FrameworkElement.MarginProperty, new Thickness(0, 7, 0, 7)));
        check.Setters.Add(new Setter(Control.VerticalContentAlignmentProperty, VerticalAlignment.Center));
        r.Add(typeof(CheckBox), check);
        var radio = new Style(typeof(RadioButton));
        radio.Setters.Add(new Setter(Control.ForegroundProperty, Foreground));
        radio.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(6, 0, 0, 0)));
        radio.Setters.Add(new Setter(FrameworkElement.MarginProperty, new Thickness(0, 7, 0, 7)));
        r.Add(typeof(RadioButton), radio);
        var slider = new Style(typeof(Slider));
        slider.Setters.Add(new Setter(Control.ForegroundProperty, Orange));
        slider.Setters.Add(new Setter(Control.BackgroundProperty, Line));
        slider.Setters.Add(new Setter(FrameworkElement.MinHeightProperty, 22.0));
        r.Add(typeof(Slider), slider);
        var tip = new Style(typeof(ToolTip));
        tip.Setters.Add(new Setter(Control.BackgroundProperty, Raised));
        tip.Setters.Add(new Setter(Control.ForegroundProperty, Foreground));
        tip.Setters.Add(new Setter(Control.BorderBrushProperty, Line));
        tip.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(10)));
        tip.Setters.Add(new Setter(Control.FontSizeProperty, 12.0));
        r.Add(typeof(ToolTip), tip);
        var expander = new Style(typeof(Expander));
        expander.Setters.Add(new Setter(Control.ForegroundProperty, Foreground));
        expander.Setters.Add(new Setter(Control.FontWeightProperty, FontWeights.SemiBold));
        expander.Setters.Add(new Setter(Control.FontSizeProperty, 13.0));
        r.Add(typeof(Expander), expander);
        return r;
    }

    private static Binding ParentBinding(string property) => new(property)
    {
        RelativeSource = RelativeSource.TemplatedParent
    };

    private static void AddComboStyles(ResourceDictionary resources)
    {
        // These selectors are deliberately non-editable. Keep native ComboBox
        // keyboard/selection behaviour while supplying a readable dark popup.
        var combo = new Style(typeof(ComboBox));
        combo.Setters.Add(new Setter(Control.ForegroundProperty, Foreground));
        combo.Setters.Add(new Setter(Control.BackgroundProperty, Raised));
        combo.Setters.Add(new Setter(Control.BorderBrushProperty, Line));
        combo.Setters.Add(new Setter(Control.BorderThicknessProperty, new Thickness(1)));
        combo.Setters.Add(new Setter(Control.FontSizeProperty, 12.0));
        combo.Setters.Add(new Setter(FrameworkElement.MinHeightProperty, 36.0));
        combo.Setters.Add(new Setter(ComboBox.MaxDropDownHeightProperty, 340.0));

        var toggleBorder = new FrameworkElementFactory(typeof(Border));
        toggleBorder.SetValue(Border.CornerRadiusProperty, new CornerRadius(7));
        toggleBorder.SetBinding(Border.BackgroundProperty, ParentBinding("Background"));
        toggleBorder.SetBinding(Border.BorderBrushProperty, ParentBinding("BorderBrush"));
        toggleBorder.SetBinding(Border.BorderThicknessProperty, ParentBinding("BorderThickness"));
        var arrow = new FrameworkElementFactory(typeof(System.Windows.Shapes.Path));
        arrow.SetValue(System.Windows.Shapes.Path.DataProperty, Geometry.Parse("M 0 0 L 4 4 L 8 0"));
        arrow.SetValue(System.Windows.Shapes.Path.StrokeProperty, Muted);
        arrow.SetValue(System.Windows.Shapes.Path.StrokeThicknessProperty, 1.5);
        arrow.SetValue(FrameworkElement.HorizontalAlignmentProperty, HorizontalAlignment.Right);
        arrow.SetValue(FrameworkElement.VerticalAlignmentProperty, VerticalAlignment.Center);
        arrow.SetValue(FrameworkElement.MarginProperty, new Thickness(0, 0, 13, 0));
        toggleBorder.AppendChild(arrow);

        var root = new FrameworkElementFactory(typeof(Grid));
        var toggle = new FrameworkElementFactory(typeof(ToggleButton));
        toggle.SetValue(UIElement.FocusableProperty, false);
        toggle.SetValue(ButtonBase.ClickModeProperty, ClickMode.Press);
        toggle.SetBinding(Control.BackgroundProperty, ParentBinding("Background"));
        toggle.SetBinding(Control.BorderBrushProperty, ParentBinding("BorderBrush"));
        toggle.SetBinding(Control.BorderThicknessProperty, ParentBinding("BorderThickness"));
        toggle.SetBinding(ToggleButton.IsCheckedProperty, new Binding("IsDropDownOpen")
        {
            RelativeSource = RelativeSource.TemplatedParent, Mode = BindingMode.TwoWay
        });
        toggle.SetValue(Control.TemplateProperty, new ControlTemplate(typeof(ToggleButton)) { VisualTree = toggleBorder });
        root.AppendChild(toggle);
        var selected = new FrameworkElementFactory(typeof(ContentPresenter));
        selected.SetValue(UIElement.IsHitTestVisibleProperty, false);
        selected.SetValue(UIElement.ClipToBoundsProperty, true);
        selected.SetValue(FrameworkElement.MarginProperty, new Thickness(11, 6, 34, 6));
        selected.SetValue(FrameworkElement.VerticalAlignmentProperty, VerticalAlignment.Center);
        selected.SetBinding(ContentPresenter.ContentProperty, ParentBinding("SelectionBoxItem"));
        selected.SetBinding(ContentPresenter.ContentTemplateProperty, ParentBinding("SelectionBoxItemTemplate"));
        selected.SetBinding(ContentPresenter.ContentStringFormatProperty, ParentBinding("SelectionBoxItemStringFormat"));
        root.AppendChild(selected);

        var popup = new FrameworkElementFactory(typeof(Popup), "PART_Popup");
        popup.SetValue(Popup.PlacementProperty, PlacementMode.Bottom);
        popup.SetValue(Popup.AllowsTransparencyProperty, true);
        popup.SetValue(UIElement.FocusableProperty, false);
        popup.SetBinding(Popup.IsOpenProperty, ParentBinding("IsDropDownOpen"));
        popup.SetBinding(Popup.PlacementTargetProperty, new Binding { RelativeSource = RelativeSource.TemplatedParent });
        var drop = new FrameworkElementFactory(typeof(Border));
        drop.SetValue(Border.BackgroundProperty, Raised);
        drop.SetValue(Border.BorderBrushProperty, Line);
        drop.SetValue(Border.BorderThicknessProperty, new Thickness(1));
        drop.SetValue(Border.CornerRadiusProperty, new CornerRadius(7));
        drop.SetValue(Border.PaddingProperty, new Thickness(4));
        drop.SetBinding(FrameworkElement.WidthProperty, ParentBinding("ActualWidth"));
        drop.SetBinding(FrameworkElement.MaxHeightProperty, ParentBinding("MaxDropDownHeight"));
        var scroll = new FrameworkElementFactory(typeof(ScrollViewer));
        scroll.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        scroll.SetValue(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Auto);
        scroll.SetValue(ScrollViewer.CanContentScrollProperty, true);
        var items = new FrameworkElementFactory(typeof(ItemsPresenter));
        items.SetValue(System.Windows.Input.KeyboardNavigation.DirectionalNavigationProperty, System.Windows.Input.KeyboardNavigationMode.Contained);
        scroll.AppendChild(items);
        drop.AppendChild(scroll);
        popup.AppendChild(drop);
        root.AppendChild(popup);
        combo.Setters.Add(new Setter(Control.TemplateProperty, new ControlTemplate(typeof(ComboBox)) { VisualTree = root }));
        var focus = new Trigger { Property = UIElement.IsKeyboardFocusWithinProperty, Value = true };
        focus.Setters.Add(new Setter(Control.BorderBrushProperty, Cyan));
        combo.Triggers.Add(focus);
        var disabled = new Trigger { Property = UIElement.IsEnabledProperty, Value = false };
        disabled.Setters.Add(new Setter(UIElement.OpacityProperty, 0.45));
        combo.Triggers.Add(disabled);
        resources.Add(typeof(ComboBox), combo);

        var item = new Style(typeof(ComboBoxItem));
        item.Setters.Add(new Setter(Control.ForegroundProperty, Foreground));
        item.Setters.Add(new Setter(Control.BackgroundProperty, Brushes.Transparent));
        item.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(8, 8, 8, 8)));
        item.Setters.Add(new Setter(Control.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch));
        var itemBorder = new FrameworkElementFactory(typeof(Border));
        itemBorder.SetValue(Border.CornerRadiusProperty, new CornerRadius(4));
        itemBorder.SetBinding(Border.BackgroundProperty, ParentBinding("Background"));
        itemBorder.SetBinding(Border.PaddingProperty, ParentBinding("Padding"));
        var itemContent = new FrameworkElementFactory(typeof(ContentPresenter));
        itemContent.SetValue(UIElement.ClipToBoundsProperty, true);
        itemBorder.AppendChild(itemContent);
        item.Setters.Add(new Setter(Control.TemplateProperty, new ControlTemplate(typeof(ComboBoxItem)) { VisualTree = itemBorder }));
        var highlighted = new Trigger { Property = ComboBoxItem.IsHighlightedProperty, Value = true };
        highlighted.Setters.Add(new Setter(Control.BackgroundProperty, Line));
        item.Triggers.Add(highlighted);
        var chosen = new Trigger { Property = Selector.IsSelectedProperty, Value = true };
        chosen.Setters.Add(new Setter(Control.ForegroundProperty, Cyan));
        item.Triggers.Add(chosen);
        resources.Add(typeof(ComboBoxItem), item);
    }

    internal static TextBlock Text(string text, double size = 14, Brush? color = null, bool bold = false) => new()
    {
        Text = text, FontSize = size, Foreground = color ?? Foreground,
        FontWeight = bold ? FontWeights.SemiBold : FontWeights.Normal,
        TextWrapping = TextWrapping.Wrap,
        Margin = new Thickness(0, 0, 0, 7)
    };

    internal static Border Card(UIElement child, Thickness? padding = null) => new()
    {
        Child = child, Background = Surface, BorderBrush = Line, BorderThickness = new Thickness(1),
        CornerRadius = new CornerRadius(16), Padding = padding ?? new Thickness(22), Margin = new Thickness(0, 0, 0, 16)
    };

    internal static Button Button(string text, Action action, bool primary = false)
    {
        var b = new Button { Content = text, Margin = new Thickness(0, 0, 8, 8) };
        if (primary) { b.Background = Cyan; b.Foreground = Background; b.BorderBrush = Cyan; }
        b.Click += (_, _) => action();
        return b;
    }

    internal static Button Segment(string text, Action action)
    {
        var button = Button(text, action);
        button.Margin = new Thickness(0);
        button.Padding = new Thickness(12, 8, 12, 8);
        button.FontSize = 11.5;
        button.MinHeight = 36;
        button.MinWidth = 76;
        return button;
    }

    internal static void SelectSegment(Button button, bool selected)
    {
        button.Background = selected ? AccentSoft : Raised;
        button.BorderBrush = selected ? Cyan : Line;
        button.Foreground = selected ? Cyan : Muted;
    }

    internal static TextBlock Eyebrow(string text)
    {
        var label = Text(text, 10.5, Muted, true);
        return label;
    }

    internal static LinearGradientBrush Gradient(string left, string right)
    {
        var gradient = new LinearGradientBrush(
            (Color)ColorConverter.ConvertFromString(left),
            (Color)ColorConverter.ConvertFromString(right),
            new Point(0, 0), new Point(1, 1));
        gradient.Freeze();
        return gradient;
    }

    internal static Border Inset(UIElement child, Thickness? padding = null) => new()
    {
        Child = child, Background = Background, BorderBrush = Line, BorderThickness = new Thickness(1),
        CornerRadius = new CornerRadius(12), Padding = padding ?? new Thickness(16)
    };

    internal static StackPanel Stack(params UIElement[] children)
    {
        var s = new StackPanel();
        foreach (var child in children) s.Children.Add(child);
        return s;
    }

    internal static TextBlock Label(string text) => Text(text, 12, Muted, true);
}
