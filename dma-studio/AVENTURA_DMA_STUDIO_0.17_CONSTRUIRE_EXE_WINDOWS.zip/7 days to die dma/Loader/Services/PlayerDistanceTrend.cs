using System;
using System.Collections.Generic;
using System.Diagnostics;
using SevenDaysEsp;

namespace SevenDaysLoader.Services;

// One bounded tracker, for the currently pinned opaque player identity only.
// Its input comes from already accepted snapshots; it performs no memory read.
internal sealed class PlayerDistanceTrendTracker
{
    internal const int MaximumSamples = 18;
    internal const int MinimumSamples = 4;
    internal const double MinimumDurationSeconds = 0.5;
    internal const double WindowSeconds = 1.2;
    internal const double SamplingIntervalSeconds = 0.075;
    internal const double EnterMovingMetersPerSecond = 0.6;
    internal const double LeaveMovingMetersPerSecond = 0.25;
    private const double MinimumSlopeIntervalSeconds = 0.1;
    private const double MaximumGapSeconds = FeedSample.ProjectionLifetimeMs / 1000.0;
    // A generous continuity guard, not a displayed estimate of player speed.
    // Either endpoint jumping invalidates the window, even if distance stays
    // constant because both positions moved by the same amount.
    private const double JumpSlackMeters = 2;
    private const double MaximumContinuousMetersPerSecond = 60;
    private readonly List<Observation> samples = new(MaximumSamples);
    private PlayerIdentity identity;
    private int generation;
    private long sequence;
    private Observation previous;
    private bool hasPrevious;

    internal PlayerDistanceTrend Current { get; private set; }
    internal int SampleCount => samples.Count;

    internal void Reset()
    {
        samples.Clear();
        identity = default;
        generation = 0;
        sequence = 0;
        previous = default;
        hasPrevious = false;
        Current = default;
    }

    internal PlayerDistanceTrend Observe(PlayerIdentity incomingIdentity, int incomingGeneration,
        long incomingSequence, long receivedTimestamp, double initialAgeMilliseconds, long nowTimestamp,
        LivePosition localPosition, LivePosition playerPosition)
    {
        if (!incomingIdentity.IsValid || incomingSequence <= 0 ||
            !FeedSample.ValidPosition(localPosition) || !FeedSample.ValidPosition(playerPosition) ||
            !TryCaptureSeconds(receivedTimestamp, initialAgeMilliseconds, nowTimestamp, out double captureSeconds))
        {
            Reset();
            return Current;
        }

        var local = Point.From(localPosition);
        var player = Point.From(playerPosition);
        var observation = new Observation(captureSeconds, local.DistanceTo(player), local, player);
        if (hasPrevious && (incomingIdentity != identity || incomingGeneration != generation)) Reset();
        if (hasPrevious && incomingSequence <= sequence)
        {
            // Replays and out-of-order samples cannot extend a trend's life or
            // serve as its first new observation after a continuity break.
            Reset();
            return Current;
        }
        if (hasPrevious)
        {
            double elapsed = captureSeconds - previous.Seconds;
            if (elapsed <= 0)
            {
                Reset();
                return Current;
            }
            double allowedMovement = JumpSlackMeters + MaximumContinuousMetersPerSecond * elapsed;
            if (elapsed >= MaximumGapSeconds || local.DistanceTo(previous.Local) > allowedMovement ||
                player.DistanceTo(previous.Player) > allowedMovement)
                Reset();
        }

        identity = incomingIdentity;
        generation = incomingGeneration;
        sequence = incomingSequence;
        previous = observation;
        hasPrevious = true;
        // Still validate every accepted capture above. Retain observations at
        // a bounded cadence so high frame rates cannot shrink the history to
        // less than its minimum duration or allocate an unbounded collection.
        if (samples.Count != 0 && captureSeconds - samples[^1].Seconds < SamplingIntervalSeconds)
            return Current;
        samples.Add(observation);
        while (samples.Count > MaximumSamples || captureSeconds - samples[0].Seconds > WindowSeconds)
            samples.RemoveAt(0);
        if (samples.Count < MinimumSamples || captureSeconds - samples[0].Seconds < MinimumDurationSeconds)
        {
            Current = default;
            return Current;
        }

        // The median of pair slopes is robust against isolated small position
        // jitter. Extremely short pairs amplify timing noise and are omitted.
        var slopes = new List<double>(samples.Count * (samples.Count - 1) / 2);
        for (int right = 1; right < samples.Count; ++right)
        {
            for (int left = 0; left < right; ++left)
            {
                double elapsed = samples[right].Seconds - samples[left].Seconds;
                if (elapsed < MinimumSlopeIntervalSeconds) continue;
                slopes.Add((samples[right].Distance - samples[left].Distance) / elapsed);
            }
        }
        if (slopes.Count == 0) { Current = default; return Current; }
        slopes.Sort();
        int middle = slopes.Count / 2;
        double rate = slopes.Count % 2 == 0 ? (slopes[middle - 1] + slopes[middle]) / 2 : slopes[middle];
        if (!double.IsFinite(rate)) { Reset(); return Current; }
        Current = new PlayerDistanceTrend(Classify(rate, Current.State), rate);
        return Current;
    }

    private static PlayerDistanceTrendState Classify(double rate, PlayerDistanceTrendState previousState)
    {
        if (rate <= -EnterMovingMetersPerSecond) return PlayerDistanceTrendState.Approaching;
        if (rate >= EnterMovingMetersPerSecond) return PlayerDistanceTrendState.Receding;
        if (previousState == PlayerDistanceTrendState.Approaching && rate < -LeaveMovingMetersPerSecond)
            return PlayerDistanceTrendState.Approaching;
        if (previousState == PlayerDistanceTrendState.Receding && rate > LeaveMovingMetersPerSecond)
            return PlayerDistanceTrendState.Receding;
        return PlayerDistanceTrendState.Stable;
    }

    private static bool TryCaptureSeconds(long received, double initialAge, long now, out double seconds)
    {
        seconds = 0;
        if (received <= 0 || now < received || !double.IsFinite(initialAge) || initialAge < 0 ||
            initialAge >= FeedSample.ProjectionLifetimeMs) return false;
        double age = initialAge + Stopwatch.GetElapsedTime(received, now).TotalMilliseconds;
        if (!double.IsFinite(age) || age < 0 || age >= FeedSample.ProjectionLifetimeMs) return false;
        // This places the capture on the receipt clock's monotonic timeline.
        // CapturedUtc is intentionally irrelevant, including after clock sync.
        seconds = received / (double)Stopwatch.Frequency - initialAge / 1000.0;
        return double.IsFinite(seconds) && seconds > 0;
    }

    private readonly record struct Observation(double Seconds, double Distance, Point Local, Point Player);

    private readonly record struct Point(double X, double Y, double Z)
    {
        internal static Point From(LivePosition value) => new(value.X, value.Y, value.Z);
        internal double DistanceTo(Point other)
        {
            double dx = X - other.X, dy = Y - other.Y, dz = Z - other.Z;
            return Math.Sqrt(dx * dx + dy * dy + dz * dz);
        }
    }
}
