using System;
using System.Threading.Tasks;
using SevenDaysEsp;

internal static class ProjectionOutputMappingTests
{
    public static Task SameAspectResolutionsPreservePositionsAndBoxes()
    {
        // These expected coordinates come from matching fractional image
        // positions, independent of the implementation's affine formula.
        foreach (var size in new[] { (1920, 1080), (2560, 1440), (3840, 2160), (1280, 720) })
        foreach (string mode in new[] { ProjectionOutputMapping.Fit, ProjectionOutputMapping.Stretch, ProjectionOutputMapping.Fill })
        {
            var mapping = Create(1920, 1080, size.Item1, size.Item2, mode);
            MapPoint(mapping, new(960, 540), size.Item1 / 2.0, size.Item2 / 2.0);
            MapPoint(mapping, new(1920, 1080), size.Item1, size.Item2);
            Check(mapping.TryMapBox(new(480, 270, 1440, 810), out var box), "Known image rectangle was rejected.");
            Close(box.Left, size.Item1 / 4.0); Close(box.Top, size.Item2 / 4.0);
            Close(box.Right, size.Item1 * .75); Close(box.Bottom, size.Item2 * .75);
            Rect(mapping.ClipViewport, 0, 0, size.Item1, size.Item2);
            Close(mapping.OffsetX, 0); Close(mapping.OffsetY, 0);
        }
        return Task.CompletedTask;
    }

    public static Task FitPreservesAspectAcrossUltrawideAndPortraitOutputs()
    {
        var wide = Create(1920, 1080, 3440, 1440, ProjectionOutputMapping.Fit);
        Rect(wide.ImageViewport, 440, 0, 2560, 1440);
        Rect(wide.ClipViewport, 440, 0, 2560, 1440);
        MapPoint(wide, new(0, 0), 440, 0);
        MapPoint(wide, new(1920, 1080), 3000, 1440);
        MapPoint(wide, new(960, 540), 1720, 720);

        var square = Create(1920, 1080, 1024, 1024, ProjectionOutputMapping.Fit);
        Rect(square.ClipViewport, 0, 224, 1024, 576);
        var portrait = Create(1920, 1080, 1080, 1920, ProjectionOutputMapping.Fit);
        Rect(portrait.ImageViewport, 0, 656.25, 1080, 607.5);
        MapPoint(portrait, new(960, 540), 540, 960);
        Close(portrait.ScaleX, portrait.ScaleY);

        var portraitSource = Create(1080, 1920, 1920, 1080, ProjectionOutputMapping.Fit);
        Rect(portraitSource.ClipViewport, 656.25, 0, 607.5, 1080);
        MapPoint(portraitSource, new(540, 960), 960, 540);
        return Task.CompletedTask;
    }

    public static Task FillCropsAndStretchMapsEachAxis()
    {
        var fill = Create(1920, 1080, 3440, 1440, ProjectionOutputMapping.Fill);
        Rect(fill.ImageViewport, 0, -247.5, 3440, 1935);
        Rect(fill.ClipViewport, 0, 0, 3440, 1440);
        MapPoint(fill, new(0, 0), 0, -247.5);
        MapPoint(fill, new(1920, 1080), 3440, 1687.5);
        MapPoint(fill, new(960, 540), 1720, 720);
        Check(fill.TryMapBox(new(0, 0, 1920, 1080), out var box), "Cropped full-image box rejected.");
        Close(box.Top, -247.5); Close(box.Bottom, 1687.5);

        var portraitFill = Create(1920, 1080, 1080, 1920, ProjectionOutputMapping.Fill);
        MapPoint(portraitFill, new(960, 540), 540, 960);
        Check(portraitFill.ImageViewport.X < 0 && portraitFill.ImageViewport.Right > 1080,
            "Portrait fill did not retain the true cropped horizontal coordinates.");
        Rect(portraitFill.ClipViewport, 0, 0, 1080, 1920);

        var stretch = Create(1920, 1080, 3440, 1440, ProjectionOutputMapping.Stretch);
        Rect(stretch.ImageViewport, 0, 0, 3440, 1440);
        MapPoint(stretch, new(480, 270), 860, 360);
        Check(stretch.ScaleX != stretch.ScaleY, "Stretch silently preserved aspect instead of following both output axes.");
        return Task.CompletedTask;
    }

    public static Task CameraSubViewportKeepsItsPlaceWithinTheImage()
    {
        var sourceViewport = new ProjectionViewport(480, 270, 960, 540);
        var wideFit = Create(1920, 1080, 3440, 1440, ProjectionOutputMapping.Fit, sourceViewport);
        Rect(wideFit.ImageViewport, 440, 0, 2560, 1440);
        Rect(wideFit.ClipViewport, 1080, 360, 1280, 720);
        MapPoint(wideFit, new(480, 270), 1080, 360);

        var stretch = Create(1920, 1080, 3440, 1440, ProjectionOutputMapping.Stretch, sourceViewport);
        Rect(stretch.ClipViewport, 860, 360, 1720, 720);
        var fill = Create(1920, 1080, 3440, 1440, ProjectionOutputMapping.Fill, sourceViewport);
        Rect(fill.ClipViewport, 860, 236.25, 1720, 967.5);

        // A camera in the top strip is completely removed by a center crop.
        // It must not be stretched back into view or assigned an arbitrary rect.
        var croppedAway = Create(1920, 1080, 3440, 1440, ProjectionOutputMapping.Fill, new(0, 0, 1920, 100));
        Check(!croppedAway.HasVisibleViewport, "A fully cropped camera viewport was invented on the output.");
        Rect(croppedAway.ClipViewport, 0, 0, 0, 0);
        Check(!croppedAway.IsMarkerVisible(Marker(new(960, 50), null)), "A fully cropped viewport exposed a marker.");
        return Task.CompletedTask;
    }

    public static Task CropVisibilityDoesNotPinOffscreenMarkersToTheEdge()
    {
        var fill = Create(1920, 1080, 3440, 1440, ProjectionOutputMapping.Fill);
        Check(!fill.IsMarkerVisible(Marker(new(960, 50), new(900, 20, 1020, 100))),
            "A fully cropped marker would still get a label clamped to the edge.");
        Check(fill.IsMarkerVisible(Marker(null, new(900, 100, 1020, 200))),
            "A partly cropped box disappeared although its interior crosses the output edge.");
        Check(fill.TryMapBox(new(900, 100, 1020, 200), out var crossing) && crossing.Top < 0,
            "The box was truncated into a false border at the output edge.");
        Check(fill.IsMarkerVisible(Marker(new(960, 540), null)), "Visible anchor rejected.");

        var limited = Create(1920, 1080, 2560, 1440, ProjectionOutputMapping.Fit, new(480, 270, 960, 540));
        Check(!limited.IsMarkerVisible(Marker(new(200, 200), null)), "Marker outside the camera viewport was exposed.");
        Check(!limited.IsMarkerVisible(Marker(null, new(0, 0, 480, 270))), "A zero-area edge touch counted as a visible rectangle.");
        Check(limited.IsMarkerVisible(Marker(null, new(400, 200, 600, 400))), "Box crossing the viewport disappeared.");
        Check(!limited.IsMarkerVisible(null), "Null marker was considered visible.");
        Check(!limited.IsMarkerVisible(Marker(new(double.NaN, 540), new(0, 0, double.PositiveInfinity, 1080))),
            "Non-finite marker geometry was displayed.");
        return Task.CompletedTask;
    }

    public static Task InvalidMappingsAndNonFiniteGeometryAreRejected()
    {
        foreach (var dimensions in new[] { (0, 1080, 2560, 1440), (1920, -1, 2560, 1440),
            (1920, 1080, 0, 1440), (1920, 1080, 2560, 32769), (32769, 1080, 2560, 1440) })
            Check(!ProjectionOutputMapping.TryCreate(dimensions.Item1, dimensions.Item2, dimensions.Item3, dimensions.Item4,
                new(0, 0, 1920, 1080), ProjectionOutputMapping.Fit, out var bad, out var reason) && bad == null && reason.Length > 0,
                "Invalid image dimensions were accepted.");
        foreach (string? mode in new string?[] { null, "", "Fit", "unknown", "fit " })
            Check(!ProjectionOutputMapping.TryCreate(1920, 1080, 2560, 1440, new(0, 0, 1920, 1080),
                mode, out var bad, out var reason) && bad == null && reason.Length > 0,
                "An unknown scaling mode silently selected a different image transform.");
        foreach (var viewport in new ProjectionViewport[] { new(-1, 0, 1920, 1080), new(0, 0, 0, 1080),
            new(1, 0, 1920, 1080), new(0, 1, 1920, 1080), new(double.NaN, 0, 1920, 1080),
            new(0, 0, double.PositiveInfinity, 1080), new(0, 0, 1920, double.NaN) })
            Check(!ProjectionOutputMapping.TryCreate(1920, 1080, 2560, 1440, viewport, ProjectionOutputMapping.Fit,
                out var bad, out var reason) && bad == null && reason.Length > 0, "Invalid source viewport accepted.");

        var mapping = Create(1920, 1080, 2560, 1440, ProjectionOutputMapping.Fit);
        foreach (var point in new ProjectionPoint[] { new(double.NaN, 0), new(0, double.PositiveInfinity),
            new(-1, 0), new(1921, 540), new(960, 1081) })
            Check(!mapping.TryMapPoint(point, out _), "Invalid source point mapped to output.");
        foreach (var box in new ProjectionBox[] { new(0, 0, 0, 10), new(20, 0, 10, 10),
            new(0, 0, double.NaN, 10), new(0, 0, 20, double.PositiveInfinity), new(-1, 0, 10, 10) })
            Check(!mapping.TryMapBox(box, out _), "Invalid source rectangle mapped to output.");
        Check(ProjectionOutputMapping.IsKnownMode(ProjectionOutputMapping.Fit) &&
            ProjectionOutputMapping.IsKnownMode(ProjectionOutputMapping.Stretch) &&
            ProjectionOutputMapping.IsKnownMode(ProjectionOutputMapping.Fill) &&
            !ProjectionOutputMapping.IsKnownMode(null), "Mode validation is inconsistent.");

        // Keep the mathematical mapper's limits aligned with ProjectionMath.
        var largest = Create(32768, 32768, 1, 1, ProjectionOutputMapping.Fit);
        MapPoint(largest, new(32768, 32768), 1, 1);
        return Task.CompletedTask;
    }

    private static ProjectionOutputMapping Create(int sw, int sh, int ow, int oh, string mode,
        ProjectionViewport? viewport = null)
    {
        if (!ProjectionOutputMapping.TryCreate(sw, sh, ow, oh, viewport ?? new(0, 0, sw, sh), mode,
            out var mapping, out var reason)) throw new InvalidOperationException("Valid mapping rejected: " + reason);
        return mapping!;
    }

    private static ProjectedMarker Marker(ProjectionPoint? anchor, ProjectionBox? box) =>
        new(7, "zombie", "fixture", 10, anchor, box);

    private static void MapPoint(ProjectionOutputMapping mapping, ProjectionPoint source, double x, double y)
    {
        Check(mapping.TryMapPoint(source, out var actual), "Known source point rejected.");
        Close(actual.X, x); Close(actual.Y, y);
    }

    private static void Rect(ProjectionViewport actual, double x, double y, double width, double height)
    {
        Close(actual.X, x); Close(actual.Y, y); Close(actual.Width, width); Close(actual.Height, height);
    }

    private static void Close(double actual, double expected)
    {
        if (!double.IsFinite(actual) || Math.Abs(actual - expected) > 0.000001)
            throw new InvalidOperationException($"Expected {expected:R}, got {actual:R}.");
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
