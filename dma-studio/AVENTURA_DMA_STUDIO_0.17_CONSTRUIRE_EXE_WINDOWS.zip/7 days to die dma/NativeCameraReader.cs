#nullable enable
// Read-only camera acquisition for the exact native profile documented in
// Loader/NativeProfileEvidence.json. No injected call, remote execution or write.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;

namespace SevenDaysEsp
{
    public sealed class NativeCameraDiagnostics
    {
        public string Format { get; set; } = "SevenDaysEsp.NativeCameraDiagnostics/1";
        public string ProfileId { get; set; } = NativeCameraProfile.ProfileId;
        public string Status { get; set; } = "CAMERA_NON_INITIALISEE";
        public string Message { get; set; } = String.Empty;
        public string Stage { get; set; } = "INITIALISATION";
        public bool ProfileVerified { get; set; }
        public string ProfileValidationScope { get; set; } = "NON_VERIFIE";
        public long InitializationAttempts { get; set; }
        public bool InitializationRetryPending { get; set; }
        public string LastInitializationFailure { get; set; } = String.Empty;
        public string FailedSignatureName { get; set; } = String.Empty;
        public string FailedSignatureRva { get; set; } = String.Empty;
        public bool XrGetterVerified { get; set; }
        public string XrValidationMode { get; set; } = "NON_EVALUE";
        public bool MatricesValidated { get; set; }
        public float[]? LastView { get; set; }
        public float[]? LastProjection { get; set; }
        public int SourceWidth { get; set; }
        public int SourceHeight { get; set; }
        public uint? RenderedFrameCount { get; set; }
        public float[]? LastNormalizedRect { get; set; }
        public float ViewportX { get; set; }
        public float ViewportY { get; set; }
        public float ViewportWidth { get; set; }
        public float ViewportHeight { get; set; }
        public string InstabilityKind { get; set; } = String.Empty;
        public string InstabilityDetail { get; set; } = String.Empty;
        public string EpochResetReason { get; set; } = String.Empty;
        public bool EpochResetOccurred { get; set; }
        public Dictionary<string, long> EpochResetCounts { get; set; } = new Dictionary<string, long>();
        public double MatrixPairMilliseconds { get; set; }
        public int NativePairReadBytes { get; set; }
        public int? ProjectionModeBefore { get; set; }
        public int? ProjectionModeAfter { get; set; }
        public int? OrthographicBefore { get; set; }
        public int? OrthographicAfter { get; set; }
        public int? ProjectionDirtyBefore { get; set; }
        public int? ProjectionDirtyAfter { get; set; }
        public float[]? NormalizedRectBefore { get; set; }
        public float[]? NormalizedRectAfter { get; set; }
        public int? NonJitteredExplicitBefore { get; set; }
        public int? NonJitteredExplicitAfter { get; set; }
        public string PresentationMode { get; set; } = "INDETERMINE";
        public string PresentationSource { get; set; } = String.Empty;
        public string ProjectionSource { get; set; } = String.Empty;
        public bool PresentationValidated { get; set; }
        public float[]? LastRawNormalizedRect { get; set; }
        public string RawViewportPhaseBefore { get; set; } = String.Empty;
        public string RawViewportPhaseAfter { get; set; } = String.Empty;
        public int? UpscalerQuality { get; set; }
        public int? RenderWidth { get; set; }
        public int? RenderHeight { get; set; }
        public int? DisplayWidth { get; set; }
        public int? DisplayHeight { get; set; }
        public Dictionary<string, long> InstabilityCauseCounts { get; set; } = new Dictionary<string, long>();
        public long OtherInstabilityCauseCount { get; set; }
        public int CameraEpoch { get; set; }
        public long Sequence { get; set; }
        public int Attempts { get; set; }
        public int ReadCalls { get; set; }
        public long BytesRead { get; set; }
        public double ElapsedMilliseconds { get; set; }
    }

    public sealed partial class NativeCameraReader
    {
        private const string MonoLayout = "Unity Mono x64 2022 (candidate)";
        private const int CaptureBudgetMs = 100;
        private const int InitializationRetryDelayMs = 2000;
        private const int MaximumAttempts = 3;
        private const int MaximumCalls = 1024;
        private const long MaximumBytes = 524288;
        // One bounded native object block contains the header, V/P matrices and
        // every interpreted camera field in the verified profile. Comparing
        // selected fields avoids treating unrelated native padding as a lock.
        private const int NativeCaptureSize = NativeCameraProfile.NonJitteredProjectionOffset + 64;
        private readonly IMemoryReader memory;
        private readonly MonoInspectionReport metadata;
        private readonly CameraProbeReport probe;
        private readonly Func<long> nowMilliseconds;
        private readonly List<ClassIdentity> classIdentities = new List<ClassIdentity>();
        private Stopwatch clock = Stopwatch.StartNew();
        private int operationBudget;
        private ulong moduleBase;
        private bool initialized;
        private bool profileVerified;
        private long initializationAttempts;
        private bool initializationRetryPending;
        private long lastInitializationFinishedMs;
        private string lastInitializationFailure = String.Empty;
        private string failedSignatureName = String.Empty, failedSignatureRva = String.Empty;
        private string profileValidationScope = "NON_VERIFIE";
        private bool xrGetterVerified;
        private string xrValidationMode = "NON_EVALUE";
        private ClassIdentity? localClass;
        private ClassIdentity? cameraClass;
        private int playerCameraOffset;
        private int finalCameraOffset;
        private NativeSample? previousContext;
        private LivePosition? previousOrigin;
        private uint previousFrame;
        private long lastProgressMs;
        private bool frameAdvanced;
        private int epoch;
        private long sequence;
        private string lastEpochResetReason = String.Empty;
        private readonly Dictionary<string, long> epochResetCounts = new Dictionary<string, long>(StringComparer.Ordinal);
        private readonly Dictionary<string, long> instabilityCauseCounts = new Dictionary<string, long>(StringComparer.Ordinal);
        private long otherInstabilityCauseCount;

        public NativeCameraDiagnostics Diagnostics { get; private set; } = new NativeCameraDiagnostics();
        public bool IsInitialized { get { return initialized; } }
        public bool InitializationRetryDue
        {
            get
            {
                if (initialized || !initializationRetryPending || nowMilliseconds == null) return false;
                long now = nowMilliseconds();
                return now >= lastInitializationFinishedMs && now - lastInitializationFinishedMs >= InitializationRetryDelayMs;
            }
        }

        public NativeCameraReader(IMemoryReader memory, MonoInspectionReport metadata, CameraProbeReport probe)
            : this(memory, metadata, probe, delegate { return (long)(Stopwatch.GetTimestamp() * (1000.0 / Stopwatch.Frequency)); }) { }

        // Deterministic monotonic-clock seam for acquisition tests. It never
        // controls read budgets, which always use the real operation stopwatch.
        internal NativeCameraReader(IMemoryReader memory, MonoInspectionReport metadata,
            CameraProbeReport probe, Func<long> nowMilliseconds)
        {
            this.memory = memory;
            this.metadata = metadata;
            this.probe = probe;
            this.nowMilliseconds = nowMilliseconds;
            InitializeProfile();
        }

        public bool InitializeProfile()
        {
            initialized = false;
            profileVerified = false;
            initializationAttempts = initializationAttempts == Int64.MaxValue ? Int64.MaxValue : initializationAttempts + 1;
            initializationRetryPending = false;
            failedSignatureName = failedSignatureRva = String.Empty;
            profileValidationScope = "NON_VERIFIE";
            xrGetterVerified = false;
            xrValidationMode = "NON_EVALUE";
            previousContext = null;
            previousOrigin = null;
            frameAdvanced = false;
            classIdentities.Clear();
            localClass = null;
            cameraClass = null;
            ResetPresentationMetadata();
            BeginOperation(1500);
            try
            {
                Diagnostics.Stage = "PROFIL_BINAIRE";
                if (memory == null || nowMilliseconds == null)
                    throw Fault("PROFIL_NATIF_INVALIDE", "Le lecteur memoire ou son horloge manque.");
                moduleBase = memory.ModuleBase(NativeCameraProfile.ModuleName);
                RequirePointer(moduleBase);
                VerifyNativeProfile();
                profileVerified = true;
                profileValidationScope = "NOYAU_CAMERA_VERIFIE_XR_CONDITIONNEL";
                xrValidationMode = "EN_ATTENTE_CAPTURE";
                Diagnostics.ProfileVerified = true;
                Diagnostics.Stage = "METADONNEES_GEREES";
                InitializeManagedMetadata();
                InitializePresentationMetadata();
                initialized = true;
                SetStatus("CAMERA_ATTENTE_RENDU", "Profil natif et metadonnees confirmes ; attente d'une camera active et d'une progression du rendu.");
                return true;
            }
            catch (NativeFault ex)
            {
                lastInitializationFailure = ex.Code + " : " + ex.Message;
                initializationRetryPending =
                    (ex.Code == "CAMERA_LECTURE_INCOMPLETE" && ex.Retryable) || ex.Code == "CAMERA_BUDGET_DEPASSE";
                SetStatus(ex.Code, ex.Message + (initializationRetryPending ?
                    " Nouvelle tentative automatique au plus tot dans 2 s." : String.Empty));
                return false;
            }
            catch (Exception ex)
            {
                SetStatus(profileVerified ? "METADONNEES_CAMERA_INVALIDES" : "PROFIL_NATIF_INVALIDE",
                    "Initialisation camera impossible : " + ShortMessage(ex));
                lastInitializationFailure = Diagnostics.Status + " : " + Diagnostics.Message;
                return false;
            }
            finally
            {
                // The worker schedules retries outside Capture. A slow failed
                // initialization must not consume its own cooldown period.
                lastInitializationFinishedMs = nowMilliseconds == null ? 0 : nowMilliseconds();
                CompleteOperation();
            }
        }

        public LiveCameraFrame? Capture(ulong local, ulong domain, LivePosition origin)
        {
            if (!initialized)
                return null; // Preserve the actionable initialization diagnostic.
            BeginOperation(CaptureBudgetMs);
            try
            {
                Diagnostics.Stage = "IDENTITES";
                if (origin == null || !Finite(origin.X) || !Finite(origin.Y) || !Finite(origin.Z))
                    throw Fault("CAMERA_IDENTITE_INVALIDE", "Origine du monde absente ou non finie.");
                RequirePointer(local);
                RequirePointer(domain);
                if (memory.ModuleBase(NativeCameraProfile.ModuleName) != moduleBase)
                {
                    InvalidateProfile();
                    throw Fault("PROFIL_NATIF_INVALIDE", "Le module Unity a change ; une nouvelle inspection de session est requise.");
                }
                NativeFault? lastFault = null;
                for (int attempt = 1; attempt <= MaximumAttempts; attempt++)
                {
                    Diagnostics.Attempts = attempt;
                    try
                    {
                        ManagedIdentity localIdentity, cameraIdentity;
                        ReadObjectGraph(local, domain, out localIdentity, out cameraIdentity);
                        RequirePointer(cameraIdentity.Native);
                        PresentationState presentationBefore = ReadPresentation(local, domain, cameraIdentity.Instance);
                        ObservePresentation(presentationBefore, false);
                        // The preflight only identifies external dependencies.
                        // Volatile mode/rect/clip values are captured with the
                        // matrices below, never borrowed from this earlier walk.
                        NativeState hints = ReadExternalHints(cameraIdentity.Native);
                        EnvironmentState environmentBefore = ReadEnvironment(hints);
                        Diagnostics.Stage = "LECTURE_ETAT_NATIF_RAPPROCHEE";
                        Diagnostics.NativePairReadBytes = NativeCaptureSize;
                        // These two reads must stay consecutive. Both include
                        // matrices AND their interpreting camera configuration;
                        // requiring a mode/rect to survive the separate global
                        // and identity walks rejected coherent render instants.
                        long pairStarted = Stopwatch.GetTimestamp();
                        byte[] firstBlock = Read(cameraIdentity.Native, NativeCaptureSize);
                        byte[] secondBlock = Read(cameraIdentity.Native, NativeCaptureSize);
                        Diagnostics.MatrixPairMilliseconds =
                            (Stopwatch.GetTimestamp() - pairStarted) * (1000.0 / Stopwatch.Frequency);
                        NativeState first = ParseNativeState(firstBlock);
                        NativeState second = ParseNativeState(secondBlock);
                        ObserveNativePair(first, second);
                        byte[] firstMatrices = SelectMatrices(first, presentationBefore.Active);
                        byte[] secondMatrices = SelectMatrices(second, presentationBefore.Active);
                        ObserveMatrices(secondMatrices);
                        ValidateNativeState(first, presentationBefore.Active);
                        ValidateNativeState(second, presentationBefore.Active);
                        Diagnostics.Stage = "COHERENCE_CAPTURE";
                        if (!SameBytes(firstMatrices, secondMatrices))
                            throw Fault("CAMERA_CAPTURE_INSTABLE", "Une matrice a change entre les deux lectures DMA rapprochees.", true,
                                "MATRICES", MatrixDifference(firstMatrices, secondMatrices));
                        // If an external dependency appeared after preflight,
                        // its state was not bracketed. Retry with that dependency
                        // rather than assume it was unchanged or inactive.
                        if (hints.CustomBuffer != first.CustomBuffer || hints.DynamicRequest != first.DynamicRequest)
                            throw Fault("CAMERA_CAPTURE_INSTABLE", "Les dependances externes de la camera ont change avant la paire native.", true,
                                "CONFIGURATION", "Camera.externalDependencies");
                        NativeSample opening = CreateSample(localIdentity, cameraIdentity, first, environmentBefore, presentationBefore);
                        NativeSample sample = CreateSample(localIdentity, cameraIdentity, second, environmentBefore, presentationBefore);
                        Diagnostics.RawViewportPhaseBefore = ApplyPresentation(opening);
                        Diagnostics.RawViewportPhaseAfter = ApplyPresentation(sample);
                        ObserveConfiguration(sample);
                        string differenceKind;
                        string? difference = SampleDifference(opening, sample, out differenceKind);
                        if (difference != null)
                            throw Fault("CAMERA_CAPTURE_INSTABLE", "La configuration camera a change entre les deux blocs natifs : " + difference + ".", true,
                                differenceKind, difference);
                        // Dimensions, external targets, XR and render progress
                        // are sampled on both sides of the native pair. A camera
                        // field changing only AFTER that pair does not replace
                        // its already coherent configuration.
                        EnvironmentState environmentAfter = ReadEnvironment(second);
                        sample = CreateSample(localIdentity, cameraIdentity, second, environmentAfter, presentationBefore);
                        Diagnostics.RawViewportPhaseAfter = ApplyPresentation(sample);
                        ObserveConfiguration(sample);
                        difference = SampleDifference(opening, sample, out differenceKind);
                        if (difference != null)
                            throw Fault("CAMERA_CAPTURE_INSTABLE", "La sortie ou une dependance camera a change autour de la paire native : " + difference + ".", true,
                                differenceKind, difference);
                        if (CounterRegressed(opening.RenderedFrame, sample.RenderedFrame))
                            throw Fault("CAMERA_CAPTURE_INSTABLE", "Le compteur de rendu a regresse pendant la mini-capture.", true,
                                "COMPTEUR_RENDU", "RenderedFrameCount regressed around matrix pair");
                        Diagnostics.Stage = "PRESENTATION_FINALE";
                        PresentationState presentationAfter = ReadPresentation(local, domain, cameraIdentity.Instance);
                        string? presentationDifference = PresentationDifference(presentationBefore, presentationAfter);
                        if (presentationDifference != null)
                            throw Fault("CAMERA_CAPTURE_INSTABLE", "La presentation finale de la camera a change pendant la capture : " + presentationDifference + ".", true,
                                "PRESENTATION", presentationDifference);
                        sample.Presentation = presentationAfter;
                        ValidatePresentationForSample(presentationAfter, sample);
                        ObservePresentation(presentationAfter, true);
                        // Close native and Mono identities after the managed
                        // presentation walk as well as the adjacent matrix pair.
                        Diagnostics.Stage = "IDENTITES_FINALES";
                        uint finalRenderedFrame = VerifyClosingIdentities(sample, local, domain);
                        if (CounterRegressed(sample.RenderedFrame, finalRenderedFrame))
                            throw Fault("CAMERA_CAPTURE_INSTABLE", "Le compteur de rendu a regresse pendant le controle final.", true,
                                "COMPTEUR_RENDU", "RenderedFrameCount regressed during closing identity checks");
                        sample.RenderedFrame = finalRenderedFrame;
                        Diagnostics.RenderedFrameCount = finalRenderedFrame;
                        float[] view = Floats(secondMatrices, 0);
                        float[] projection = Floats(secondMatrices, 64);
                        Diagnostics.Stage = "MATRICES";
                        ValidateMatrices(view, projection, sample);
                        Diagnostics.MatricesValidated = true;
                        Diagnostics.Stage = "PROGRESSION_RENDU";
                        if (!ConfirmRenderProgress(sample, origin)) return null;
                        float[] combined = MultiplyColumnMajorToRowMajor(projection, view);
                        float viewportX = sample.Rect[0] * sample.Width;
                        float viewportWidth = sample.Rect[2] * sample.Width;
                        float viewportHeight = sample.Rect[3] * sample.Height;
                        float viewportY = (1f - sample.Rect[1] - sample.Rect[3]) * sample.Height;
                        // Round-off at the edge of a full-height rect must not
                        // turn an otherwise valid viewport into a negative one.
                        viewportX = Math.Max(0, viewportX);
                        viewportY = Math.Max(0, viewportY);
                        viewportWidth = Math.Min(viewportWidth, sample.Width - viewportX);
                        viewportHeight = Math.Min(viewportHeight, sample.Height - viewportY);
                        CheckBudget();
                        sequence = sequence == Int64.MaxValue ? 1 : sequence + 1;
                        Diagnostics.Sequence = sequence;
                        Diagnostics.CameraEpoch = epoch;
                        SetStatus("CAMERA_PRETE", presentationAfter.Active ?
                            "Matrices non jitterees, presentation finale " + Diagnostics.PresentationMode + " et progression du rendu confirmees." :
                            "Matrices natives, camera active, sortie et progression du rendu confirmees.");
                        return new LiveCameraFrame {
                            ProfileId = NativeCameraProfile.ProfileId,
                            ViewProjection = combined,
                            SourceWidth = sample.Width, SourceHeight = sample.Height,
                            ViewportX = viewportX, ViewportY = viewportY,
                            ViewportWidth = viewportWidth, ViewportHeight = viewportHeight,
                            ClipDepth = "MinusOneToOne", Sequence = sequence,
                            CameraEpoch = epoch, ReadDurationMs = clock.Elapsed.TotalMilliseconds
                        };
                    }
                    catch (NativeFault ex)
                    {
                        RecordFault(ex);
                        lastFault = ex;
                        if (!ex.Retryable || attempt == MaximumAttempts || clock.ElapsedMilliseconds >= CaptureBudgetMs - 5) throw;
                    }
                }
                throw lastFault ?? Fault("CAMERA_CAPTURE_INSTABLE", "Aucune capture coherente disponible.");
            }
            catch (NativeFault ex)
            {
                RecordFault(ex);
                Diagnostics.MatricesValidated = false;
                SetStatus(ex.Code, ex.Message);
                return null;
            }
            catch (Exception ex)
            {
                Diagnostics.MatricesValidated = false;
                Diagnostics.InstabilityKind = "LECTURE";
                Diagnostics.InstabilityDetail = ShortMessage(ex);
                SetStatus("CAMERA_LECTURE_INCOMPLETE", "Lecture camera interrompue : " + ShortMessage(ex));
                return null;
            }
            finally { CompleteOperation(); }
        }

        private void VerifyNativeProfile()
        {
            byte[] dos = Read(moduleBase, 64);
            if (dos[0] != (byte)'M' || dos[1] != (byte)'Z')
                throw Fault("PROFIL_NATIF_INVALIDE", "En-tete DOS Unity invalide.");
            int peOffset = BitConverter.ToInt32(dos, 0x3C);
            if (peOffset < 64 || peOffset > 4096)
                throw Fault("PROFIL_NATIF_INVALIDE", "Position de l'en-tete PE hors limites.");
            byte[] pe = Read(moduleBase + (ulong)peOffset, 0x108);
            int sectionCount = BitConverter.ToUInt16(pe, 6);
            int optionalSize = BitConverter.ToUInt16(pe, 20);
            if (BitConverter.ToUInt32(pe, 0) != 0x4550 ||
                BitConverter.ToUInt16(pe, 4) != NativeCameraProfile.Machine ||
                BitConverter.ToUInt32(pe, 8) != NativeCameraProfile.PeTimestamp ||
                BitConverter.ToUInt16(pe, 24) != NativeCameraProfile.OptionalHeaderMagic ||
                BitConverter.ToUInt32(pe, 80) != NativeCameraProfile.ImageSize ||
                optionalSize < 0x70 || optionalSize > 0x400 || sectionCount < 1 || sectionCount > 96)
                throw Fault("PROFIL_NATIF_INVALIDE", "Ce module Unity ne correspond pas au binaire exact analyse.");
            byte[] sections = Read(moduleBase + (ulong)(peOffset + 24 + optionalSize), sectionCount * 40);
            bool textFound = false, rdataFound = false;
            for (int i = 0; i < sectionCount; i++)
            {
                int offset = i * 40;
                string name = Encoding.ASCII.GetString(sections, offset, 8).TrimEnd('\0');
                uint size = BitConverter.ToUInt32(sections, offset + 8);
                uint rva = BitConverter.ToUInt32(sections, offset + 12);
                if (name == ".text") textFound = rva == NativeCameraProfile.TextRva && size == NativeCameraProfile.TextSize;
                if (name == ".rdata") rdataFound = rva == NativeCameraProfile.ReadOnlyDataRva && size == NativeCameraProfile.ReadOnlyDataSize;
            }
            if (!textFound || !rdataFound)
                throw Fault("PROFIL_NATIF_INVALIDE", "Sections natives Unity differentes du profil.");
            foreach (NativeCameraSignature signature in NativeCameraProfile.Signatures)
                if (!signature.RequiresXrManager) VerifyNativeSignature(signature);
        }

        private void VerifyNativeSignature(NativeCameraSignature signature)
        {
            byte[] expected = Convert.FromHexString(signature.BytesHex);
            byte[] actual;
            try { actual = Read(moduleBase + signature.Rva, expected.Length); }
            catch (NativeFault ex)
            {
                RecordFailedSignature(signature);
                throw Fault(ex.Code, "Verification de " + signature.Name + " (" + failedSignatureRva + ") : " + ex.Message,
                    ex.Retryable, ex.Kind, ex.Detail);
            }
            if (!SameBytes(actual, expected))
            {
                RecordFailedSignature(signature);
                throw Fault("PROFIL_NATIF_INVALIDE", "Signature native differente : " + signature.Name + " (" + failedSignatureRva + ").",
                    false, "PROFIL", signature.Name);
            }
            if (failedSignatureName == signature.Name)
                failedSignatureName = failedSignatureRva = String.Empty;
        }

        private void RecordFailedSignature(NativeCameraSignature signature)
        {
            failedSignatureName = signature.Name;
            failedSignatureRva = "0x" + signature.Rva.ToString("X", CultureInfo.InvariantCulture);
            Diagnostics.FailedSignatureName = failedSignatureName;
            Diagnostics.FailedSignatureRva = failedSignatureRva;
        }

        private void VerifyXrGetterBeforeUse()
        {
            if (xrGetterVerified) return;
            Diagnostics.Stage = "VALIDATION_DEPENDANCE_XR";
            xrValidationMode = "GETTER_XR_REQUIS";
            try
            {
                foreach (NativeCameraSignature signature in NativeCameraProfile.Signatures)
                    if (signature.RequiresXrManager) VerifyNativeSignature(signature);
                xrGetterVerified = true;
            }
            catch (NativeFault ex)
            {
                if (ex.Code == "PROFIL_NATIF_INVALIDE")
                {
                    InvalidateProfile();
                    xrValidationMode = "SIGNATURE_XR_DIFFERENTE";
                }
                else xrValidationMode = "GETTER_XR_NON_VERIFIE";
                throw;
            }
            Diagnostics.Stage = "CONFIGURATION_SORTIE";
        }

        private void InvalidateProfile()
        {
            initialized = false;
            profileVerified = false;
            initializationRetryPending = false;
            profileValidationScope = "INVALIDE";
            xrGetterVerified = false;
        }

        private void InitializeManagedMetadata()
        {
            if (metadata == null || probe == null || metadata.SelectedLayout != MonoLayout ||
                (metadata.Status != "METADONNEES_PARTIELLES" && metadata.Status != "METADONNEES_COLLECTEES") ||
                metadata.Classes == null || probe.LocalClass == null || probe.Objects == null)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Le rapport Mono courant et le releve camera sont requis.");
            MonoClassReport localReport = UniqueClass(metadata.Classes, "EntityPlayerLocal", "");
            MonoClassReport localProbe = probe.LocalClass;
            if (localProbe.Name != localReport.Name || !String.IsNullOrEmpty(localProbe.Namespace) ||
                ParseAddress(localProbe.Address) != ParseAddress(localReport.Address) || localProbe.InstanceSize != localReport.InstanceSize)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Le releve camera ne correspond pas a la classe locale de cette session.");
            CameraObjectReport player = UniqueObject("playerCamera");
            CameraObjectReport final = UniqueObject("finalCamera");
            if (!player.IdentityValidated || !final.IdentityValidated ||
                player.ActualType != "UnityEngine.Camera" || final.ActualType != "UnityEngine.Camera" ||
                player.NativePointerFieldOffset != 16 || final.NativePointerFieldOffset != 16 ||
                player.ClassHierarchy == null || final.ClassHierarchy == null ||
                player.ClassHierarchy.Count < 2 || player.ClassHierarchy.Count > 12 ||
                final.ClassHierarchy.Count != player.ClassHierarchy.Count)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "L'identite UnityEngine.Camera et m_CachedPtr ne sont pas confirmees.");
            for (int i = 0; i < player.ClassHierarchy.Count; i++)
            {
                MonoClassReport a = player.ClassHierarchy[i], b = final.ClassHierarchy[i];
                if (a.Name != b.Name || a.Namespace != b.Namespace || a.InstanceSize != b.InstanceSize ||
                    ParseAddress(a.Address) != ParseAddress(b.Address))
                    throw Fault("METADONNEES_CAMERA_INVALIDES", "Les types des deux references camera ne correspondent pas.");
            }
            if (FullName(player.ClassHierarchy[0]) != "UnityEngine.Camera" ||
                FullName(player.ClassHierarchy[player.ClassHierarchy.Count - 1]) != "System.Object")
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Heritage de la camera inattendu.");
            localClass = ReadClassIdentity(localProbe);
            classIdentities.Add(localClass);
            ClassIdentity? objectClass = null;
            MonoClassReport? objectReport = null;
            for (int i = 0; i < player.ClassHierarchy.Count; i++)
            {
                ClassIdentity identity = ReadClassIdentity(player.ClassHierarchy[i]);
                ulong expectedParent = i + 1 < player.ClassHierarchy.Count ? ParseAddress(player.ClassHierarchy[i + 1].Address) : 0;
                if (identity.Parent != expectedParent || identity.Size > player.ClassHierarchy[0].InstanceSize)
                    throw Fault("METADONNEES_CAMERA_INVALIDES", "Heritage natif Mono de la camera incoherent.");
                if (i == 0) cameraClass = identity;
                if (FullName(player.ClassHierarchy[i]) == "UnityEngine.Object")
                {
                    if (objectClass != null)
                        throw Fault("METADONNEES_CAMERA_INVALIDES", "Classe UnityEngine.Object dupliquee dans l'heritage.");
                    objectClass = identity;
                    objectReport = player.ClassHierarchy[i];
                }
                classIdentities.Add(identity);
            }
            if (cameraClass == null || objectClass == null || objectReport == null)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Classes Unity manquantes.");
            MonoFieldReport playerField = RequiredField(localProbe, "playerCamera", "UnityEngine.Camera", 0x12);
            MonoFieldReport finalField = RequiredField(localProbe, "finalCamera", "UnityEngine.Camera", 0x12);
            MatchField(playerField, RequiredField(localReport, "playerCamera", "UnityEngine.Camera", 0x12));
            MatchField(finalField, RequiredField(localReport, "finalCamera", "UnityEngine.Camera", 0x12));
            if (playerField.Offset == finalField.Offset)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Les deux champs camera partagent un offset ambigu.");
            VerifyLiveFields(localClass, localProbe, new[] { playerField, finalField }, cameraClass.Address);
            MonoFieldReport cachedPtr = RequiredField(objectReport, "m_CachedPtr", "System.IntPtr", 0x18);
            if (cachedPtr.Offset != NativeCameraProfile.ManagedNativePointerOffset)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "L'offset m_CachedPtr ne correspond pas au wrapper natif analyse.");
            VerifyLiveFields(objectClass, objectReport, new[] { cachedPtr }, 0);
            playerCameraOffset = playerField.Offset;
            finalCameraOffset = finalField.Offset;
        }

        private void ReadObjectGraph(ulong local, ulong domain, out ManagedIdentity localIdentity, out ManagedIdentity cameraIdentity)
        {
            Diagnostics.Stage = "IDENTITES";
            ulong? localRuntime = null, cameraRuntime = null;
            foreach (ClassIdentity identity in classIdentities)
            {
                bool isLocal = Object.ReferenceEquals(identity, localClass);
                bool isCamera = Object.ReferenceEquals(identity, cameraClass);
                ulong? runtime = VerifyClassStable(identity, isLocal || isCamera);
                if (isLocal) localRuntime = runtime;
                if (isCamera) cameraRuntime = runtime;
            }
            // Each runtime pointer belongs to this pass's fresh class header.
            // The closing graph repeats both reads; none is kept for a later
            // pass, capture or rendering epoch.
            localIdentity = ReadManagedIdentity(local, localClass!, domain, false, observedRuntime: localRuntime);
            ulong player, final;
            int min = Math.Min(playerCameraOffset, finalCameraOffset), span = Math.Abs(playerCameraOffset - finalCameraOffset) + 8;
            if (span <= 64)
            {
                byte[] references = Read(local + (ulong)min, span);
                player = BitConverter.ToUInt64(references, playerCameraOffset - min);
                final = BitConverter.ToUInt64(references, finalCameraOffset - min);
            }
            else { player = U64(local + (ulong)playerCameraOffset); final = U64(local + (ulong)finalCameraOffset); }
            if (player == 0 || final == 0)
                throw Fault("CAMERA_IDENTITE_INVALIDE", "Une reference camera est nulle ; attente du chargement.", true);
            if (player != final)
                throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "Les cameras joueur et finale sont distinctes ; desactive la resolution dynamique pour ce profil.");
            cameraIdentity = ReadManagedIdentity(player, cameraClass!, domain, true, observedRuntime: cameraRuntime);
        }

        private NativeState ReadExternalHints(ulong native)
        {
            // Only these two fields select memory outside the camera object.
            // Projection mode, rect, clips and dirty state intentionally are not
            // interpreted until their bytes are captured beside the matrices.
            const int start = NativeCameraProfile.TargetTextureIdOffset;
            byte[] hints = Read(native + start, NativeCameraProfile.DynamicResolutionRequestOffset + 1 - start);
            return new NativeState {
                CustomBuffer = BitConverter.ToUInt64(hints, NativeCameraProfile.CustomBufferOffset - start),
                DynamicRequest = hints[NativeCameraProfile.DynamicResolutionRequestOffset - start]
            };
        }

        private static NativeState ParseNativeState(byte[] block)
        {
            byte[] matrices = new byte[128];
            Buffer.BlockCopy(block, NativeCameraProfile.ViewOffset, matrices, 0, matrices.Length);
            byte[] nonJitteredProjection = new byte[64];
            Buffer.BlockCopy(block, NativeCameraProfile.NonJitteredProjectionOffset, nonJitteredProjection, 0, 64);
            float[] rect = new float[4];
            for (int i = 0; i < rect.Length; i++)
                rect[i] = BitConverter.ToSingle(block, NativeCameraProfile.RectOffset + i * 4);
            return new NativeState {
                NativeVtable = BitConverter.ToUInt64(block, 0),
                Active = block[NativeCameraProfile.ActiveOffset],
                ProjectionDirty = block[NativeCameraProfile.ProjectionDirtyOffset],
                NonJitteredExplicit = block[NativeCameraProfile.NonJitteredExplicitOffset],
                TargetTexture = BitConverter.ToInt32(block, NativeCameraProfile.TargetTextureIdOffset),
                TargetDisplay = BitConverter.ToInt32(block, NativeCameraProfile.TargetDisplayOffset),
                CustomBuffer = BitConverter.ToUInt64(block, NativeCameraProfile.CustomBufferOffset),
                ImplicitView = block[NativeCameraProfile.ImplicitViewOffset],
                Orthographic = block[NativeCameraProfile.OrthographicOffset],
                DynamicRequest = block[NativeCameraProfile.DynamicResolutionRequestOffset],
                ProjectionMode = BitConverter.ToInt32(block, NativeCameraProfile.ProjectionModeOffset),
                Near = BitConverter.ToSingle(block, NativeCameraProfile.NearClipOffset),
                Far = BitConverter.ToSingle(block, NativeCameraProfile.FarClipOffset),
                Rect = rect, Matrices = matrices, NonJitteredProjection = nonJitteredProjection
            };
        }

        private static byte[] SelectMatrices(NativeState state, bool useNonJitteredProjection)
        {
            if (!useNonJitteredProjection) return state.Matrices;
            byte[] selected = (byte[])state.Matrices.Clone();
            Buffer.BlockCopy(state.NonJitteredProjection, 0, selected, 64, 64);
            return selected;
        }

        private void ValidateNativeState(NativeState state, bool useNonJitteredProjection)
        {
            RequireReadOnlyPointer(state.NativeVtable, 8);
            if (!InText(U64(state.NativeVtable)))
                throw Fault("CAMERA_IDENTITE_INVALIDE", "Table native de la camera hors du module confirme.", true);
            if (state.Active == 0)
                throw Fault("CAMERA_INACTIVE", "La camera de la partie n'est pas active.");
            // The verified non-jittered getter reads its separate storage only
            // while the explicit flag is set. Its value does not depend on the
            // ordinary P cache or that cache's dirty flag. The standard path
            // continues to require its own consumed projection to be clean.
            if (useNonJitteredProjection && state.NonJitteredExplicit != 1)
                throw Fault("CAMERA_CAPTURE_INSTABLE", "La projection sans jitter n'est pas explicitement disponible dans la paire native.", true,
                    "PROJECTION_NON_JITTEREE", "Camera.nonJitteredExplicit != 1");
            if (!useNonJitteredProjection && state.ProjectionDirty != 0)
                throw Fault("CAMERA_CAPTURE_INSTABLE", "Le cache de projection est en cours de recalcul dans la paire native.", true,
                    "PROJECTION_EN_COURS", "Camera.projectionDirty != 0");
            if (state.TargetTexture != 0 || state.TargetDisplay != 0)
                throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "Ce profil requiert la sortie principale du jeu sans RenderTexture cible.");
            if (state.ImplicitView > 1 || state.Orthographic > 1 || state.DynamicRequest > 1 ||
                state.ProjectionMode < 0 || state.ProjectionMode > 2)
                throw Fault("CAMERA_IDENTITE_INVALIDE", "Indicateurs natifs de camera incoherents.", true);
            // The context copies physical-camera state during SetupContext;
            // the native mode can change before the next managed update.
            // Modes 0/1 are the normal explicit/reset projection phases.
            if (useNonJitteredProjection && state.ProjectionMode == 2)
                throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "La reconstruction avec une camera physique n'est pas prise en charge.", false,
                    "PRESENTATION", "Upscaler.nativePhysicalCamera");
            if (!AllFinite(state.Rect) || state.Rect[0] < -0.00001f || state.Rect[1] < -0.00001f ||
                state.Rect[2] <= 0 || state.Rect[3] <= 0 || state.Rect[0] + state.Rect[2] > 1.00001f ||
                state.Rect[1] + state.Rect[3] > 1.00001f)
                throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "Le viewport normalise sort de la surface du jeu.");
        }

        private EnvironmentState ReadEnvironment(NativeState state)
        {
            Diagnostics.Stage = "CONFIGURATION_SORTIE";
            byte customInactive = 0;
            if (state.CustomBuffer != 0)
            {
                RequirePointer(state.CustomBuffer);
                customInactive = Read(state.CustomBuffer + 0x33, 1)[0];
                if (customInactive == 0)
                    throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "Un buffer de rendu particulier remplace la sortie ecran standard.");
            }
            ulong graphics = 0;
            byte graphicsDynamic = 0;
            if (state.DynamicRequest != 0)
            {
                graphics = Pointer(moduleBase + NativeCameraProfile.GraphicsGlobalRva);
                graphicsDynamic = Read(graphics + NativeCameraProfile.GraphicsDynamicResolutionOffset, 1)[0];
                if (graphicsDynamic != 0)
                    throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "La resolution dynamique native est active ; desactive-la pour ce profil.");
            }
            ulong screen = Pointer(moduleBase + NativeCameraProfile.ScreenGlobalRva);
            ulong screenVtable = Pointer(screen);
            RequireReadOnlyPointer(screenVtable, NativeCameraProfile.ScreenHeightVirtualSlot + 8);
            byte[] screenMethods = Read(screenVtable + NativeCameraProfile.ScreenWidthVirtualSlot, 16);
            if (BitConverter.ToUInt64(screenMethods, 0) != moduleBase + NativeCameraProfile.ScreenWidthMethodRva ||
                BitConverter.ToUInt64(screenMethods, 8) != moduleBase + NativeCameraProfile.ScreenHeightMethodRva)
                throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "L'implementation de la sortie ecran differe du profil Windows analyse.");
            byte[] screenState = Read(screen + NativeCameraProfile.ScreenWidthOffset, 29);
            int width = BitConverter.ToInt32(screenState, 0), height = BitConverter.ToInt32(screenState, 12);
            if (width < 64 || height < 64 || width > 16384 || height > 16384)
                throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "Dimensions de sortie du jeu absentes ou hors limites.");
            if (screenState[28] != 0)
                throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "La sortie stereoscopique n'est pas prise en charge par ce profil.");
            ulong xr = U64(moduleBase + NativeCameraProfile.XrGlobalRva), xrVtable = 0;
            xrValidationMode = xr == 0 ? "GESTIONNAIRE_ABSENT" : "GESTIONNAIRE_PRESENT_A_VERIFIER";
            if (xr != 0)
            {
                RequirePointer(xr);
                xrVtable = Pointer(xr);
                RequireReadOnlyPointer(xrVtable, NativeCameraProfile.XrEnabledVirtualSlot + 8);
                if (U64(xrVtable + NativeCameraProfile.XrEnabledVirtualSlot) != moduleBase + NativeCameraProfile.XrEnabledMethodRva)
                {
                    xrValidationMode = "IMPLEMENTATION_XR_NON_SUPPORTEE";
                    throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "L'implementation XR presente n'est pas identifiee par ce profil.");
                }
                // The signed native null gate does not consult this getter
                // while no XR manager exists. A newly appearing manager must
                // validate the getter before any use of its enabled offset.
                VerifyXrGetterBeforeUse();
                xrValidationMode = "GESTIONNAIRE_PRESENT_GETTER_VERIFIE";
                if (Read(xr + NativeCameraProfile.XrEnabledOffset, 1)[0] != 0)
                {
                    xrValidationMode = "XR_ACTIF_NON_SUPPORTE";
                    throw Fault("CAMERA_CONFIGURATION_NON_SUPPORTEE", "Le rendu XR est actif ; ce profil vise une sortie ecran classique.");
                }
            }
            ulong time = Pointer(moduleBase + NativeCameraProfile.TimeGlobalRva);
            uint rendered = BitConverter.ToUInt32(Read(time + NativeCameraProfile.RenderedFrameCountOffset, 4), 0);
            return new EnvironmentState {
                CustomInactive = customInactive, Graphics = graphics, GraphicsDynamic = graphicsDynamic,
                Screen = screen, ScreenVtable = screenVtable, Width = width, Height = height,
                Xr = xr, XrVtable = xrVtable, Time = time, RenderedFrame = rendered
            };
        }

        private static NativeSample CreateSample(ManagedIdentity local, ManagedIdentity camera,
            NativeState state, EnvironmentState environment, PresentationState presentation)
        {
            return new NativeSample {
                Local = local, Camera = camera, Native = camera.Native,
                NativeVtable = state.NativeVtable, Active = state.Active,
                CustomBuffer = state.CustomBuffer, CustomInactive = environment.CustomInactive,
                ImplicitView = state.ImplicitView, Orthographic = state.Orthographic, ProjectionMode = state.ProjectionMode,
                DynamicRequest = state.DynamicRequest, Graphics = environment.Graphics, GraphicsDynamic = environment.GraphicsDynamic,
                Screen = environment.Screen, ScreenVtable = environment.ScreenVtable, Width = environment.Width, Height = environment.Height,
                Xr = environment.Xr, XrVtable = environment.XrVtable, Time = environment.Time, RenderedFrame = environment.RenderedFrame,
                Rect = state.Rect, RawRect = state.Rect, Near = state.Near, Far = state.Far,
                Presentation = presentation
            };
        }

        private string ApplyPresentation(NativeSample sample)
        {
            PresentationState presentation = sample.Presentation;
            ValidatePresentationForSample(presentation, sample);
            if (!presentation.Active) return "NATIVE";
            // ConfigureCameraViewport saves _originalRect and scales only the
            // internal rendering viewport. ResetCameraViewport restores it.
            // Both raw phases are legitimate; any third geometry is rejected.
            float[] reduced = {
                0, 0,
                presentation.OriginalRect[2] * presentation.RenderWidth / presentation.DisplayWidth,
                presentation.OriginalRect[3] * presentation.RenderHeight / presentation.DisplayHeight
            };
            string phase = SamePresentationRect(sample.RawRect, presentation.OriginalRect) ? "PRESENTATION" :
                SamePresentationRect(sample.RawRect, reduced) ? "INTERNAL_RENDER" : String.Empty;
            if (phase.Length == 0)
                throw Fault("CAMERA_CAPTURE_INSTABLE", "Le viewport natif ne correspond a aucune phase du traitement confirme.", true,
                    "PRESENTATION", "Camera.normalizedRect outside original/render phases");
            sample.Rect = (float[])presentation.OriginalRect.Clone();
            return phase;
        }

        private static bool SamePresentationRect(float[] actual, float[] expected)
        {
            if (actual.Length != 4 || expected.Length != 4) return false;
            // At most 0.017 physical pixel for the supported 16384-pixel source.
            // This covers float operation rounding, not arbitrary viewport drift.
            for (int i = 0; i < 4; i++)
                if (!Finite(actual[i]) || !Finite(expected[i]) || Math.Abs(actual[i] - expected[i]) > 0.000001f) return false;
            return true;
        }

        private uint VerifyClosingIdentities(NativeSample sample, ulong local, ulong domain)
        {
            ManagedIdentity localAfter, cameraAfter;
            ReadObjectGraph(local, domain, out localAfter, out cameraAfter);
            string? managedDifference = ManagedDifference(sample.Local, localAfter, "Local") ??
                ManagedDifference(sample.Camera, cameraAfter, "Camera");
            if (managedDifference != null)
                throw Fault("CAMERA_CAPTURE_INSTABLE", "Une reference Mono a change apres les matrices : " + managedDifference + ".", true,
                    "IDENTITE", managedDifference);
            byte[] nativeHead = Read(sample.Native, 0x40);
            if (BitConverter.ToUInt64(nativeHead, 0) != sample.NativeVtable)
                throw Fault("CAMERA_CAPTURE_INSTABLE", "La table native de la camera a change apres les matrices.", true,
                    "IDENTITE", "Camera.nativeVtable");
            if (nativeHead[NativeCameraProfile.ActiveOffset] == 0)
                throw Fault("CAMERA_INACTIVE", "La camera est devenue inactive pendant le controle final.");
            if (U64(moduleBase + NativeCameraProfile.ScreenGlobalRva) != sample.Screen ||
                U64(sample.Screen) != sample.ScreenVtable)
                throw Fault("CAMERA_CAPTURE_INSTABLE", "L'objet de sortie ecran a change apres les matrices.", true,
                    "IDENTITE", "Screen.pointer/vtable");
            if (U64(moduleBase + NativeCameraProfile.TimeGlobalRva) != sample.Time)
                throw Fault("CAMERA_CAPTURE_INSTABLE", "Le gestionnaire de temps a change apres les matrices.", true,
                    "IDENTITE", "Time.manager");
            if (U64(moduleBase + NativeCameraProfile.XrGlobalRva) != sample.Xr ||
                (sample.Xr != 0 && U64(sample.Xr) != sample.XrVtable))
                throw Fault("CAMERA_CAPTURE_INSTABLE", "Le gestionnaire XR a change apres les matrices.", true,
                    "IDENTITE", "XR.pointer/vtable");
            if (sample.DynamicRequest != 0 && U64(moduleBase + NativeCameraProfile.GraphicsGlobalRva) != sample.Graphics)
                throw Fault("CAMERA_CAPTURE_INSTABLE", "Le peripherique graphique a change apres les matrices.", true,
                    "IDENTITE", "Graphics.pointer");
            // The view may legitimately advance while these durable identities
            // are read. Do not compare it again or substitute a later view into
            // the already coherent matrix/viewport pair.
            return BitConverter.ToUInt32(Read(sample.Time + NativeCameraProfile.RenderedFrameCountOffset, 4), 0);
        }

        private ManagedIdentity ReadManagedIdentity(ulong instance, ClassIdentity expected, ulong domain, bool native,
            ulong? observedRuntime = null)
        {
            RequirePointer(instance);
            byte[] objectHeader = Read(instance, native ? 24 : 16);
            ulong table = BitConverter.ToUInt64(objectHeader, 0);
            RequirePointer(table);
            byte[] tableHeader = Read(table, 24);
            if (BitConverter.ToUInt64(tableHeader, 0) != expected.Address || BitConverter.ToUInt64(tableHeader, 16) != domain)
                throw Fault("CAMERA_IDENTITE_INVALIDE", "La classe ou le domaine Mono d'un objet camera/local a change.", true);
            ulong runtime = observedRuntime ?? U64(expected.Address + 0xD0);
            RequirePointer(runtime);
            // Even a single-domain runtime contains the first table at +8.
            // Capture it beside the count; larger domain lists still read
            // every remaining slot and retain the same uniqueness checks.
            byte[] runtimeHeader = Read(runtime, 16);
            int maximum = BitConverter.ToUInt16(runtimeHeader, 0);
            if (maximum >= 32)
                throw Fault("CAMERA_IDENTITE_INVALIDE", "Nombre de domaines Mono hors limites.");
            byte[] remainingTables = maximum == 0 ? Array.Empty<byte>() : Read(runtime + 16, maximum * 8);
            ulong slot = 0;
            for (int i = 0; i <= maximum; i++)
                if ((i == 0 ? BitConverter.ToUInt64(runtimeHeader, 8) :
                    BitConverter.ToUInt64(remainingTables, (i - 1) * 8)) == table)
                {
                    if (slot != 0) throw Fault("CAMERA_IDENTITE_INVALIDE", "Vtable Mono enregistree plusieurs fois.");
                    slot = runtime + 8 + (ulong)i * 8;
                }
            if (slot == 0) throw Fault("CAMERA_IDENTITE_INVALIDE", "Vtable Mono absente des domaines de sa classe.", true);
            return new ManagedIdentity { Instance = instance, Table = table, Domain = domain,
                Runtime = runtime, Slot = slot, Native = native ? BitConverter.ToUInt64(objectHeader, 16) : 0 };
        }

        private bool ConfirmRenderProgress(NativeSample sample, LivePosition origin)
        {
            long now = nowMilliseconds();
            uint delta = unchecked(sample.RenderedFrame - previousFrame);
            string? resetReason = previousContext == null || previousOrigin == null ? "INITIAL_CONTEXT" :
                ContextDifference(previousContext, sample);
            if (resetReason == null && !SamePosition(previousOrigin!, origin)) resetReason = "ORIGIN_CHANGED";
            if (resetReason == null && now < lastProgressMs) resetReason = "CLOCK_REGRESSED";
            if (resetReason == null && delta != 0 && delta > Int32.MaxValue) resetReason = "RENDER_COUNTER_RESET";
            if (resetReason != null)
            {
                epoch = epoch == Int32.MaxValue ? 1 : epoch + 1;
                previousContext = sample;
                previousOrigin = new LivePosition { X = origin.X, Y = origin.Y, Z = origin.Z };
                previousFrame = sample.RenderedFrame;
                lastProgressMs = now;
                frameAdvanced = false;
                Diagnostics.CameraEpoch = epoch;
                lastEpochResetReason = resetReason;
                Diagnostics.EpochResetReason = resetReason;
                Diagnostics.EpochResetOccurred = true;
                long count;
                epochResetCounts.TryGetValue(resetReason, out count);
                epochResetCounts[resetReason] = count == Int64.MaxValue ? count : count + 1;
                SetStatus("CAMERA_ATTENTE_RENDU", "Camera coherente ; attente d'une nouvelle image du jeu pour confirmer la progression du rendu.");
                return false;
            }
            if (delta != 0)
            {
                previousFrame = sample.RenderedFrame;
                lastProgressMs = now;
                frameAdvanced = true;
            }
            Diagnostics.CameraEpoch = epoch;
            if (now - lastProgressMs > 250)
            {
                SetStatus("CAMERA_RENDU_FIGE", "Le compteur de rendu n'avance plus depuis plus de 250 ms ; reperes suspendus.");
                return false;
            }
            if (!frameAdvanced)
            {
                SetStatus("CAMERA_ATTENTE_RENDU", "Attente d'une progression du compteur de rendu du jeu.");
                return false;
            }
            return true;
        }

        private static void ValidateMatrices(float[] view, float[] projection, NativeSample sample)
        {
            if (!AllFinite(view) || !AllFinite(projection))
                throw Fault("CAMERA_MATRICE_INVALIDE", "Une matrice camera contient une valeur non finie.", true);
            for (int i = 0; i < 16; i++)
                if (Math.Abs(view[i]) > 10000000 || Math.Abs(projection[i]) > 1000000)
                    throw Fault("CAMERA_MATRICE_INVALIDE", "Amplitude d'une matrice camera hors limites.", true);
            if (Math.Abs(view[3]) > 0.0001 || Math.Abs(view[7]) > 0.0001 ||
                Math.Abs(view[11]) > 0.0001 || Math.Abs(view[15] - 1) > 0.0001)
                throw Fault("CAMERA_MATRICE_INVALIDE", "La vue camera n'est pas une transformation affine rigide.", true);
            for (int row = 0; row < 3; row++)
                for (int other = row; other < 3; other++)
                {
                    double dot = 0;
                    for (int col = 0; col < 3; col++) dot += (double)view[col * 4 + row] * view[col * 4 + other];
                    if (Math.Abs(dot - (row == other ? 1 : 0)) > 0.025)
                        throw Fault("CAMERA_MATRICE_INVALIDE", "Les axes de la vue camera ne sont pas orthonormaux.", true);
                }
            double determinant = view[0] * ((double)view[5] * view[10] - (double)view[9] * view[6]) -
                view[4] * ((double)view[1] * view[10] - (double)view[9] * view[2]) +
                view[8] * ((double)view[1] * view[6] - (double)view[5] * view[2]);
            if (Math.Abs(Math.Abs(determinant) - 1) > 0.05)
                throw Fault("CAMERA_MATRICE_INVALIDE", "Determinant de la vue camera incoherent.", true);
            if (!Finite(sample.Near) || !Finite(sample.Far) || sample.Near <= 0 || sample.Far <= sample.Near ||
                projection[0] <= 0 || projection[5] <= 0)
                throw Fault("CAMERA_MATRICE_INVALIDE", "Plans de coupe ou echelles de projection invalides.", true);
            int[] zeros = { 1, 2, 3, 4, 6, 7 };
            foreach (int index in zeros)
                if (Math.Abs(projection[index]) > 0.001)
                    throw Fault("CAMERA_MATRICE_INVALIDE", "Projection inclinee ou convention non prise en charge.", true);
            double range = (double)sample.Far - sample.Near;
            if (sample.Orthographic == 0)
            {
                if (Math.Abs(projection[11] + 1) > 0.001 || Math.Abs(projection[15]) > 0.001 ||
                    Math.Abs(projection[12]) > 0.001 || Math.Abs(projection[13]) > 0.001 ||
                    !Close(projection[10], -(sample.Far + (double)sample.Near) / range) ||
                    !Close(projection[14], -(2.0 * sample.Far * sample.Near) / range))
                    throw Fault("CAMERA_MATRICE_INVALIDE", "La projection ne correspond pas a une perspective CPU Unity valide.", true);
            }
            else if (Math.Abs(projection[11]) > 0.001 || Math.Abs(projection[15] - 1) > 0.001 ||
                Math.Abs(projection[8]) > 0.001 || Math.Abs(projection[9]) > 0.001 ||
                !Close(projection[10], -2.0 / range) || !Close(projection[14], -(sample.Far + (double)sample.Near) / range))
                throw Fault("CAMERA_MATRICE_INVALIDE", "La projection orthographique CPU Unity n'est pas coherente.", true);
        }

        private static float[] MultiplyColumnMajorToRowMajor(float[] projection, float[] view)
        {
            float[] output = new float[16];
            for (int row = 0; row < 4; row++)
                for (int col = 0; col < 4; col++)
                {
                    double value = 0;
                    for (int k = 0; k < 4; k++) value += (double)projection[k * 4 + row] * view[col * 4 + k];
                    float result = (float)value;
                    if (!Finite(result)) throw Fault("CAMERA_MATRICE_INVALIDE", "Produit des matrices non fini.");
                    output[row * 4 + col] = result;
                }
            return output;
        }

        private ClassIdentity ReadClassIdentity(MonoClassReport report)
        {
            ulong address = ParseAddress(report.Address);
            byte[] data = Read(address, 0x110);
            uint token = BitConverter.ToUInt32(data, 0x58);
            if (data[0x1B] != 1 || BitConverter.ToInt32(data, 0x1C) != report.InstanceSize ||
                report.InstanceSize < 16 || report.InstanceSize > 1048576 ||
                (token & 0xFF000000U) != 0x02000000U || (token & 0xFFFFFFU) == 0 ||
                (!String.IsNullOrEmpty(report.MetadataToken) && ParseNumber(report.MetadataToken) != token))
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Identite de classe Mono differente du rapport courant.");
            ulong image = BitConverter.ToUInt64(data, 0x40);
            RequirePointer(image);
            VerifyName(BitConverter.ToUInt64(data, 0x48), report.Name);
            VerifyName(BitConverter.ToUInt64(data, 0x50), report.Namespace ?? String.Empty);
            ulong parent = BitConverter.ToUInt64(data, 0x30);
            if (parent != 0) RequirePointer(parent);
            return new ClassIdentity { Address = address, Parent = parent, Size = report.InstanceSize, Header = data };
        }

        private ulong? VerifyClassStable(ClassIdentity expected, bool includeRuntime = false)
        {
            byte[] current = Read(expected.Address, includeRuntime ? 0xD8 : 0x60);
            int[] offsets = { 0x1B, 0x1C, 0x30, 0x40, 0x48, 0x50, 0x58 };
            int[] sizes = { 1, 4, 8, 8, 8, 8, 4 };
            for (int i = 0; i < offsets.Length; i++)
                for (int j = 0; j < sizes[i]; j++)
                    if (current[offsets[i] + j] != expected.Header[offsets[i] + j])
                        throw Fault("CAMERA_IDENTITE_INVALIDE", "Une identite de classe Mono a change depuis l'inspection.", true);
            return includeRuntime ? BitConverter.ToUInt64(current, 0xD0) : (ulong?)null;
        }

        private void VerifyLiveFields(ClassIdentity owner, MonoClassReport report, MonoFieldReport[] wanted, ulong referenceClass)
        {
            int count = BitConverter.ToInt32(owner.Header, 0x100);
            if (count < 1 || count > 512 || count != report.DeclaredFieldCount)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Nombre de champs de la classe differant du releve camera.");
            ulong fieldsAddress = BitConverter.ToUInt64(owner.Header, 0x98);
            RequirePointer(fieldsAddress);
            byte[] fields = Read(fieldsAddress, count * 32);
            foreach (MonoFieldReport expected in wanted)
            {
                int matches = 0;
                for (int i = 0; i < count; i++)
                {
                    int start = i * 32;
                    if (BitConverter.ToInt32(fields, start + 24) != expected.Offset) continue;
                    if (BitConverter.ToUInt64(fields, start + 16) != owner.Address)
                        throw Fault("METADONNEES_CAMERA_INVALIDES", "Proprietaire d'un champ cible incoherent.");
                    ulong nameAddress = BitConverter.ToUInt64(fields, start + 8);
                    if (!NameMatches(nameAddress, expected.Name)) continue;
                    byte[] type = Read(BitConverter.ToUInt64(fields, start), 16);
                    byte expectedCode = (byte)ParseNumber(expected.TypeCode);
                    ushort flags = BitConverter.ToUInt16(type, 8);
                    if ((flags & 0x50) != 0 || type[10] != expectedCode ||
                        (expectedCode == 0x12 && BitConverter.ToUInt64(type, 0) != referenceClass))
                        throw Fault("METADONNEES_CAMERA_INVALIDES", "Type ou portee d'un champ camera different du rapport.");
                    matches++;
                }
                if (matches != 1)
                    throw Fault("METADONNEES_CAMERA_INVALIDES", "Champ camera introuvable ou ambigu dans les metadonnees vivantes : " + expected.Name + ".");
            }
        }

        private static MonoClassReport UniqueClass(List<MonoClassReport> classes, string name, string ns)
        {
            MonoClassReport? found = null;
            foreach (MonoClassReport candidate in classes)
                if (candidate.Name == name && (candidate.Namespace ?? String.Empty) == ns)
                { if (found != null) throw Fault("METADONNEES_CAMERA_INVALIDES", "Classe Mono ambigue."); found = candidate; }
            return found ?? throw Fault("METADONNEES_CAMERA_INVALIDES", "Classe Mono requise absente : " + name + ".");
        }

        private CameraObjectReport UniqueObject(string field)
        {
            CameraObjectReport? found = null;
            foreach (CameraObjectReport candidate in probe.Objects)
                if (candidate.SourceField == field)
                { if (found != null) throw Fault("METADONNEES_CAMERA_INVALIDES", "Reference camera ambigue."); found = candidate; }
            return found ?? throw Fault("METADONNEES_CAMERA_INVALIDES", "Reference camera absente du releve : " + field + ".");
        }

        private static MonoFieldReport RequiredField(MonoClassReport owner, string name, string type, byte code)
        {
            MonoFieldReport? found = null;
            foreach (MonoFieldReport candidate in owner.Fields)
                if (candidate.Name == name)
                { if (found != null) throw Fault("METADONNEES_CAMERA_INVALIDES", "Champ Mono ambigu."); found = candidate; }
            if (found == null || found.Type != type || ParseNumber(found.TypeCode) != code || found.IsStatic ||
                found.IsLiteral || !String.IsNullOrEmpty(found.Issue) || found.Offset < 16 || found.Offset > owner.InstanceSize - 8)
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Champ d'instance non confirme : " + name + ".");
            return found;
        }

        private static void MatchField(MonoFieldReport a, MonoFieldReport b)
        {
            if (a.Offset != b.Offset || a.Type != b.Type || ParseNumber(a.TypeCode) != ParseNumber(b.TypeCode))
                throw Fault("METADONNEES_CAMERA_INVALIDES", "Les rapports courants divergent sur les champs camera.");
        }

        private static string? SampleDifference(NativeSample a, NativeSample b, out string kind)
        {
            kind = "IDENTITE";
            string? managed = ManagedDifference(a.Local, b.Local, "Local") ?? ManagedDifference(a.Camera, b.Camera, "Camera");
            if (managed != null) return managed;
            if (a.Native != b.Native || a.NativeVtable != b.NativeVtable) return "Camera.nativePointer/vtable";
            if (a.Screen != b.Screen || a.ScreenVtable != b.ScreenVtable) return "Screen.pointer/vtable";
            if (a.Time != b.Time) return "Time.manager";
            if (a.Xr != b.Xr || a.XrVtable != b.XrVtable) return "XR.pointer/vtable";
            if (a.Graphics != b.Graphics) return "Graphics.pointer";
            kind = "CONFIGURATION";
            if (a.Active != b.Active) return "Camera.active";
            if (a.CustomBuffer != b.CustomBuffer || a.CustomInactive != b.CustomInactive) return "Camera.customTargetBuffer";
            if (a.ImplicitView != b.ImplicitView) return "Camera.implicitView";
            if (a.Orthographic != b.Orthographic) return "Camera.orthographic";
            if (!a.Presentation.Active && a.ProjectionMode != b.ProjectionMode) return "Camera.projectionMode";
            if (a.DynamicRequest != b.DynamicRequest || a.GraphicsDynamic != b.GraphicsDynamic) return "Camera.dynamicResolution";
            if (a.Width != b.Width || a.Height != b.Height) return "Screen.width/height";
            if (!SameFloats(a.Rect, b.Rect)) return "Camera.normalizedRect";
            if (a.Near != b.Near || a.Far != b.Far) return "Camera.near/far";
            kind = "PRESENTATION";
            string? presentation = PresentationDifference(a.Presentation, b.Presentation);
            if (presentation != null) return presentation;
            kind = String.Empty;
            return null;
        }

        private static string? ContextDifference(NativeSample a, NativeSample b)
        {
            if (a.Local.Instance != b.Local.Instance) return "LOCAL_INSTANCE_CHANGED";
            if (a.Local.Domain != b.Local.Domain || a.Camera.Domain != b.Camera.Domain) return "MONO_DOMAIN_CHANGED";
            if (a.Local.Table != b.Local.Table) return "LOCAL_VTABLE_CHANGED";
            if (a.Local.Runtime != b.Local.Runtime || a.Local.Slot != b.Local.Slot) return "LOCAL_RUNTIME_CHANGED";
            if (a.Camera.Instance != b.Camera.Instance) return "CAMERA_INSTANCE_CHANGED";
            if (a.Camera.Table != b.Camera.Table) return "CAMERA_VTABLE_CHANGED";
            if (a.Camera.Runtime != b.Camera.Runtime || a.Camera.Slot != b.Camera.Slot) return "CAMERA_RUNTIME_CHANGED";
            if (a.Native != b.Native || a.Camera.Native != b.Camera.Native) return "NATIVE_POINTER_CHANGED";
            if (a.NativeVtable != b.NativeVtable) return "NATIVE_VTABLE_CHANGED";
            if (a.Time != b.Time) return "TIME_MANAGER_CHANGED";
            if (a.Screen != b.Screen) return "SCREEN_POINTER_CHANGED";
            if (a.Xr != b.Xr || a.XrVtable != b.XrVtable) return "XR_MANAGER_CHANGED";
            if (a.Width != b.Width || a.Height != b.Height) return "SOURCE_SIZE_CHANGED";
            if (PresentationDifference(a.Presentation, b.Presentation) != null) return "PRESENTATION_CONTEXT_CHANGED";
            if (!SameFloats(a.Rect, b.Rect)) return "VIEWPORT_CHANGED";
            return null;
        }

        private static string? ManagedDifference(ManagedIdentity a, ManagedIdentity b, string label)
        {
            if (a.Instance != b.Instance) return label + ".instance";
            if (a.Table != b.Table) return label + ".vtable";
            if (a.Domain != b.Domain) return label + ".domain";
            if (a.Runtime != b.Runtime || a.Slot != b.Slot) return label + ".runtimeRegistration";
            if (a.Native != b.Native) return label + ".nativePointer";
            return null;
        }
        private static bool CounterRegressed(uint before, uint after)
        { uint delta = unchecked(after - before); return delta != 0 && delta > Int32.MaxValue; }
        private static string MatrixDifference(byte[] before, byte[] after)
        {
            bool view = false, projection = false;
            for (int i = 0; i < 64; i++) if (before[i] != after[i]) { view = true; break; }
            for (int i = 64; i < 128; i++) if (before[i] != after[i]) { projection = true; break; }
            return view && projection ? "WorldToCamera + Projection" : view ? "WorldToCamera" : "Projection";
        }
        private static bool SamePosition(LivePosition a, LivePosition b) { return a.X == b.X && a.Y == b.Y && a.Z == b.Z; }
        private static bool SameFloats(float[] a, float[] b)
        { if (a.Length != b.Length) return false; for (int i = 0; i < a.Length; i++) if (a[i] != b[i]) return false; return true; }
        private static bool SameBytes(byte[] a, byte[] b)
        { if (a.Length != b.Length) return false; for (int i = 0; i < a.Length; i++) if (a[i] != b[i]) return false; return true; }
        private static bool Close(double actual, double expected) { return Math.Abs(actual - expected) <= Math.Max(0.0001, Math.Abs(expected) * 0.002); }
        private static bool Finite(float value) { return !Single.IsNaN(value) && !Single.IsInfinity(value); }
        private static bool AllFinite(float[] values) { foreach (float value in values) if (!Finite(value)) return false; return true; }
        private static float[] Floats(byte[] bytes, int offset)
        { float[] values = new float[16]; for (int i = 0; i < 16; i++) values[i] = BitConverter.ToSingle(bytes, offset + i * 4); return values; }
        private static string FullName(MonoClassReport value) { return String.IsNullOrEmpty(value.Namespace) ? value.Name : value.Namespace + "." + value.Name; }
        private static string ShortMessage(Exception ex) { string text = ex.Message; return text.Length <= 240 ? text : text.Substring(0, 240); }

        private void ObserveConfiguration(NativeSample sample)
        {
            Diagnostics.SourceWidth = sample.Width;
            Diagnostics.SourceHeight = sample.Height;
            Diagnostics.LastNormalizedRect = (float[])sample.Rect.Clone();
            Diagnostics.ViewportX = sample.Rect[0] * sample.Width;
            Diagnostics.ViewportY = (1f - sample.Rect[1] - sample.Rect[3]) * sample.Height;
            Diagnostics.ViewportWidth = sample.Rect[2] * sample.Width;
            Diagnostics.ViewportHeight = sample.Rect[3] * sample.Height;
            Diagnostics.RenderedFrameCount = sample.RenderedFrame;
        }

        private void ObserveMatrices(byte[] bytes)
        {
            float[] view = Floats(bytes, 0), projection = Floats(bytes, 64);
            Diagnostics.LastView = AllFinite(view) ? view : null;
            Diagnostics.LastProjection = AllFinite(projection) ? projection : null;
        }

        private void ObserveNativePair(NativeState before, NativeState after)
        {
            Diagnostics.ProjectionModeBefore = before.ProjectionMode;
            Diagnostics.ProjectionModeAfter = after.ProjectionMode;
            Diagnostics.OrthographicBefore = before.Orthographic;
            Diagnostics.OrthographicAfter = after.Orthographic;
            Diagnostics.ProjectionDirtyBefore = before.ProjectionDirty;
            Diagnostics.ProjectionDirtyAfter = after.ProjectionDirty;
            Diagnostics.NonJitteredExplicitBefore = before.NonJitteredExplicit;
            Diagnostics.NonJitteredExplicitAfter = after.NonJitteredExplicit;
            // JSON diagnostics must stay serializable even for rejected bytes.
            Diagnostics.NormalizedRectBefore = AllFinite(before.Rect) ? (float[])before.Rect.Clone() : null;
            Diagnostics.NormalizedRectAfter = AllFinite(after.Rect) ? (float[])after.Rect.Clone() : null;
            Diagnostics.LastRawNormalizedRect = AllFinite(after.Rect) ? (float[])after.Rect.Clone() : null;
        }

        private void ObservePresentation(PresentationState state, bool validated)
        {
            Diagnostics.PresentationMode = !state.Active ? "NATIVE" : state.Mode == 6 ? "FSR3" : "DLSS";
            Diagnostics.PresentationSource = !state.Active ? "Camera.normalizedRect" : Diagnostics.PresentationMode + "._originalRect";
            Diagnostics.ProjectionSource = state.Active ? "Camera.nonJitteredProjectionMatrix" : "Camera.projectionMatrix";
            Diagnostics.PresentationValidated = validated;
            Diagnostics.UpscalerQuality = state.Active ? state.Quality : (int?)null;
            Diagnostics.RenderWidth = state.Active ? state.RenderWidth : (int?)null;
            Diagnostics.RenderHeight = state.Active ? state.RenderHeight : (int?)null;
            Diagnostics.DisplayWidth = state.Active ? state.DisplayWidth : (int?)null;
            Diagnostics.DisplayHeight = state.Active ? state.DisplayHeight : (int?)null;
        }

        private void RecordFault(NativeFault fault)
        {
            string kind = fault.Kind;
            if (kind.Length == 0)
            {
                switch (fault.Code)
                {
                    case "CAMERA_IDENTITE_INVALIDE": kind = "IDENTITE"; break;
                    case "CAMERA_CONFIGURATION_NON_SUPPORTEE": case "CAMERA_INACTIVE": kind = "CONFIGURATION"; break;
                    case "CAMERA_MATRICE_INVALIDE": kind = "MATRICES"; break;
                    case "CAMERA_BUDGET_DEPASSE": kind = "BUDGET"; break;
                    case "CAMERA_LECTURE_INCOMPLETE": kind = "LECTURE"; break;
                    default: kind = "CAPTURE"; break;
                }
            }
            Diagnostics.InstabilityKind = kind;
            Diagnostics.InstabilityDetail = fault.Detail.Length == 0 ? fault.Message : fault.Detail;
            // An exception crosses both the retry loop and the outer handler.
            // Count the concrete rejected attempt once, even when propagated.
            if (!fault.Counted)
            {
                fault.Counted = true;
                string key = kind + " / " + (fault.Detail.Length == 0 ? fault.Code : fault.Detail);
                long count;
                if (instabilityCauseCounts.TryGetValue(key, out count))
                    instabilityCauseCounts[key] = count == Int64.MaxValue ? count : count + 1;
                else if (instabilityCauseCounts.Count < 64) instabilityCauseCounts[key] = 1;
                else if (otherInstabilityCauseCount < Int64.MaxValue) otherInstabilityCauseCount++;
            }
        }

        private void VerifyName(ulong address, string expected)
        { if (!NameMatches(address, expected)) throw Fault("METADONNEES_CAMERA_INVALIDES", "Nom de classe ou de champ different du rapport."); }
        private bool NameMatches(ulong address, string expected)
        {
            if (expected == null || expected.Length > 255) throw Fault("METADONNEES_CAMERA_INVALIDES", "Nom de metadonnee hors limites.");
            byte[] bytes = Encoding.UTF8.GetBytes(expected);
            byte[] actual = Read(address, bytes.Length + 1);
            if (actual[bytes.Length] != 0) return false;
            for (int i = 0; i < bytes.Length; i++) if (actual[i] != bytes[i]) return false;
            return true;
        }

        private static ulong ParseAddress(string value) { ulong result = ParseNumber(value); RequirePointer(result); return result; }
        private static ulong ParseNumber(string value)
        {
            if (String.IsNullOrEmpty(value)) throw Fault("METADONNEES_CAMERA_INVALIDES", "Valeur de metadonnee manquante.");
            bool hex = value.StartsWith("0x", StringComparison.OrdinalIgnoreCase);
            ulong result;
            if (!UInt64.TryParse(hex ? value.Substring(2) : value, hex ? NumberStyles.AllowHexSpecifier : NumberStyles.None,
                CultureInfo.InvariantCulture, out result)) throw Fault("METADONNEES_CAMERA_INVALIDES", "Valeur de metadonnee invalide.");
            return result;
        }

        private void BeginOperation(int budget)
        {
            clock = Stopwatch.StartNew(); operationBudget = budget;
            Diagnostics = new NativeCameraDiagnostics { ProfileVerified = profileVerified, CameraEpoch = epoch, Sequence = sequence,
                EpochResetReason = lastEpochResetReason };
            ObserveVerificationState();
        }
        private void CompleteOperation()
        {
            ObserveVerificationState();
            Diagnostics.ElapsedMilliseconds = clock.Elapsed.TotalMilliseconds;
            Diagnostics.EpochResetCounts = new Dictionary<string, long>(epochResetCounts, StringComparer.Ordinal);
            Diagnostics.InstabilityCauseCounts = new Dictionary<string, long>(instabilityCauseCounts, StringComparer.Ordinal);
            Diagnostics.OtherInstabilityCauseCount = otherInstabilityCauseCount;
        }
        private void ObserveVerificationState()
        {
            Diagnostics.ProfileVerified = profileVerified;
            Diagnostics.ProfileValidationScope = profileValidationScope;
            Diagnostics.InitializationAttempts = initializationAttempts;
            Diagnostics.InitializationRetryPending = initializationRetryPending;
            Diagnostics.LastInitializationFailure = lastInitializationFailure;
            Diagnostics.FailedSignatureName = failedSignatureName;
            Diagnostics.FailedSignatureRva = failedSignatureRva;
            Diagnostics.XrGetterVerified = xrGetterVerified;
            Diagnostics.XrValidationMode = xrValidationMode;
        }
        private void SetStatus(string code, string message) { Diagnostics.Status = code; Diagnostics.Message = message; }
        private void CheckBudget()
        {
            if (clock.ElapsedMilliseconds >= operationBudget || Diagnostics.ReadCalls >= MaximumCalls || Diagnostics.BytesRead > MaximumBytes)
                throw Fault("CAMERA_BUDGET_DEPASSE", "Budget de lecture camera atteint ; nouvelle capture au prochain passage.");
        }
        private byte[] Read(ulong address, int count)
        {
            RequirePointer(address);
            if (count <= 0 || count > 65536 || address > 0x00007FFFFFFFFFFFUL - (ulong)count || Diagnostics.BytesRead > MaximumBytes - count)
                throw Fault("CAMERA_LECTURE_INCOMPLETE", "Plage de lecture camera hors limites.");
            CheckBudget();
            Diagnostics.ReadCalls++;
            byte[] bytes;
            try { bytes = memory.Read(address, count); }
            catch (Exception ex) { throw Fault("CAMERA_LECTURE_INCOMPLETE", "Lecture memoire camera incomplete : " + ShortMessage(ex), true); }
            if (bytes == null || bytes.Length != count)
                throw Fault("CAMERA_LECTURE_INCOMPLETE", "La lecture camera n'a pas retourne tous les octets demandes.", true);
            Diagnostics.BytesRead += bytes.Length;
            CheckBudget();
            return bytes;
        }
        private ulong U64(ulong address) { return BitConverter.ToUInt64(Read(address, 8), 0); }
        private ulong Pointer(ulong address) { ulong value = U64(address); RequirePointer(value); return value; }
        private static void RequirePointer(ulong address)
        { if (address < 0x10000 || address > 0x00007FFFFFFFFFFFUL) throw Fault("CAMERA_IDENTITE_INVALIDE", "Pointeur camera ou metadonnee hors plage utilisateur.", true); }
        private void RequireReadOnlyPointer(ulong address, int length)
        {
            ulong start = moduleBase + NativeCameraProfile.ReadOnlyDataRva;
            if (address < start || address > start + NativeCameraProfile.ReadOnlyDataSize - (ulong)length)
                throw Fault("CAMERA_IDENTITE_INVALIDE", "Table native hors de la section de donnees confirmees.", true);
        }
        private bool InText(ulong address)
        { return address >= moduleBase + NativeCameraProfile.TextRva && address < moduleBase + NativeCameraProfile.TextRva + NativeCameraProfile.TextSize; }
        private static NativeFault Fault(string code, string message, bool retry = false, string kind = "", string detail = "")
        { return new NativeFault(code, message, retry, kind, detail); }
        private sealed class NativeFault : IOException
        {
            internal readonly string Code, Kind, Detail;
            internal readonly bool Retryable;
            internal bool Counted;
            internal NativeFault(string code, string message, bool retry, string kind, string detail) : base(message)
            { Code = code; Retryable = retry; Kind = kind; Detail = detail; }
        }
        private sealed class ClassIdentity
        { internal ulong Address, Parent; internal int Size; internal byte[] Header = Array.Empty<byte>(); }
        private sealed class ManagedIdentity
        { internal ulong Instance, Table, Domain, Runtime, Slot, Native; }
        private sealed class NativeState
        {
            internal ulong NativeVtable, CustomBuffer;
            internal byte Active, ProjectionDirty, NonJitteredExplicit, ImplicitView, Orthographic, DynamicRequest;
            internal int ProjectionMode, TargetTexture, TargetDisplay;
            internal float Near, Far;
            internal float[] Rect = Array.Empty<float>();
            internal byte[] Matrices = Array.Empty<byte>();
            internal byte[] NonJitteredProjection = Array.Empty<byte>();
        }
        private sealed class EnvironmentState
        {
            internal ulong Graphics, Screen, ScreenVtable, Xr, XrVtable, Time;
            internal byte CustomInactive, GraphicsDynamic;
            internal int Width, Height;
            internal uint RenderedFrame;
        }
        private sealed class NativeSample
        {
            internal ManagedIdentity Local = new ManagedIdentity(), Camera = new ManagedIdentity();
            internal ulong Native, NativeVtable, CustomBuffer, Graphics, Screen, ScreenVtable, Xr, XrVtable, Time;
            internal byte Active, CustomInactive, ImplicitView, Orthographic, DynamicRequest, GraphicsDynamic;
            internal int ProjectionMode, Width, Height;
            internal uint RenderedFrame;
            internal float Near, Far;
            internal float[] Rect = Array.Empty<float>();
            internal float[] RawRect = Array.Empty<float>();
            internal PresentationState Presentation = new PresentationState();
        }
    }
}
