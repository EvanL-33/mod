﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [string]$VmmDir = 'C:\Users\Media\Desktop\MemProcFS_files_and_binaries-win_x64-latest',
    [string]$Device = 'fpga',
    [ValidateRange(50, 2000)][int]$IntervalMilliseconds = 150
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)

function Write-State([string]$State, [string]$Message) {
    [Console]::WriteLine(('[{0}] {1}' -f $State, $Message))
    [Console]::Out.Flush()
}

if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT -or [IntPtr]::Size -ne 8) {
    Write-State 'ERREUR_ENVIRONNEMENT' 'Utilise Windows PowerShell 5.1 x64.'
    exit 2
}

$session = $null
$reader = $null
$resultCode = 6
$cameraAttempted = $false
$reportedFirstFailure = $false
$reportDirectory = Join-Path $PSScriptRoot 'rapports'
$reportPath = Join-Path $reportDirectory ('rapport-live-' + [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0, 6) + '.json')
$report = [ordered]@{
    Format = 'SevenDaysEsp.LiveSession/1'
    ToolVersion = '0.4.1-dev'
    CreatedUtc = [DateTime]::UtcNow.ToString('o')
    UpdatedUtc = $null
    Status = 'INITIALISATION'
    Message = 'Lecture des positions et radar sur le PC lecteur.'
    CanProjectToGameScreen = $false
    ProcessId = $null
    MemProcFsVersion = $null
    Mono = $null
    GameVersion = $null
    Camera = $null
    FramesRead = 0
    FramesRejected = 0
    FirstSuccessUtc = $null
    LastSuccessUtc = $null
    LastPlayersCount = 0
    LastZombiesCount = 0
    LastRejectedEntities = 0
    LastReadDurationMs = 0
    ReadCalls = 0
    ReadBytes = 0
    Error = $null
    Note = 'Ce rapport conserve les metadonnees, etats et compteurs ; pas de liste de noms ou de positions de joueurs.'
}

function Save-LiveReport([switch]$Announce) {
    $temporary = $reportPath + '.tmp'
    try {
        $report.UpdatedUtc = [DateTime]::UtcNow.ToString('o')
        if ($null -ne $session) {
            $report.ReadCalls = $session.ReadCalls
            $report.ReadBytes = $session.ReadBytes
        }
        [IO.Directory]::CreateDirectory($reportDirectory) | Out-Null
        $json = $report | ConvertTo-Json -Depth 25
        [IO.File]::WriteAllText($temporary, $json, [Text.UTF8Encoding]::new($false))
        if ([IO.File]::Exists($reportPath)) {
            [IO.File]::Replace($temporary, $reportPath, [System.Management.Automation.Language.NullString]::Value)
        } else { [IO.File]::Move($temporary, $reportPath) }
        if ($Announce) { Write-State 'RAPPORT_LIVE' $reportPath }
    } catch {
        Write-State 'ERREUR_RAPPORT' ('Le radar peut continuer. ' + $_.Exception.GetBaseException().Message)
    } finally {
        try { if ([IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) } } catch { }
    }
}

try {
    Write-State 'VERSION' 'Radar DMA 0.4.1-dev - lecture reelle joueurs/zombies ; projection camera non validee.'
    Write-State 'COMPILATION' 'Preparation du lecteur continu, du radar et du releve camera cible.'
    $sources = @('DmaMemory.cs', 'MonoInspector.cs', 'MonoGameVersion.cs', 'LiveEntityReader.cs', 'LiveRadarView.cs', 'CameraProbe.cs') |
        ForEach-Object { Join-Path $PSScriptRoot $_ }
    foreach ($file in $sources) {
        if (-not [IO.File]::Exists($file)) { throw ('Source absente : ' + [IO.Path]::GetFileName($file)) }
    }
    Add-Type -Path $sources -ReferencedAssemblies 'System.dll', 'System.Core.dll', 'System.Windows.Forms.dll', 'System.Drawing.dll' -ErrorAction Stop
    Write-State 'CONNEXION' 'Ouverture MemProcFS et recherche de 7DaysToDie.exe.'
    $session = [SevenDaysEsp.DmaMemory]::new($VmmDir, $Device)
    $report.ProcessId = $session.ProcessId
    $report.MemProcFsVersion = $session.VmmVersion
    Write-State 'JEU_TROUVE' ('PID {0} - MemProcFS {1}' -f $session.ProcessId, $session.VmmVersion)
    Write-State 'ANALYSE_MONO' 'Resolution des classes et offsets de cette session.'
    $inspector = [SevenDaysEsp.MonoInspector]::new($session)
    $metadata = $inspector.Inspect()
    $report.Mono = $metadata
    Write-State $metadata.Status $metadata.Message
    $versionReader = [SevenDaysEsp.MonoGameVersionReader]::new($session)
    $version = $versionReader.Inspect($metadata)
    $report.GameVersion = $version
    if ($version.Status -ne 'VERSION_JEU_LUE') { throw ('Version du jeu non confirmee : ' + $version.Message) }
    Write-State 'VERSION_JEU' $version.DisplayVersion
    if ($version.DisplayVersion -cne 'V 3.4.0 (b10)') {
        throw ('Ce lecteur est cible sur V 3.4.0 (b10). Version lue : ' + $version.DisplayVersion + '. Joins le rapport pour adapter le profil.')
    }
    $reader = [SevenDaysEsp.LiveEntityReader]::new($session, $metadata)
    $report.Status = 'ATTENTE_ENTITES'
    $report.Message = 'Charge une partie ; le radar attend une lecture valide du joueur local et des entites.'
    Save-LiveReport -Announce
    [SevenDaysEsp.LiveRadarWindow]::Start()
    [SevenDaysEsp.LiveRadarWindow]::Clear($report.Message)
    Write-State 'RADAR_OUVERT' 'Fenetre sur le PC lecteur. Ferme cette fenetre pour arreter la lecture DMA.'
    $resultCode = 0
    $lastState = ''
    $lastMessage = ''
    $logClock = [Diagnostics.Stopwatch]::StartNew()
    $loopClock = [Diagnostics.Stopwatch]::new()
    while ([SevenDaysEsp.LiveRadarWindow]::IsOpen) {
        $loopClock.Restart()
        $snapshot = $null
        try {
            $snapshot = $reader.Capture()
            if ($null -eq $snapshot) { throw 'Le lecteur n''a fourni aucun instantane.' }
            $state = $snapshot.Status
            $message = $snapshot.Message
            $report.LastReadDurationMs = $snapshot.ReadDurationMs
            $report.LastRejectedEntities = $snapshot.RejectedEntities
            if ($state -eq 'ENTITES_LUES') {
                $report.FramesRead++
                if ($null -eq $report.FirstSuccessUtc) { $report.FirstSuccessUtc = $snapshot.CapturedUtc.ToString('o') }
                $report.LastSuccessUtc = $snapshot.CapturedUtc.ToString('o')
                $report.LastPlayersCount = $snapshot.PlayersCount
                $report.LastZombiesCount = $snapshot.ZombiesCount
                $message = '{0} joueur(s), {1} zombie(s), {2} element(s) ecarte(s), lecture {3} ms.' -f $snapshot.PlayersCount, $snapshot.ZombiesCount, $snapshot.RejectedEntities, $snapshot.ReadDurationMs
                if (-not $cameraAttempted) {
                    $cameraAttempted = $true
                    [SevenDaysEsp.LiveRadarWindow]::Clear('Lecture des metadonnees camera ; reprise du radar dans un instant.')
                    Write-State 'SONDE_CAMERA' 'Releve cible des objets camera ; aucune matrice native supposee.'
                    $cameraProbe = [SevenDaysEsp.CameraProbe]::new($session)
                    $report.Camera = $cameraProbe.Inspect($metadata, $reader.LocalPlayerAddress)
                    Write-State 'CAMERA' $report.Camera.Message
                    $report.Status = $state
                    $report.Message = $message
                    Save-LiveReport -Announce
                    # La sonde peut durer plusieurs secondes. Relire un instantane frais avant affichage.
                    continue
                }
                [SevenDaysEsp.LiveRadarWindow]::Publish($snapshot)
            } else {
                $report.FramesRejected++
                [SevenDaysEsp.LiveRadarWindow]::Clear($message)
            }
        } catch {
            $state = 'LECTURE_INTERROMPUE'
            $message = $_.Exception.GetBaseException().Message
            $report.FramesRejected++
            [SevenDaysEsp.LiveRadarWindow]::Clear($message)
        }
        $report.Status = $state
        $report.Message = $message
        if ($state -ne $lastState -or ($state -ne 'ENTITES_LUES' -and $message -ne $lastMessage) -or $logClock.ElapsedMilliseconds -ge 10000) {
            Write-State $state $message
            $lastState = $state
            $lastMessage = $message
            $logClock.Restart()
        }
        if ($state -ne 'ENTITES_LUES' -and -not $reportedFirstFailure) {
            $reportedFirstFailure = $true
            Save-LiveReport -Announce
        }
        $delay = [Math]::Max(16, $IntervalMilliseconds - [int][Math]::Min(2000, $loopClock.ElapsedMilliseconds))
        Start-Sleep -Milliseconds $delay
    }
    $uiError = [SevenDaysEsp.LiveRadarWindow]::LastError
    if (-not [string]::IsNullOrWhiteSpace($uiError)) { throw ('Erreur du radar : ' + $uiError) }
    if ($report.FramesRead -eq 0) {
        $resultCode = 7
        Write-State 'AUCUNE_CAPTURE_VALIDEE' 'Fenetre fermee sans lecture valide des entites. Consulte le rapport live.'
    } else {
        Write-State 'RADAR_FERME' ('Fenetre fermee ; {0} capture(s) valide(s), {1} capture(s) rejetee(s).' -f $report.FramesRead, $report.FramesRejected)
    }
} catch {
    $report.Status = 'ERREUR_RADAR'
    $report.Error = $_.Exception.GetBaseException().Message
    $report.Message = $report.Error
    Write-State 'ERREUR_RADAR' $report.Error
    if ($report.Error -like '*JEU_NON_TROUVE*') { $resultCode = 5 } else { $resultCode = 6 }
} finally {
    if ('SevenDaysEsp.LiveRadarWindow' -as [type]) {
        try { [SevenDaysEsp.LiveRadarWindow]::Stop() } catch { Write-State 'ERREUR_FERMETURE_RADAR' $_.Exception.GetBaseException().Message }
    }
    if ($null -ne $session) {
        $report.ReadCalls = $session.ReadCalls
        $report.ReadBytes = $session.ReadBytes
        try { $session.Dispose(); Write-State 'FERMETURE' 'Session DMA fermee.' }
        catch { Write-State 'ERREUR_FERMETURE' $_.Exception.GetBaseException().Message; $resultCode = 6 }
    }
    Save-LiveReport -Announce
}
exit $resultCode
