﻿using System;
using System.Buffers.Binary;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SevenDaysEsp;

// The fixture maps independent PE/signature goldens from the supplied binary and
// analysis JSON, then traverses the production reader's actual Mono/native path.
// Synthetic objects and matrices verify the implementation contract; they do not
// establish the validity or latency of a live DMA camera cache.
internal static class NativeCameraTests
{
    public static Task NormalMotionBetweenMetadataReadsIsAccepted()
    {
        var fixture = new Fixture();
        var reader = fixture.Reader();
        Prime(reader, fixture);
        LiveCameraFrame before = RequireFrame(reader, fixture);
        int movementUpdates = 0;
        float viewTranslation = -10;
        var matrixTranslations = new List<float>();
        var matrixReadIndexes = new List<int>();
        int readIndex = 0;
        fixture.Memory.BeforeRead = (address, count) =>
        {
            readIndex++;
            // The game continues to render while slower identity/metadata
            // reads run. It stays unchanged for an immediately repeated native
            // matrix/configuration block, which is the coherent instant the reader must capture.
            if ((Contains(address, count, fixture.LocalClass + 0x1C, 4)) ||
                (Contains(address, count, fixture.Local, 16)))
            {
                viewTranslation = -10 - ++movementUpdates * 0.25f;
                fixture.Memory.F32(fixture.Native + 0x80 + 12 * 4, viewTranslation);
                fixture.Advance();
            }
            if (Contains(address, count, fixture.Native, 0x798))
            {
                matrixTranslations.Add(viewTranslation);
                matrixReadIndexes.Add(readIndex);
            }
        };

        for (int capture = 0; capture < 3; capture++)
        {
            int previousUpdates = movementUpdates;
            matrixTranslations.Clear();
            matrixReadIndexes.Clear();
            LiveCameraFrame frame = RequireFrame(reader, fixture);
            Check(movementUpdates > previousUpdates,
                "The moving-game fixture did not update during identity reads.");
            Check(reader.Diagnostics.Attempts == 1 && matrixTranslations.Count == 2 &&
                matrixTranslations[0] == matrixTranslations[1] && matrixReadIndexes[1] == matrixReadIndexes[0] + 1,
                "Ordinary motion outside the V/P pair still forced retries or separated the two native camera blocks.");
            Near(frame.ViewProjection[3], 0.5625f * matrixTranslations[0],
                "The published frame did not use the coherent V/P pair actually captured");
            Check(frame.CameraEpoch == before.CameraEpoch && frame.Sequence > before.Sequence,
                "Normal view movement changed camera identity or failed to advance the sequence.");
            before = frame;
        }

        // A stationary camera can retain exactly the same matrices while the
        // renderer advances between their reads. Advancement alone is not a
        // torn matrix pair and must not produce another camera epoch.
        var stationary = new Fixture();
        var stationaryReader = stationary.Reader();
        Prime(stationaryReader, stationary);
        LiveCameraFrame firstStationary = RequireFrame(stationaryReader, stationary);
        int stationaryMatrixReads = 0;
        stationary.Memory.BeforeRead = (address, count) =>
        {
            if (Contains(address, count, stationary.Native, 0x798) && ++stationaryMatrixReads == 2)
                stationary.Advance();
        };
        LiveCameraFrame progressed = RequireFrame(stationaryReader, stationary);
        Check(stationaryMatrixReads == 2 && stationaryReader.Diagnostics.Attempts == 1 &&
            progressed.CameraEpoch == firstStationary.CameraEpoch,
            "A progressing render counter invalidated an otherwise identical matrix pair.");
        return Task.CompletedTask;
    }

    public static Task NativeConfigurationOutsidePairDoesNotInvalidateCapture()
    {
        var fixture = new Fixture();
        var reader = fixture.Reader();
        Prime(reader, fixture);
        LiveCameraFrame prior = RequireFrame(reader, fixture);
        int environmentReads = 0, readIndex = 0;
        var pairIndexes = new List<int>();
        fixture.Memory.BeforeRead = (address, count) =>
        {
            readIndex++;
            // The camera enters a temporary render configuration during the
            // object/metadata walk, then returns to the game's full image before
            // the two native blocks. The old reader borrowed this earlier rect
            // and mode, causing a false mismatch around a coherent V/P pair.
            if (Contains(address, count, fixture.LocalClass + 0x1C, 4))
            {
                fixture.Memory.I32(fixture.Native + 0x514, 1);
                fixture.Memory.F32(fixture.Native + 0x434, 0.8328125f);
                fixture.Memory.F32(fixture.Native + 0x438, 0.8324074f);
            }
            if (Contains(address, count, fixture.Screen + 0xFC, 29))
            {
                environmentReads++;
                bool beforePair = (environmentReads & 1) != 0;
                fixture.Memory.I32(fixture.Native + 0x514, beforePair ? 0 : 2);
                fixture.Memory.F32(fixture.Native + 0x434, beforePair ? 1 : 0.8328125f);
                fixture.Memory.F32(fixture.Native + 0x438, beforePair ? 1 : 0.8324074f);
                fixture.Advance();
            }
            if (Contains(address, count, fixture.Native, 0x798)) pairIndexes.Add(readIndex);
        };

        for (int i = 0; i < 3; i++)
        {
            pairIndexes.Clear();
            LiveCameraFrame captured = RequireFrame(reader, fixture);
            Check(reader.Diagnostics.Attempts == 1 && pairIndexes.Count == 2 && pairIndexes[1] == pairIndexes[0] + 1,
                "A configuration changing outside the paired native blocks still forced a retry.");
            Check(reader.Diagnostics.NativePairReadBytes == 0x798 &&
                reader.Diagnostics.ProjectionModeBefore == 0 && reader.Diagnostics.ProjectionModeAfter == 0 &&
                reader.Diagnostics.OrthographicBefore == 0 && reader.Diagnostics.OrthographicAfter == 0,
                "The diagnostic did not retain the exact configuration captured with the matrices.");
            Check(captured.ViewportWidth == 1920 && captured.ViewportHeight == 1080 && captured.ViewportY == 0,
                "A transient earlier/later viewport replaced the coherent full-image camera viewport.");
            Check(captured.CameraEpoch == prior.CameraEpoch && captured.Sequence > prior.Sequence,
                "Changes outside the native pair reset the confirmed camera epoch.");
            prior = captured;
        }
        return Task.CompletedTask;
    }

    public static Task PairedConfigurationChangesArePreciselyDiagnosed()
    {
        foreach (var change in new (string Detail, Action<Fixture> Apply, int ModeAfter, int OrthoAfter)[]
        {
            ("Camera.projectionMode", f => f.Memory.I32(f.Native + 0x514, 0), 0, 0),
            ("Camera.orthographic", f => f.Memory.Byte(f.Native + 0x523, 1), 1, 1)
        })
        {
            var fixture = new Fixture();
            var reader = fixture.Reader();
            Prime(reader, fixture);
            LiveCameraFrame prior = RequireFrame(reader, fixture);
            int pairReads = 0;
            fixture.Memory.BeforeRead = (address, count) =>
            {
                if (!Contains(address, count, fixture.Native, 0x798)) return;
                pairReads++;
                if ((pairReads & 1) != 0)
                {
                    fixture.Memory.I32(fixture.Native + 0x514, 1);
                    fixture.Memory.Byte(fixture.Native + 0x523, 0);
                }
                else change.Apply(fixture);
            };
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null && pairReads == 6 &&
                reader.Diagnostics.Status == "CAMERA_CAPTURE_INSTABLE" && reader.Diagnostics.InstabilityKind == "CONFIGURATION" &&
                reader.Diagnostics.InstabilityDetail == change.Detail,
                "A changing native mode was accepted or its exact cause was hidden: " + change.Detail);
            Check(reader.Diagnostics.ProjectionModeBefore == 1 && reader.Diagnostics.ProjectionModeAfter == change.ModeAfter &&
                reader.Diagnostics.OrthographicBefore == 0 && reader.Diagnostics.OrthographicAfter == change.OrthoAfter,
                "Before/after mode observations do not describe the rejected native pair.");
            string cause = "CONFIGURATION / " + change.Detail;
            Check(reader.Diagnostics.InstabilityCauseCounts.TryGetValue(cause, out long failures) && failures == 3,
                "The concrete rejected attempts were lost or double-counted by the outer exception handler.");

            fixture.Memory.BeforeRead = null;
            fixture.Memory.I32(fixture.Native + 0x514, 1);
            fixture.Memory.Byte(fixture.Native + 0x523, 0);
            fixture.Advance();
            LiveCameraFrame recovered = RequireFrame(reader, fixture);
            Check(recovered.CameraEpoch == prior.CameraEpoch && reader.Diagnostics.InstabilityCauseCounts[cause] == 3 &&
                reader.Diagnostics.InstabilityDetail == "",
                "Recovery changed epoch, erased cause totals or reused the previous failure as the current one.");
        }
        return Task.CompletedTask;
    }

    public static Task DirtyEitherNativeBlockIsRejected()
    {
        foreach (var dirty in new[] { (First: (byte)1, Second: (byte)0), (First: (byte)0, Second: (byte)1) })
        {
            var fixture = new Fixture();
            var reader = fixture.Reader();
            Prime(reader, fixture);
            int pairReads = 0;
            fixture.Memory.BeforeRead = (address, count) =>
            {
                if (Contains(address, count, fixture.Native, 0x798))
                    fixture.Memory.Byte(fixture.Native + 0x510, (++pairReads & 1) != 0 ? dirty.First : dirty.Second);
            };
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null && pairReads == 6 &&
                reader.Diagnostics.InstabilityDetail == "Camera.projectionDirty != 0" &&
                reader.Diagnostics.ProjectionDirtyBefore == dirty.First && reader.Diagnostics.ProjectionDirtyAfter == dirty.Second,
                "A dirty projection cache in one native block escaped validation.");
            Check(reader.Diagnostics.InstabilityCauseCounts.TryGetValue("PROJECTION_EN_COURS / Camera.projectionDirty != 0", out long failures) && failures == 3,
                "Dirty-pair failures were not counted exactly once per rejected attempt.");
        }
        return Task.CompletedTask;
    }

    public static Task UpscalerUsesSavedPresentationAcrossNativePhases()
    {
        foreach (int mode in new[] { 6, 7 })
        foreach (byte finalBlit in new byte[] { 0, 1 })
        {
            var fixture = new Fixture();
            fixture.EnableUpscaling(mode);
            fixture.Memory.Byte(fixture.Layer + Fixture.LayerFinalBlitOffset, finalBlit);
            var reader = fixture.Reader();
            Prime(reader, fixture);
            LiveCameraFrame first = RequireFrame(reader, fixture);
            int nativeReads = 0;
            fixture.Memory.BeforeRead = (address, count) =>
            {
                if (!Contains(address, count, fixture.Native, 0x798)) return;
                bool reduced = (++nativeReads & 1) != 0;
                // These are the two exact phases implicated in the real report.
                // They deliberately change BETWEEN the paired native blocks.
                fixture.SetRenderPhase(reduced);
                fixture.Memory.Byte(fixture.Native + 0x510, reduced ? (byte)1 : (byte)0);
                fixture.Memory.I32(fixture.Native + 0x514, reduced ? 0 : 1);
                fixture.Memory.F32(fixture.Native + 0xC0 + 8 * 4, reduced ? .003f : -.004f);
                fixture.Memory.F32(fixture.Native + 0xC0 + 9 * 4, reduced ? -.002f : .001f);
            };
            for (int i = 0; i < 5; i++)
            {
                nativeReads = 0;
                fixture.Advance();
                LiveCameraFrame frame = RequireFrame(reader, fixture);
                Check(nativeReads == 2 && reader.Diagnostics.Attempts == 1,
                    "Documented temporary upscaler phases still force retries.");
                Check(frame.CameraEpoch == first.CameraEpoch && frame.Sequence > first.Sequence &&
                    !reader.Diagnostics.EpochResetOccurred,
                    "The same final presentation was treated as a changed camera context.");
                Check(frame.SourceWidth == 1920 && frame.SourceHeight == 1080,
                    "The internal render resolution replaced the final source image.");
                Check(Math.Abs(frame.ViewportX) < .001 && Math.Abs(frame.ViewportY) < .001 &&
                    Math.Abs(frame.ViewportWidth - 1920) < .001 && Math.Abs(frame.ViewportHeight - 1080) < .001,
                    "The 1599 by 899 intermediate viewport was published instead of the saved presentation.");
                Check(ProjectionMath.TryCreateView(frame.ViewProjection, new LivePosition(),
                    frame.SourceWidth, frame.SourceHeight,
                    new ProjectionViewport(frame.ViewportX, frame.ViewportY, frame.ViewportWidth, frame.ViewportHeight),
                    ProjectionDepthRange.MinusOneToOne, out var view, out var reason),
                    "The final upscaler view was not projectable: " + reason);
                // Independent analytic point: camera at (10,5,-3), point ten
                // units forward. Its screen position must be the image center.
                Check(ProjectionMath.TryProjectPoint(view!, new LivePosition { X = 10, Y = 5, Z = 7 }, out var point) &&
                    Math.Abs(point.X - 960) < .001 && Math.Abs(point.Y - 540) < .001,
                    "A point moved with raw viewport phases or with the unused jittered matrix.");
                for (int component = 0; component < 16; component++)
                    Near(frame.ViewProjection[component], first.ViewProjection[component],
                        "Non-jittered projection changed with a temporary phase at component " + component);
                first = frame;
            }
            Check(reader.Diagnostics.EpochResetCounts.Count == 1 && reader.Diagnostics.EpochResetCounts["INITIAL_CONTEXT"] == 1,
                "Temporary render phases accumulated viewport epochs.");
        }
        return Task.CompletedTask;
    }

    public static Task UpscalerContextChangesStillRequireConfirmation()
    {
        foreach (Action<Fixture> change in new Action<Fixture>[]
        {
            f => f.EnableUpscaling(7),
            f => f.ReplaceFsr3(),
            f => f.ReplaceContext(),
            f =>
            {
                f.Memory.I32(f.Screen + 0xFC, 2560); f.Memory.I32(f.Screen + 0x108, 1440);
                f.SetPresentationSize(2560, 1440, 2133, 1199); f.SetRenderPhase(false);
            },
            f => f.DisableUpscaling()
        })
        {
            var fixture = new Fixture();
            fixture.EnableUpscaling(6);
            var reader = fixture.Reader();
            Prime(reader, fixture);
            LiveCameraFrame before = RequireFrame(reader, fixture);
            change(fixture);
            fixture.Advance();
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null &&
                reader.Diagnostics.Status == "CAMERA_ATTENTE_RENDU" && reader.Diagnostics.EpochResetOccurred,
                "A genuine upscaler owner, mode or final display change bypassed render confirmation.");
            fixture.Advance();
            LiveCameraFrame after = RequireFrame(reader, fixture);
            Check(after.CameraEpoch > before.CameraEpoch && after.Sequence > before.Sequence,
                "A changed upscaler context did not establish a new confirmed epoch.");
        }
        return Task.CompletedTask;
    }

    public static Task UpscalerOwnershipAndModesAreRequired()
    {
        foreach (Action<Fixture> mutation in new Action<Fixture>[]
        {
            f => f.Memory.U64(f.Local + Fixture.LocalRenderManagerOffset, 0),
            f => f.Memory.U64(f.RenderManager + Fixture.ManagerPlayerOffset, f.CloneManaged(f.Local, 0x40)),
            f => f.Memory.U64(f.RenderManager + Fixture.ManagerLayerOffset, 0),
            f => f.Memory.U64(f.RenderManagerVtable + 0x10, f.Domain + 0x100),
            f => f.Memory.U64(f.LayerVtable + 0x10, f.Domain + 0x100),
            f => f.Memory.U64(f.LayerClass + 0x40, f.Memory.Allocate(32)),
            f => f.Memory.U64(f.LayerFields + 16, f.LocalClass),
            f => f.Memory.I32(f.Fsr3Fields + 24, Fixture.UpscalerOriginalRectOffset + 8),
            f => f.Memory.U64(f.Layer + Fixture.LayerCameraOffset, f.NewCameraObject()),
            f => f.Memory.U64(f.Layer + Fixture.LayerContextOffset, 0),
            f => f.Memory.U64(f.Context + Fixture.ContextCameraOffset, f.NewCameraObject()),
            f => f.Memory.U64(f.ContextVtable + 0x10, f.Domain + 0x100),
            f => f.Memory.U64(f.Context + Fixture.ContextFsrOffset, f.Dlss),
            f => f.Memory.U64(f.Fsr3Vtable + 0x10, f.Domain + 0x100),
            f => f.Memory.U64(f.Fsr3Vtable, f.LayerClass),
            f => f.Memory.I32(f.Layer + Fixture.LayerModeOffset, 8),
            f => f.Memory.I32(f.Context + Fixture.ContextModeOffset, 7),
            f => f.Memory.Byte(f.RenderManager + Fixture.ManagerEnabledOffset, 0),
            f => f.Memory.U64(f.Layer + Fixture.LayerTargetOffset, f.Native),
            f => f.Memory.Byte(f.Layer + Fixture.LayerSceneViewOffset, 1),
            f => f.Memory.Byte(f.Context + Fixture.ContextStereoOffset, 1),
            f => f.Memory.Byte(f.Context + Fixture.ContextSceneOffset, 1),
            f => f.Memory.Byte(f.Context + Fixture.ContextPhysicalOffset, 1),
            f => f.Memory.Byte(f.Fsr3 + Fixture.UpscalerStereoOffset, 1)
        })
        {
            var fixture = new Fixture();
            fixture.EnableUpscaling(6);
            var reader = fixture.Reader();
            Prime(reader, fixture); RequireFrame(reader, fixture);
            // A reduced raw rect has x=0: absence of the 1e-7 marker alone
            // must never let a missing/bad upscaler graph fall back to native.
            fixture.SetRenderPhase(true);
            mutation(fixture); fixture.Advance();
            RequireRejectedPresentation(reader, fixture, "An absent, foreign or inconsistent presentation graph was accepted.");
        }
        return Task.CompletedTask;
    }

    public static Task UpscalerGraphChangesDuringCaptureAreRejected()
    {
        foreach (Action<Fixture> mutation in new Action<Fixture>[]
        {
            f => f.ReplaceContext(),
            f => f.ReplaceFsr3(),
            f =>
            {
                ulong address = f.Fsr3 + Fixture.UpscalerQualityOffset;
                int prior = BitConverter.ToInt32(f.Memory.Read(address, 4), 0);
                f.Memory.I32(address, prior == 2 ? 3 : 2);
            },
            f =>
            {
                ulong address = f.Layer + Fixture.LayerFinalBlitOffset;
                byte prior = f.Memory.Read(address, 1)[0];
                f.Memory.Byte(address, prior == 0 ? (byte)1 : (byte)0);
            }
        })
        {
            var fixture = new Fixture(); fixture.EnableUpscaling(6);
            var reader = fixture.Reader(); Prime(reader, fixture); RequireFrame(reader, fixture);
            int nativeReads = 0;
            fixture.Memory.BeforeRead = (address, count) =>
            {
                if (Contains(address, count, fixture.Native, 0x798) && (++nativeReads & 1) == 0)
                    mutation(fixture);
            };
            RequireRejectedPresentation(reader, fixture,
                "The presentation graph changed across the native pair without invalidating its frame.");
            Check(nativeReads >= 2, "The presentation-mutation fixture did not reach the paired native acquisition.");
        }
        return Task.CompletedTask;
    }

    public static Task UpscalerRejectsInvalidPresentationAndNonJitteredData()
    {
        foreach (int mode in new[] { 6, 7 })
        foreach (Action<Fixture, ulong> mutation in new Action<Fixture, ulong>[]
        {
            (f,u) => f.Memory.F32(u + Fixture.UpscalerOriginalRectOffset, float.NaN),
            (f,u) => f.Memory.F32(u + Fixture.UpscalerOriginalRectOffset + 8, .8f),
            (f,u) => f.Memory.I32(u + Fixture.UpscalerDisplayOffset, 0),
            (f,u) => f.Memory.I32(u + Fixture.UpscalerDisplayOffset, 1600),
            (f,u) => f.Memory.I32(u + Fixture.UpscalerRenderOffset, 0),
            (f,u) => f.Memory.I32(u + Fixture.UpscalerRenderOffset, 1921),
            (f,u) => f.Memory.I32(u + Fixture.UpscalerQualityOffset, 0),
            (f,u) => f.Memory.I32(f.Context + Fixture.ContextScreenHeightOffset, 899),
            (f,u) => f.Memory.F32(f.Native + 0x434, .7f),
            (f,u) => f.Memory.I32(f.Native + 0x514, 2), // Physical mode may precede the context's flag update.
            (f,u) => f.Memory.Byte(f.Native + 0x554, 0),
            (f,u) => f.Memory.F32(f.Native + 0x758, float.NaN),
            (f,u) => f.Memory.Write(f.Native + 0x758, new byte[64])
        })
        {
            var fixture = new Fixture(); fixture.EnableUpscaling(mode);
            var reader = fixture.Reader(); Prime(reader, fixture); RequireFrame(reader, fixture);
            mutation(fixture, mode == 6 ? fixture.Fsr3 : fixture.Dlss); fixture.Advance();
            RequireRejectedPresentation(reader, fixture,
                "Invalid saved geometry, dimensions or explicit non-jittered projection was accepted.");
        }
        foreach (bool changeFlag in new[] { false, true })
        {
            var fixture = new Fixture(); fixture.EnableUpscaling(6);
            var reader = fixture.Reader(); Prime(reader, fixture); RequireFrame(reader, fixture);
            int nativeReads = 0;
            fixture.Memory.BeforeRead = (address, count) =>
            {
                if (!Contains(address, count, fixture.Native, 0x798)) return;
                bool first = (++nativeReads & 1) != 0;
                if (changeFlag) fixture.Memory.Byte(fixture.Native + 0x554, first ? (byte)1 : (byte)0);
                else fixture.Memory.F32(fixture.Native + 0x758 + 8 * 4, first ? 0 : .002f);
            };
            RequireRejectedPresentation(reader, fixture,
                "A changing explicit flag or non-jittered matrix escaped paired coherence validation.");
            Check(nativeReads >= 2, "The non-jittered mutation did not exercise the native pair.");
        }
        return Task.CompletedTask;
    }

    public static Task NativeRenderingKeepsItsOwnViewportAndProjection()
    {
        var fixture = new Fixture();
        // A disabled upscaler may retain its old fields. The positively
        // confirmed native path must neither consume them nor force full screen.
        fixture.Memory.F32(fixture.Fsr3 + Fixture.UpscalerOriginalRectOffset, float.NaN);
        fixture.Memory.F32(fixture.Dlss + Fixture.UpscalerOriginalRectOffset, float.NaN);
        fixture.Memory.Byte(fixture.Native + 0x554, 1);
        fixture.Memory.F32(fixture.Native + 0x758, float.NaN);
        fixture.Memory.F32(fixture.Native + 0x42C, .1f); fixture.Memory.F32(fixture.Native + 0x430, .2f);
        fixture.Memory.F32(fixture.Native + 0x434, .5f); fixture.Memory.F32(fixture.Native + 0x438, .6f);
        var reader = fixture.Reader(); Prime(reader, fixture);
        LiveCameraFrame frame = RequireFrame(reader, fixture);
        Near(frame.ViewportX, 192, "Native inset X with stale upscaler fields");
        Near(frame.ViewportY, 216, "Native inset Y with stale upscaler fields");
        Near(frame.ViewportWidth, 960, "Native inset width with stale upscaler fields");
        Near(frame.ViewportHeight, 648, "Native inset height with stale upscaler fields");
        fixture.Memory.Byte(fixture.Native + 0x510, 1); fixture.Advance();
        RequireRejectedPresentation(reader, fixture,
            "The native path bypassed its dirty guard because an explicit non-jittered flag remained set.");
        return Task.CompletedTask;
    }

    public static Task DisabledPostProcessingCannotReuseUpscalerState()
    {
        foreach (int mode in new[] { 6, 7 })
        foreach (bool destroyed in new[] { false, true })
        {
            var fixture = new Fixture(); fixture.EnableUpscaling(mode);
            var reader = fixture.Reader(); Prime(reader, fixture); RequireFrame(reader, fixture);
            // OnDisable leaves the old managed context and explicit projection
            // available. Rendering by other cameras can still advance the count.
            if (destroyed) fixture.Memory.U64(fixture.Layer + 0x10, 0);
            else fixture.Memory.Byte(fixture.LayerNative + 0x39, 0);
            fixture.Advance();
            RequireRejectedPresentation(reader, fixture,
                "A disabled or destroyed post-process layer reused its old upscaler state.");
        }
        foreach (int mutation in new[] { 0, 1, 2 })
        {
            var fixture = new Fixture(); fixture.EnableUpscaling(6);
            var reader = fixture.Reader(); Prime(reader, fixture); RequireFrame(reader, fixture);
            int nativeReads = 0;
            fixture.Memory.BeforeRead = (address, count) =>
            {
                if (!Contains(address, count, fixture.Native, 0x798) || (++nativeReads & 1) != 0) return;
                if (mutation == 0)
                    fixture.Memory.Byte(fixture.LayerNative + 0x39, 0);
                else if (mutation == 1)
                {
                    fixture.LayerNative = fixture.CloneManaged(fixture.LayerNative, 0x80);
                    fixture.Memory.U64(fixture.Layer + 0x10, fixture.LayerNative);
                }
                else
                {
                    ulong previous = BitConverter.ToUInt64(fixture.Memory.Read(fixture.LayerNative, 8), 0);
                    fixture.Memory.U64(fixture.LayerNative,
                        previous == Fixture.Module + 0x1980100 ? Fixture.Module + 0x1980200 : Fixture.Module + 0x1980100);
                }
            };
            RequireRejectedPresentation(reader, fixture,
                "A changing native layer pointer, vtable or active state escaped capture validation.");
            Check(nativeReads >= 2, "The component mutation did not occur across a native camera pair.");
        }
        foreach (bool destroyed in new[] { false, true })
        {
            var fixture = new Fixture();
            if (destroyed) fixture.Memory.U64(fixture.Layer + 0x10, 0);
            else fixture.Memory.Byte(fixture.LayerNative + 0x39, 0);
            var reader = fixture.Reader(); Prime(reader, fixture);
            LiveCameraFrame frame = RequireFrame(reader, fixture);
            Check(frame.ViewportWidth == 1920 && frame.ViewportHeight == 1080,
                "An explicitly disabled upscaler prevented otherwise valid native rendering.");
        }
        return Task.CompletedTask;
    }

    private static void RequireRejectedPresentation(NativeCameraReader reader, Fixture fixture, string message)
    {
        Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null &&
            reader.Diagnostics.Status != "CAMERA_PRETE" && reader.Diagnostics.Status != "CAMERA_ATTENTE_RENDU",
            message + " Status: " + reader.Diagnostics.Status + " / " + reader.Diagnostics.Message);
    }

    public static Task ExactProfileAndProjection()
    {
        var fixture = new Fixture();
        var reader = fixture.Reader();
        Check(reader.Diagnostics.ProfileVerified, "Exact independent PE/signature evidence did not verify: " + reader.Diagnostics.Message);
        Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null && reader.Diagnostics.Status == "CAMERA_ATTENTE_RENDU",
            "The first stable observation must wait for rendered-frame advancement.");
        fixture.Advance();
        LiveCameraFrame frame = RequireFrame(reader, fixture);
        Check(frame.Format == "SevenDaysEsp.CameraFrame/1" && frame.ProfileId == GoldenProfileId,
            "The native frame lost its exact profile/format identity.");
        Check(frame.SourceWidth == 1920 && frame.SourceHeight == 1080 && frame.ViewportX == 0 && frame.ViewportY == 0 &&
            frame.ViewportWidth == 1920 && frame.ViewportHeight == 1080 && frame.ClipDepth == "MinusOneToOne",
            "The native frame lost its source viewport/clip contract.");

        // Independent analytic P*V golden: camera at (10,5,-3), Unity view Z flip,
        // vertical FOV 90 only as test data, 16:9, near .1, far 1000.
        float a = -1000.1f / 999.9f, b = -200f / 999.9f;
        float[] expected = { 0.5625f, 0, 0, -5.625f, 0, 1, 0, -5, 0, 0, -a, -3 * a + b, 0, 0, 1, 3 };
        Check(frame.ViewProjection.Length == 16, "View-projection does not contain sixteen values.");
        for (int i = 0; i < expected.Length; i++)
            Near(frame.ViewProjection[i], expected[i], "Canonical matrix component " + i);
        // World/render point (10,5,7) is ten units ahead of this camera.
        Near(frame.ViewProjection[0] * 10 + frame.ViewProjection[3], 0, "Known point horizontal clip coordinate");
        Near(frame.ViewProjection[5] * 5 + frame.ViewProjection[7], 0, "Known point vertical clip coordinate");
        Near(frame.ViewProjection[14] * 7 + frame.ViewProjection[15], 10, "Known point positive clip W");
        long sequence = frame.Sequence;
        int epoch = frame.CameraEpoch;
        fixture.Advance();
        LiveCameraFrame next = RequireFrame(reader, fixture);
        Check(next.Sequence > sequence && next.CameraEpoch == epoch, "Same-camera progress must advance sequence without changing epoch.");

        // A full-screen rect alone cannot detect an inverted viewport-origin
        // formula. Exercise an asymmetric inset with a known top-left result.
        var inset = new Fixture();
        inset.Memory.F32(inset.Native + 0x42C, 0.1f);
        inset.Memory.F32(inset.Native + 0x430, 0.2f);
        inset.Memory.F32(inset.Native + 0x434, 0.5f);
        inset.Memory.F32(inset.Native + 0x438, 0.6f);
        var insetReader = inset.Reader();
        Prime(insetReader, inset);
        LiveCameraFrame insetFrame = RequireFrame(insetReader, inset);
        Near(insetFrame.ViewportX, 192, "Inset viewport X");
        Near(insetFrame.ViewportY, 216, "Inset viewport top-left Y");
        Near(insetFrame.ViewportWidth, 960, "Inset viewport width");
        Near(insetFrame.ViewportHeight, 648, "Inset viewport height");
        return Task.CompletedTask;
    }

    public static Task GroupedPresentationMetadataRemainsLiveAndValidated()
    {
        var fixture = new Fixture();
        fixture.EnableUpscaling(6);
        ulong selectedFields = fixture.PadLayerDescriptors();
        ulong typeBase = fixture.Memory.AllocatePageAligned(1);
        ulong[] types = Enumerable.Range(0, 8).Select(i => typeBase + (ulong)(i * 16)).ToArray();
        types[5] = types[4]; // Both boolean fields may share one MonoType.
        fixture.RelocateFieldTypes(selectedFields, types);
        var reader = fixture.Reader();
        int groupedReads = 0, descriptorWindows = 0;
        Action<ulong, int> inspect = (address, count) =>
        {
            if (Overlaps(address, count, fixture.LayerFields, 13 * 32))
            {
                Check(address >= selectedFields && address + (ulong)count <= selectedFields + 8 * 32,
                    "Live presentation validation read unused descriptor prefixes or suffixes.");
                if (Contains(address, count, selectedFields, 8 * 32)) descriptorWindows++;
            }
            if (Contains(address, count, types[0], 16) && Contains(address, count, types[7], 16)) groupedReads++;
        };
        fixture.Memory.BeforeRead = inspect;
        Prime(reader, fixture);
        RequireFrame(reader, fixture);
        Check(groupedReads >= 2 && descriptorWindows >= 2,
            "The positive fixture did not exercise grouped types and the selected descriptor window on both phases.");
        ulong aliasedType = types[4];
        byte[] originalType = fixture.Memory.Read(aliasedType, 16);
        foreach (Action corrupt in new Action[]
        {
            () => fixture.Memory.Byte(aliasedType + 10, 0x08),
            () => fixture.Memory.U64(aliasedType, fixture.CameraClass),
            () => fixture.Memory.U16(aliasedType + 8, 0x10)
        })
        {
            corrupt(); fixture.Advance();
            RequireRejectedPresentation(reader, fixture,
                "A corrupted aliased type reused metadata bytes retained from an earlier capture.");
            fixture.Memory.Write(aliasedType, originalType);
            fixture.Advance(); RequireFrame(reader, fixture);
        }

        ulong changedDescriptor = selectedFields + 6 * 32;
        byte[] originalDescriptor = fixture.Memory.Read(changedDescriptor, 32);
        foreach (bool changeDescriptor in new[] { false, true })
        {
            bool changed = false;
            int nativeBlocks = 0, closingReads = 0;
            fixture.Memory.BeforeRead = (address, count) =>
            {
                inspect(address, count);
                if (Contains(address, count, fixture.Native, 0x798) && ++nativeBlocks == 2)
                {
                    changed = true;
                    if (changeDescriptor) fixture.Memory.U64(changedDescriptor + 16, fixture.LocalClass);
                    else fixture.Memory.Byte(aliasedType + 10, 0x08);
                }
                if (changed && Contains(address, count,
                    changeDescriptor ? changedDescriptor + 16 : aliasedType + 10, changeDescriptor ? 8 : 1)) closingReads++;
            };
            RequireRejectedPresentation(reader, fixture,
                "Closing validation reused descriptor/type bytes from before the native pair.");
            Check(changed && nativeBlocks >= 2 && closingReads > 0,
                "The metadata mutation did not reach the native pair and its closing revalidation.");
            fixture.Memory.Write(aliasedType, originalType);
            fixture.Memory.Write(changedDescriptor, originalDescriptor);
            fixture.Memory.BeforeRead = inspect;
            fixture.Advance(); RequireFrame(reader, fixture);
        }
        return Task.CompletedTask;
    }

    public static Task GroupedPresentationReadsRespectBoundsAndRejectShortData()
    {
        foreach (bool spanLimit in new[] { false, true })
        {
            var fixture = new Fixture();
            fixture.EnableUpscaling(spanLimit ? 7 : 6);
            ulong region = fixture.Memory.AllocatePageAligned(3);
            ulong[] offsets = spanLimit
                ? Enumerable.Range(0, 8).Select(i => (ulong)(i * 80)).ToArray()
                : new ulong[] { 0xFF0, 0x1000, 0x1010, 0x1080, 0x1090, 0x10A0, 0x1FF8, 0x2010 };
            ulong[] types = offsets.Select(offset => region + offset).ToArray();
            fixture.RelocateFieldTypes(fixture.LayerFields, types);
            var reader = fixture.Reader();
            var requests = new List<(ulong Address, int Count)>();
            fixture.Memory.BeforeRead = (address, count) =>
            {
                if (!types.Any(type => Overlaps(address, count, type, 16))) return;
                requests.Add((address, count));
                Check(count <= 512, "A grouped MonoType read exceeded its bounded span.");
                bool crossesPage = (address >> 12) != ((address + (ulong)count - 1) >> 12);
                if (crossesPage)
                    Check(count == 16 && types.Contains(address),
                        "Grouping joined types across a page boundary instead of retaining an individual crossing type.");
                if (!spanLimit)
                    Check(!(Contains(address, count, types[2], 16) && Contains(address, count, types[3], 16)),
                        "A type group crossed a gap larger than 64 bytes.");
            };
            Prime(reader, fixture); RequireFrame(reader, fixture);
            Check(requests.Any(r => r.Count > 16), "The boundary fixture did not exercise a real grouped read.");
            if (!spanLimit)
                Check(requests.Any(r => r.Address == types[6] && r.Count == 16),
                    "An individually page-crossing MonoType did not keep its original exact read.");

            foreach (bool descriptor in new[] { false, true })
            {
                int shortReads = 0;
                fixture.Memory.ReadOverride = (address, count) =>
                {
                    bool target = descriptor
                        ? count > 32 && Contains(address, count, fixture.LayerFields + 16, 8)
                        : count > 16 && Contains(address, count, types[spanLimit ? 0 : 1], 16);
                    if (!target) return null;
                    shortReads++;
                    return new byte[count - 1];
                };
                Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null && shortReads > 0 &&
                    reader.Diagnostics.Status == "CAMERA_LECTURE_INCOMPLETE" && reader.Diagnostics.ProfileVerified,
                    "A partial grouped metadata read was accepted or lost its IO diagnostic.");
                fixture.Memory.ReadOverride = null;
                fixture.Advance(); RequireFrame(reader, fixture);
            }
        }
        return Task.CompletedTask;
    }

    public static Task RuntimeRegistrationReadsAllSlotsAndCurrentHeaders()
    {
        foreach (string role in new[] { "local", "camera", "layer" })
        foreach (int slot in new[] { 0, 2 })
        {
            var fixture = new Fixture(); fixture.EnableUpscaling(6);
            var owner = fixture.RuntimeOwner(role);
            ulong runtime = fixture.RegisterRuntime(owner.Class, owner.Table, 2, slot);
            ulong other = fixture.Memory.Allocate(0x60);
            fixture.Memory.U64(other, owner.Class);
            fixture.Memory.U64(other + 16, fixture.Memory.Allocate(32));
            fixture.Memory.U64(runtime + 8 + (ulong)((slot == 0 ? 2 : 0) * 8), other);
            var reader = fixture.Reader();
            Prime(reader, fixture);
            LiveCameraFrame before = RequireFrame(reader, fixture);
            fixture.RegisterRuntime(owner.Class, owner.Table, 1, 1);
            fixture.Memory.Write(runtime + 8, new byte[24]);
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null &&
                reader.Diagnostics.Status == "CAMERA_ATTENTE_RENDU",
                "A runtime change did not use the current class header and require a fresh context: " + role);
            fixture.Advance();
            LiveCameraFrame after = RequireFrame(reader, fixture);
            Check(after.CameraEpoch > before.CameraEpoch,
                "Replacing the runtime registration did not change the confirmed epoch: " + role);
        }

        foreach (string role in new[] { "camera", "layer" })
        foreach (string failure in new[] { "duplicate", "missing", "too-many", "null-runtime", "foreign-domain" })
        {
            var fixture = new Fixture(); fixture.EnableUpscaling(6);
            var reader = fixture.Reader(); Prime(reader, fixture); RequireFrame(reader, fixture);
            var owner = fixture.RuntimeOwner(role);
            switch (failure)
            {
                case "duplicate": fixture.RegisterRuntime(owner.Class, owner.Table, 2, 0, 2); break;
                case "missing": fixture.RegisterRuntime(owner.Class, owner.Table, 2); break;
                case "too-many": fixture.RegisterRuntime(owner.Class, owner.Table, 32, 0); break;
                case "null-runtime": fixture.Memory.U64(owner.Class + 0xD0, 0); break;
                default:
                    fixture.RegisterRuntime(owner.Class, owner.Table, 2, 2);
                    fixture.Memory.U64(owner.Table + 16, fixture.Memory.Allocate(32));
                    break;
            }
            RequireRejectedPresentation(reader, fixture,
                "The grouped runtime path accepted invalid registration/domain data: " + role + "/" + failure);
        }

        foreach (string role in new[] { "local", "camera", "layer" })
        {
            var fixture = new Fixture(); fixture.EnableUpscaling(6);
            var owner = fixture.RuntimeOwner(role);
            ulong first = fixture.RegisterRuntime(owner.Class, owner.Table, 0, 0);
            ulong second = fixture.RegisterRuntime(owner.Class, owner.Table, 2, 2);
            fixture.Memory.U64(owner.Class + 0xD0, first);
            var reader = fixture.Reader(); Prime(reader, fixture); RequireFrame(reader, fixture);
            int nativeBlocks = 0, changes = 0;
            fixture.Memory.BeforeRead = (address, count) =>
            {
                if (!Contains(address, count, fixture.Native, 0x798) || (++nativeBlocks & 1) != 0) return;
                fixture.Memory.U64(owner.Class + 0xD0, (++changes & 1) != 0 ? second : first);
            };
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null &&
                reader.Diagnostics.Status == "CAMERA_CAPTURE_INSTABLE" && nativeBlocks >= 2 && changes > 0,
                "The runtime pointer was not revalidated after the native pair: " + role);
        }
        return Task.CompletedTask;
    }

    public static Task RuntimeHeaderAndSuffixShortReadsFailClosed()
    {
        foreach (string role in new[] { "camera", "layer" })
        foreach (bool suffix in new[] { false, true })
        {
            var fixture = new Fixture(); fixture.EnableUpscaling(6);
            var owner = fixture.RuntimeOwner(role);
            ulong runtime = fixture.RegisterRuntime(owner.Class, owner.Table, 2, 2);
            var reader = fixture.Reader(); Prime(reader, fixture); RequireFrame(reader, fixture);
            int shortReads = 0;
            fixture.Memory.ReadOverride = (address, count) =>
            {
                if (!Contains(address, count, runtime + (suffix ? 16UL : 0UL), 16)) return null;
                shortReads++;
                return new byte[count - 1];
            };
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null && shortReads > 0 &&
                reader.Diagnostics.Status == "CAMERA_LECTURE_INCOMPLETE" && reader.Diagnostics.ProfileVerified,
                "A truncated runtime header or additional-domain suffix was consumed: " + role);
            fixture.Memory.ReadOverride = null;
            fixture.Advance(); RequireFrame(reader, fixture);
        }
        return Task.CompletedTask;
    }

    public static Task InitializationReadFailureRecoversOnlyOutsideCapture()
    {
        var signature = GoldenSignatures.Single(s => s.Name == "ProjectionGetterCallsCache");
        foreach (bool shortRead in new[] { false, true })
        {
            var fixture = new Fixture();
            ulong target = Fixture.Module + signature.Rva;
            bool failNext = true;
            int memoryReads = 0;
            var requests = new List<(ulong Address, int Count)>();
            fixture.Memory.BeforeRead = (address, count) =>
            {
                memoryReads++;
                requests.Add((address, count));
                if (!shortRead && address == target && failNext)
                {
                    failNext = false;
                    fixture.Clock += 700; // A slow attempt ends after its initial timestamp.
                    throw new IOException("Synthetic DMA incomplete: 0/" + count + " bytes.");
                }
            };
            fixture.Memory.ReadOverride = (address, count) =>
            {
                if (!shortRead || address != target || !failNext) return null;
                failNext = false;
                fixture.Clock += 700;
                return new byte[count - 1];
            };
            var reader = fixture.Reader();
            long failedAt = fixture.Clock;
            Check(!reader.IsInitialized && !reader.Diagnostics.ProfileVerified &&
                reader.Diagnostics.Stage == "PROFIL_BINAIRE" && reader.Diagnostics.Status == "CAMERA_LECTURE_INCOMPLETE" &&
                reader.Diagnostics.InitializationAttempts == 1 && reader.Diagnostics.InitializationRetryPending &&
                !reader.InitializationRetryDue && !String.IsNullOrEmpty(reader.Diagnostics.LastInitializationFailure),
                "A failed initial profile read lost its unverified state or retry classification.");
            Check(reader.Diagnostics.FailedSignatureName == signature.Name &&
                SignatureRva(reader.Diagnostics.FailedSignatureRva) == signature.Rva,
                "The failed initial code read lost its signature and RVA diagnostics.");
            string failure = reader.Diagnostics.LastInitializationFailure;
            NativeCameraDiagnostics failed = reader.Diagnostics;
            int readsAtFailure = memoryReads, lookupsAtFailure = fixture.Memory.ModuleLookups;
            foreach (int elapsed in new[] { 0, 1999, 2000, 4000 })
            {
                fixture.Clock = failedAt + elapsed;
                Check(reader.InitializationRetryDue == (elapsed >= 2000),
                    "The retry deadline is not two seconds after the completed attempt.");
                Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null &&
                    memoryReads == readsAtFailure && fixture.Memory.ModuleLookups == lookupsAtFailure &&
                    ReferenceEquals(failed, reader.Diagnostics) &&
                    reader.Diagnostics.InitializationAttempts == 1 && !reader.Diagnostics.ProfileVerified,
                    "Capture performed initialization IO or changed diagnostics while the profile was unavailable.");
            }
            requests.Clear();
            Check(reader.InitializeProfile() && reader.IsInitialized && reader.Diagnostics.ProfileVerified &&
                reader.Diagnostics.InitializationAttempts == 2 && !reader.Diagnostics.InitializationRetryPending &&
                !reader.InitializationRetryDue,
                "The explicit retry between captures did not recover from a transient read.");
            Check(requests.Contains((Fixture.Module, 64)) &&
                requests.Contains((Fixture.Module + 0xFEFB50UL, GoldenSignatures.Single(s => s.Name == "BindingRegistration").Hex.Length / 2)) &&
                requests.Contains((target, signature.Hex.Length / 2)),
                "Recovery did not restart the PE and mandatory signature validation from the beginning.");
            Check(reader.Diagnostics.FailedSignatureName == String.Empty && reader.Diagnostics.FailedSignatureRva == String.Empty,
                "A completed revalidation retained a currently failing signature.");
            Prime(reader, fixture);
            RequireFrame(reader, fixture);
            Check(reader.Diagnostics.InitializationAttempts == 2 && !reader.Diagnostics.InitializationRetryPending &&
                reader.Diagnostics.LastInitializationFailure == failure,
                "The first successful camera captures lost initialization history or kept retry pending.");
        }
        return Task.CompletedTask;
    }

    public static Task PersistentInitializationReadsRespectCompletionCooldown()
    {
        var signature = GoldenSignatures.Single(s => s.Name == "ProjectionGetterCallsCache");
        var fixture = new Fixture();
        int memoryReads = 0, failures = 0;
        fixture.Memory.BeforeRead = (address, count) =>
        {
            memoryReads++;
            if (address != Fixture.Module + signature.Rva) return;
            failures++;
            fixture.Clock += 900;
            throw new IOException("Persistent synthetic profile read failure.");
        };
        var reader = fixture.Reader();
        for (int attempt = 1; attempt <= 3; attempt++)
        {
            Check(failures == attempt && reader.Diagnostics.InitializationAttempts == attempt &&
                !reader.IsInitialized && !reader.Diagnostics.ProfileVerified &&
                reader.Diagnostics.InitializationRetryPending && !reader.InitializationRetryDue &&
                reader.Diagnostics.Status == "CAMERA_LECTURE_INCOMPLETE",
                "Persistent IO was promoted to a valid profile or retried without its cooldown.");
            long ended = fixture.Clock;
            int reads = memoryReads, lookups = fixture.Memory.ModuleLookups;
            for (int poll = 0; poll < 20; poll++)
            {
                fixture.Clock = ended + poll * 100;
                Check(!reader.InitializationRetryDue && reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null,
                    "A frequent entity-loop poll retried initialization before the cooldown.");
            }
            fixture.Clock = ended + 1999;
            Check(!reader.InitializationRetryDue && memoryReads == reads && fixture.Memory.ModuleLookups == lookups,
                "Initialization IO occurred during the quiet interval.");
            fixture.Clock = ended + 2000;
            Check(reader.InitializationRetryDue && reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null &&
                memoryReads == reads && fixture.Memory.ModuleLookups == lookups && reader.Diagnostics.InitializationAttempts == attempt,
                "A due retry ran inside Capture instead of the worker's between-capture step.");
            if (attempt < 3) Check(!reader.InitializeProfile(), "Persistent IO unexpectedly completed initialization.");
        }
        return Task.CompletedTask;
    }

    public static Task InitializationBudgetFailureCanRecover()
    {
        var signature = GoldenSignatures.Single(s => s.Name == "ProjectionGetterCallsCache");
        var fixture = new Fixture();
        bool delayed = false;
        fixture.Memory.BeforeRead = (address, count) =>
        {
            if (address != Fixture.Module + signature.Rva || delayed) return;
            delayed = true;
            // Read budgets intentionally use a real stopwatch, independently of
            // the injected retry/render clock. One delayed read exercises it.
            System.Threading.Thread.Sleep(1550);
            fixture.Clock += 1550;
        };
        var reader = fixture.Reader();
        Check(delayed && !reader.IsInitialized && !reader.Diagnostics.ProfileVerified &&
            reader.Diagnostics.Status == "CAMERA_BUDGET_DEPASSE" && reader.Diagnostics.InitializationAttempts == 1 &&
            reader.Diagnostics.InitializationRetryPending && !reader.InitializationRetryDue,
            "An exhausted initialization budget did not stay unverified and recoverable.");
        fixture.Clock += 1999;
        Check(!reader.InitializationRetryDue, "A budget failure scheduled its retry before the completed attempt's cooldown.");
        fixture.Clock++;
        Check(reader.InitializationRetryDue && reader.InitializeProfile() && reader.Diagnostics.InitializationAttempts == 2,
            "The bounded initialization did not recover on its next explicit attempt.");
        Prime(reader, fixture);
        RequireFrame(reader, fixture);
        Check(reader.IsInitialized && reader.Diagnostics.ProfileVerified && !reader.Diagnostics.InitializationRetryPending,
            "A recovered budget failure did not reach a newly confirmed camera.");
        return Task.CompletedTask;
    }

    public static Task RetriedInitializationRevalidatesEarlierCodeAndRejectsMismatch()
    {
        var failedSignature = GoldenSignatures.Single(s => s.Name == "ProjectionGetterCallsCache");
        var earlierSignature = GoldenSignatures.Single(s => s.Name == "BindingRegistration");
        var fixture = new Fixture();
        bool unreadable = true;
        int memoryReads = 0;
        fixture.Memory.BeforeRead = (address, count) =>
        {
            memoryReads++;
            if (unreadable && address == Fixture.Module + failedSignature.Rva)
                throw new IOException("Synthetic first-attempt code read failure.");
        };
        var reader = fixture.Reader();
        Check(reader.Diagnostics.InitializationRetryPending && !reader.Diagnostics.ProfileVerified,
            "The first IO failure did not prepare the retry regression.");
        unreadable = false;
        fixture.Memory.Byte(Fixture.Module + earlierSignature.Rva,
            (byte)(Convert.FromHexString(earlierSignature.Hex)[0] ^ 1));
        fixture.Clock += 2000;
        Check(reader.InitializationRetryDue && !reader.InitializeProfile() &&
            !reader.IsInitialized && !reader.Diagnostics.ProfileVerified &&
            reader.Diagnostics.Status == "PROFIL_NATIF_INVALIDE" && reader.Diagnostics.InitializationAttempts == 2 &&
            reader.Diagnostics.FailedSignatureName == earlierSignature.Name &&
            !reader.Diagnostics.InitializationRetryPending,
            "A retry reused earlier signature trust or classified a real mismatch as transient IO.");
        int reads = memoryReads, lookups = fixture.Memory.ModuleLookups;
        fixture.Clock += 100000;
        Check(!reader.InitializationRetryDue && reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null &&
            memoryReads == reads && fixture.Memory.ModuleLookups == lookups && reader.Diagnostics.InitializationAttempts == 2,
            "A hard binary mismatch was automatically retried or produced a camera.");
        return Task.CompletedTask;
    }

    public static Task ColdUnusedXrCodeDoesNotBlockProjection()
    {
        ulong codePage = (Fixture.Module + 0xF7FE30UL) & ~4095UL;
        foreach (int mode in new[] { 0, 6, 7 })
        {
            var fixture = new Fixture();
            if (mode != 0) fixture.EnableUpscaling(mode);
            int coldCodeReads = 0;
            fixture.Memory.BeforeRead = (address, count) =>
            {
                if (address < codePage + 4096 && address + (ulong)count > codePage)
                {
                    coldCodeReads++;
                    throw new IOException("The unused XR code page is permanently unreadable.");
                }
            };
            var reader = fixture.Reader();
            Check(reader.IsInitialized && reader.Diagnostics.ProfileVerified &&
                !reader.Diagnostics.XrGetterVerified && reader.Diagnostics.InitializationAttempts == 1,
                "A null XR manager still required its unreachable optional getter during initialization.");
            Prime(reader, fixture);
            for (int capture = 0; capture < 3; capture++)
            {
                RequireFrame(reader, fixture);
                Check(coldCodeReads == 0 && !reader.Diagnostics.XrGetterVerified &&
                    reader.Diagnostics.ProfileVerified && reader.Diagnostics.InitializationAttempts == 1,
                    "A null XR manager read cold code or falsely marked its getter verified.");
                fixture.Advance();
            }
        }
        return Task.CompletedTask;
    }

    public static Task XrManagerRequiresVerifiedGetterAndStableReferences()
    {
        const ulong getterRva = 0xF7FE30UL;
        const ulong globalRva = 0x1D33D20UL;
        foreach (bool lateAppearance in new[] { false, true })
        foreach (string failure in new[] { "unreadable", "mismatch", "active" })
        {
            var fixture = new Fixture();
            ulong xr = 0;
            if (!lateAppearance)
            {
                fixture.SetXr(failure == "active");
                xr = BitConverter.ToUInt64(fixture.Memory.Read(Fixture.Module + globalRva, 8), 0);
            }
            if (failure == "mismatch") fixture.Memory.Byte(Fixture.Module + getterRva, 0);
            bool unreadable = failure == "unreadable";
            int getterReads = 0, flagReads = 0, memoryReads = 0;
            fixture.Memory.BeforeRead = (address, count) =>
            {
                memoryReads++;
                if (address == Fixture.Module + getterRva)
                {
                    getterReads++;
                    if (unreadable) throw new IOException("Synthetic conditional XR getter read: 0/8 bytes.");
                }
                if (xr != 0 && Contains(address, count, xr + 0x2A5, 1))
                {
                    flagReads++;
                    Check(getterReads > 0 && !unreadable && failure != "mismatch",
                        "XR enabled state was interpreted before its conditional getter was verified.");
                }
            };
            var reader = fixture.Reader();
            RequireInitialized(reader);
            Check(getterReads == 0 && !reader.Diagnostics.XrGetterVerified,
                "The base profile speculatively read or trusted the conditional XR getter.");
            if (lateAppearance)
            {
                Prime(reader, fixture);
                RequireFrame(reader, fixture);
                Check(getterReads == 0 && flagReads == 0,
                    "A camera without an XR manager touched the conditional XR implementation.");
                fixture.SetXr(failure == "active");
                xr = BitConverter.ToUInt64(fixture.Memory.Read(Fixture.Module + globalRva, 8), 0);
            }
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null && getterReads > 0,
                "An existing or newly appeared XR manager bypassed its required getter validation: " + failure);
            if (failure == "unreadable")
            {
                Check(reader.Diagnostics.Status == "CAMERA_LECTURE_INCOMPLETE" && flagReads == 0 &&
                    reader.IsInitialized && reader.Diagnostics.ProfileVerified && !reader.Diagnostics.XrGetterVerified &&
                    !reader.Diagnostics.InitializationRetryPending && reader.Diagnostics.FailedSignatureName == "XrEnabledGetter" &&
                    SignatureRva(reader.Diagnostics.FailedSignatureRva) == getterRva,
                    "Conditional XR IO was mistaken for an inactive manager or a new initialization attempt.");
                unreadable = false;
                Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null &&
                    reader.Diagnostics.Status == "CAMERA_ATTENTE_RENDU",
                    "A newly readable XR path reused an old rendered-frame confirmation.");
                fixture.Advance();
                RequireFrame(reader, fixture);
                Check(reader.Diagnostics.XrGetterVerified && flagReads > 0 && reader.Diagnostics.InitializationAttempts == 1,
                    "Conditional XR recovery did not verify its code before consuming the enabled flag.");
            }
            else if (failure == "mismatch")
            {
                Check(reader.Diagnostics.Status == "PROFIL_NATIF_INVALIDE" && flagReads == 0 &&
                    !reader.IsInitialized && !reader.Diagnostics.ProfileVerified && !reader.Diagnostics.XrGetterVerified &&
                    !reader.Diagnostics.InitializationRetryPending,
                    "A conditional XR signature mismatch did not revoke the profile and camera path.");
                int reads = memoryReads;
                fixture.Clock += 100000;
                Check(!reader.InitializationRetryDue && reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null &&
                    memoryReads == reads,
                    "A failed conditional signature enabled an automatic initialization retry.");
            }
            else
            {
                Check(reader.Diagnostics.Status == "CAMERA_CONFIGURATION_NON_SUPPORTEE" &&
                    reader.Diagnostics.XrGetterVerified && flagReads > 0 && reader.Diagnostics.ProfileVerified,
                    "Verified code incorrectly allowed an active XR renderer.");
            }
        }

        // An initially absent manager must not be treated as a constant null pointer.
        // Make every before/after environment pair observe different identities.
        var changing = new Fixture();
        changing.SetXr(false);
        ulong manager = BitConverter.ToUInt64(changing.Memory.Read(Fixture.Module + globalRva, 8), 0);
        changing.Memory.U64(Fixture.Module + globalRva, 0);
        var changingReader = changing.Reader();
        Prime(changingReader, changing);
        RequireFrame(changingReader, changing);
        int globals = 0, nativeBlocks = 0;
        changing.Memory.BeforeRead = (address, count) =>
        {
            if (Contains(address, count, Fixture.Module + globalRva, 8))
                changing.Memory.U64(address, (++globals & 1) != 0 ? 0 : manager);
            if (Contains(address, count, changing.Native, 0x798)) nativeBlocks++;
        };
        Check(changingReader.Capture(changing.Local, changing.Domain, changing.Origin) == null &&
            changingReader.Diagnostics.Status == "CAMERA_CAPTURE_INSTABLE" && globals >= 2 && nativeBlocks >= 2,
            "An XR manager appearing between the paired environment reads escaped coherence validation.");
        return Task.CompletedTask;
    }

    private static ulong SignatureRva(string text)
    {
        Check(text.StartsWith("0x", StringComparison.OrdinalIgnoreCase), "A signature RVA is not formatted as hexadecimal.");
        return UInt64.Parse(text.Substring(2), System.Globalization.NumberStyles.HexNumber,
            System.Globalization.CultureInfo.InvariantCulture);
    }

    public static Task ProfileMismatchFailsClosed()
    {
        foreach (var signature in GoldenSignatures)
        {
            var fixture = new Fixture();
            ulong address = Fixture.Module + signature.Rva;
            fixture.Memory.Byte(address, (byte)(fixture.Memory.Read(address, 1)[0] ^ 0x01));
            var reader = fixture.Reader();
            if (signature.Name == "XrEnabledGetter")
            {
                Check(reader.IsInitialized && reader.Diagnostics.ProfileVerified,
                    "The conditional signature was incorrectly required before an XR manager existed.");
                fixture.SetXr(false);
                Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null,
                    "The changed conditional XR implementation produced a camera.");
            }
            Check(!reader.Diagnostics.ProfileVerified && reader.Diagnostics.Status == "PROFIL_NATIF_INVALIDE" &&
                !reader.IsInitialized && !reader.Diagnostics.InitializationRetryPending,
                "Changed independent code signature was accepted: " + signature.Name);
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null,
                "Unverified profile produced a camera frame: " + signature.Name);
        }
        foreach (Action<Fixture> mutation in new Action<Fixture>[]
        {
            f => f.Memory.Byte(Fixture.Module, 0),
            f => f.Memory.U16(Fixture.Module + GoldenPeOffset + 4, 0x14C),
            f => f.Memory.U32(Fixture.Module + GoldenPeOffset + 8, 1),
            f => f.Memory.U32(Fixture.Module + GoldenPeOffset + 24 + 56, 0x1000)
        })
        {
            var fixture = new Fixture();
            mutation(fixture);
            var reader = fixture.Reader();
            Check(!reader.Diagnostics.ProfileVerified && reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null,
                "Malformed or mismatched PE image was accepted.");
        }
        var previouslyValid = new Fixture();
        var previousReader = previouslyValid.Reader();
        previouslyValid.Memory.Byte(Fixture.Module + GoldenSignatures[0].Rva, 0);
        Check(!previousReader.InitializeProfile() && !previousReader.Diagnostics.ProfileVerified,
            "Revalidating changed executable code retained the former profile trust.");
        Check(previousReader.Capture(previouslyValid.Local, previouslyValid.Domain, previouslyValid.Origin) == null,
            "A failed profile revalidation retained a camera path.");
        return Task.CompletedTask;
    }

    public static Task MetadataAndIdentityRejected()
    {
        foreach (Action<Fixture> mutation in new Action<Fixture>[]
        {
            f => f.Metadata.SelectedLayout = "Unsupported layout",
            f => f.Metadata.Classes[0].Fields[0].Type = "UnityEngine.Transform",
            f => f.Probe.LocalClass.Fields[0].Offset += 8,
            f => f.Probe.Objects[0].IdentityValidated = false,
            f => f.Probe.Objects[0].NativePointerFieldOffset = 24,
            f => f.Memory.Byte(f.CameraClass + 0x1B, 2),
            f => f.Memory.U32(f.CameraClass + 0x58, 0x0200FFFF),
            f => f.Memory.U64(f.LocalFields + 16, f.CameraClass),
            f => f.Memory.I32(f.LocalFields + 24, 0x30)
        })
        {
            var fixture = new Fixture();
            RequireInitialized(fixture.Reader());
            mutation(fixture);
            var reader = fixture.Reader();
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null,
                "Uncorroborated camera metadata produced a frame.");
            fixture.Advance();
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null && reader.Diagnostics.Status != "CAMERA_ATTENTE_RENDU",
                "Advancing frames promoted uncorroborated metadata to usable data.");
        }
        foreach (Action<Fixture> mutation in new Action<Fixture>[]
        {
            f => f.Memory.U64(f.CameraVtable + 0x10, f.Domain + 0x100),
            f => f.Memory.U64(f.LocalVtable + 0x10, f.Domain + 0x100),
            f => f.Memory.U64(f.CameraVtable, f.LocalClass),
            f => f.Memory.U64(f.CameraRuntime + 8, f.LocalVtable),
            f => f.Memory.U64(f.CameraObject + 0x10, 0)
        })
        {
            var fixture = new Fixture();
            var reader = fixture.Reader();
            RequireInitialized(reader);
            mutation(fixture);
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null,
                "Invalid live camera/domain identity produced a frame.");
            fixture.Advance();
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null,
                "Frame progress bypassed an invalid live camera/domain identity.");
        }
        return Task.CompletedTask;
    }

    public static Task UnsupportedRenderingPathsRejected()
    {
        foreach (Action<Fixture> mutation in new Action<Fixture>[]
        {
            f => f.Memory.Byte(f.Native + 0x39, 0),
            f => f.Memory.I32(f.Native + 0x34C, 17),
            f => f.SetCustomBuffer(0),
            f => f.Memory.I32(f.Native + 0x3E0, 1),
            f => f.Memory.Byte(f.Screen + 0x118, 1),
            f => f.SetXr(true),
            f => { f.Memory.Byte(f.Native + 0x529, 1); f.Memory.Byte(f.Graphics + 0x49B, 1); },
            f => f.Memory.U64(f.Local + 0x28, f.NewCameraObject())
        })
        {
            var fixture = new Fixture();
            var reader = fixture.Reader();
            RequireInitialized(reader);
            mutation(fixture);
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null,
                "Unsupported camera output path was accepted.");
            fixture.Advance();
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null,
                "Frame progress enabled an unsupported output path.");
        }
        return Task.CompletedTask;
    }

    public static Task SupportedEngineFlagsRemainUsable()
    {
        foreach (Action<Fixture> mutation in new Action<Fixture>[]
        {
            f => f.Memory.Byte(f.Native + 0x512, 1), // Ordinary implicit view, not a dirty flag.
            f => f.Memory.I32(f.Native + 0x514, 0), // Stable explicit projection.
            f => f.Memory.I32(f.Native + 0x514, 2), // Stable physical projection remains subject to matrix validation.
            f => f.Memory.Byte(f.Native + 0x529, 1), // Graphics support stays zero: request is ineffective.
            f => f.SetXr(false), // An allocated XR manager is not automatically active.
            f => f.SetCustomBuffer(1), // Inactive custom buffer falls through to Screen.
            f => f.Memory.I32(f.Native + 0x3E4, 3), // Stereo target eyes alone do not enable VR.
            f => f.Memory.F32(f.Native + 0x80 + 10 * 4, 1) // A reflected parent can reverse view handedness.
        })
        {
            var fixture = new Fixture();
            mutation(fixture);
            var reader = fixture.Reader();
            Prime(reader, fixture);
            RequireFrame(reader, fixture);
        }
        return Task.CompletedTask;
    }

    public static Task InvalidMatricesDimensionsAndClipsRejected()
    {
        foreach (Action<Fixture> mutation in new Action<Fixture>[]
        {
            f => f.Memory.Byte(f.Native + 0x510, 1),
            f => f.Memory.Byte(f.Native + 0x512, 2),
            f => f.Memory.F32(f.Native + 0x80, float.NaN),
            f => f.Memory.F32(f.Native + 0x80 + 10 * 4, 0), // Degenerate view.
            f => f.Memory.F32(f.Native + 0x80, 2), // Non-rigid view.
            f => f.Memory.F32(f.Native + 0x80 + 3 * 4, 1), // Non-affine last row.
            f => f.Memory.Write(f.Native + 0xC0, new byte[64]),
            f => f.Memory.F32(f.Native + 0xC0, float.PositiveInfinity),
            f => f.Memory.F32(f.Native + 0x464, 0),
            f => f.Memory.F32(f.Native + 0x468, 0.05f),
            f => f.Memory.I32(f.Screen + 0xFC, 0),
            f => f.Memory.I32(f.Screen + 0x108, -1),
            f => f.Memory.I32(f.Screen + 0xFC, 1000000),
            f => f.Memory.F32(f.Native + 0x42C, float.NaN),
            f => f.Memory.F32(f.Native + 0x434, 0),
            f => f.Memory.F32(f.Native + 0x438, 2)
        })
        {
            var fixture = new Fixture();
            var reader = fixture.Reader();
            RequireInitialized(reader);
            mutation(fixture);
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null,
                "Malformed native matrices/viewport/clipping were accepted.");
            fixture.Advance();
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null,
                "Frame advancement promoted malformed native camera data.");
        }
        return Task.CompletedTask;
    }

    public static Task CaptureInstabilityRejected()
    {
        foreach (Action<Fixture> mutation in new Action<Fixture>[]
        {
            f => f.Memory.F32(f.Native + 0x80 + 12 * 4, BitConverter.ToSingle(f.Memory.Read(f.Native + 0x80 + 12 * 4, 4), 0) - 1),
            f => f.Memory.Byte(f.Native + 0x510, 1),
            f => f.Memory.U64(f.CameraObject + 0x10, f.CloneNative()),
            f => f.Memory.U64(f.CameraVtable + 0x10, f.Domain + 0x100),
            f => f.Memory.I32(f.Screen + 0xFC, BitConverter.ToInt32(f.Memory.Read(f.Screen + 0xFC, 4), 0) - 1)
        })
        {
            var fixture = new Fixture();
            var reader = fixture.Reader();
            Prime(reader, fixture);
            int viewReads = 0;
            fixture.Memory.BeforeRead = (address, count) =>
            {
                if (count >= 0x798 && Contains(address, count, fixture.CurrentNative, 0x798) && ++viewReads % 2 == 0)
                    mutation(fixture);
            };
            LiveCameraFrame? frame = reader.Capture(fixture.Local, fixture.Domain, fixture.Origin);
            Check(viewReads >= 2, "Instability fixture did not exercise both native matrix reads.");
            Check(frame == null, "A changing native camera sample escaped coherence checks.");
        }

        // The counter may still be newer than the last accepted frame while
        // regressing inside this pair. Comparing only with the former capture
        // would therefore miss this torn observation.
        var regression = new Fixture();
        var regressionReader = regression.Reader();
        Prime(regressionReader, regression);
        RequireFrame(regressionReader, regression);
        regression.Advance();
        regression.Advance();
        int regressionReads = 0;
        regression.Memory.BeforeRead = (address, count) =>
        {
            if (Contains(address, count, regression.Native, 0x798) && ++regressionReads % 2 == 0)
                regression.Memory.I32(regression.Time + 0xD0,
                    BitConverter.ToInt32(regression.Memory.Read(regression.Time + 0xD0, 4), 0) - 1);
        };
        Check(regressionReader.Capture(regression.Local, regression.Domain, regression.Origin) == null &&
            regressionReader.Diagnostics.Status == "CAMERA_CAPTURE_INSTABLE" &&
            regressionReader.Diagnostics.InstabilityKind == "COMPTEUR_RENDU" && regressionReads >= 2,
            "A render counter regressing inside the mini-capture escaped its coherence guard.");
        return Task.CompletedTask;
    }

    public static Task RenderedFrameConfirmationAndExpiry()
    {
        var fixture = new Fixture();
        var reader = fixture.Reader();
        Prime(reader, fixture);
        RequireFrame(reader, fixture);
        fixture.Clock += 251;
        fixture.Memory.I32(fixture.Time + 0xC8, 500); // Simulation advances, rendering does not.
        Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null && reader.Diagnostics.Status == "CAMERA_RENDU_FIGE",
            "An old rendered frame remained usable because simulation/frameCount was advancing.");
        fixture.Advance();
        LiveCameraFrame? recovered = reader.Capture(fixture.Local, fixture.Domain, fixture.Origin);
        if (recovered == null) { fixture.Advance(); recovered = reader.Capture(fixture.Local, fixture.Domain, fixture.Origin); }
        Check(recovered != null, "Rendered-frame progress did not recover camera acquisition.");
        return Task.CompletedTask;
    }

    public static Task ContextChangesRequireNewEpoch()
    {
        foreach (var change in new (string Reason, Action<Fixture> Mutate)[]
        {
            ("ORIGIN_CHANGED", f => f.Origin = new LivePosition { X = 512, Y = 0, Z = -256 }),
            ("NATIVE_POINTER_CHANGED", f => f.Memory.U64(f.CameraObject + 0x10, f.CloneNative())),
            ("TIME_MANAGER_CHANGED", f => f.ReplaceTimeManager()),
            ("LOCAL_INSTANCE_CHANGED", f => f.ReplaceLocal()),
            ("MONO_DOMAIN_CHANGED", f => f.ChangeDomain()),
            ("SOURCE_SIZE_CHANGED", f => f.Memory.I32(f.Screen + 0xFC, 1600)),
            ("VIEWPORT_CHANGED", f => f.Memory.F32(f.Native + 0x434, 0.8f))
        })
        {
            var fixture = new Fixture();
            var reader = fixture.Reader();
            Prime(reader, fixture);
            LiveCameraFrame before = RequireFrame(reader, fixture);
            change.Mutate(fixture);
            fixture.Advance();
            Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null && reader.Diagnostics.Status == "CAMERA_ATTENTE_RENDU",
                "Changed camera context did not require a new rendered-frame confirmation: " + change.Reason);
            Check(reader.Diagnostics.EpochResetOccurred && reader.Diagnostics.EpochResetReason == change.Reason &&
                reader.Diagnostics.EpochResetCounts.TryGetValue(change.Reason, out long resets) && resets == 1 &&
                reader.Diagnostics.EpochResetCounts.TryGetValue("INITIAL_CONTEXT", out long initialResets) && initialResets == 1,
                "The epoch diagnostic lost or misclassified its concrete reset cause: " + change.Reason);
            fixture.Advance();
            LiveCameraFrame after = RequireFrame(reader, fixture);
            Check(after.CameraEpoch > before.CameraEpoch && after.Sequence > before.Sequence &&
                !reader.Diagnostics.EpochResetOccurred && reader.Diagnostics.EpochResetCounts[change.Reason] == 1,
                "Camera/origin/domain change did not establish a stable new epoch with monotonic sequence: " + change.Reason);
        }
        return Task.CompletedTask;
    }

    private static void Prime(NativeCameraReader reader, Fixture fixture)
    {
        RequireInitialized(reader);
        Check(reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) == null && reader.Diagnostics.Status == "CAMERA_ATTENTE_RENDU",
            "The native camera fixture was not ready for initial confirmation: " + reader.Diagnostics.Status + " / " + reader.Diagnostics.Message);
        fixture.Advance();
    }

    private static LiveCameraFrame RequireFrame(NativeCameraReader reader, Fixture fixture) =>
        reader.Capture(fixture.Local, fixture.Domain, fixture.Origin) ?? throw new InvalidOperationException(
            "A coherent native frame was rejected: " + reader.Diagnostics.Status + " / " + reader.Diagnostics.Message);

    private static void RequireInitialized(NativeCameraReader reader) =>
        Check(reader.Diagnostics.ProfileVerified && reader.Diagnostics.Status == "CAMERA_ATTENTE_RENDU",
            "The independent positive fixture failed to initialize: " + reader.Diagnostics.Status + " / " + reader.Diagnostics.Message);

    private static bool Overlaps(ulong address, int count, ulong target, int width) =>
        address < target + (ulong)width && target < address + (ulong)count;

    private static bool Contains(ulong address, int count, ulong target, int width) =>
        address <= target && (ulong)count >= target - address + (ulong)width;

    private static void Near(float actual, float expected, string label) =>
        Check(float.IsFinite(actual) && Math.Abs(actual - expected) < 0.0001f, label + ": expected " + expected + ", actual " + actual);

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    private sealed class Fixture
    {
        internal const ulong Module = 0x00007FF600000000;
        internal readonly FakeMemory Memory = new();
        internal readonly MonoInspectionReport Metadata = new()
        { SelectedLayout = "Unity Mono x64 2022 (candidate)", Status = "METADONNEES_PARTIELLES" };
        internal readonly CameraProbeReport Probe = new() { Status = "CAMERA_METADONNEES_PARTIELLES" };
        internal LivePosition Origin = new() { X = 256, Y = 0, Z = -512 };
        internal ulong Local, Domain, CameraObject, Native, Screen, Time, Graphics;
        internal ulong LocalClass, CameraClass, LocalVtable, CameraVtable, CameraRuntime, LocalFields;
        internal ulong RenderManager, RenderManagerClass, RenderManagerVtable, Layer, LayerClass, LayerVtable, LayerNative;
        internal ulong Context, ContextClass, ContextVtable, Fsr3, Dlss, Fsr3Vtable, DlssVtable;
        internal ulong LayerFields, ContextFields, Fsr3Fields, DlssFields;
        internal const int LocalRenderManagerOffset = 0x30;
        internal const int ManagerPlayerOffset = 0x20, ManagerLayerOffset = 0x28, ManagerEnabledOffset = 0x30;
        internal const int LayerCameraOffset = 0x20, LayerModeOffset = 0x28, LayerContextOffset = 0x30;
        internal const int LayerTargetOffset = 0x38, LayerFinalBlitOffset = 0x40, LayerSceneViewOffset = 0x41;
        internal const int LayerFsrOffset = 0x48, LayerDlssOffset = 0x50;
        internal const int ContextCameraOffset = 0x20, ContextModeOffset = 0x28;
        internal const int ContextFsrOffset = 0x30, ContextDlssOffset = 0x38;
        internal const int ContextScreenWidthOffset = 0x40, ContextScreenHeightOffset = 0x44;
        internal const int ContextStereoOffset = 0x48, ContextSceneOffset = 0x49, ContextPhysicalOffset = 0x4A;
        internal const int UpscalerOriginalRectOffset = 0x20, UpscalerDisplayOffset = 0x30;
        internal const int UpscalerRenderOffset = 0x38, UpscalerQualityOffset = 0x40, UpscalerStereoOffset = 0x44;
        internal long Clock = 10000;
        internal ulong CurrentNative => BitConverter.ToUInt64(Memory.Read(CameraObject + 0x10, 8), 0);
        private readonly List<ulong> vtables = new();
        private readonly Dictionary<string, (ulong address, MonoClassReport report)> classes = new(StringComparer.Ordinal);
        private int renderedFrame = 100;

        internal Fixture()
        {
            Memory.Write(Module, Convert.FromBase64String(GoldenPeHeader));
            foreach (var signature in GoldenSignatures) Memory.Write(Module + signature.Rva, Convert.FromHexString(signature.Hex));
            Domain = Memory.Allocate(32);
            ulong gameImage = Memory.Allocate(32), unityImage = Memory.Allocate(32), coreImage = Memory.Allocate(32);
            ulong postprocessImage = Memory.Allocate(32), fsrImage = Memory.Allocate(32), dlssImage = Memory.Allocate(32);
            MakeClass("System.Object", 16, 0x02000001, coreImage, null);
            MakeClass("System.ValueType", 16, 0x02000002, coreImage, "System.Object");
            MakeClass("System.Enum", 20, 0x02000003, coreImage, "System.ValueType");
            MakeClass("UnityEngine.Object", 24, 0x02000283, unityImage, "System.Object");
            MakeClass("UnityEngine.Component", 24, 0x0200027D, unityImage, "UnityEngine.Object");
            MakeClass("UnityEngine.Behaviour", 24, 0x02000110, unityImage, "UnityEngine.Component");
            MakeClass("UnityEngine.MonoBehaviour", 24, 0x02000111, unityImage, "UnityEngine.Behaviour");
            MakeClass("UnityEngine.Texture", 24, 0x02000290, unityImage, "UnityEngine.Object");
            ulong textureClass = MakeClass("UnityEngine.RenderTexture", 24, 0x02000291, unityImage, "UnityEngine.Texture");
            ulong rectClass = MakeClass("UnityEngine.Rect", 32, 0x02000292, unityImage, "System.ValueType");
            ulong vectorClass = MakeClass("UnityEngine.Vector2Int", 24, 0x02000293, unityImage, "System.ValueType");
            AddFields("UnityEngine.Rect", ("m_XMin", "System.Single", (byte)0x0C, 16, 0UL),
                ("m_YMin", "System.Single", (byte)0x0C, 20, 0UL),
                ("m_Width", "System.Single", (byte)0x0C, 24, 0UL),
                ("m_Height", "System.Single", (byte)0x0C, 28, 0UL));
            AddFields("UnityEngine.Vector2Int", ("m_X", "System.Int32", (byte)0x08, 16, 0UL),
                ("m_Y", "System.Int32", (byte)0x08, 20, 0UL));
            ulong antialiasingClass = MakeClass("Antialiasing", 20, 0x02000040, postprocessImage, "System.Enum");
            ulong fsrQualityClass = MakeClass("TND.FSR.FSR3_Quality", 20, 0x02000011, fsrImage, "System.Enum");
            ulong dlssQualityClass = MakeClass("TND.DLSS.DLSS_Quality", 20, 0x02000012, dlssImage, "System.Enum");
            foreach (string name in new[] { "Antialiasing", "TND.FSR.FSR3_Quality", "TND.DLSS.DLSS_Quality" })
                AddFields(name, ("value__", "System.Int32", (byte)0x08, 16, 0UL));
            CameraClass = MakeClass("UnityEngine.Camera", 24, 0x02000102, unityImage, "UnityEngine.Behaviour");
            LocalClass = MakeClass("EntityPlayerLocal", 0x40, 0x020004D3, gameImage, null);
            AddFields("UnityEngine.Object", ("m_CachedPtr", "System.IntPtr", (byte)0x18, 16, 0UL));
            RenderManagerClass = MakeClass("GameRenderManager", 0x48, 0x02000350, gameImage, "System.Object");
            LayerClass = MakeClass("UnityEngine.Rendering.PostProcessing.PostProcessLayer", 0x80, 0x02000030, postprocessImage, "UnityEngine.MonoBehaviour");
            ContextClass = MakeClass("UnityEngine.Rendering.PostProcessing.PostProcessRenderContext", 0x70, 0x02000031, postprocessImage, "System.Object");
            ulong fsr3Class = MakeClass("UnityEngine.Rendering.PostProcessing.FSR3", 0x60, 0x02000032, postprocessImage, "System.Object");
            ulong dlssClass = MakeClass("UnityEngine.Rendering.PostProcessing.DLSS", 0x60, 0x02000033, postprocessImage, "System.Object");
            LocalFields = AddFields("EntityPlayerLocal", ("playerCamera", "UnityEngine.Camera", (byte)0x12, 0x20, CameraClass),
                ("finalCamera", "UnityEngine.Camera", (byte)0x12, 0x28, CameraClass),
                ("renderManager", "GameRenderManager", (byte)0x12, LocalRenderManagerOffset, RenderManagerClass));
            AddFields("GameRenderManager", ("player", "EntityPlayerLocal", (byte)0x12, ManagerPlayerOffset, LocalClass),
                ("layer", "UnityEngine.Rendering.PostProcessing.PostProcessLayer", (byte)0x12, ManagerLayerOffset, LayerClass),
                ("upscalingEnabled", "System.Boolean", (byte)0x02, ManagerEnabledOffset, 0UL));
            LayerFields = AddFields("UnityEngine.Rendering.PostProcessing.PostProcessLayer",
                ("m_Camera", "UnityEngine.Camera", (byte)0x12, LayerCameraOffset, CameraClass),
                ("antialiasingMode", "Antialiasing", (byte)0x11, LayerModeOffset, antialiasingClass),
                ("m_CurrentContext", "UnityEngine.Rendering.PostProcessing.PostProcessRenderContext", (byte)0x12, LayerContextOffset, ContextClass),
                ("m_originalTargetTexture", "UnityEngine.RenderTexture", (byte)0x12, LayerTargetOffset, textureClass),
                ("finalBlitToCameraTarget", "System.Boolean", (byte)0x02, LayerFinalBlitOffset, 0UL),
                ("m_IsRenderingInSceneView", "System.Boolean", (byte)0x02, LayerSceneViewOffset, 0UL),
                ("fsr3", "UnityEngine.Rendering.PostProcessing.FSR3", (byte)0x12, LayerFsrOffset, fsr3Class),
                ("dlss", "UnityEngine.Rendering.PostProcessing.DLSS", (byte)0x12, LayerDlssOffset, dlssClass));
            ContextFields = AddFields("UnityEngine.Rendering.PostProcessing.PostProcessRenderContext",
                ("m_Camera", "UnityEngine.Camera", (byte)0x12, ContextCameraOffset, CameraClass),
                ("<antialiasing>k__BackingField", "Antialiasing", (byte)0x11, ContextModeOffset, antialiasingClass),
                ("<superResolution3>k__BackingField", "UnityEngine.Rendering.PostProcessing.FSR3", (byte)0x12, ContextFsrOffset, fsr3Class),
                ("<deepLearningSuperSampling>k__BackingField", "UnityEngine.Rendering.PostProcessing.DLSS", (byte)0x12, ContextDlssOffset, dlssClass),
                ("<screenWidth>k__BackingField", "System.Int32", (byte)0x08, ContextScreenWidthOffset, 0UL),
                ("<screenHeight>k__BackingField", "System.Int32", (byte)0x08, ContextScreenHeightOffset, 0UL),
                ("<stereoActive>k__BackingField", "System.Boolean", (byte)0x02, ContextStereoOffset, 0UL),
                ("<isSceneView>k__BackingField", "System.Boolean", (byte)0x02, ContextSceneOffset, 0UL),
                ("physicalCamera", "System.Boolean", (byte)0x02, ContextPhysicalOffset, 0UL));
            Fsr3Fields = AddFields("UnityEngine.Rendering.PostProcessing.FSR3",
                ("_originalRect", "UnityEngine.Rect", (byte)0x11, UpscalerOriginalRectOffset, rectClass),
                ("_displaySize", "UnityEngine.Vector2Int", (byte)0x11, UpscalerDisplayOffset, vectorClass),
                ("_maxRenderSize", "UnityEngine.Vector2Int", (byte)0x11, UpscalerRenderOffset, vectorClass),
                ("qualityMode", "TND.FSR.FSR3_Quality", (byte)0x11, UpscalerQualityOffset, fsrQualityClass),
                ("isStereoRendering", "System.Boolean", (byte)0x02, UpscalerStereoOffset, 0UL));
            DlssFields = AddFields("UnityEngine.Rendering.PostProcessing.DLSS",
                ("_originalRect", "UnityEngine.Rect", (byte)0x11, UpscalerOriginalRectOffset, rectClass),
                ("displaySize", "UnityEngine.Vector2Int", (byte)0x11, UpscalerDisplayOffset, vectorClass),
                ("renderSize", "UnityEngine.Vector2Int", (byte)0x11, UpscalerRenderOffset, vectorClass),
                ("qualityMode", "TND.DLSS.DLSS_Quality", (byte)0x11, UpscalerQualityOffset, dlssQualityClass),
                ("isStereoRendering", "System.Boolean", (byte)0x02, UpscalerStereoOffset, 0UL));

            LocalVtable = MakeVtable(LocalClass, out _);
            CameraVtable = MakeVtable(CameraClass, out CameraRuntime);
            Native = Memory.Allocate(0x800);
            CameraObject = NewCameraObject();
            Local = Memory.Allocate(0x40);
            Memory.U64(Local, LocalVtable); Memory.U64(Local + 0x20, CameraObject); Memory.U64(Local + 0x28, CameraObject);
            RenderManagerVtable = MakeVtable(RenderManagerClass, out _);
            LayerVtable = MakeVtable(LayerClass, out _);
            ContextVtable = MakeVtable(ContextClass, out _);
            Fsr3Vtable = MakeVtable(fsr3Class, out _); DlssVtable = MakeVtable(dlssClass, out _);
            RenderManager = Memory.Allocate(0x48); Layer = Memory.Allocate(0x80); Context = Memory.Allocate(0x70);
            Fsr3 = Memory.Allocate(0x60); Dlss = Memory.Allocate(0x60);
            Memory.U64(RenderManager, RenderManagerVtable); Memory.U64(Layer, LayerVtable); Memory.U64(Context, ContextVtable);
            Memory.U64(Fsr3, Fsr3Vtable); Memory.U64(Dlss, DlssVtable);
            LayerNative = Memory.Allocate(0x80);
            Memory.U64(Layer + 0x10, LayerNative);
            Memory.U64(LayerNative, Module + 0x1980100);
            Memory.U64(Module + 0x1980100, Module + 0x6F2D0);
            Memory.U64(Module + 0x1980200, Module + 0x6F2D0);
            Memory.Byte(LayerNative + 0x39, 1);
            Memory.U64(Local + LocalRenderManagerOffset, RenderManager);
            Memory.U64(RenderManager + ManagerPlayerOffset, Local); Memory.U64(RenderManager + ManagerLayerOffset, Layer);
            Memory.U64(Layer + LayerCameraOffset, CameraObject);
            Memory.Byte(Layer + LayerFinalBlitOffset, 1);
            Memory.U64(Layer + LayerFsrOffset, Fsr3); Memory.U64(Layer + LayerDlssOffset, Dlss);
            Memory.U64(Context + ContextCameraOffset, CameraObject);
            Memory.U64(Context + ContextFsrOffset, Fsr3); Memory.U64(Context + ContextDlssOffset, Dlss);
            SetPresentationSize(1920, 1080, 1599, 899);
            Metadata.Classes.Add(Clone(classes["EntityPlayerLocal"].report));
            Probe.LocalClass = Clone(classes["EntityPlayerLocal"].report);
            foreach (string field in new[] { "playerCamera", "finalCamera" })
            {
                var item = new CameraObjectReport
                {
                    SourceField = field, DeclaredType = "UnityEngine.Camera", ActualType = "UnityEngine.Camera",
                    ObjectAddress = Hex(CameraObject), NativePointer = Hex(Native), NativePointerFieldOffset = 16,
                    IdentityValidated = true, Status = "METADONNEES_RELEVEES"
                };
                foreach (string name in new[] { "UnityEngine.Camera", "UnityEngine.Behaviour", "UnityEngine.Component", "UnityEngine.Object", "System.Object" })
                    item.ClassHierarchy.Add(Clone(classes[name].report));
                Probe.Objects.Add(item);
            }
            var managerReport = new CameraObjectReport
            {
                SourceField = "renderManager", DeclaredType = "GameRenderManager", ActualType = "GameRenderManager",
                ObjectAddress = Hex(RenderManager), IdentityValidated = true, Status = "METADONNEES_RELEVEES"
            };
            foreach (string name in new[] { "GameRenderManager", "System.Object" })
                managerReport.ClassHierarchy.Add(Clone(classes[name].report));
            Probe.Objects.Add(managerReport);

            Screen = Memory.Allocate(0x200); Time = Memory.Allocate(0x200); Graphics = Memory.Allocate(0x500);
            Memory.U64(Module + 0x1D33BD0, Screen); Memory.U64(Module + 0x1CCBA38, Time);
            Memory.U64(Module + 0x1D33D20, 0); Memory.U64(Module + 0x1C43080, Graphics);
            Memory.U64(Screen, Module + 0x19D65A0);
            Memory.U64(Module + 0x19D65A0 + 0xB0, Module + 0x48D20);
            Memory.U64(Module + 0x19D65A0 + 0xB8, Module + 0x48D30);
            Memory.I32(Screen + 0xFC, 1920); Memory.I32(Screen + 0x108, 1080);
            Memory.I32(Time + 0xC8, renderedFrame); Memory.I32(Time + 0xD0, renderedFrame);
            Memory.U64(Native, Module + 0x1980000);
            Memory.U64(Module + 0x1980000, Module + 0x6F2D0);
            Memory.Byte(Native + 0x39, 1); Memory.Byte(Native + 0x512, 1); Memory.I32(Native + 0x514, 1);
            Memory.I32(Native + 0x3E4, 3);
            Memory.F32(Native + 0x42C, 0); Memory.F32(Native + 0x430, 0);
            Memory.F32(Native + 0x434, 1); Memory.F32(Native + 0x438, 1);
            Memory.F32(Native + 0x464, 0.1f); Memory.F32(Native + 0x468, 1000);
            Matrix(Native + 0x80, new float[] { 1, 0, 0, -10, 0, 1, 0, -5, 0, 0, -1, -3, 0, 0, 0, 1 });
            float a = -1000.1f / 999.9f, b = -200f / 999.9f;
            Matrix(Native + 0xC0, new float[] { 0.5625f, 0, 0, 0, 0, 1, 0, 0, 0, 0, a, b, 0, 0, -1, 0 });
        }

        internal void SetPresentationSize(int width, int height, int renderWidth, int renderHeight)
        {
            foreach (ulong upscaler in new[] { Fsr3, Dlss })
            {
                Memory.F32(upscaler + UpscalerOriginalRectOffset, 1e-7f);
                Memory.F32(upscaler + UpscalerOriginalRectOffset + 4, 0);
                Memory.F32(upscaler + UpscalerOriginalRectOffset + 8, 1);
                Memory.F32(upscaler + UpscalerOriginalRectOffset + 12, 1);
                Memory.I32(upscaler + UpscalerDisplayOffset, width); Memory.I32(upscaler + UpscalerDisplayOffset + 4, height);
                Memory.I32(upscaler + UpscalerRenderOffset, renderWidth); Memory.I32(upscaler + UpscalerRenderOffset + 4, renderHeight);
                Memory.I32(upscaler + UpscalerQualityOffset, 2);
            }
            Memory.I32(Context + ContextScreenWidthOffset, width); Memory.I32(Context + ContextScreenHeightOffset, height);
        }
        internal void EnableUpscaling(int mode)
        {
            Memory.Byte(RenderManager + ManagerEnabledOffset, 1);
            Memory.I32(Layer + LayerModeOffset, mode); Memory.I32(Context + ContextModeOffset, mode);
            Memory.U64(Layer + LayerContextOffset, Context);
            // Independent native getter/setter evidence: flag at +0x554,
            // explicit CPU non-jittered matrix at +0x758. Never an assumed FOV.
            Memory.Byte(Native + 0x554, 1);
            Memory.Write(Native + 0x758, Memory.Read(Native + 0xC0, 64));
            SetRenderPhase(false);
        }
        internal void DisableUpscaling()
        {
            Memory.Byte(RenderManager + ManagerEnabledOffset, 0); Memory.I32(Layer + LayerModeOffset, 0);
            Memory.U64(Layer + LayerContextOffset, 0);
            Memory.F32(Native + 0x42C, 0); Memory.F32(Native + 0x430, 0);
            Memory.F32(Native + 0x434, 1); Memory.F32(Native + 0x438, 1);
        }
        internal void SetRenderPhase(bool reduced)
        {
            ulong upscaler = BitConverter.ToInt32(Memory.Read(Layer + LayerModeOffset, 4), 0) == 7 ? Dlss : Fsr3;
            int width = BitConverter.ToInt32(Memory.Read(upscaler + UpscalerDisplayOffset, 4), 0);
            int height = BitConverter.ToInt32(Memory.Read(upscaler + UpscalerDisplayOffset + 4, 4), 0);
            int renderWidth = BitConverter.ToInt32(Memory.Read(upscaler + UpscalerRenderOffset, 4), 0);
            int renderHeight = BitConverter.ToInt32(Memory.Read(upscaler + UpscalerRenderOffset + 4, 4), 0);
            Memory.F32(Native + 0x42C, reduced ? 0 : 1e-7f); Memory.F32(Native + 0x430, 0);
            Memory.F32(Native + 0x434, reduced ? (float)renderWidth / width : 1);
            Memory.F32(Native + 0x438, reduced ? (float)renderHeight / height : 1);
        }
        internal ulong CloneManaged(ulong instance, int size)
        {
            ulong result = Memory.Allocate(size); Memory.Write(result, Memory.Read(instance, size)); return result;
        }
        internal void ReplaceContext()
        {
            Context = CloneManaged(Context, 0x70); Memory.U64(Layer + LayerContextOffset, Context);
        }
        internal void ReplaceFsr3()
        {
            Fsr3 = CloneManaged(Fsr3, 0x60); Memory.U64(Layer + LayerFsrOffset, Fsr3); Memory.U64(Context + ContextFsrOffset, Fsr3);
        }
        internal ulong PadLayerDescriptors()
        {
            ulong old = LayerFields;
            LayerFields = Memory.Allocate(13 * 32);
            for (int i = 0; i < 13; i++)
            {
                ulong descriptor = LayerFields + (ulong)(i * 32), type = Memory.Allocate(16);
                Memory.Byte(type + 10, 0x02);
                Memory.U64(descriptor, type);
                Memory.U64(descriptor + 8, Memory.CString("unused" + i));
                Memory.U64(descriptor + 16, LayerClass);
                Memory.I32(descriptor + 24, 0x60 + i);
            }
            ulong selected = LayerFields + 2 * 32;
            Memory.Write(selected, Memory.Read(old, 8 * 32));
            Memory.U64(LayerClass + 0x98, LayerFields);
            Memory.I32(LayerClass + 0x100, 13);
            return selected;
        }
        internal void RelocateFieldTypes(ulong descriptors, ulong[] addresses)
        {
            byte[][] headers = new byte[addresses.Length][];
            for (int i = 0; i < addresses.Length; i++)
            {
                ulong original = BitConverter.ToUInt64(Memory.Read(descriptors + (ulong)(i * 32), 8), 0);
                headers[i] = Memory.Read(original, 16);
            }
            for (int i = 0; i < addresses.Length; i++)
            {
                Memory.Write(addresses[i], headers[i]);
                Memory.U64(descriptors + (ulong)(i * 32), addresses[i]);
            }
        }
        internal (ulong Class, ulong Table) RuntimeOwner(string role) => role switch
        {
            "local" => (LocalClass, LocalVtable),
            "camera" => (CameraClass, CameraVtable),
            "layer" => (LayerClass, LayerVtable),
            _ => throw new ArgumentException("Unknown runtime fixture role.", nameof(role))
        };
        internal ulong RegisterRuntime(ulong klass, ulong table, int maximum, params int[] slots)
        {
            ulong runtime = Memory.Allocate(8 + (maximum + 1) * 8);
            Memory.U16(runtime, (ushort)maximum);
            foreach (int slot in slots) Memory.U64(runtime + 8 + (ulong)(slot * 8), table);
            Memory.U64(klass + 0xD0, runtime);
            return runtime;
        }
        internal NativeCameraReader Reader() => new(Memory, Metadata, Probe, () => Clock);
        internal void Advance()
        {
            renderedFrame++;
            Clock += 16;
            Memory.I32(Time + 0xC8, renderedFrame); Memory.I32(Time + 0xD0, renderedFrame);
        }
        internal ulong NewCameraObject()
        {
            ulong address = Memory.Allocate(24);
            Memory.U64(address, CameraVtable); Memory.U64(address + 16, Native);
            return address;
        }
        internal ulong CloneNative()
        {
            ulong address = Memory.Allocate(0x800);
            Memory.Write(address, Memory.Read(Native, 0x800));
            return address;
        }
        internal void ReplaceTimeManager()
        {
            ulong previous = Time;
            Time = Memory.Allocate(0x200); Memory.Write(Time, Memory.Read(previous, 0x200));
            Memory.U64(Module + 0x1CCBA38, Time);
        }
        internal void ReplaceLocal()
        {
            ulong previous = Local;
            Local = Memory.Allocate(0x40); Memory.Write(Local, Memory.Read(previous, 0x40));
            Memory.U64(RenderManager + ManagerPlayerOffset, Local);
        }
        internal void ChangeDomain()
        {
            Domain = Memory.Allocate(32);
            foreach (ulong vtable in vtables) Memory.U64(vtable + 0x10, Domain);
        }
        internal void SetXr(bool active)
        {
            ulong xr = Memory.Allocate(0x400);
            Memory.U64(Module + 0x1D33D20, xr); Memory.U64(xr, Module + 0x1A6CF88);
            Memory.U64(Module + 0x1A6CF88 + 8, Module + 0xF7FE30);
            Memory.Byte(xr + 0x2A5, active ? (byte)1 : (byte)0);
        }
        internal void SetCustomBuffer(byte inactive)
        {
            ulong buffer = Memory.Allocate(64);
            Memory.U64(Native + 0x350, buffer); Memory.Byte(buffer + 0x33, inactive);
        }
        private void Matrix(ulong address, float[] rowMajor)
        {
            for (int column = 0; column < 4; column++)
                for (int row = 0; row < 4; row++) Memory.F32(address + (ulong)((column * 4 + row) * 4), rowMajor[row * 4 + column]);
        }
        private ulong MakeClass(string fullName, int size, uint token, ulong image, string? parentName)
        {
            int dot = fullName.LastIndexOf('.');
            string name = fullName.Substring(dot + 1), ns = dot < 0 ? "" : fullName.Substring(0, dot);
            ulong parent = parentName == null ? 0 : classes[parentName].address;
            ulong address = Memory.Allocate(0x180);
            Memory.Byte(address + 0x1B, 1); Memory.I32(address + 0x1C, size);
            Memory.U64(address + 0x30, parent); Memory.U64(address + 0x40, image);
            Memory.U64(address + 0x48, Memory.CString(name)); Memory.U64(address + 0x50, Memory.CString(ns));
            Memory.U32(address + 0x58, token);
            var report = new MonoClassReport
            {
                Name = name, Namespace = ns, Address = Hex(address), Parent = parentName!, MetadataToken = "0x" + token.ToString("X8"),
                InstanceSize = size, FieldsComplete = true
            };
            classes.Add(fullName, (address, report));
            return address;
        }
        private ulong AddFields(string owner, params (string name, string type, byte code, int offset, ulong data)[] fields)
        {
            var klass = classes[owner];
            ulong descriptors = Memory.Allocate(32 * fields.Length);
            Memory.U64(klass.address + 0x98, descriptors); Memory.I32(klass.address + 0x100, fields.Length);
            for (int i = 0; i < fields.Length; i++)
            {
                var field = fields[i];
                ulong descriptor = descriptors + (ulong)(32 * i), type = Memory.Allocate(16);
                Memory.U64(type, field.data); Memory.Byte(type + 10, field.code);
                Memory.U64(descriptor, type); Memory.U64(descriptor + 8, Memory.CString(field.name));
                Memory.U64(descriptor + 16, klass.address); Memory.I32(descriptor + 24, field.offset);
                klass.report.Fields.Add(new MonoFieldReport
                { Name = field.name, Type = field.type, TypeCode = "0x" + field.code.ToString("X2"), Offset = field.offset, OffsetHex = "0x" + field.offset.ToString("X") });
            }
            klass.report.DeclaredFieldCount = fields.Length;
            return descriptors;
        }
        private ulong MakeVtable(ulong klass, out ulong runtime)
        {
            runtime = Memory.Allocate(32);
            ulong vtable = Memory.Allocate(0x60);
            Memory.U64(klass + 0xD0, runtime); Memory.U64(runtime + 8, vtable);
            Memory.U64(vtable, klass); Memory.U64(vtable + 0x10, Domain);
            vtables.Add(vtable);
            return vtable;
        }
        private static MonoClassReport Clone(MonoClassReport value) => new()
        {
            Name = value.Name, Namespace = value.Namespace, Address = value.Address, Parent = value.Parent,
            MetadataToken = value.MetadataToken, InstanceSize = value.InstanceSize,
            FieldsComplete = value.FieldsComplete, DeclaredFieldCount = value.DeclaredFieldCount,
            Fields = value.Fields.Select(f => new MonoFieldReport
            { Name = f.Name, Type = f.Type, TypeCode = f.TypeCode, Offset = f.Offset, OffsetHex = f.OffsetHex, IsStatic = f.IsStatic, IsLiteral = f.IsLiteral }).ToList()
        };
        private static string Hex(ulong value) => "0x" + value.ToString("X16");
    }

    private sealed class FakeMemory : IMemoryReader
    {
        private readonly Dictionary<ulong, byte[]> pages = new();
        private ulong next = 0x000002AA00000000;
        internal Action<ulong, int>? BeforeRead;
        internal Func<ulong, int, byte[]?>? ReadOverride;
        internal int ModuleLookups;
        internal ulong AllocatePageAligned(int pageCount)
        {
            ulong reserved = Allocate((pageCount + 1) * 4096);
            return (reserved + 4095UL) & ~4095UL;
        }
        internal ulong Allocate(int count)
        {
            ulong address = next;
            next += (ulong)((count + 15) & ~15);
            Write(address, new byte[count]);
            return address;
        }
        internal void Write(ulong address, byte[] bytes)
        {
            for (int i = 0; i < bytes.Length; i++)
            {
                ulong at = address + (ulong)i, page = at & ~4095UL;
                if (!pages.TryGetValue(page, out byte[]? data)) { data = new byte[4096]; pages.Add(page, data); }
                data[(int)(at & 4095)] = bytes[i];
            }
        }
        internal void Byte(ulong address, byte value) => Write(address, new[] { value });
        internal void U16(ulong address, ushort value) { byte[] b = new byte[2]; BinaryPrimitives.WriteUInt16LittleEndian(b, value); Write(address, b); }
        internal void U32(ulong address, uint value) { byte[] b = new byte[4]; BinaryPrimitives.WriteUInt32LittleEndian(b, value); Write(address, b); }
        internal void I32(ulong address, int value) { byte[] b = new byte[4]; BinaryPrimitives.WriteInt32LittleEndian(b, value); Write(address, b); }
        internal void U64(ulong address, ulong value) { byte[] b = new byte[8]; BinaryPrimitives.WriteUInt64LittleEndian(b, value); Write(address, b); }
        internal void F32(ulong address, float value) => I32(address, BitConverter.SingleToInt32Bits(value));
        internal ulong CString(string text)
        {
            ulong address = Allocate(256);
            Write(address, Encoding.UTF8.GetBytes(text));
            return address;
        }
        public byte[] Read(ulong address, int count)
        {
            BeforeRead?.Invoke(address, count);
            byte[]? overridden = ReadOverride?.Invoke(address, count);
            if (overridden != null) return overridden;
            if (count < 0 || count > 1048576) throw new IOException("Synthetic read outside its budget.");
            byte[] result = new byte[count];
            for (int i = 0; i < count; i++)
            {
                ulong at = address + (ulong)i;
                if (!pages.TryGetValue(at & ~4095UL, out byte[]? data)) throw new IOException("Unmapped synthetic page at 0x" + at.ToString("X"));
                result[i] = data[(int)(at & 4095)] ;
            }
            return result;
        }
        public ulong ModuleBase(string name)
        {
            ModuleLookups++;
            return name == "UnityPlayer.dll" ? Fixture.Module : throw new IOException("Unexpected module lookup: " + name);
        }
        public ulong ExportAddress(string module, string symbol) => throw new InvalidOperationException("Native fixture must not invoke or resolve remote methods.");
    }

    // Golden data is independently extracted from the exact supplied UnityPlayer.dll.
    // SHA-256: a8dcc8f6f4cbee3da56552a4adbe56724228a0efcc2fcd737b516933f0418081
    // Every signature below was checked against its mapped RVA in that file.
    private const string GoldenProfileId = "unity-2022.3.62f2-7670c08855a9-native-v1";
    private const ulong GoldenPeOffset = 0x138;
    private const string GoldenPeHeader =
        "TVqQAAMAAAAEAAAA//8AALgAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAEAAA4fug4AtAnNIbgBTM0hVGhpcyBw" +
        "cm9ncmFtIGNhbm5vdCBiZSBydW4gaW4gRE9TIG1vZGUuDQ0KJAAAAAAAAACQCBRe1Gl6DdRpeg3UaXoNMBl5DPBpeg1qGH4Mxml6DWoYeQzLaXoN" +
        "868XDdVpeg1BG34Mv2l6DUY3fgz2aXoNRjd/DD5peg0wGX4Ml2l6DTAZewz/aXoN1Gl7DfFreg1Kyb0N3Gl6DWoYfwxEaXoNMBl/DDRpeg0mMH8M" +
        "3Wl6DdRpeg30aXoNQRtzDHBteg1BG3oM1Wl6DUEbhQ3VaXoNQRt4DNVpeg1SaWNo1Gl6DQAAAAAAAAAAUEUAAGSGCABNftZoAAAAAAAAAADwACIg" +
        "CwIOHACohwEA6l8AAAAAAEj/fwEAEAAAAAAAgAEAAAAAEAAAAAIAAAYAAAAAAAAABgAAAAAAAAAAwOcBAAQAAGuU2gEDAGABAAAQAAAAAAAAEAAA" +
        "AAAAAAAAEAAAAAAAABAAAAAAAAAAAAAAEAAAAABswQFkAAAAZGzBAZABAAAA0OUB4AkAAACQ0wEQHhEAAGbaAagpAAAA4OUBIN4BABC0rQFUAAAA" +
        "AAAAAAAAAAAAAAAAAAAAAAC2rQEoAAAAcLStATgBAAAAAAAAAAAAAADAhwFIEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALnRleHQAAACTp4cB" +
        "ABAAAACohwEABAAAAAAAAAAAAAAAAAAAIAAAYC5yZGF0YQAAruI5AADAhwEA5DkAAKyHAQAAAAAAAAAAAAAAAEAAAEAuZGF0YQAAAIjfEQAAsMEB" +
        "ALAEAACQwQEAAAAAAAAAAAAAAABAAADALnBkYXRhAAAQHhEAAJDTAQAgEQAAQMYBAAAAAAAAAAAAAAAAQAAAQC5yb2RhdGEAgAsAAACw5AEADAAA" +
        "AGDXAQAAAAAAAAAAAAAAAEAAAEBfUkRBVEEAAHQPAQAAwOQBABABAABs1wEAAAAAAAAAAAAAAABAAABALnJzcmMAAADgCQAAANDlAQAKAAAAfNgB" +
        "AAAAAAAAAAAAAAAAQAAAQC5yZWxvYwAAIN4BAADg5QEA4AEAAIbYAQAAAAAAAAAAAAAAAEAAAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
        "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
        "AAAAAAAAAAAAAAAAAAAAAFVIieVIiU0QSIlVGEyJRSBWV0iLdRBIi30YSItFIA9vDg/VCA9/Dw9vTggP1UgID39PCA9vThAP1UgQD39PEA9vThgP" +
        "1UgYD39PGF9eSInsXcNVSInlSIlNEEiJVRhMiUUgTIlNKFdIi0UQSItVGA9vAA/VAg9vSAgP1UoID29QEA/VUhAPb1gYD9VaGEiLVSAP7/8PfzgP" +
        "f3gID394EA9/eBhIY30oD/nCD/3SD2/pD/3QD+UtRp/kAQ/96Q9v+w/lPUmf5AEP/fsP+f0Pb+kPb+MP5S02n+QBD/3pD+UdHJ/kAQ/93A/93Q9v" +
        "8g9v4A/90w/95w/5xw/58w9vyg9v3A9hyA9p0A9h3g9p5g9vwQ9v6g9iww9qyw9i1A9q7A9v3Q/5wg/90g9v6Q/90A/lLcqe5AEP/ekPb/sP5T3N" +
        "nuQBD/37D/n9D2/pD2/jD+Utup7kAQ/96Q/lHaCe5AEP/dwP/d0P/QWznuQBD/0VrJ7kAQ9v8g9v4A/90w/95w/5xw/58w9x4gMPceADD3HkAw9x" +
        "5gMPb8oPb9wPYcgPadAPYd4PaeYPb8EPb+oPYsMPassPYtQPauwP7/8PbiIPYOcP7cQPZ8cPfgIPbiQ6D2DnD+3MD2fPD34MOg9uJHoPYOcP7dQP" +
        "Z9cPfhR6SAH6D24keg9g5w/t7A9n7w9+LHpfSInsXcPMzMzMzMzMzFVIieVIiU0QSIlVGEyJRSBMiU0oVldIi0UQSIt1GA9vAA9vSAgPb1AQD29Y" +
        "GEhjRSBIi1UoSGN9MA/5wg/90g9v6Q/90A/lLdSd5AEP/ekPb/sP5T3XneQBD/37D/n9D2/pD2/jD+UtxJ3kAQ/96Q/lHaqd5AEP/dwP/d0Pb/IP" +
        "b+AP/dMP/ecP+ccP+fMPb8oPb9wPYcgPadAPYd4PaeYPb8EPb+oPYsMPassPYtQPauwPb90P+cIP/dIPb+kP/dAP5S1YneQBD/3pD2/7D+U9W53k" +
        "AQ/9+w/5/Q9v6Q9v4w/lLUid5AEP/ekP5R0uneQBD/3cD/3dD/0FQZ3kAQ/9FTqd5AEPb/IPb+AP/dMP/ecP+ccP+fMPceIDD3HgAw9x5AMPceYD" +
        "D2/KD2/cD2HID2nQD2HeD2nmD2/BD2/qD2LDD2rLD2LUD2rsD+//D24mD2DnD+3ED2fHD34CD24kBg9g5w/tzA9nzw9+DDoPbiRGD2DnD+3UD2fX" +
        "D34UekgB+kgBxg9uJEYPYOcP7ewPZ+8Pfix6X15Iiexdw1VIieVIiU0QSIlVGEyJRSBMiU0oD25tEEiLRRhIY1UgD+/AD/0teJzkAUiNDFIPceUD" +
        "D2HtD2LtD24ID24UEA9uHFAPbiQISItFKEhjVTAPYMgP7c0PZ8hIjQxSD2DQD+3VD2fQD2DYD+3dD2fYD2DgD+3lD2fgD34ID34UEA9+HFAPfiQI" +
        "SInsXcPMzMzMzMzMVUiJ5UiJTRBIiVUYTIlFIEyJTShIi1UYSItFEGYPbiBmD24qZg/EYCAEZg/EKgRmD9XlZg/v7WYPfihmD35oIEiLRSBIY1Uo" +
        "8g9w5ADzD3DkAEiNDFJmD/0lwpvkAWYPceQD8w9+APMPfgwQ8w9+FFDzD34cCGYPYMVmD2DNZg9g1WYPYN1mD/3EZg/9zGYP/dRmD/3cZg9nxWYP" +
        "Z81mD2fVZg9n3WYP1gBmD9YMEEiNBFBmD9YQZg/WHBBIiexdw1VIieVIiU0QSIlVGEyJRSBMiU0oSIPsIGYPfzQkZg9/fCQQVldIi0UQSItVGEiL" +
        "fSBmD+//Zg9vAGYPb1AQZg9vSCBmD29YMGYPfzhmD394EGYPf3ggZg9/eDBmD9UCZg/VUhBmD9UKZg/VWhBIY1UoZg9v4GYPYsFmD2rhZg9wwNhm" +
        "D3DM2GYPb+JmD2LTZg9q42YPcNLYZg9w3NhmD/nCZg/90mYPb+lmD/3QZg/lLbqa5AFIjQxSZg/96WYPb/tmD+U9tprkAWYP/ftmD/n9Zg9v6WYP" +
        "b+NmD+UtnprkAWYP/elmD+UdgprkAWYP/dxmD/3dZg9v8mYPb+BmD/3TZg/952YP+cdmD/nzZg9v+mYPYdBmD2n4Zg9v7GYPYeZmD2nuZg9vymYP" +
        "YtRmD2rMZg9v92YPYv1mD2r1Zg9v6mYPYtdmD2rvZg9v+WYPYs5mD2r+Zg9wwthmD3DR2GYPcM3YZg9w39hmD/nCZg/90mYPb+lmD/3QZg/lLe6Z" +
        "5AFmD/3pZg9v+2YP5T3umeQBZg/9+2YP+f1mD2/pZg9v42YP5S3WmeQBZg/96WYP5R26meQBZg/93GYP/d1mD/0FmpnkAWYP/RWSmeQBZg9v8mYP" +
        "b+BmD/3TZg/952YP+cdmD/nzZg9x4gNmD3HgA2YPceQDZg9x5gNmD2/6Zg9h0GYPafhmD2/sZg9h5mYPae5mD2/KZg9i1GYPasxmD2/3Zg9i/WYP" +
        "avVmD2/qZg9i12YPau9mD2/5Zg9izmYPav5mD3DC2GYPcNHYZg9wzdhmD3Df2GYP7//zD34n8w9+LBdmD2DnZg9g72YP/cRmD/3N8w9+JFfzD34s" +
        "D2YPYOdmD2DvZg/91GYP/d1mD2fHZg9nz2YPZ9dmD2ffZg/WB2YP1gwXZg/WFFdmD9YcD19eZg9vfCQQZg9vNCRIg8QgSInsXcNVSInlSIlNEEiJ" +
        "VRhMiUUgTIlNKFdIi0UQSIt9IEiLVTBmD+/tZg9uIkhjVShIjQxS8w9+B/MPfgwX8w9+FFfzD34cD2YPYeRmD2LkZg/9JUaY5AFmD3HkA2YPYMVm" +
        "D2DNZg9g1WYPYN1mD/3EZg/9zGYP/dRmD/3cZg9nxWYPZ81mD2fVZg9n3WYP1gdmD9YMF2YP1hRXZg/WHA9fSInsXcNVSInlSIlNEEiJVRhMiUUg" +
        "TIlNKEiD7CBmD380JGYPf3wkEFdIi0UQSItVGEiLfSBmD+//Zg9vAGYPb1AQZg9vSCBmD29YMGYPfzhmD394EGYPf3ggZg9/eDBmD9UCZg/VUhBm" +
        "D9UKZg/VWhBIi1UwZg9v4GYPYsFmD2rhZg9wwNhmD3DM2GYPb+JmD2LTZg9q42YPcNLYZg9w3NhmD8QCAGYPxEICBGYP+cJmD/3SZg9v6WYP/dBm" +
        "D+UtSZfkAWYP/elmD2/7Zg/lPUmX5AFmD/37Zg/5/WYPb+lmD2/jZg/lLTGX5AFmD/3pZg/lHRWX5AFmD/3cZg/93WYPb/JmD2/gZg/902YP/edm" +
        "D/nHZg/582YPb/pmD2HQZg9p+GYPb+xmD2HmZg9p7mYPb8pmD2LUZg9qzGYPb/dmD2L9Zg9q9WYPb+pmD2LXZg9q72YPb/lmD2LOZg9q/mYPcMLY" +
        "Zg9w0dhmD3DN2GYPcN/YZg/5wmYP/dJmD2/pZg/90GYP5S2BluQBZg/96WYPb/tmD+U9gZbkAWYP/ftmD/n9Zg9v6WYPb+NmD+UtaZbkAWYP/elm" +
        "D+UdTZbkAWYP/dxmD/3dZg/9BS2W5AFmD/0VJZbkAWYPb/JmD2/gZg/902YP/edmD/nHZg/582YPceIDZg9x4ANmD3HkA2YPceYDZg9v+mYPYdBm" +
        "D2n4Zg9v7GYPYeZmD2nuZg9vymYPYtRmD2rMZg9v92YPYv1mD2r1Zg9v6mYPYtdmD2rvZg9v+WYPYs5mD2r+Zg9wwthmD3DR2GYPcM3YZg9w39hm" +
        "D+//SGNVKPMPfifzD34sF0iNDFJmD2DnZg9g72YP/cRmD/3N8w9+JFfzD34sD2YPYOdmD2DvZg/91GYP/d1mD2fHZg9nz2YPZ9dmD2ffSGNVKGYP" +
        "1gdmD9YMF0iNPFdmD9YXZg/WHBdfZg9vfCQQZg9vNCRIg8QgSInsXcPMzMzMzMzMzMzMzMzMzMxVSInlSIlNEEiJVRhIi1UQSMfAAwADAA9vAg9v" +
        "SghID274D29SEA9vWhgPYf9Ii1UYD2/gD2/pD/3jD/3qD2/0D/3lD/n1D/nDD/nKD2/oD/3BD/npD2/cD2HgD2nYD2/OD2H1D2nND2/ED2/TD2LG" +
        "D2rmD2LRD2rZD2/ID2/sD/3LD/3qD2/xD/3ND/n1D/3PD/33D3HhAw9x5gMP+cMP+eIPb+gP/cQP+ewP/ccP/Q==";

    private static readonly (string Name, ulong Rva, string Hex)[] GoldenSignatures =
    {
        ("NonJitteredProjectionGetter", 0x6F90FUL, "80b954050000007409488d8158070000eb05e8eac636000f1000488bbc24880000000f11030f1048100f114b100f1040200f1143200f1048300f114b30"),
        ("NonJitteredProjectionSetter", 0x6FA6FUL, "c68054050000010f10030f1180580700000f104b100f1188680700000f1043200f1180780700000f104b30488b5c24780f118888070000"),
        ("BindingRegistration", 0xFEFB50UL, "48895c240848896c2410488974241848897c24204154415641574883ec204533ff4c8d25880401ff4533f60f1f4400004b8bb426e0ca8e0133ff48393d27d2c5004b8bac26a0378f01762733db0f1f00488b0501d2c500488bd6488bcdff1403ffc7488d5b084863c7483b05f8d1c50072de488bd6488bcdff150253d40041ffc74983c6084181ff970d000072a2"),
        ("WorldToCameraReadAndRecompute", 0x6F3ACUL, "80bb1205000000740f488d9380000000488bcbe82cc836000f1083800000000f11070f108b900000000f114f100f1083a00000000f1147200f108bb0000000488b9c24880000000f114f304883c4605f5e5dc3488bd6488d4d"),
        ("WorldToCameraSetterImplicitFlag", 0x6F517UL, "0f1003488bbc24880000000f1180800000000f104b100f1188900000000f1043200f1180a00000000f104b30488b5c2478c68012050000000f"),
        ("WorldToCameraResetImplicitFlag", 0x6FFC2UL, "488b9c2480000000c68012050000014883c4605dc3"),
        ("ProjectionGetterCallsCache", 0x6F675UL, "481048894de8c645f001e88cc93600488bbc24880000000f10000f11030f1048100f114b100f1040200f1143200f1048300f114b30488b5c24784883c4605dc3488bd7488d"),
        ("ProjectionCacheDirtyGate", 0x3DC010UL, "488bc4534883ec7080b91005000000488bd90f8444010000"),
        ("ProjectionCacheClearAndReturn", 0x3DC140UL, "440f28442440488d83c00000000f287c24500f28742460488bbc2488000000c68310050000004883c4705bc3488d81c00000004883c4705bc3"),
        ("NormalizedRectGetter", 0x6D62FUL, "0f10802c040000488b5c24780f1107488bbc24880000004883c4605dc3488bd3"),
        ("TargetTexturePPtrGetter", 0x6E364UL, "4881c14c030000e8705a0e004885c07421"),
        ("TargetTextureZeroResolver", 0x153DE0UL, "40564883ec208b3185f6750833c04883c4205ec3"),
        ("TargetDisplayGetter", 0x6E821UL, "8b80e0030000488b9c24800000004883c4605dc3"),
        ("BehaviourActiveGetter", 0xF8B91UL, "80783900488b9c24800000000f95c04883c4605dc3"),
        ("ScreenDimensionsGetters", 0x82230UL, "488b059919cb018b80fc000000c3cccc488b058919cb018b8008010000c3"),
        ("ScreenVirtualDimensions", 0x48D20UL, "8b81fc000000c3cccccccccccccccccc8b8108010000c3"),
        ("TimeFrameCountGetters", 0x1118F0UL, "488b0541a1bb018b80c8000000c3cccc488b0531a1bb018b80d0000000c3"),
        ("PixelRectCustomBufferBranch", 0x3D04CDUL, "488b85500300004885c00f848e000000807833000f8584000000"),
        ("PixelRectDisplayAndScreenPath", 0x3D05BFUL, "4c6385e003000033c9443b059d4996017d144b8d144048c1e205488d05904996014803d0eb03488bd14585c074244885d2741f660f6e4218660f6e4a1c0f5bc048890f0f5bc9f30f114708f30f114f0ceb52488b1db8359601488bcb488b03ff90b8000000488bcb48c744242000000000660f6ef0488b030f5bf6ff90b00000000f104c24200fc6c9d2660f6ec00f5bc0f30f10c80fc6c927f30f10ce0fc6c9390f110f"),
        ("StereoXrNullGate", 0x3D38C5UL, "488b0d540496014885c9742c488b01ff500884c0742283bbe4030000007419488b0d35049601488b01ff90f003000084c0740540b701eb034032ff"),
        ("StereoScreenAndXrGate", 0x3D3941UL, "488b0588029601488b5c243080b81801000000750a4084ff75054084ed74094084f6751684c9751232c0488b742438488b6c24404883c4205fc3488b742438b001488b6c24404883c4205f"),
        ("ProjectionViewMultiply", 0x3DC9A0UL, "48895c2408574883ec7080b91205000000488bf90f297424600f297c2450440f29442440440f294c2430440f29542420740c488d9180000000e812f2ffff488bcfe82af6ffff0f18080f188f800000000f109f80000000488b9c24800000000f10a7900000000f10"),
        ("XrEnabledGetter", 0xF7FE30UL, "0fb681a5020000c3"),
        ("CameraRenderRefreshesView", 0x542540UL, "80bf1205000000740f488d9780000000488bcfe89896e9ff488d9f80000000"),
        ("EffectiveAllowDynamicResolutionGetter", 0x66537UL, "80b829050000007420488b0539cbbd0180b89b040000007410b001488b9c24800000004883c4605dc3"),
    };
}
