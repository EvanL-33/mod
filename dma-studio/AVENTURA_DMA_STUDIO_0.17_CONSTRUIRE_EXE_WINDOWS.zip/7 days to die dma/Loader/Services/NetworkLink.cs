using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using SevenDaysEsp;

namespace SevenDaysLoader.Services;

public static class NetworkAddresses
{
    public static bool IsPrivate(IPAddress address)
    {
        if (address.AddressFamily != AddressFamily.InterNetwork) return false;
        byte[] bytes = address.GetAddressBytes();
        return bytes[0] == 10 || (bytes[0] == 172 && bytes[1] >= 16 && bytes[1] <= 31) ||
            (bytes[0] == 192 && bytes[1] == 168) || (bytes[0] == 169 && bytes[1] == 254) || IPAddress.IsLoopback(address);
    }

    public static string[] GetLocalAddresses() => NetworkInterface.GetAllNetworkInterfaces()
        .Where(x => x.OperationalStatus == OperationalStatus.Up)
        .SelectMany(x => x.GetIPProperties().UnicastAddresses)
        .Select(x => x.Address).Where(IsPrivate).Where(x => !IPAddress.IsLoopback(x))
        .Select(x => x.ToString()).Distinct().OrderBy(x => x).ToArray();
}

public sealed class PairingInformation
{
    public int Version { get; set; } = 1;
    public string Host { get; set; } = "";
    public int Port { get; set; }
    public string Fingerprint { get; set; } = "";
    public string Token { get; set; } = "";

    public string Encode() => "7DTD1." + Convert.ToBase64String(JsonSerializer.SerializeToUtf8Bytes(this, Wire.Json)).TrimEnd('=').Replace('+', '-').Replace('/', '_');

    public static PairingInformation Parse(string text)
    {
        try
        {
            text = text.Trim();
            if (!text.StartsWith("7DTD1.", StringComparison.Ordinal) || text.Length > 2048)
                throw new FormatException();
            string encoded = text.Substring(6).Replace('-', '+').Replace('_', '/');
            encoded = encoded.PadRight((encoded.Length + 3) / 4 * 4, '=');
            var value = JsonSerializer.Deserialize<PairingInformation>(Convert.FromBase64String(encoded), Wire.Json);
            if (value == null || value.Version != 1 || !IPAddress.TryParse(value.Host, out var address) ||
                !NetworkAddresses.IsPrivate(address) || value.Port < 1024 || value.Port > 65535 ||
                Convert.FromHexString(value.Fingerprint).Length != 32 || Convert.FromBase64String(value.Token).Length != 32)
                throw new FormatException();
            value.Host = address.ToString();
            return value;
        }
        catch (Exception ex) when (ex is FormatException || ex is JsonException || ex is ArgumentException || ex is NullReferenceException)
        {
            throw new InvalidDataException("Code de liaison invalide. Copie le code complet créé sur le PC lecteur.");
        }
    }
}

public sealed class LinkRequest
{
    public int Version { get; set; } = 1;
    public string Type { get; set; } = "poll";
    public string Token { get; set; } = "";
    public long Id { get; set; }
}

public sealed class LinkPacket
{
    public int Version { get; set; } = 1;
    public string Type { get; set; } = "frame";
    public long Id { get; set; }
    public LoaderStatus Status { get; set; } = new();
    public LiveEntitySnapshot? Frame { get; set; }
    public double AgeMs { get; set; }
}

// TLS authenticates the reader via the exact certificate fingerprint in the
// pairing code; a fresh 256-bit token authenticates the display to the reader.
// The code is never saved or logged. There are no remote execution commands.
public sealed class DisplayServer : IAsyncDisposable
{
    private readonly Func<FeedSample?> frameProvider;
    private readonly Func<LoaderStatus> statusProvider;
    private readonly CancellationTokenSource stop = new();
    private readonly RSA key = RSA.Create(2048);
    private readonly X509Certificate2 certificate;
    private readonly byte[] token = RandomNumberGenerator.GetBytes(32);
    private TcpListener? listener;
    private TcpClient? activeClient;
    private Task? serveTask;
    public event Action<bool>? ClientChanged;
    public event Action<string>? Error;

    public DisplayServer(Func<FeedSample?> frameProvider, Func<LoaderStatus> statusProvider)
    {
        this.frameProvider = frameProvider;
        this.statusProvider = statusProvider;
        var request = new CertificateRequest("CN=7DTD-Loader", key, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        request.CertificateExtensions.Add(new X509BasicConstraintsExtension(false, false, 0, true));
        request.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.DigitalSignature, true));
        request.CertificateExtensions.Add(new X509EnhancedKeyUsageExtension(new OidCollection { new("1.3.6.1.5.5.7.3.1") }, true));
        certificate = request.CreateSelfSigned(DateTimeOffset.UtcNow.AddMinutes(-5), DateTimeOffset.UtcNow.AddDays(7));
    }

    public string Start(string address, int port)
    {
        if (listener != null) throw new InvalidOperationException("Le partage est déjà actif.");
        if (!IPAddress.TryParse(address, out var ip) || !NetworkAddresses.IsPrivate(ip) ||
            (!IPAddress.IsLoopback(ip) && !NetworkAddresses.GetLocalAddresses().Contains(ip.ToString())) || port < 1024 || port > 65535)
            throw new ArgumentException("Sélectionne l'adresse IPv4 locale de ce PC et un port entre 1024 et 65535.");
        listener = new TcpListener(ip, port);
        listener.Start(2);
        serveTask = ServeAsync(stop.Token);
        return new PairingInformation
        {
            Host = ip.ToString(), Port = port,
            Fingerprint = Convert.ToHexString(SHA256.HashData(certificate.RawData)),
            Token = Convert.ToBase64String(token)
        }.Encode();
    }

    private async Task ServeAsync(CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            bool authenticated = false;
            try
            {
                using TcpClient client = await listener!.AcceptTcpClientAsync(cancellationToken).ConfigureAwait(false);
                activeClient = client;
                client.NoDelay = true;
                if (client.Client.RemoteEndPoint is not IPEndPoint endpoint || !NetworkAddresses.IsPrivate(endpoint.Address)) continue;
                using var ssl = new SslStream(client.GetStream(), false);
                using (var handshake = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken))
                {
                    handshake.CancelAfter(TimeSpan.FromSeconds(5));
                    await ssl.AuthenticateAsServerAsync(new SslServerAuthenticationOptions
                    {
                        ServerCertificate = certificate,
                        EnabledSslProtocols = SslProtocols.Tls12 | SslProtocols.Tls13,
                        ClientCertificateRequired = false
                    }, handshake.Token).ConfigureAwait(false);
                    var hello = await Wire.ReadAsync<LinkRequest>(ssl, handshake.Token).ConfigureAwait(false);
                    byte[] offered;
                    try { offered = Convert.FromBase64String(hello.Token); }
                    catch (Exception ex) when (ex is FormatException || ex is ArgumentException) { throw new AuthenticationException("Liaison refusée."); }
                    if (hello.Version != 1 || hello.Type != "hello" || offered.Length != token.Length ||
                        !CryptographicOperations.FixedTimeEquals(token, offered)) throw new AuthenticationException("Liaison refusée.");
                    await Wire.WriteAsync(ssl, new LinkPacket { Type = "ready" }, handshake.Token).ConfigureAwait(false);
                }
                authenticated = true;
                ClientChanged?.Invoke(true);
                long previous = 0;
                while (!cancellationToken.IsCancellationRequested)
                {
                    using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                    deadline.CancelAfter(TimeSpan.FromSeconds(5));
                    var poll = await Wire.ReadAsync<LinkRequest>(ssl, deadline.Token).ConfigureAwait(false);
                    if (poll.Version != 1 || poll.Type != "poll" || poll.Id <= previous) throw new InvalidDataException("Requête de liaison invalide.");
                    previous = poll.Id;
                    var sample = frameProvider();
                    var state = statusProvider();
                    // Select once. A frame expiring between two freshness checks
                    // must never be paired with age zero and rejuvenated remotely.
                    var selected = sample?.IsFresh == true ? sample : null;
                    var packet = new LinkPacket
                    {
                        Id = poll.Id,
                        Status = state with { ReportPath = "", IsSharing = false, HasDisplayClient = false, IsReader = false, CanProject = selected?.IsProjectionFresh == true },
                        Frame = selected?.Snapshot,
                        AgeMs = selected?.AgeMs ?? 0
                    };
                    await Wire.WriteAsync(ssl, packet, deadline.Token).ConfigureAwait(false);
                }
            }
            catch (Exception ex) when (ex is IOException || ex is SocketException || ex is AuthenticationException || ex is OperationCanceledException || ex is ObjectDisposedException || ex is InvalidDataException || ex is JsonException)
            {
                if (!cancellationToken.IsCancellationRequested && authenticated)
                    Error?.Invoke("L'affichage distant s'est déconnecté ; le lecteur local peut continuer.");
            }
            finally
            {
                activeClient = null;
                if (authenticated) ClientChanged?.Invoke(false);
            }
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (stop.IsCancellationRequested) return;
        stop.Cancel();
        listener?.Stop();
        activeClient?.Dispose();
        if (serveTask != null)
        {
            try { await serveTask.WaitAsync(TimeSpan.FromSeconds(2)).ConfigureAwait(false); }
            catch (Exception ex) when (ex is OperationCanceledException || ex is TimeoutException || ex is SocketException) { }
        }
        certificate.Dispose();
        key.Dispose();
        CryptographicOperations.ZeroMemory(token);
        stop.Dispose();
    }
}

public sealed class DisplayClient : IAsyncDisposable
{
    private readonly CancellationTokenSource stop = new();
    private TcpClient? client;
    private SslStream? ssl;
    private Task? pollTask;
    private long requestId;
    private bool disposed;
    public event Action<FeedSample?, LoaderStatus>? Received;
    public event Action<string>? Ended;

    public async Task ConnectAsync(string pairingCode, CancellationToken cancellationToken = default)
    {
        PairingInformation pairing = PairingInformation.Parse(pairingCode);
        byte[] fingerprint = Convert.FromHexString(pairing.Fingerprint);
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, stop.Token);
        deadline.CancelAfter(TimeSpan.FromSeconds(8));
        client = new TcpClient(AddressFamily.InterNetwork) { NoDelay = true };
        try
        {
            await client.ConnectAsync(IPAddress.Parse(pairing.Host), pairing.Port, deadline.Token).ConfigureAwait(false);
            ssl = new SslStream(client.GetStream(), false, (_, remote, _, _) =>
                remote != null && CryptographicOperations.FixedTimeEquals(fingerprint, SHA256.HashData(remote.GetRawCertData())));
            await ssl.AuthenticateAsClientAsync(new SslClientAuthenticationOptions
            {
                TargetHost = "7DTD-Loader",
                EnabledSslProtocols = SslProtocols.Tls12 | SslProtocols.Tls13,
                CertificateRevocationCheckMode = X509RevocationMode.NoCheck
            }, deadline.Token).ConfigureAwait(false);
            await Wire.WriteAsync(ssl, new LinkRequest { Type = "hello", Token = pairing.Token }, deadline.Token).ConfigureAwait(false);
            var ready = await Wire.ReadAsync<LinkPacket>(ssl, deadline.Token).ConfigureAwait(false);
            if (ready.Version != 1 || ready.Type != "ready") throw new InvalidDataException("Le lecteur a renvoyé une réponse inattendue.");
            await PollOnceAsync(deadline.Token).ConfigureAwait(false);
            pollTask = PollAsync(stop.Token);
        }
        catch
        {
            ssl?.Dispose();
            client.Dispose();
            throw;
        }
    }

    private async Task PollAsync(CancellationToken cancellationToken)
    {
        try
        {
            while (!cancellationToken.IsCancellationRequested)
            {
                await Task.Delay(100, cancellationToken).ConfigureAwait(false);
                using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
                deadline.CancelAfter(TimeSpan.FromMilliseconds(1800));
                await PollOnceAsync(deadline.Token).ConfigureAwait(false);
            }
        }
        catch (Exception ex) when (ex is IOException || ex is InvalidDataException || ex is SocketException || ex is AuthenticationException || ex is OperationCanceledException || ex is ObjectDisposedException || ex is JsonException)
        {
            if (!cancellationToken.IsCancellationRequested) Ended?.Invoke("Liaison interrompue. Les repères sont effacés ; reconnecte le mode affichage.");
        }
        finally { ssl?.Dispose(); client?.Dispose(); }
    }

    private async Task PollOnceAsync(CancellationToken cancellationToken)
    {
        long id = Interlocked.Increment(ref requestId);
        long began = Stopwatch.GetTimestamp();
        await Wire.WriteAsync(ssl!, new LinkRequest { Id = id }, cancellationToken).ConfigureAwait(false);
        var packet = await Wire.ReadAsync<LinkPacket>(ssl!, cancellationToken).ConfigureAwait(false);
        double roundTrip = Stopwatch.GetElapsedTime(began).TotalMilliseconds;
        if (packet.Version != 1 || packet.Type != "frame" || packet.Id != id || packet.Status == null ||
            !double.IsFinite(packet.AgeMs) || packet.AgeMs < 0 || packet.Status.Message == null || packet.Status.Message.Length > 4096 ||
            packet.Status.Stage == null || packet.Status.Stage.Length > 128 || packet.Status.GameVersion == null || packet.Status.GameVersion.Length > 128 ||
            packet.Status.MemProcFsVersion == null || packet.Status.MemProcFsVersion.Length > 128 ||
            packet.Status.ProjectionMessage == null || packet.Status.ProjectionMessage.Length > 4096)
            throw new InvalidDataException("Données de liaison invalides.");
        FeedSample? sample = packet.Frame != null && FeedSample.IsValid(packet.Frame)
            ? new FeedSample(packet.Frame, packet.AgeMs + roundTrip) : null;
        if (sample?.IsFresh != true) sample = null;
        Received?.Invoke(sample, packet.Status with { IsReader = false, IsBusy = false, CanProject = sample?.IsProjectionFresh == true, ReportPath = "" });
    }

    public async ValueTask DisposeAsync()
    {
        if (disposed) return;
        disposed = true;
        stop.Cancel();
        ssl?.Dispose();
        client?.Dispose();
        if (pollTask != null)
        {
            try { await pollTask.WaitAsync(TimeSpan.FromSeconds(2)).ConfigureAwait(false); }
            catch (Exception ex) when (ex is OperationCanceledException || ex is TimeoutException || ex is IOException || ex is InvalidDataException) { }
        }
        stop.Dispose();
    }
}
