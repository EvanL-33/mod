﻿// Radar 2D uniquement : aucune lecture DMA, aucune projection vers l'ecran du jeu.
// C# 5 / .NET Framework 4.x. Les DTO proviennent de LiveEntityReader.cs.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Threading;
using System.Windows.Forms;

namespace SevenDaysEsp
{
    public static class LiveRadarWindow
    {
        private const double MaximumAgeMs = 2000.0;
        private static readonly object lifecycleGate = new object();
        private static RunState current;

        private sealed class Dot
        {
            public string Kind;
            public string Name;
            public int Id;
            public double X, Y, Z;
        }

        private sealed class Frame
        {
            public bool Valid;
            public double AgeAtReceiptMs;
            public long ReceivedTicks;
            public double LocalX, LocalY, LocalZ;
            public int LocalId;
            public int Players, Zombies, Rejected;
            public long ReadDurationMs;
            public string Status;
            public string Message;
            public string Warning;
            public Dot[] Dots;
        }

        private sealed class RunState
        {
            public readonly object Gate = new object();
            public readonly ManualResetEventSlim Ready = new ManualResetEventSlim(false);
            public readonly ManualResetEventSlim Done = new ManualResetEventSlim(false);
            public Thread Thread;
            public Frame Frame;
            public long Revision;
            public string EmptyStatus = "En attente d'une capture du jeu.";
            public Exception Error;
            public volatile bool Open;
            public volatile bool StopRequested;
            public volatile bool Completed;
        }

        public static bool IsOpen
        {
            get { lock (lifecycleGate) { return current != null && current.Open && !current.Completed; } }
        }

        public static string LastError
        {
            get
            {
                RunState state;
                lock (lifecycleGate) { state = current; }
                if (state == null) return null;
                lock (state.Gate) { return state.Error == null ? null : state.Error.Message; }
            }
        }

        public static void Start()
        {
            RunState state;
            lock (lifecycleGate)
            {
                if (current != null && !current.Completed)
                    throw new InvalidOperationException("Une fenetre radar est deja ouverte ou en cours de demarrage.");
                state = new RunState();
                state.Thread = new Thread(delegate() { Run(state); });
                state.Thread.Name = "SevenDaysEsp.LiveRadar.UI";
                state.Thread.IsBackground = true;
                state.Thread.SetApartmentState(ApartmentState.STA);
                current = state;
                try { state.Thread.Start(); }
                catch { state.Completed = true; state.Ready.Set(); state.Done.Set(); throw; }
            }
            if (!state.Ready.Wait(5000))
            {
                state.StopRequested = true;
                throw new TimeoutException("La fenetre radar n'a pas pu demarrer dans le delai de 5 secondes.");
            }
            lock (state.Gate)
            {
                if (state.Error != null)
                    throw new InvalidOperationException("Demarrage du radar impossible : " + state.Error.Message, state.Error);
            }
            if (!state.Open)
                throw new InvalidOperationException("La fenetre radar a ete fermee avant la fin du demarrage.");
        }

        private static void Run(RunState state)
        {
            try
            {
                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.ThrowException, true);
                Application.EnableVisualStyles();
                using (RadarForm form = new RadarForm(state))
                {
                    form.Shown += delegate
                    {
                        state.Open = true;
                        state.Ready.Set();
                        if (state.StopRequested) form.Close();
                    };
                    if (!state.StopRequested) Application.Run(form);
                }
            }
            catch (Exception error)
            {
                lock (state.Gate) { state.Error = error; }
            }
            finally
            {
                state.Open = false;
                state.Completed = true;
                state.Ready.Set();
                state.Done.Set();
            }
        }

        public static void Publish(LiveEntitySnapshot snapshot)
        {
            if (snapshot == null) throw new ArgumentNullException("snapshot");
            RunState state;
            lock (lifecycleGate) { state = current; }
            if (state == null || state.Completed || state.StopRequested) return;

            // Le producteur peut reutiliser ses DTO apres cet appel, mais ne doit
            // pas modifier la collection pendant la copie elle-meme.
            Frame frame = CopyFrame(snapshot);
            lock (state.Gate)
            {
                if (state.Completed || state.StopRequested) return;
                state.Frame = frame;
                state.Revision++;
            }
        }

        public static void Clear(string status)
        {
            RunState state;
            lock (lifecycleGate) { state = current; }
            if (state == null) return;
            lock (state.Gate)
            {
                state.Frame = null;
                state.EmptyStatus = Clean(status, 280, "En attente d'une capture valide.");
                state.Revision++;
            }
        }

        public static void Stop()
        {
            RunState state;
            lock (lifecycleGate) { state = current; }
            if (state == null || state.Completed) return;
            state.StopRequested = true;
            // Le timer UI ferme la fenetre. Aucun controle n'est accede depuis
            // le thread du lecteur, meme si la fenetre est deja en destruction.
            if (Thread.CurrentThread != state.Thread) state.Done.Wait(2000);
        }

        private static Frame CopyFrame(LiveEntitySnapshot source)
        {
            Frame result = new Frame();
            DateTime receivedUtc = DateTime.UtcNow;
            result.ReceivedTicks = Stopwatch.GetTimestamp();
            result.AgeAtReceiptMs = (receivedUtc - source.CapturedUtc).TotalMilliseconds;
            result.Status = Clean(source.Status, 80, "DONNEES_ABSENTES");
            result.Message = Clean(source.Message, 280, "Aucune capture exploitable.");
            result.ReadDurationMs = Math.Max(0L, source.ReadDurationMs);
            result.Rejected = Math.Max(0, source.RejectedEntities);
            result.LocalId = source.LocalId;
            result.Warning = String.Empty;
            if (source.Warnings != null && source.Warnings.Count > 0)
                result.Warning = Clean(source.Warnings[0], 180, String.Empty);
            result.Dots = new Dot[0];
            if (source.CapturedUtc.Kind != DateTimeKind.Utc || result.AgeAtReceiptMs < 0 ||
                result.AgeAtReceiptMs > MaximumAgeMs || source.Status != "ENTITES_LUES" ||
                source.LocalPosition == null || !Finite(source.LocalPosition.X) ||
                !Finite(source.LocalPosition.Y) || !Finite(source.LocalPosition.Z))
            {
                if (source.Status == "ENTITES_LUES")
                    result.Message = "Horodatage ou position locale invalide, ou capture deja perimee.";
                return result;
            }
            result.LocalX = source.LocalPosition.X;
            result.LocalY = source.LocalPosition.Y;
            result.LocalZ = source.LocalPosition.Z;
            if (source.Entities == null)
            {
                result.Message = "La collection d'entites est absente.";
                return result;
            }
            if (source.Entities.Count > 4096)
                throw new ArgumentException("Le radar accepte au maximum 4096 entites par capture.", "source");
            List<Dot> dots = new List<Dot>(source.Entities.Count);
            HashSet<int> ids = new HashSet<int>();
            foreach (LiveEntity entity in source.Entities)
            {
                if (entity == null || entity.Position == null || entity.EntityId == source.LocalId ||
                    (entity.Kind != "player" && entity.Kind != "zombie") ||
                    !Finite(entity.Position.X) || !Finite(entity.Position.Y) || !Finite(entity.Position.Z) ||
                    !ids.Add(entity.EntityId))
                {
                    result.Rejected++;
                    continue;
                }
                dots.Add(new Dot {
                    Kind = entity.Kind, Id = entity.EntityId,
                    Name = Clean(entity.Name, 64, String.Empty),
                    X = entity.Position.X, Y = entity.Position.Y, Z = entity.Position.Z
                });
                if (entity.Kind == "player") result.Players++; else result.Zombies++;
            }
            result.Dots = dots.ToArray();
            result.Valid = true;
            return result;
        }

        private static bool Finite(float value) { return !Single.IsNaN(value) && !Single.IsInfinity(value); }

        private static string Clean(string text, int limit, string fallback)
        {
            if (String.IsNullOrEmpty(text)) return fallback;
            int length = Math.Min(text.Length, limit);
            char[] chars = new char[length];
            for (int i = 0; i < length; i++) chars[i] = Char.IsControl(text[i]) ? ' ' : text[i];
            return new string(chars);
        }

        private static double Age(Frame frame)
        {
            return frame.AgeAtReceiptMs + (Stopwatch.GetTimestamp() - frame.ReceivedTicks) * 1000.0 / Stopwatch.Frequency;
        }

        private sealed class RadarForm : Form
        {
            private sealed class RadarCanvas : Control
            {
                private readonly RadarForm owner;
                public RadarCanvas(RadarForm owner)
                {
                    this.owner = owner;
                    SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                        ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
                    TabStop = false;
                }
                protected override void OnPaint(PaintEventArgs e)
                {
                    base.OnPaint(e);
                    owner.PaintRadar(e.Graphics, ClientRectangle);
                }
            }

            private sealed class VisibleDot
            {
                public Dot Dot;
                public double Dx, Dy, Dz, Distance;
            }

            private static readonly Color PlayerColor = Color.FromArgb(81, 218, 245);
            private static readonly Color ZombieColor = Color.FromArgb(255, 170, 71);
            private readonly RunState state;
            private readonly RadarCanvas canvas;
            private readonly ListView list;
            private readonly Label counts;
            private readonly Label status;
            private readonly CheckBox players;
            private readonly CheckBox zombies;
            private readonly NumericUpDown range;
            private readonly System.Windows.Forms.Timer timer;
            private readonly Font uiFont;
            private readonly Font titleFont;
            private readonly Font smallFont;
            private readonly Font messageFont;
            private long lastRevision = -1;
            private long lastListTicks;
            private bool lastFresh;
            private bool forceList = true;

            public RadarForm(RunState state)
            {
                this.state = state;
                Text = "7 Days to Die — Radar DMA joueurs / zombies";
                StartPosition = FormStartPosition.CenterScreen;
                ClientSize = new Size(1060, 700);
                MinimumSize = new Size(930, 610);
                BackColor = Color.FromArgb(15, 19, 26);
                ForeColor = Color.WhiteSmoke;
                AutoScaleMode = AutoScaleMode.Dpi;
                KeyPreview = true;
                uiFont = new Font("Segoe UI", 9.0f);
                titleFont = new Font("Segoe UI", 17.0f, FontStyle.Bold);
                smallFont = new Font("Segoe UI", 8.5f);
                messageFont = new Font("Segoe UI", 12.0f, FontStyle.Bold);
                Font = uiFont;

                TableLayoutPanel layout = new TableLayoutPanel();
                layout.Dock = DockStyle.Fill;
                layout.Padding = new Padding(16, 12, 16, 12);
                layout.ColumnCount = 1;
                layout.RowCount = 5;
                layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 38));
                layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
                layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
                layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
                layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 64));
                Controls.Add(layout);

                Label title = MakeLabel("RADAR DMA  /  JOUEURS ET ZOMBIES", Color.WhiteSmoke);
                title.Font = titleFont;
                layout.Controls.Add(title, 0, 0);
                layout.Controls.Add(MakeLabel("Positions du jeu sur le PC lecteur  •  Vue du dessus  •  Axes fixes : +Z en haut, +X a droite", Color.Silver), 0, 1);

                FlowLayoutPanel controls = new FlowLayoutPanel();
                controls.Dock = DockStyle.Fill;
                controls.WrapContents = false;
                controls.Padding = new Padding(0, 5, 0, 0);
                players = MakeFilter("Joueurs", PlayerColor);
                zombies = MakeFilter("Zombies", ZombieColor);
                controls.Controls.Add(players);
                controls.Controls.Add(zombies);
                Label rangeLabel = new Label();
                rangeLabel.Text = "Portee horizontale (m)";
                rangeLabel.AutoSize = true;
                rangeLabel.Margin = new Padding(14, 6, 6, 0);
                controls.Controls.Add(rangeLabel);
                range = new NumericUpDown();
                range.Minimum = 25;
                range.Maximum = 5000;
                range.Increment = 25;
                range.Value = 200;
                range.Width = 84;
                range.Margin = new Padding(0, 3, 16, 0);
                controls.Controls.Add(range);
                Button close = new Button();
                close.Text = "Fermer";
                close.Size = new Size(80, 28);
                close.BackColor = Color.FromArgb(42, 50, 63);
                close.FlatStyle = FlatStyle.Flat;
                close.Margin = new Padding(0, 1, 0, 0);
                close.Click += delegate { Close(); };
                controls.Controls.Add(close);
                players.CheckedChanged += delegate { forceList = true; canvas.Invalidate(); };
                zombies.CheckedChanged += delegate { forceList = true; canvas.Invalidate(); };
                range.ValueChanged += delegate { forceList = true; canvas.Invalidate(); };
                layout.Controls.Add(controls, 0, 2);

                TableLayoutPanel main = new TableLayoutPanel();
                main.Dock = DockStyle.Fill;
                main.ColumnCount = 2;
                main.RowCount = 1;
                main.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 56));
                main.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 44));
                main.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
                canvas = new RadarCanvas(this);
                canvas.Dock = DockStyle.Fill;
                canvas.Margin = new Padding(0, 0, 12, 0);
                canvas.BackColor = Color.FromArgb(10, 14, 20);
                main.Controls.Add(canvas, 0, 0);
                TableLayoutPanel detail = new TableLayoutPanel();
                detail.Dock = DockStyle.Fill;
                detail.ColumnCount = 1;
                detail.RowCount = 2;
                detail.Margin = new Padding(0);
                detail.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
                detail.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
                counts = MakeLabel("Entites a portee : en attente", Color.WhiteSmoke);
                detail.Controls.Add(counts, 0, 0);
                list = new ListView();
                list.Dock = DockStyle.Fill;
                list.View = View.Details;
                list.FullRowSelect = true;
                list.MultiSelect = false;
                list.HideSelection = false;
                list.BorderStyle = BorderStyle.None;
                list.BackColor = Color.FromArgb(21, 27, 36);
                list.ForeColor = Color.WhiteSmoke;
                list.Columns.Add("Entite / identifiant", 180);
                list.Columns.Add("Dist. 3D", 80, HorizontalAlignment.Right);
                list.Columns.Add("Delta Y", 76, HorizontalAlignment.Right);
                list.SizeChanged += delegate
                {
                    if (list.ClientSize.Width > 220)
                        list.Columns[0].Width = Math.Max(100, list.ClientSize.Width - 176);
                };
                detail.Controls.Add(list, 0, 1);
                main.Controls.Add(detail, 1, 0);
                layout.Controls.Add(main, 0, 3);
                status = MakeLabel("En attente d'une capture du jeu.", Color.Silver);
                status.Padding = new Padding(0, 10, 0, 0);
                layout.Controls.Add(status, 0, 4);
                KeyDown += delegate(object sender, KeyEventArgs e)
                {
                    if (e.KeyCode == Keys.Escape) { e.Handled = true; Close(); }
                };
                timer = new System.Windows.Forms.Timer();
                timer.Interval = 50;
                timer.Tick += delegate
                {
                    if (state.StopRequested) { Close(); return; }
                    RefreshData();
                    canvas.Invalidate();
                };
                timer.Start();
            }

            private static Label MakeLabel(string text, Color color)
            {
                Label label = new Label();
                label.Text = text;
                label.ForeColor = color;
                label.Dock = DockStyle.Fill;
                label.TextAlign = ContentAlignment.MiddleLeft;
                label.Margin = new Padding(0);
                return label;
            }

            private static CheckBox MakeFilter(string text, Color color)
            {
                CheckBox control = new CheckBox();
                control.Text = text;
                control.ForeColor = color;
                control.Checked = true;
                control.AutoSize = true;
                control.Margin = new Padding(0, 5, 16, 0);
                return control;
            }

            private Frame ReadFrame(out long revision, out string emptyStatus)
            {
                lock (state.Gate)
                {
                    revision = state.Revision;
                    emptyStatus = state.EmptyStatus;
                    return state.Frame;
                }
            }

            private bool Fresh(Frame frame)
            {
                if (frame == null || !frame.Valid) return false;
                double age = Age(frame);
                return age >= 0 && age <= MaximumAgeMs;
            }

            private List<VisibleDot> CollectVisibleDots(Frame frame)
            {
                double limit = (double)range.Value;
                List<VisibleDot> result = new List<VisibleDot>();
                foreach (Dot dot in frame.Dots)
                {
                    if ((dot.Kind == "player" && !players.Checked) || (dot.Kind == "zombie" && !zombies.Checked)) continue;
                    double dx = dot.X - frame.LocalX, dy = dot.Y - frame.LocalY, dz = dot.Z - frame.LocalZ;
                    double horizontalSquared = dx * dx + dz * dz;
                    if (horizontalSquared > limit * limit) continue;
                    result.Add(new VisibleDot { Dot = dot, Dx = dx, Dy = dy, Dz = dz,
                        Distance = Math.Sqrt(horizontalSquared + dy * dy) });
                }
                result.Sort(delegate(VisibleDot a, VisibleDot b) { return a.Distance.CompareTo(b.Distance); });
                return result;
            }

            private void RefreshData()
            {
                long revision;
                string empty;
                Frame frame = ReadFrame(out revision, out empty);
                bool fresh = Fresh(frame);
                long ticks = Stopwatch.GetTimestamp();
                bool updateList = forceList || fresh != lastFresh ||
                    (revision != lastRevision && (ticks - lastListTicks) * 1000.0 / Stopwatch.Frequency >= 200);
                if (!fresh)
                {
                    if (list.Items.Count != 0) list.Items.Clear();
                    counts.Text = "Aucune position affichee";
                    string reason = frame == null ? empty : (frame.Valid ? "DONNEES PERIMEES — derniere capture trop ancienne." : frame.Message);
                    status.Text = reason + "\r\nLes reperes sont masques apres 2 s sans capture valide. Echap : fermer.";
                    status.ForeColor = Color.FromArgb(255, 188, 105);
                }
                else
                {
                    List<VisibleDot> visible = CollectVisibleDots(frame);
                    counts.Text = visible.Count + " entites a portee" + (visible.Count > 256 ? " — 256 plus proches dans la liste" : String.Empty);
                    status.ForeColor = Color.Silver;
                    status.Text = String.Format(CultureInfo.InvariantCulture,
                        "Lecture reelle : {0} joueurs / {1} zombies  |  Age : {2:0} ms  |  Lecture : {3} ms  |  Ecartes : {4}\r\n{5}",
                        frame.Players, frame.Zombies, Age(frame), frame.ReadDurationMs, frame.Rejected,
                        String.IsNullOrEmpty(frame.Warning) ? "Distance 3D ; Delta Y positif = entite plus haute. Echap : fermer." : frame.Warning);
                    if (updateList)
                    {
                        list.BeginUpdate();
                        try
                        {
                            list.Items.Clear();
                            for (int i = 0; i < visible.Count && i < 256; i++)
                            {
                                VisibleDot item = visible[i];
                                string kind = item.Dot.Kind == "player" ? "Joueur" : "Zombie";
                                string name = String.IsNullOrEmpty(item.Dot.Name) ? kind : item.Dot.Name;
                                ListViewItem row = new ListViewItem(name + " #" + item.Dot.Id);
                                row.ForeColor = item.Dot.Kind == "player" ? PlayerColor : ZombieColor;
                                row.SubItems.Add(item.Distance.ToString("0.0", CultureInfo.CurrentCulture) + " m");
                                row.SubItems.Add(item.Dy.ToString("+0.0;-0.0;0.0", CultureInfo.CurrentCulture) + " m");
                                list.Items.Add(row);
                            }
                        }
                        finally { list.EndUpdate(); }
                    }
                }
                if (updateList)
                {
                    lastRevision = revision;
                    lastListTicks = ticks;
                    forceList = false;
                }
                lastFresh = fresh;
            }

            private void PaintRadar(Graphics graphics, Rectangle bounds)
            {
                graphics.SmoothingMode = SmoothingMode.AntiAlias;
                float radius = Math.Min(bounds.Width - 76, bounds.Height - 80) * 0.5f;
                if (radius < 30) return;
                float cx = bounds.Width * 0.5f, cy = bounds.Height * 0.5f + 6;
                using (Pen grid = new Pen(Color.FromArgb(43, 55, 70), 1))
                using (Brush muted = new SolidBrush(Color.FromArgb(146, 163, 182)))
                {
                    for (int i = 1; i <= 3; i++)
                    {
                        float r = radius * i / 3;
                        graphics.DrawEllipse(grid, cx - r, cy - r, r * 2, r * 2);
                        graphics.DrawString(((double)range.Value * i / 3).ToString("0", CultureInfo.CurrentCulture) + " m",
                            smallFont, muted, cx + 4, cy - r + 3);
                    }
                    graphics.DrawLine(grid, cx - radius, cy, cx + radius, cy);
                    graphics.DrawLine(grid, cx, cy - radius, cx, cy + radius);
                    graphics.DrawString("+Z", smallFont, muted, cx - 9, cy - radius - 22);
                    graphics.DrawString("+X", smallFont, muted, cx + radius + 7, cy - 8);
                }

                long revision;
                string empty;
                Frame frame = ReadFrame(out revision, out empty);
                if (!Fresh(frame))
                {
                    string message = frame == null ? "EN ATTENTE DE POSITIONS" :
                        (frame.Valid ? "DONNEES PERIMEES" : "CAPTURE NON DISPONIBLE");
                    using (Brush background = new SolidBrush(Color.FromArgb(235, 10, 14, 20)))
                    using (Brush text = new SolidBrush(Color.FromArgb(244, 196, 133)))
                    using (StringFormat format = new StringFormat())
                    {
                        RectangleF messageBounds = new RectangleF(15, cy - 45, bounds.Width - 30, 90);
                        graphics.FillRectangle(background, messageBounds);
                        format.Alignment = StringAlignment.Center;
                        format.LineAlignment = StringAlignment.Center;
                        graphics.DrawString(message, messageFont, text, messageBounds, format);
                    }
                    return;
                }
                List<VisibleDot> visible = CollectVisibleDots(frame);
                double scale = radius / (double)range.Value;
                using (Brush playerBrush = new SolidBrush(PlayerColor))
                using (Brush zombieBrush = new SolidBrush(ZombieColor))
                using (Pen outline = new Pen(Color.FromArgb(10, 14, 20), 1.5f))
                using (Brush localBrush = new SolidBrush(Color.WhiteSmoke))
                {
                    for (int i = visible.Count - 1; i >= 0; i--)
                    {
                        VisibleDot item = visible[i];
                        float x = cx + (float)(item.Dx * scale);
                        float y = cy - (float)(item.Dz * scale);
                        Brush brush = item.Dot.Kind == "player" ? playerBrush : zombieBrush;
                        if (item.Dot.Kind == "player")
                        {
                            graphics.FillRectangle(brush, x - 4, y - 4, 8, 8);
                            graphics.DrawRectangle(outline, x - 4, y - 4, 8, 8);
                        }
                        else
                        {
                            graphics.FillEllipse(brush, x - 4, y - 4, 8, 8);
                            graphics.DrawEllipse(outline, x - 4, y - 4, 8, 8);
                        }
                        if (visible.Count <= 30)
                            graphics.DrawString(item.Dot.Id.ToString(CultureInfo.InvariantCulture), smallFont, brush, x + 6, y - 8);
                    }
                    graphics.FillEllipse(localBrush, cx - 5, cy - 5, 10, 10);
                    graphics.DrawEllipse(outline, cx - 5, cy - 5, 10, 10);
                    graphics.DrawString("Toi", smallFont, localBrush, cx + 9, cy + 5);
                }
            }

            protected override void Dispose(bool disposing)
            {
                if (disposing)
                {
                    if (timer != null) { timer.Stop(); timer.Dispose(); }
                    if (uiFont != null) uiFont.Dispose();
                    if (titleFont != null) titleFont.Dispose();
                    if (smallFont != null) smallFont.Dispose();
                    if (messageFont != null) messageFont.Dispose();
                }
                base.Dispose(disposing);
            }
        }
    }
}
