using System;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;

namespace SevenDaysLoader.UI;

// This is the PC's opaque video output for a hardware fuser. The selected
// key colour fills the entire physical monitor, including the taskbar area.
// Entity rendering remains in the existing validated radar window above it.
internal sealed class FuserSurface : Window
{
    private readonly ILoaderController controller;
    private readonly FuserTestPattern pattern;
    private string deviceName = "";
    private string keyColor = "#000000";

    internal FuserSurface(ILoaderController controller)
    {
        this.controller = controller;
        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        WindowStartupLocation = WindowStartupLocation.Manual;
        AllowsTransparency = false;
        Background = Brushes.Black;
        ShowInTaskbar = false;
        ShowActivated = false;
        Topmost = true;
        Width = 640;
        Height = 480;
        UseLayoutRounding = true;
        SnapsToDevicePixels = true;
        pattern = new FuserTestPattern(controller);
        Content = pattern;
        SourceInitialized += (_, _) =>
        {
            var handle = new WindowInteropHelper(this).Handle;
            long styles = Native.GetWindowLongPtr(handle, -20).ToInt64();
            // Do not activate on mouse input. Unlike the radar, this opaque
            // surface deliberately intercepts clicks instead of passing them
            // through to desktop icons hidden underneath.
            Native.SetWindowLongPtr(handle, -20, new IntPtr(styles | 0x08000000L | 0x80L));
            HwndSource.FromHwnd(handle)?.AddHook(WindowMessage);
        };
    }

    internal bool ShowOn(System.Windows.Forms.Screen screen)
    {
        if (keyColor != controller.Settings.FuserKeyColor)
        {
            keyColor = controller.Settings.FuserKeyColor;
            Background = Theme.Brush(keyColor);
        }
        bool newlyVisible = !IsVisible;
        if (newlyVisible) Show();
        var handle = new WindowInteropHelper(this).Handle;
        var bounds = screen.Bounds;
        bool matches = Native.GetWindowRect(handle, out var actual) &&
            actual.Left == bounds.Left && actual.Top == bounds.Top &&
            actual.Right == bounds.Right && actual.Bottom == bounds.Bottom;
        bool moved = newlyVisible || deviceName != screen.DeviceName || !matches;
        if (moved)
        {
            // SetWindowPos receives physical pixels under PerMonitorV2. WPF
            // receives WM_DPICHANGED/WM_SIZE and updates the drawing DIP size.
            if (!Native.SetWindowPos(handle, new IntPtr(-1), bounds.Left, bounds.Top,
                bounds.Width, bounds.Height, 0x0010))
                throw new System.ComponentModel.Win32Exception(System.Runtime.InteropServices.Marshal.GetLastWin32Error(),
                    "La sortie plein écran du fuser n’a pas pu être positionnée.");
            deviceName = screen.DeviceName;
        }
        pattern.SetOutput(screen.DeviceName, bounds.Width, bounds.Height);
        return moved;
    }

    private static IntPtr WindowMessage(IntPtr hwnd, int message, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (message == 0x0021) { handled = true; return new IntPtr(3); } // MA_NOACTIVATE
        return IntPtr.Zero;
    }
}

// A calibration pattern, never a preview of entities or a camera projection.
internal sealed class FuserTestPattern : FrameworkElement
{
    private readonly ILoaderController controller;
    private string deviceName = "";
    private int pixelWidth, pixelHeight;
    private bool patternEnabled;

    internal FuserTestPattern(ILoaderController controller) => this.controller = controller;
    internal void SetOutput(string name, int width, int height)
    {
        bool changed = name != deviceName || width != pixelWidth || height != pixelHeight ||
            patternEnabled != controller.Settings.FuserTestPattern;
        deviceName = name;
        pixelWidth = width;
        pixelHeight = height;
        patternEnabled = controller.Settings.FuserTestPattern;
        if (changed) InvalidateVisual();
    }

    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);
        if (!controller.Settings.FuserTestPattern || ActualWidth < 100 || ActualHeight < 100) return;
        var dpi = VisualTreeHelper.GetDpi(this);
        double sx = Math.Max(1, dpi.DpiScaleX), sy = Math.Max(1, dpi.DpiScaleY);
        double x = 2 / sx, y = 2 / sy;
        double right = ActualWidth - x, bottom = ActualHeight - y;
        double armX = 48 / sx, armY = 48 / sy;
        var pen = new Pen(Brushes.White, 2 / sx);
        dc.DrawRectangle(null, new Pen(Brushes.White, 1 / sx), new Rect(x, y, right - x, bottom - y));
        Corner(dc, pen, x, y, armX, armY);
        Corner(dc, pen, right, y, -armX, armY);
        Corner(dc, pen, x, bottom, armX, -armY);
        Corner(dc, pen, right, bottom, -armX, -armY);
        var center = new Point(ActualWidth / 2, ActualHeight / 2);
        dc.DrawLine(pen, new Point(center.X - armX, center.Y), new Point(center.X + armX, center.Y));
        dc.DrawLine(pen, new Point(center.X, center.Y - armY), new Point(center.X, center.Y + armY));
        dc.DrawEllipse(null, pen, center, 10 / sx, 10 / sy);
        Label(dc, "TEST AFFICHAGE · MIRE FUSER", ActualWidth / 2, 30, centered: true, size: 22);
        Label(dc, pixelWidth + " × " + pixelHeight + " pixels  ·  " + deviceName, ActualWidth / 2, 65, centered: true);
        Label(dc, "Haut gauche · 0, 0", 18, 18);
        Label(dc, "Haut droit · " + (pixelWidth - 1) + ", 0", ActualWidth - 18, 18, rightAligned: true);
        Label(dc, "Bas gauche · 0, " + (pixelHeight - 1), 18, ActualHeight - 44);
        Label(dc, "Bas droit · " + (pixelWidth - 1) + ", " + (pixelHeight - 1), ActualWidth - 18, ActualHeight - 44, rightAligned: true);
        Label(dc, "Centre · " + pixelWidth / 2 + ", " + pixelHeight / 2, center.X, center.Y + armY + 18, centered: true);
        Label(dc, "Repères de calibration uniquement · aucune entité du jeu", ActualWidth / 2, ActualHeight - 76, centered: true);
    }

    private static void Corner(DrawingContext dc, Pen pen, double x, double y, double dx, double dy)
    {
        dc.DrawLine(pen, new Point(x, y), new Point(x + dx, y));
        dc.DrawLine(pen, new Point(x, y), new Point(x, y + dy));
    }

    private void Label(DrawingContext dc, string value, double x, double y, bool centered = false, bool rightAligned = false, double size = 14)
    {
        var text = new FormattedText(value, CultureInfo.GetCultureInfo("fr-FR"), FlowDirection.LeftToRight,
            new Typeface("Segoe UI"), size, Brushes.White, VisualTreeHelper.GetDpi(this).PixelsPerDip);
        double left = centered ? x - text.Width / 2 : rightAligned ? x - text.Width : x;
        left = Math.Clamp(left, 4, Math.Max(4, ActualWidth - text.Width - 4));
        dc.DrawRoundedRectangle(Theme.Surface, null, new Rect(left - 5, y - 3, text.Width + 10, text.Height + 6), 3, 3);
        dc.DrawText(text, new Point(left, y));
    }
}

// Shared between the DMA landing page and the menu/settings. The first fuser
// activation requires an explicit monitor choice; the overlay's default index
// is never silently treated as that choice.
internal sealed class FuserOutputControls : StackPanel
{
    private readonly ILoaderController controller;
    private readonly Action? activate;
    private readonly ComboBox monitors;
    private readonly ComboBox keyColor;
    private readonly CheckBox test;
    private readonly Button start;
    private readonly Button stop;
    private readonly TextBlock state;
    private string[] names = Array.Empty<string>();
    private string[] labels = Array.Empty<string>();
    private string chosenDevice = "";
    private bool updating;
    private bool wasFuser;
    private int observedMonitor = -1;
    private static readonly string[] Keys = { "#000000", "#00FF00", "#FF00FF" };

    internal FuserOutputControls(ILoaderController controller, Action? activate = null)
    {
        this.controller = controller;
        this.activate = activate;
        Children.Add(Theme.Text("SORTIE VERS LE FUSER", 11, Theme.Orange, true));
        Children.Add(Theme.Text("Choisis l’écran relié à l’entrée overlay du fuser. La sortie sera un plein écran de couleur clé, avec le radar et le menu au-dessus.", 12, Theme.Muted));
        monitors = new ComboBox { Margin = new Thickness(0, 5, 0, 10) };
        monitors.SelectionChanged += (_, _) =>
        {
            if (updating) return;
            chosenDevice = monitors.SelectedIndex > 0 && monitors.SelectedIndex <= names.Length ? names[monitors.SelectedIndex - 1] : "";
            Refresh();
        };
        Children.Add(Theme.Label("Écran envoyé au fuser · choix obligatoire"));
        Children.Add(monitors);
        keyColor = new ComboBox { ItemsSource = new[] { "Noir · #000000", "Vert · #00FF00", "Magenta · #FF00FF" }, Margin = new Thickness(0, 0, 0, 10) };
        keyColor.SelectionChanged += (_, _) =>
        {
            if (updating || keyColor.SelectedIndex < 0) return;
            controller.Settings.FuserKeyColor = Keys[keyColor.SelectedIndex];
            Save();
        };
        Children.Add(Theme.Label("Couleur clé à régler aussi sur le fuser"));
        Children.Add(keyColor);
        test = new CheckBox { Content = "Afficher la mire TEST AFFICHAGE · cette session" };
        RoutedEventHandler changeTest = (_, _) =>
        {
            if (updating) return;
            controller.Settings.FuserTestPattern = test.IsChecked == true;
            Save();
        };
        test.Checked += changeTest;
        test.Unchecked += changeTest;
        Children.Add(test);
        var buttons = new WrapPanel();
        start = Theme.Button("Activer la sortie fuser", Start, true);
        stop = Theme.Button("Retour à la superposition", Stop);
        buttons.Children.Add(start);
        buttons.Children.Add(stop);
        Children.Add(buttons);
        state = Theme.Text("", 12, Theme.Muted);
        Children.Add(state);
        Children.Add(Theme.Text("F6 masque les repères en conservant le fond. Inser ouvre le menu. Ctrl+Alt+F11 quitte la sortie fuser. Ces touches doivent être envoyées au PC qui exécute le loader.", 11, Theme.Muted));
        Refresh();
    }

    internal static string ScreenLabel(System.Windows.Forms.Screen screen, int index) =>
        "Écran " + (index + 1) + " · " + screen.DeviceName + " · " + screen.Bounds.Width + " × " + screen.Bounds.Height +
        (screen.Primary ? " · principal" : " · secondaire");

    internal void Refresh()
    {
        if (updating) return;
        updating = true;
        try
        {
            var screens = System.Windows.Forms.Screen.AllScreens;
            var s = controller.Settings;
            bool fuser = s.OutputMode == "fuser";
            if (fuser && (!wasFuser || observedMonitor != s.MonitorIndex) && s.MonitorIndex >= 0 && s.MonitorIndex < screens.Length &&
                string.Equals(screens[s.MonitorIndex].DeviceName, s.FuserDeviceName, StringComparison.OrdinalIgnoreCase))
                chosenDevice = screens[s.MonitorIndex].DeviceName;
            string[] currentNames = screens.Select(screen => screen.DeviceName).ToArray();
            string[] currentLabels = new[] { "Choisir la sortie reliée au fuser…" }.Concat(screens.Select(ScreenLabel)).ToArray();
            if (!names.SequenceEqual(currentNames) || !labels.SequenceEqual(currentLabels))
            {
                names = currentNames;
                labels = currentLabels;
                monitors.ItemsSource = labels;
            }
            int chosen = Array.IndexOf(names, chosenDevice);
            monitors.SelectedIndex = chosen < 0 ? 0 : chosen + 1;
            keyColor.SelectedIndex = Math.Max(0, Array.IndexOf(Keys, s.FuserKeyColor));
            test.IsChecked = s.FuserTestPattern;
            start.IsEnabled = chosen >= 0;
            start.Content = fuser ? "Appliquer cette sortie fuser" : "Activer la sortie fuser";
            stop.IsEnabled = fuser;
            state.Text = fuser && s.MonitorIndex >= 0 && s.MonitorIndex < screens.Length
                ? "Fuser sélectionné · " + ScreenLabel(screens[s.MonitorIndex], s.MonitorIndex)
                : "Superposition locale · choisis une sortie pour activer le fuser.";
            wasFuser = fuser;
            observedMonitor = s.MonitorIndex;
        }
        finally { updating = false; }
    }

    private void Start()
    {
        var screens = System.Windows.Forms.Screen.AllScreens;
        int index = Array.FindIndex(screens, screen => screen.DeviceName == chosenDevice);
        if (index < 0) { chosenDevice = ""; Refresh(); return; }
        controller.Settings.MonitorIndex = index;
        controller.Settings.FuserDeviceName = screens[index].DeviceName;
        controller.Settings.OutputMode = "fuser";
        Save();
        activate?.Invoke();
        Refresh();
    }

    private void Stop()
    {
        controller.Settings.OutputMode = "overlay";
        controller.Settings.FuserTestPattern = false;
        Save();
        Refresh();
    }

    private void Save()
    {
        try { controller.SaveSettings(); }
        catch (Exception e) { controller.Log("Réglages de sortie non enregistrés : " + e.Message); }
    }
}
