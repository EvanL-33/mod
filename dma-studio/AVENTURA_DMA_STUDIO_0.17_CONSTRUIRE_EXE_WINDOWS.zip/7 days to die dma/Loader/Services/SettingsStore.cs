using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using SevenDaysEsp;

namespace SevenDaysLoader.Services;

public sealed class SettingsStore
{
    private readonly object ioGate = new();
    public static readonly string[] AllowedKeys = { "Insert", "Home", "F6", "F7", "F8", "F9", "F10", "F11" };
    public string DirectoryPath { get; }
    public string FilePath => Path.Combine(DirectoryPath, "loader-settings.json");
    public string BackupPath => Path.Combine(DirectoryPath, "loader-settings.backup.json");
    public string RejectedPath => Path.Combine(DirectoryPath, "loader-settings.invalid.json");
    public string ReportsPath => Path.Combine(DirectoryPath, "rapports");
    public string? LoadWarning { get; private set; }

    public SettingsStore(string? directory = null)
    {
        DirectoryPath = directory ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SevenDaysDmaLauncher");
    }

    public LoaderSettings Load()
    {
        lock (ioGate) return LoadCore();
    }

    private LoaderSettings LoadCore()
    {
        LoadWarning = null;
        LoaderSettings settings = new();
        try
        {
            if (File.Exists(FilePath))
            {
                settings = ReadSettingsFile(FilePath);
            }
            else
            {
                // Import only the old SDK path; keep the original settings file intact.
                string oldPath = Path.Combine(DirectoryPath, "settings.json");
                if (File.Exists(oldPath) && new FileInfo(oldPath).Length <= 65536)
                {
                    using var old = JsonDocument.Parse(File.ReadAllText(oldPath));
                    if (old.RootElement.TryGetProperty("MemProcFsDirectory", out var directory) && directory.ValueKind == JsonValueKind.String)
                        settings.SdkDirectory = directory.GetString() ?? settings.SdkDirectory;
                }
            }
        }
        catch (Exception ex) when (ex is IOException || ex is InvalidDataException || ex is UnauthorizedAccessException || ex is JsonException || ex is ArgumentException)
        {
            LoadWarning = "Impossible de relire les réglages ; valeurs par défaut utilisées. " + ex.Message;
            settings = new LoaderSettings();
            if (File.Exists(BackupPath))
            {
                try
                {
                    settings = ReadSettingsFile(BackupPath);
                    LoadWarning = "Réglages récupérés depuis la sauvegarde précédente ; le fichier principal est illisible. " + ex.Message;
                }
                catch (Exception backupError) when (backupError is IOException || backupError is InvalidDataException || backupError is UnauthorizedAccessException || backupError is JsonException || backupError is ArgumentException)
                {
                    LoadWarning += " La sauvegarde est également illisible : " + backupError.Message;
                }
            }
        }
        Normalize(settings);
        return settings;
    }

    public void Save(LoaderSettings settings)
    {
        // Connection continuations and UI controls can both save. Serialize the
        // entire operation so an older serialized payload cannot finish last.
        lock (ioGate) SaveCore(settings);
    }

    private void SaveCore(LoaderSettings settings)
    {
        Normalize(settings);
        Directory.CreateDirectory(DirectoryPath);
        string temporary = FilePath + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            string json = JsonSerializer.Serialize(settings, new JsonSerializerOptions(Wire.Json) { WriteIndented = true });
            File.WriteAllText(temporary, json, new UTF8Encoding(false));
            if (File.Exists(FilePath))
            {
                bool validPrevious = true;
                try { ReadSettingsFile(FilePath); }
                catch (Exception ex) when (ex is JsonException || ex is InvalidDataException)
                {
                    validPrevious = false;
                    // Keep the last good backup when recovering a malformed
                    // primary file, and retain its bytes for troubleshooting.
                    File.Copy(FilePath, RejectedPath, overwrite: true);
                }
                File.Replace(temporary, FilePath, validPrevious ? BackupPath : null);
            }
            else File.Move(temporary, FilePath);
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
    }

    private static LoaderSettings ReadSettingsFile(string path)
    {
        if (new FileInfo(path).Length > 65536) throw new InvalidDataException("Réglages trop volumineux.");
        return JsonSerializer.Deserialize<LoaderSettings>(File.ReadAllText(path), Wire.Json)
            ?? throw new InvalidDataException("Réglages vides.");
    }

    public static void Normalize(LoaderSettings settings)
    {
        settings.SchemaVersion = 2;
        settings.Mode = settings.Mode == "display" ? "display" : "reader";
        settings.SdkDirectory ??= new LoaderSettings().SdkDirectory;
        settings.Device = string.IsNullOrWhiteSpace(settings.Device) ? "fpga" : settings.Device.Trim();
        // Migrate the old default once. Other saved rates, and any explicit
        // 150 ms choice made after this migration, remain under user control.
        if (settings.ReadCadenceVersion < 1 && settings.IntervalMs == 150)
            settings.IntervalMs = CaptureCadence.DefaultIntervalMs;
        settings.ReadCadenceVersion = 1;
        settings.IntervalMs = Math.Clamp(settings.IntervalMs, 50, 2000);
        settings.MaxDistance = Math.Clamp(settings.MaxDistance, 25, 5000);
        settings.RadarSize = Math.Clamp(settings.RadarSize, 180, 520);
        settings.RadarOpacity = double.IsFinite(settings.RadarOpacity) ? Math.Clamp(settings.RadarOpacity, 0.25, 1) : 0.88;
        settings.RadarRangeMeters = Math.Clamp(settings.RadarRangeMeters, 25, 5000);
        settings.OutputMode = settings.OutputMode == "fuser" ? "fuser" : "overlay";
        if (!ProjectionOutputMapping.IsKnownMode(settings.EspScaleMode)) settings.EspScaleMode = ProjectionOutputMapping.Fit;
        settings.FuserDeviceName = settings.FuserDeviceName?.Trim() ?? "";
        if (settings.FuserDeviceName.Length > 128) settings.FuserDeviceName = "";
        foreach (char character in settings.FuserDeviceName)
        {
            if (char.IsControl(character)) { settings.FuserDeviceName = ""; break; }
        }
        settings.FuserKeyColor = settings.FuserKeyColor?.ToUpperInvariant() ?? "#000000";
        if (settings.FuserKeyColor != "#000000" && settings.FuserKeyColor != "#00FF00" && settings.FuserKeyColor != "#FF00FF")
            settings.FuserKeyColor = "#000000";
        settings.MonitorIndex = Math.Clamp(settings.MonitorIndex, 0, 31);
        settings.SharePort = Math.Clamp(settings.SharePort, 1024, 65535);
        settings.ShareAddress ??= "";
        settings.PlayerColor = IsColor(settings.PlayerColor) ? settings.PlayerColor.ToUpperInvariant() : "#66DEF2";
        settings.ZombieColor = IsColor(settings.ZombieColor) ? settings.ZombieColor.ToUpperInvariant() : "#FF9A52";
        if (settings.EspProfilesVersion < 1)
        {
            settings.PlayerEsp = ImportProfile(settings, settings.ShowPlayers, settings.PlayerColor);
            settings.ZombieEsp = ImportProfile(settings, settings.ShowZombies, settings.ZombieColor);
        }
        settings.EspProfilesVersion = 1;
        settings.PlayerEsp ??= new EntityEspSettings();
        settings.ZombieEsp ??= new EntityEspSettings { Color = "#FF9A52" };
        if (ReferenceEquals(settings.PlayerEsp, settings.ZombieEsp)) settings.ZombieEsp = settings.ZombieEsp.Copy();
        NormalizeProfile(settings.PlayerEsp, "#66DEF2");
        NormalizeProfile(settings.ZombieEsp, "#FF9A52");
        if (ReferenceEquals(settings.PlayerEsp.Rules, settings.ZombieEsp.Rules))
            settings.ZombieEsp.Rules = settings.ZombieEsp.Rules.Copy();
        settings.PlayerFeatures ??= new PlayerFeaturesSettings();
        settings.PvpSense ??= new PvpSenseSettings();
        settings.PvpSense.Normalize();
        settings.PlayerFeatures.MaximumOffscreenIndicators = Math.Clamp(settings.PlayerFeatures.MaximumOffscreenIndicators, 1, 32);
        settings.PlayerFeatures.AlertDistance = Math.Clamp(settings.PlayerFeatures.AlertDistance, 10, 1000);
        settings.PlayerFeatures.AlertRearmMargin = Math.Clamp(settings.PlayerFeatures.AlertRearmMargin, 5, 100);
        settings.PlayerFeatures.AlertCooldownSeconds = Math.Clamp(settings.PlayerFeatures.AlertCooldownSeconds, 3, 120);
        if (Array.IndexOf(AllowedKeys, settings.MenuKey) < 0) settings.MenuKey = "Insert";
        if (Array.IndexOf(AllowedKeys, settings.ToggleKey) < 0 || settings.ToggleKey == settings.MenuKey)
            settings.ToggleKey = settings.MenuKey == "F6" ? "F7" : "F6";
        // Preserve the existing menu/master assignments. Optional shortcuts
        // never take over an older binding during migration or import.
        var assigned = new HashSet<string>(StringComparer.Ordinal) { settings.MenuKey, settings.ToggleKey };
        settings.PlayersKey = NormalizeOptionalKey(settings.PlayersKey, assigned);
        settings.ZombiesKey = NormalizeOptionalKey(settings.ZombiesKey, assigned);
        settings.RadarKey = NormalizeOptionalKey(settings.RadarKey, assigned);
        settings.CreativeMenuKey = NormalizeOptionalKey(settings.CreativeMenuKey, assigned);
        if (settings.OverlayAnchor != "TopLeft" && settings.OverlayAnchor != "BottomLeft" && settings.OverlayAnchor != "BottomRight")
            settings.OverlayAnchor = "TopRight";
    }

    private static EntityEspSettings ImportProfile(LoaderSettings settings, bool enabled, string color) => new()
    {
        Enabled = enabled, Color = color, MaxDistance = settings.MaxDistance,
        ShowNames = settings.ShowNames, ShowHealth = settings.ShowHealth, ShowDistances = settings.ShowDistances
    };

    private static void NormalizeProfile(EntityEspSettings profile, string fallbackColor)
    {
        profile.Color = IsColor(profile.Color) ? profile.Color.ToUpperInvariant() : fallbackColor;
        profile.BoxStyle = profile.BoxStyle == "corners" ? "corners" : "full";
        profile.MaxDistance = Math.Clamp(profile.MaxDistance, 25, 5000);
        profile.FontSize = double.IsFinite(profile.FontSize) ? Math.Clamp(profile.FontSize, 10, 20) : 12;
        profile.LineThickness = double.IsFinite(profile.LineThickness) ? Math.Clamp(profile.LineThickness, 1, 4) : 1.5;
        profile.Rules ??= new EntityDisplayRulesSettings();
        profile.Rules.Normalize();
    }

    private static bool IsColor(string? value) => value != null && Regex.IsMatch(value, "\\A#[0-9A-Fa-f]{6}\\z");

    private static string NormalizeOptionalKey(string? value, HashSet<string> assigned)
    {
        if (string.IsNullOrEmpty(value) || Array.IndexOf(AllowedKeys, value) < 0 || !assigned.Add(value)) return "";
        return value;
    }
}
