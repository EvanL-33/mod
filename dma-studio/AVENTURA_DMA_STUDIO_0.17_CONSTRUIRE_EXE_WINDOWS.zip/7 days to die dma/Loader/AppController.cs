using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using SevenDaysLoader.Services;
using SevenDaysDmaControl;

namespace SevenDaysLoader;

public sealed class AppController : ILoaderController, IAsyncDisposable
{
    private readonly SettingsStore store;
    private readonly SemaphoreSlim gate = new(1, 1);
    private readonly object statusGate = new();
    private readonly object logGate = new();
    private readonly List<string> log = new();
    private readonly HashSet<object> playerDetailConsumers = new(ReferenceEqualityComparer.Instance);
    private readonly string logPath;
    private volatile CancellationTokenSource? connectCancellation;
    private WorkerHost? worker;
    private DisplayClient? display;
    private DisplayServer? server;
    private volatile FeedSample? frame;
    private volatile LoaderStatus status = new();
    private volatile int generation;
    private int stopVersion;
    private bool disposed;
    private string lastLoggedKey = "";
    private long lastMessageTime;
    private readonly CreativeMenuSession creativeMenu = new();
    private readonly PlayerControlSession playerControls = new();
    private PlayerDmaStatRequest? statPending;
    private PlayerDmaStatResult? statResult;
    private long statSequence;
    private string lastControlLogKey = "";
    private readonly GameReconnectCoordinator reconnect = new();

    public LoaderSettings Settings { get; }
    public LoaderStatus Status => status with { CanProject = frame?.IsProjectionFresh == true };
    public FeedSample? CurrentFrame => frame?.IsFresh == true ? frame : null;
    public IReadOnlyList<string> LogLines { get { lock (logGate) return log.ToArray(); } }
    public string ReportDirectory => store.ReportsPath;
    public string SettingsDirectory => store.DirectoryPath;
    public RenderPerformanceTracker Performance { get; } = new();
    public PlayerSessionService Players { get; } = new();
    public CreativeMenuState CreativeMenu => creativeMenu.State;
    public PlayerControlState PlayerControls => playerControls.State;
    public PlayerDmaStatResult? LastDmaStatResult { get { lock (statusGate) return statResult; } }
    public bool IsDmaStatBusy { get { lock (statusGate) return statPending != null; } }
    public event Action? StateChanged;
    public event Action? SettingsChanged;

    public AppController(SettingsStore? settingsStore = null)
    {
        store = settingsStore ?? new SettingsStore();
        Settings = store.Load();
        Players.PreferencesChanged += PlayerPreferencesChanged;
        status = new LoaderStatus { IsReader = Settings.Mode == "reader" };
        logPath = Path.Combine(store.DirectoryPath, "logs", "loader-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N")[..6] + ".log");
        Log("7DTD Loader 0.15.0-dev — surveillance et statistiques locales via DMA.");
        if (store.LoadWarning != null) Log(store.LoadWarning);
    }

    private void ChangeStatus(Func<LoaderStatus, LoaderStatus> change)
    {
        lock (statusGate) status = change(status);
        Notify(StateChanged);
    }

    private static void Notify(Action? action)
    {
        if (action == null) return;
        foreach (Action observer in action.GetInvocationList())
            try { observer(); } catch (Exception) { /* A closing view cannot stop the reader. */ }
    }

    private int BeginGeneration()
    {
        lock (statusGate)
        {
            frame = null;
            Performance.Reset(++generation);
            Players.Reset(generation);
            creativeMenu.Reset(generation);
            playerControls.Reset(generation);
            statPending = null; statResult = null;
            lastControlLogKey = "";
            return generation;
        }
    }

    private bool ApplyGeneration(int expected, FeedSample? sample, Func<LoaderStatus, LoaderStatus> change)
    {
        lock (statusGate)
        {
            if (generation != expected) return false;
            // A timer may read CurrentFrame without waiting for StateChanged.
            // Register the receipt before the volatile publication makes the
            // sample visible to the renderer.
            if (sample != null)
            {
                Performance.ObserveReceived(sample, expected);
                Players.Observe(sample, expected, Settings.PlayerFeatures,
                    Settings.EspEnabled && Settings.PlayerEsp.Enabled && Settings.ShowHud);
            }
            else
            {
                Performance.ObserveUnavailable(expected);
                Players.ObserveUnavailable(expected);
            }
            status = change(status);
            frame = sample;
            creativeMenu.ObserveContext(expected, status.ProcessId, sample,
                worker != null && status.IsReader && status.HasDmaSession && status.IsConnected);
            if (statPending != null && ((sample != null && sample.IsFresh &&
                (statPending.ExpectedPlayerContextId != sample.Snapshot.PlayerContextId ||
                statPending.ExpectedPlayerId != sample.Snapshot.LocalId)) ||
                (!status.IsConnected && status.ProcessId != statPending.ExpectedProcessId)))
                statPending = null;
            playerControls.ObserveContext(expected, status.ProcessId, sample,
                worker != null && status.IsReader && status.HasDmaSession && status.IsConnected);
            UpdateReadOptions();
        }
        Notify(StateChanged);
        return true;
    }

    public Task ConnectReaderAsync()
    {
        int requestedStopVersion = Interlocked.Increment(ref stopVersion);
        reconnect.Cancel();
        return ConnectReaderCoreAsync(requestedStopVersion, null, CancellationToken.None);
    }

    private async Task ConnectReaderCoreAsync(int requestedStopVersion, int? recoveryGeneration, CancellationToken cancellationToken)
    {
        await gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            ObjectDisposedException.ThrowIf(disposed, this);
            cancellationToken.ThrowIfCancellationRequested();
            if (recoveryGeneration.HasValue && (generation != recoveryGeneration.Value ||
                !Settings.AutoReconnectGame || Settings.Mode != "reader" ||
                Volatile.Read(ref stopVersion) != requestedStopVersion)) return;
            if (Volatile.Read(ref stopVersion) != requestedStopVersion) throw new OperationCanceledException("Connexion annulée.");
            await DisconnectCoreAsync().ConfigureAwait(false);
            cancellationToken.ThrowIfCancellationRequested();
            if (Volatile.Read(ref stopVersion) != requestedStopVersion) throw new OperationCanceledException("Connexion annulée.");
            Settings.Mode = "reader";
            SaveSettings();
            string? directory = await Task.Run(() => SdkLocator.Find(Settings.SdkDirectory)).ConfigureAwait(false);
            cancellationToken.ThrowIfCancellationRequested();
            if (Volatile.Read(ref stopVersion) != requestedStopVersion) throw new OperationCanceledException("Connexion annulée.");
            if (directory == null)
                throw new FileNotFoundException("Choisis le dossier MemProcFS x64 contenant vmm.dll et leechcore.dll.");
            if (!Regex.IsMatch(Settings.Device, "\\Afpga(?:://[^\\s\\x00]+)?\\z", RegexOptions.IgnoreCase))
                throw new ArgumentException("Périphérique attendu : fpga ou fpga://…");
            Settings.SdkDirectory = directory;
            SaveSettings();
            int current = BeginGeneration();
            connectCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            if (Volatile.Read(ref stopVersion) != requestedStopVersion) connectCancellation.Cancel();
            worker = new WorkerHost();
            worker.ControlError += message =>
            {
                if (generation == current) Log("Contrôle du lecteur : " + message);
            };
            worker.Message += message => ReceiveWorker(message, current);
            worker.Ended += message =>
            {
                bool shouldReconnect = false;
                if (!ApplyGeneration(current, null, old =>
                {
                    shouldReconnect = GameReconnectCoordinator.CanRecover(old, Settings) &&
                        Volatile.Read(ref stopVersion) == requestedStopVersion && !disposed;
                    bool preserve = old.Stage.StartsWith("ERREUR", StringComparison.Ordinal) ||
                        old.Stage == GameReconnectCoordinator.ProcessLostStage;
                    return old with
                    {
                        IsBusy = shouldReconnect, IsConnected = false, HasDmaSession = false,
                        Stage = shouldReconnect ? "RECONNEXION_JEU" : preserve ? old.Stage : "LECTEUR_ARRETE",
                        Message = shouldReconnect ? "Le jeu a quitté la session. Nouvelle recherche automatique dans 2 secondes…" : preserve ? old.Message : message
                    };
                })) return;
                lock (statusGate)
                {
                    if (generation == current) { creativeMenu.Reset(current); playerControls.Reset(current); statPending = null; statResult = null; }
                }
                Notify(StateChanged);
                Log(message);
                if (shouldReconnect) _ = QueueGameRecoveryAsync(current, requestedStopVersion);
            };
            ChangeStatus(old => new LoaderStatus { Stage = "CONNEXION", Message = "Démarrage du lecteur DMA…", IsBusy = true, IsReader = true });
            Log("Ouverture du lecteur DMA. Dossier MemProcFS : " + directory);
            await worker.StartAsync(new WorkerStart
            {
                SdkDirectory = directory, Device = Settings.Device,
                IntervalMs = Settings.IntervalMs, ReportDirectory = ReportDirectory,
                OutputAtConnection = CaptureDisplayConfiguration(),
                ReadOptions = CurrentReadOptions()
            }, connectCancellation.Token).ConfigureAwait(false);
            // Settings can change while the child establishes its pipe. Send
            // the latest complete preferences once startup has finished.
            UpdateReadOptions();
        }
        catch (Exception ex)
        {
            frame = null;
            bool cancelled = ex is OperationCanceledException;
            ChangeStatus(old => old with { IsBusy = false, IsConnected = false, HasDmaSession = false, Stage = cancelled ? "ARRETE" : "ERREUR_CONNEXION", Message = cancelled ? "Connexion annulée." : ex.GetBaseException().Message });
            Log(cancelled ? "Connexion annulée." : "Connexion impossible : " + ex.GetBaseException().Message);
            throw;
        }
        finally { gate.Release(); }
    }

    private async Task QueueGameRecoveryAsync(int expectedGeneration, int requestedStopVersion)
    {
        try
        {
            // A replacement worker can itself exit before the preceding
            // startup callback has returned. Wait for that callback once so
            // this newer generation is not left busy without a scheduled task.
            for (int attempt = 0; attempt < 2; attempt++)
            {
                Task preceding;
                bool scheduled;
                lock (statusGate)
                {
                    if (disposed || generation != expectedGeneration ||
                        Volatile.Read(ref stopVersion) != requestedStopVersion ||
                        !Settings.AutoReconnectGame || Settings.Mode != "reader" ||
                        status.Stage != "RECONNEXION_JEU") return;
                    preceding = reconnect.Completion;
                    scheduled = reconnect.TrySchedule(expectedGeneration,
                        token => ConnectReaderCoreAsync(requestedStopVersion, expectedGeneration, token),
                        error => Log("Reconnexion automatique interrompue : " + error.GetBaseException().Message));
                }
                if (scheduled)
                {
                    Log("[RECONNEXION_JEU] Reprise de la recherche automatique ; les commandes du créatif ne sont pas rejouées.");
                    return;
                }
                await preceding.ConfigureAwait(false);
            }
            FinishUnscheduledRecovery(expectedGeneration, requestedStopVersion,
                "Reprise automatique indisponible. Utilise Reconnecter pour reprendre la lecture.");
        }
        catch (Exception error)
        {
            FinishUnscheduledRecovery(expectedGeneration, requestedStopVersion,
                "Reprise automatique interrompue : " + error.GetBaseException().Message);
        }
    }

    private void FinishUnscheduledRecovery(int expectedGeneration, int requestedStopVersion, string message)
    {
        lock (statusGate)
        {
            if (disposed || generation != expectedGeneration || Volatile.Read(ref stopVersion) != requestedStopVersion ||
                status.Stage != "RECONNEXION_JEU") return;
            status = status with { Stage = GameReconnectCoordinator.ProcessLostStage, IsBusy = false, Message = message };
        }
        Log(message);
        Notify(StateChanged);
    }

    private DisplayConfigurationReport CaptureDisplayConfiguration()
    {
        var result = new DisplayConfigurationReport
        {
            CapturedUtc = DateTime.UtcNow, OutputMode = Settings.OutputMode,
            EspScaleMode = Settings.EspScaleMode,
            SelectedMonitorIndex = Settings.MonitorIndex,
            EspEnabled = Settings.EspEnabled, ShowProjectedEsp = Settings.ShowProjectedEsp,
            ShowPlayers = Settings.PlayerEsp.Enabled, ShowZombies = Settings.ZombieEsp.Enabled,
            ShowHealth = Settings.PlayerEsp.ShowHealth || Settings.ZombieEsp.ShowHealth,
            MaxDistance = EspDisplayPolicy.RadarRange(Settings),
            PlayerEsp = Settings.PlayerEsp.Copy(), ZombieEsp = Settings.ZombieEsp.Copy()
        };
        try
        {
            var screens = System.Windows.Forms.Screen.AllScreens;
            if (Settings.MonitorIndex < 0 || Settings.MonitorIndex >= screens.Length)
                result.Issue = "Écran sélectionné indisponible au moment de la connexion.";
            else
            {
                var screen = screens[Settings.MonitorIndex];
                result.DeviceName = screen.DeviceName;
                result.PixelWidth = screen.Bounds.Width;
                result.PixelHeight = screen.Bounds.Height;
            }
        }
        catch (Exception ex)
        {
            string detail = ex.GetBaseException().Message;
            result.Issue = detail.Length <= 240 ? detail : detail.Substring(0, 240);
        }
        return result;
    }

    private void ReceiveWorker(WorkerMessage message, int expectedGeneration)
    {
        if (message.Kind == WorkerControl.PlayerDmaStatResultKind)
        {
            bool accepted = false;
            var incoming = message.PlayerDmaStatResult;
            lock (statusGate)
            {
                if (generation == expectedGeneration && statPending != null &&
                    PlayerDmaStatPolicy.IsPlausibleResult(incoming) && incoming != null &&
                    incoming.Sequence == statPending.Sequence && incoming.RequestId == statPending.RequestId &&
                    incoming.ProcessId == statPending.ExpectedProcessId &&
                    incoming.PlayerContextId == statPending.ExpectedPlayerContextId && incoming.Stat == statPending.Stat &&
                    incoming.DesiredValue == statPending.DesiredValue)
                {
                    statPending = null;
                    statResult = incoming;
                    accepted = true;
                }
            }
            if (accepted) { Log("[STATS_DMA / " + incoming!.Code + "] " + incoming.Message); Notify(StateChanged); }
            return;
        }
        if (message.Kind == WorkerControl.PlayerControlStateKind || message.Kind == WorkerControl.PlayerControlSubmissionKind)
        {
            bool accepted;
            string? line = null;
            lock (statusGate)
            {
                accepted = generation == expectedGeneration && (message.Kind == WorkerControl.PlayerControlStateKind
                    ? message.PlayerControlObservation != null && playerControls.Observe(expectedGeneration, message.PlayerControlObservation)
                    : message.PlayerControlSubmission != null && playerControls.AcceptSubmission(expectedGeneration, message.PlayerControlSubmission));
                if (accepted)
                {
                    var controlState = playerControls.State;
                    string key = controlState.Code + "|" + controlState.Message;
                    if (key != lastControlLogKey)
                    {
                        lastControlLogKey = key;
                        line = "[PERSONNAGE / " + controlState.Code + "] " + controlState.Message;
                    }
                }
            }
            if (line != null) Log(line);
            if (accepted) Notify(StateChanged);
            return;
        }
        // Command results are not frames. Routing them through ApplyGeneration
        // would clear the ESP, invalidate player observations and affect timing.
        if (message.Kind == WorkerControl.CreativeResultKind)
        {
            bool accepted;
            CreativeMenuState? receivedState = null;
            lock (statusGate)
            {
                accepted = generation == expectedGeneration && message.CreativeResult != null &&
                    creativeMenu.Accept(expectedGeneration, message.CreativeResult);
                if (accepted) receivedState = creativeMenu.State;
            }
            if (accepted)
            {
                Log("[MENU_CREATIF / " + receivedState!.Code + "] " + receivedState.Message);
                Notify(StateChanged);
            }
            return;
        }
        FeedSample? sample = null;
        if (message.Kind == "frame" && message.Frame != null && FeedSample.IsValid(message.Frame) && double.IsFinite(message.AgeMs) && message.AgeMs >= 0 &&
            message.CapturedTimestamp > 0 && message.CapturedTimestamp <= Stopwatch.GetTimestamp())
        {
            double transitAge = Stopwatch.GetElapsedTime(message.CapturedTimestamp).TotalMilliseconds;
            var incoming = new FeedSample(message.Frame, Math.Max(message.AgeMs, transitAge));
            sample = incoming.IsFresh ? incoming : null;
        }

        bool ready = message.Stage == "DMA_CONNECTEE" || message.Stage == "ATTENTE_JEU" || message.Stage == "ATTENTE_CHARGEMENT_JEU" || message.Stage == "ATTENTE_ENTITES" || message.Kind == "frame" || message.Stage == "LECTURE_NON_VALIDEE" ||
            message.Stage == "LIMITE_LECTURE" || message.Stage == "DONNEES_EXPIREES" || message.Stage == "CAMERA_NON_VALIDEE" || message.Stage == "CAMERA_NATIVE";
        if (!ApplyGeneration(expectedGeneration, sample, old => old with
        {
            Stage = message.Stage, Message = message.Message,
            IsBusy = message.Kind != "error" && !ready,
            IsConnected = message.Kind != "error" && message.ProcessId > 0,
            HasDmaSession = message.HasDmaSession && message.Kind != "error",
            IsReader = true, CanProject = sample?.IsProjectionFresh == true,
            ProjectionMessage = message.ProjectionMessage,
            ProcessId = message.ProcessId,
            GameVersion = string.IsNullOrEmpty(message.GameVersion) ? old.GameVersion : message.GameVersion,
            MemProcFsVersion = string.IsNullOrEmpty(message.MemProcFsVersion) ? old.MemProcFsVersion : message.MemProcFsVersion,
            ReportPath = message.ReportPath
        })) return;
        long now = Stopwatch.GetTimestamp();
        // A changed diagnostic must appear immediately, even when its generic
        // status is still LECTURE_NON_VALIDEE. Live counters remain coalesced.
        string logKey = message.Stage + (message.Kind == "frame" ? "" : "|" + message.Message);
        if (logKey != lastLoggedKey || Stopwatch.GetElapsedTime(lastMessageTime, now).TotalSeconds >= 10)
        {
            lastLoggedKey = logKey;
            lastMessageTime = now;
            Log("[" + message.Stage + "] " + message.Message);
        }
    }

    public async Task RequestDmaStatAsync(PlayerDmaStatKind kind, float? value = null)
    {
        PlayerDmaStatRequest request;
        WorkerHost host;
        int ticket;
        lock (statusGate)
        {
            ObjectDisposedException.ThrowIf(disposed, this);
            var current = frame;
            if (worker == null || !status.IsReader || Settings.Mode != "reader" ||
                !status.IsConnected || !status.HasDmaSession || current?.IsFresh != true ||
                current.Snapshot.PlayerContextId == null)
                throw new InvalidOperationException("Connecte la DMA et attends une capture valide du personnage.");
            if (statPending != null)
                throw new InvalidOperationException("Une autre demande de statistique est déjà en cours.");
            host = worker; ticket = generation;
            request = new PlayerDmaStatRequest
            {
                Sequence = ++statSequence, RequestId = Guid.NewGuid().ToString("N"),
                ExpectedProcessId = status.ProcessId,
                ExpectedPlayerContextId = current.Snapshot.PlayerContextId,
                ExpectedPlayerId = current.Snapshot.LocalId,
                Stat = kind, DesiredValue = value,
                RequestedTimestamp = Stopwatch.GetTimestamp()
            };
            PlayerDmaStatPolicy.Validate(request);
            statPending = request;
            statResult = null;
        }
        Notify(StateChanged);
        try { await host.SendPlayerDmaStatAsync(request).ConfigureAwait(false); }
        catch (Exception error)
        {
            lock (statusGate)
            {
                if (ticket == generation && statPending?.RequestId == request.RequestId)
                {
                    statPending = null;
                    statResult = new PlayerDmaStatResult
                    {
                        Sequence = request.Sequence, RequestId = request.RequestId,
                        ProcessId = request.ExpectedProcessId, PlayerContextId = request.ExpectedPlayerContextId,
                        Stat = request.Stat, DesiredValue = request.DesiredValue,
                        Code = "ENVOI_NON_CONFIRME", Message = error.GetBaseException().Message
                    };
                }
            }
            Notify(StateChanged);
        }
    }

    public Task SetCreativeMenuAsync(bool? enabled) => SendCreativeMenuAsync(enabled, toggle: false);

    public Task ToggleCreativeMenuAsync() => SendCreativeMenuAsync(null, toggle: true);

    public async Task SendPlayerControlAsync(ControlOperation operation, bool enabled = false,
        float value = 0, float x = 0, float y = 0, float z = 0)
    {
        WorkerHost currentWorker;
        PlayerControlRequest request;
        int current;
        lock (statusGate)
        {
            ObjectDisposedException.ThrowIf(disposed, this);
            if (worker == null || !status.IsReader || Settings.Mode != "reader")
                throw new InvalidOperationException("Cette commande s’utilise sur le PC connecté à la DMA.");
            current = generation; currentWorker = worker;
            playerControls.ObserveContext(current, status.ProcessId, frame, status.HasDmaSession && status.IsConnected);
            request = playerControls.Begin(current, operation, enabled, value, x, y, z);
        }
        Notify(StateChanged);
        try { await currentWorker.SendPlayerControlAsync(request).ConfigureAwait(false); }
        catch (Exception error)
        {
            bool changed;
            lock (statusGate) changed = generation == current && playerControls.FailSend(current, request, error.GetBaseException().Message);
            if (changed) { Log("[PERSONNAGE] " + playerControls.State.Message); Notify(StateChanged); }
        }
    }

    private async Task SendCreativeMenuAsync(bool? enabled, bool toggle)
    {
        WorkerHost currentWorker;
        CreativeMenuRequest request;
        int current;
        lock (statusGate)
        {
            ObjectDisposedException.ThrowIf(disposed, this);
            if (worker == null || !status.IsReader || Settings.Mode != "reader")
                throw new InvalidOperationException("Cette commande s’utilise sur le PC connecté à la DMA.");
            current = generation;
            currentWorker = worker;
            creativeMenu.ObserveContext(current, status.ProcessId, frame,
                status.IsReader && status.HasDmaSession && status.IsConnected);
            request = toggle ? creativeMenu.BeginToggle(current) : creativeMenu.Begin(current, enabled);
        }
        Notify(StateChanged);
        try
        {
            await currentWorker.SendCreativeMenuAsync(request).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            bool changed;
            string? detail = null;
            lock (statusGate)
            {
                changed = generation == current &&
                    creativeMenu.FailSend(current, request, ex.GetBaseException().Message);
                if (changed) detail = creativeMenu.State.Message;
            }
            if (changed)
            {
                Log("[MENU_CREATIF] " + detail);
                Notify(StateChanged);
            }
        }
    }

    public async Task ConnectDisplayAsync(string pairingCode)
    {
        int requestedStopVersion = Interlocked.Increment(ref stopVersion);
        reconnect.Cancel();
        await gate.WaitAsync().ConfigureAwait(false);
        try
        {
            ObjectDisposedException.ThrowIf(disposed, this);
            if (Volatile.Read(ref stopVersion) != requestedStopVersion) throw new OperationCanceledException("Connexion annulée.");
            await DisconnectCoreAsync().ConfigureAwait(false);
            if (Volatile.Read(ref stopVersion) != requestedStopVersion) throw new OperationCanceledException("Connexion annulée.");
            Settings.Mode = "display";
            SaveSettings();
            int current = BeginGeneration();
            connectCancellation = new CancellationTokenSource();
            if (Volatile.Read(ref stopVersion) != requestedStopVersion) connectCancellation.Cancel();
            display = new DisplayClient();
            display.Received += (sample, state) =>
            {
                ApplyGeneration(current, sample, _ => state with { IsReader = false, IsBusy = false });
            };
            display.Ended += message =>
            {
                if (!ApplyGeneration(current, null, old => old with { IsConnected = false, HasDmaSession = false, IsBusy = false, Stage = "LIAISON_PERDUE", Message = message })) return;
                Log(message);
            };
            ChangeStatus(_ => new LoaderStatus { IsReader = false, IsBusy = true, Stage = "LIAISON", Message = "Connexion au PC lecteur…" });
            await display.ConnectAsync(pairingCode, connectCancellation.Token).ConfigureAwait(false);
            Log("Liaison chiffrée établie avec le PC lecteur.");
        }
        catch (Exception ex)
        {
            frame = null;
            string message = ex is OperationCanceledException ? "Délai de connexion dépassé ou connexion annulée." : ex.GetBaseException().Message;
            ChangeStatus(old => old with { IsBusy = false, IsConnected = false, HasDmaSession = false, Stage = "ERREUR_LIAISON", Message = message });
            Log("Connexion affichage impossible : " + message);
            throw;
        }
        finally { gate.Release(); }
    }

    public async Task<string> StartSharingAsync(string localAddress)
    {
        await gate.WaitAsync().ConfigureAwait(false);
        try
        {
            ObjectDisposedException.ThrowIf(disposed, this);
            if (Settings.Mode != "reader" || worker == null || !Status.IsConnected)
                throw new InvalidOperationException("Connecte d'abord le lecteur DMA sur ce PC.");
            await StopSharingCoreAsync().ConfigureAwait(false);
            var created = new DisplayServer(() => CurrentFrame, () => Status);
            lock (statusGate) server = created;
            created.ClientChanged += connected =>
            {
                lock (statusGate)
                {
                    if (server != created) return;
                    status = status with { HasDisplayClient = connected };
                }
                Notify(StateChanged);
                Log(connected ? "PC jeu connecté à l'affichage." : "PC jeu déconnecté de l'affichage.");
            };
            created.Error += Log;
            string code = created.Start(localAddress, Settings.SharePort);
            Settings.ShareAddress = localAddress;
            SaveSettings();
            ChangeStatus(old => old with { IsSharing = true });
            Log("Partage local démarré sur " + localAddress + ":" + Settings.SharePort + ".");
            return code;
        }
        catch
        {
            await StopSharingCoreAsync().ConfigureAwait(false);
            throw;
        }
        finally { gate.Release(); }
    }

    public async Task StopSharingAsync()
    {
        await gate.WaitAsync().ConfigureAwait(false);
        try { await StopSharingCoreAsync().ConfigureAwait(false); }
        finally { gate.Release(); }
    }

    private async Task StopSharingCoreAsync()
    {
        DisplayServer? previous;
        lock (statusGate) { previous = server; server = null; }
        if (previous != null) await previous.DisposeAsync().ConfigureAwait(false);
        ChangeStatus(old => old with { IsSharing = false, HasDisplayClient = false });
        UpdateReadOptions();
    }

    public async Task DisconnectAsync()
    {
        Interlocked.Increment(ref stopVersion);
        reconnect.Cancel();
        try { connectCancellation?.Cancel(); } catch (ObjectDisposedException) { }
        await gate.WaitAsync().ConfigureAwait(false);
        try
        {
            await DisconnectCoreAsync().ConfigureAwait(false);
            ChangeStatus(old => new LoaderStatus { IsReader = Settings.Mode == "reader", Stage = "ARRETE", Message = "Lecture et liaison arrêtées. Le menu reste accessible.", ReportPath = old.ReportPath });
            Log("Session arrêtée.");
        }
        finally { gate.Release(); }
    }

    private async Task DisconnectCoreAsync()
    {
        lock (statusGate)
        {
            ++generation;
            frame = null;
            Performance.Reset(generation);
            Players.Reset(generation);
            creativeMenu.Reset(generation);
            playerControls.Reset(generation);
            statPending = null; statResult = null;
            lastControlLogKey = "";
            status = status with { IsConnected = false, HasDmaSession = false, IsBusy = false };
        }
        Notify(StateChanged);
        try { connectCancellation?.Cancel(); } catch (ObjectDisposedException) { }
        await StopSharingCoreAsync().ConfigureAwait(false);
        var previousDisplay = display;
        display = null;
        if (previousDisplay != null) await previousDisplay.DisposeAsync().ConfigureAwait(false);
        var previousWorker = worker;
        worker = null;
        if (previousWorker != null) await previousWorker.DisposeAsync().ConfigureAwait(false);
        connectCancellation?.Dispose();
        connectCancellation = null;
    }

    public void SaveSettings()
    {
        try { store.Save(Settings); }
        catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException || ex is ArgumentException)
        { Log("Réglages actifs mais non enregistrés : " + ex.Message); }
        if (!Settings.AutoReconnectGame || Settings.Mode != "reader")
        {
            reconnect.Cancel();
            bool endedPendingRecovery = false;
            lock (statusGate)
            {
                if (status.Stage == "RECONNEXION_JEU")
                {
                    status = status with
                    {
                        IsBusy = false, Stage = GameReconnectCoordinator.ProcessLostStage,
                        Message = "Recherche automatique annulée. Utilise Reconnecter pour reprendre la lecture."
                    };
                    endedPendingRecovery = true;
                }
            }
            if (endedPendingRecovery) Notify(StateChanged);
        }
        Players.UpdatePreferences(Settings.PlayerFeatures,
            Settings.EspEnabled && Settings.PlayerEsp.Enabled && Settings.ShowHud);
        UpdateReadOptions();
        Notify(SettingsChanged);
    }

    private void UpdateReadOptions()
    {
        // Keep the sharing decision and its non-blocking mailbox publication
        // ordered with changes to the server. A stale local decision must not
        // overtake the request to provide all details to a remote display.
        lock (statusGate)
            worker?.UpdateReadOptions(CurrentReadOptions());
    }

    private SevenDaysEsp.LiveReadOptions CurrentReadOptions()
    {
        lock (statusGate)
        {
            var pinned = Players.ReadSnapshot().Pinned;
            bool pinnedDetails = Settings.EspEnabled && Settings.PlayerEsp.Enabled && Settings.ShowHud &&
                Settings.PlayerFeatures.ShowPinnedCard && pinned != null && !pinned.Visual.Hidden;
            return LiveReadPolicy.FromSettings(Settings, server != null,
                playerDetailConsumers.Count > 0 || pinnedDetails);
        }
    }

    public void SetPlayerDetailsVisible(object consumer, bool visible)
    {
        ArgumentNullException.ThrowIfNull(consumer);
        lock (statusGate)
        {
            if (disposed) return;
            bool changed = visible ? playerDetailConsumers.Add(consumer) : playerDetailConsumers.Remove(consumer);
            if (changed) UpdateReadOptions();
        }
    }

    private void PlayerPreferencesChanged()
    {
        UpdateReadOptions();
        Notify(StateChanged);
    }

    public void ToggleEsp()
    {
        Settings.EspEnabled = !Settings.EspEnabled;
        SaveSettings();
        Log(Settings.EspEnabled ? "Affichage ESP/radar activé. " + Status.ProjectionMessage : "Affichage ESP/radar désactivé.");
    }

    public void TogglePlayers()
    {
        Settings.PlayerEsp.Enabled = !Settings.PlayerEsp.Enabled;
        SaveSettings();
        Log("Profil Joueurs " + (Settings.PlayerEsp.Enabled ? "activé" : "désactivé") + VisibilitySuffix());
    }

    public void ToggleZombies()
    {
        Settings.ZombieEsp.Enabled = !Settings.ZombieEsp.Enabled;
        SaveSettings();
        Log("Profil Zombies " + (Settings.ZombieEsp.Enabled ? "activé" : "désactivé") + VisibilitySuffix());
    }

    public void ToggleRadar()
    {
        Settings.ShowRadar = !Settings.ShowRadar;
        SaveSettings();
        Log("Radar " + (Settings.ShowRadar ? "activé" : "désactivé") + VisibilitySuffix());
    }

    private string VisibilitySuffix() => Settings.EspEnabled ? "." :
        " ; l’affichage général reste masqué (" + Settings.ToggleKey + " pour le réactiver).";

    public void Log(string message)
    {
        message = Regex.Replace(message ?? "", "7DTD1\\.[A-Za-z0-9_=-]+", "[code de liaison masqué]");
        if (message.Length > 4096) message = message.Substring(0, 4096);
        string line = DateTime.Now.ToString("HH:mm:ss") + "  " + message.Replace('\r', ' ').Replace('\n', ' ');
        lock (logGate)
        {
            log.Add(line);
            if (log.Count > 500) log.RemoveRange(0, log.Count - 500);
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(logPath)!);
                if (!File.Exists(logPath) || new FileInfo(logPath).Length < 2 * 1024 * 1024)
                    File.AppendAllText(logPath, line + Environment.NewLine, new UTF8Encoding(false));
            }
            catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException) { }
        }
        Notify(StateChanged);
    }

    public void OpenReportDirectory()
    {
        Directory.CreateDirectory(ReportDirectory);
        Process.Start(new ProcessStartInfo(ReportDirectory) { UseShellExecute = true });
    }

    public async ValueTask DisposeAsync()
    {
        if (disposed) return;
        Interlocked.Increment(ref stopVersion);
        reconnect.Cancel();
        try { connectCancellation?.Cancel(); } catch (ObjectDisposedException) { }
        await gate.WaitAsync().ConfigureAwait(false);
        try
        {
            if (disposed) return;
            disposed = true;
            Players.PreferencesChanged -= PlayerPreferencesChanged;
            lock (statusGate) playerDetailConsumers.Clear();
            await DisconnectCoreAsync().ConfigureAwait(false);
        }
        finally { gate.Release(); }
    }
}
