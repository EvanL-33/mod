using System;
using System.Collections.Generic;
using System.Linq;
using SevenDaysEsp;

namespace SevenDaysLoader.Services;

// One filter shared by drawing, radar and diagnostics. This operates only on
// user preferences; it never changes or prolongs the validity of a capture.
public static class EspDisplayPolicy
{
    public static bool HasProjectedProfile(LoaderSettings settings) =>
        settings.PlayerEsp is { Enabled: true, HasProjectedContent: true } ||
        (settings.PlayerEsp is { Enabled: true } && PvpSenseLabels.WantsPlayerLabel(settings.PvpSense)) ||
        (settings.PlayerEsp is { Enabled: true } && settings.PlayerFeatures.OffscreenIndicators) ||
        settings.ZombieEsp is { Enabled: true, HasProjectedContent: true } ||
        (settings.ZombieEsp is { Enabled: true } && PvpSenseLabels.WantsZombieLabel(settings.PvpSense));

    public static bool TryGetVisibleProfile(LoaderSettings settings, string kind, double distanceMeters,
        bool projected, out EntityEspSettings? profile, double heightMeters = double.NaN,
        PlayerVisualState? visual = null)
    {
        profile = kind == "player" ? settings.PlayerEsp : kind == "zombie" ? settings.ZombieEsp : null;
        return profile != null && profile.Enabled && double.IsFinite(distanceMeters) && distanceMeters >= 0 &&
            distanceMeters <= Math.Clamp(profile.MaxDistance, 25, 5000) &&
            (!projected || profile.HasProjectedContent ||
                (kind == "player" ? PvpSenseLabels.WantsPlayerLabel(settings.PvpSense) :
                    PvpSenseLabels.WantsZombieLabel(settings.PvpSense))) &&
            EntityDisplayRules.PassesHeight(profile, kind, heightMeters, visual);
    }

    // Radar range is horizontal. Independent mode changes only this view;
    // projected markers and off-screen arrows retain their profile distance.
    public static bool TryGetRadarProfile(LoaderSettings settings, string kind, double horizontalDistanceMeters,
        double heightMeters, PlayerVisualState? visual, out EntityEspSettings? profile)
    {
        profile = kind == "player" ? settings.PlayerEsp : kind == "zombie" ? settings.ZombieEsp : null;
        if (profile == null || !profile.Enabled || !double.IsFinite(horizontalDistanceMeters) || horizontalDistanceMeters < 0)
            return false;
        int range = settings.RadarIndependentRange ? Math.Clamp(settings.RadarRangeMeters, 25, 5000) :
            Math.Clamp(profile.MaxDistance, 25, 5000);
        return horizontalDistanceMeters <= range && EntityDisplayRules.PassesHeight(profile, kind, heightMeters, visual);
    }

    // A single map scale keeps positions comparable when each kind has its own
    // visibility distance. Disabling a kind removes it from range selection.
    public static int RadarRange(LoaderSettings settings)
    {
        if (settings.RadarIndependentRange) return Math.Clamp(settings.RadarRangeMeters, 25, 5000);
        int players = settings.PlayerEsp?.Enabled == true ? Math.Clamp(settings.PlayerEsp.MaxDistance, 25, 5000) : 0;
        int zombies = settings.ZombieEsp?.Enabled == true ? Math.Clamp(settings.ZombieEsp.MaxDistance, 25, 5000) : 0;
        return Math.Max(25, Math.Max(players, zombies));
    }

    // Bound text work while reserving half of the budget for each category.
    // Unused places are reassigned to the nearest remaining targets. A horde
    // must not consume all labels intended for players, and box-only profiles
    // must not consume text capacity at all.
    public static HashSet<int> SelectProjectedLabels(LoaderSettings settings,
        IEnumerable<ProjectedMarker> visibleMarkers, int maximumLabels = 64,
        Func<ProjectedMarker, int>? priority = null, Func<ProjectedMarker, PlayerVisualState?>? visual = null)
    {
        int limit = Math.Clamp(maximumLabels, 0, 128);
        var result = new HashSet<int>();
        if (limit == 0) return result;
        var candidates = visibleMarkers.Where(marker =>
            TryGetVisibleProfile(settings, marker.Kind, marker.DistanceMeters, true, out var profile,
                marker.HeightMeters, visual?.Invoke(marker)) &&
            (profile!.ShowNames || profile.ShowHealth || profile.ShowDistances ||
                (profile.Rules?.ShowHeightIndicator == true && double.IsFinite(marker.HeightMeters)) ||
                (marker.Kind == "player" ? PvpSenseLabels.WantsPlayerLabel(settings.PvpSense) :
                    PvpSenseLabels.WantsZombieLabel(settings.PvpSense))))
            .OrderByDescending(marker => priority?.Invoke(marker) ?? 0)
            .ThenBy(marker => marker.DistanceMeters).ThenBy(marker => marker.EntityId).ToArray();
        foreach (string kind in new[] { "player", "zombie" })
            foreach (var marker in candidates.Where(marker => marker.Kind == kind).Take(limit / 2))
                result.Add(marker.EntityId);
        foreach (var marker in candidates)
        {
            if (result.Count >= limit) break;
            result.Add(marker.EntityId);
        }
        return result;
    }
}
