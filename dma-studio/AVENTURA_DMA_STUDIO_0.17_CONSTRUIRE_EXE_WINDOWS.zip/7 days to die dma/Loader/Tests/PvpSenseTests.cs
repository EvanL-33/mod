using System;
using System.Threading.Tasks;
using SevenDaysEsp;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class PvpSenseTests
{
    private static void Check(bool value, string text) { if (!value) throw new Exception(text); }
    private static LivePosition P(float x, float z) => new() { X = x, Y = 0, Z = z };

    public static Task OrientationMeasuresBodyDirectionOnly()
    {
        var p = P(0, 0);
        Check(Math.Abs(PvpSenseMath.AngleToLocal(0, p, P(0, 10))!.Value) < 0.001, "0 yaw must point along +Z");
        Check(Math.Abs(PvpSenseMath.AngleToLocal(90, p, P(10, 0))!.Value) < 0.001, "90 yaw must point along +X");
        Check(Math.Abs(PvpSenseMath.AngleToLocal(0, p, P(10, 0))!.Value - 90) < 0.001, "perpendicular rotation");
        Check(Math.Abs(PvpSenseMath.AngleToLocal(180, p, P(0, 10))!.Value - 180) < 0.001, "opposite rotation");
        Check(!PvpSenseMath.AngleToLocal(null, p, P(0, 10)).HasValue, "unknown yaw must remain unknown");
        Check(!PvpSenseMath.AngleToLocal(float.NaN, p, P(0, 10)).HasValue, "bad yaw must remain unknown");
        Check(!PvpSenseMath.AngleToLocal(0, p, p).HasValue, "coincident actors have no meaningful angle");
        return Task.CompletedTask;
    }

    public static Task LabelsNeverInventWeaponOrTarget()
    {
        var s = new PvpSenseSettings { ShowHeldItemId = true, ShowFacing = true,
            ShowMovement = true, ShowZombieTarget = true };
        Check(PvpSenseLabels.ForPlayer(s, true, true, false, 37, 15) ==
            "accroupi · course · objet #37 · corps orienté vers toi", "Unexpected player details");
        Check(PvpSenseLabels.ForPlayer(s, false, false, false, null, null) == string.Empty,
            "Unknown player state must not be fabricated");
        Check(PvpSenseLabels.ForZombie(s, true) == "CIBLE : TOI", "Confirmed zombie targeting is missing");
        Check(PvpSenseLabels.ForZombie(s, null) == string.Empty &&
            PvpSenseLabels.ForZombie(s, false) == string.Empty,
            "Unknown and negative targets must not be shown as confirmed");
        s.ShowZombieTarget = false;
        Check(PvpSenseLabels.ForZombie(s, true) == string.Empty, "Disabled labels still visible");
        return Task.CompletedTask;
    }

    public static Task SettingsAreOptInAndBounded()
    {
        var s = new LoaderSettings();
        Check(!s.PvpSense.ShowHeldItemId && !s.PvpSense.ShowMovement && !s.PvpSense.ShowFacing &&
            !s.PvpSense.ShowZombieTarget && !s.PvpSense.ShowBloodMoon && !s.PvpSense.ZombieTargetSound,
            "New optional details must be disabled in existing settings");
        s.PvpSense.FacingConeDegrees = 500;
        s.PvpSense.SoundCooldownSeconds = -5;
        SettingsStore.Normalize(s);
        Check(s.PvpSense.FacingConeDegrees == 90 && s.PvpSense.SoundCooldownSeconds == 5, "Bounds incorrect");
        var read = LiveReadPolicy.FromSettings(s, false);
        Check(!read.PlayerFacing && !read.PlayerHeldItem && !read.PlayerMovement &&
            !read.ZombieAttackTarget && !read.WorldBloodMoon, "Default optional reads active");
        s.PvpSense.ShowMovement = true;
        s.PvpSense.ShowFacing = true;
        s.PvpSense.ShowHeldItemId = true;
        s.PvpSense.ShowZombieTarget = true;
        s.PvpSense.ShowBloodMoon = true;
        read = LiveReadPolicy.FromSettings(s, false);
        Check(read.PlayerFacing && read.PlayerHeldItem && read.PlayerMovement &&
            read.ZombieAttackTarget && read.WorldBloodMoon, "Enabled reads not sent to DMA worker");
        var copy = read.Copy();
        Check(ReadOptionsValue.Equal(read, copy), "Read options copy is incomplete");
        copy.PlayerMovement = false;
        Check(!ReadOptionsValue.Equal(read, copy), "Changed PvP read setting is ignored by worker");
        return Task.CompletedTask;
    }
}
