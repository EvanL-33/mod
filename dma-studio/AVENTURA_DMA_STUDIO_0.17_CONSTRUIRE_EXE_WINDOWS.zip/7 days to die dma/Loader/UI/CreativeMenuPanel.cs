using System;
using System.Globalization;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace SevenDaysLoader.UI;

// The panel requests an action. It never binds an editable checkbox to a saved
// setting, and never sends a command during construction, refresh or unload.
internal sealed class CreativeMenuPanel : StackPanel
{
    private readonly ILoaderController controller;
    private readonly TextBlock state = FixedLine(19, 15);
    private readonly TextBlock detail = FixedLine(20, 11);
    private readonly TextBlock observation = FixedLine(18, 10);
    private readonly Button enable = new() { Content = "Activer" };
    private readonly Button disable = new() { Content = "Désactiver" };
    private readonly Button inspect = new() { Content = "Actualiser" };

    internal CreativeMenuPanel(ILoaderController controller)
    {
        this.controller = controller;
        Children.Add(Theme.Text("Menu créatif", 20, null, true));
        Children.Add(Theme.Text("Active l’option créative du client dans la partie chargée, pour tes parties locales et ton serveur.", 12, Theme.Muted));

        var readout = Theme.Stack(state, detail, observation);
        var box = Theme.Inset(readout, new Thickness(14, 12, 14, 12));
        box.Margin = new Thickness(0, 10, 0, 14);
        Children.Add(box);

        var actions = new Grid { Margin = new Thickness(0, 0, 0, 15) };
        Button[] buttons = { enable, disable, inspect };
        for (int i = 0; i < buttons.Length; ++i)
        {
            actions.ColumnDefinitions.Add(new ColumnDefinition());
            buttons[i].Margin = new Thickness(0, 0, i == buttons.Length - 1 ? 0 : 8, 0);
            Grid.SetColumn(buttons[i], i);
            actions.Children.Add(buttons[i]);
        }
        enable.BorderBrush = Theme.Cyan;
        enable.Click += async (_, _) => await RequestAsync(true);
        disable.Click += async (_, _) => await RequestAsync(false);
        inspect.Click += async (_, _) => await RequestAsync(null);
        inspect.ToolTip = "Relit l’option du jeu, sans la modifier.";
        Children.Add(actions);

        Children.Add(Theme.Text("Après activation, ferme le menu du loader puis utilise la touche du menu créatif définie dans le jeu. Après désactivation, ferme aussi la fenêtre créative si elle était déjà ouverte.", 12, Theme.Muted));
        Children.Add(Theme.Text("L’état affiché concerne l’option du client. Si ton serveur active lui-même le mode créatif, désactiver cette option ne retire pas cet accès.", 11, Theme.Muted));
        Children.Add(Theme.Text("Cette option ne conserve pas les succès en mode créatif.", 12, Theme.Orange));
        Children.Add(Theme.Text("L’activation est volontaire : aucun choix n’est réappliqué au démarrage ou après une reconnexion. Actualiser permet de vérifier si le jeu a changé l’option depuis la dernière lecture.", 11, Theme.Muted));
        Children.Add(Theme.Text("Fermer le loader ne désactive pas automatiquement une option déjà appliquée.", 11, Theme.Muted));
        Refresh();
    }

    private static TextBlock FixedLine(double height, double size) => new()
    {
        Height = height,
        FontSize = size,
        Foreground = Theme.Muted,
        Margin = new Thickness(0, 0, 0, 4),
        TextWrapping = TextWrapping.NoWrap,
        TextTrimming = TextTrimming.CharacterEllipsis
    };

    private async Task RequestAsync(bool? value)
    {
        try { await controller.SetCreativeMenuAsync(value); }
        catch (Exception ex)
        {
            // Expected command failures normally arrive through the shared
            // state. Keep a closing/disconnected view from crashing the app.
            controller.Log("Menu créatif : " + ex.GetBaseException().Message);
        }
        Refresh();
    }

    internal void Refresh()
    {
        var current = controller.CreativeMenu;
        state.Text = current.IsBusy ? "Commande en cours…"
            : current.ObservedEnabled == true ? "Option du client : activée"
            : current.ObservedEnabled == false ? "Option du client : désactivée"
            : "Option du client : état non confirmé";
        state.Foreground = current.IsBusy ? Theme.Muted
            : current.ObservedEnabled == true ? Theme.Cyan : Theme.Foreground;
        state.FontWeight = FontWeights.SemiBold;
        detail.Text = current.Message;
        detail.ToolTip = current.Message;
        observation.Text = current.ConfirmedUtc.HasValue
            ? "Dernière confirmation : " + current.ConfirmedUtc.Value.ToLocalTime().ToString("HH:mm:ss", CultureInfo.CurrentCulture)
            : controller.Status.IsReader
                ? "Disponible quand le monde et le joueur local sont confirmés."
                : "Cette commande s’utilise sur le PC connecté à la DMA.";
        enable.IsEnabled = disable.IsEnabled = inspect.IsEnabled = current.CanRequest;
    }
}
