﻿#requires -Version 5.1
[CmdletBinding()]
param([string]$VmmDir = '', [string]$Device = 'fpga')

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)

function Write-State([string]$State, [string]$Message) {
    [Console]::WriteLine(('[{0}] {1}' -f $State, $Message))
    [Console]::Out.Flush()
}

if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT -or [IntPtr]::Size -ne 8) {
    Write-State 'ERREUR_ENVIRONNEMENT' 'Utilise Windows PowerShell 5.1 x64.'
    exit 2
}

$session = $null
$resultCode = 6
$reportPath = $null
$report = [ordered]@{
    Format = 'SevenDaysEsp.DmaInspection/1'
    ToolVersion = '0.4.1-dev'
    CreatedUtc = [DateTime]::UtcNow.ToString('o')
    Status = 'INITIALISATION'
    CanRunEsp = $false
    ProcessId = $null
    MemProcFsVersion = $null
    TargetWindowsBuild = $null
    Modules = @()
    Mono = $null
    GameVersion = $null
    ModuleVersions = @()
    Error = $null
    ReadCalls = 0
    ReadBytes = 0
    NextRequired = @('Valider les acces aux instances et aux listes joueurs/zombies', 'Resoudre et valider la camera native Unity et le repere des positions')
}

try {
    Write-State 'VERSION' 'ESP 0.4.1-dev - detection de version et analyse de compatibilite DMA.'
    if ([string]::IsNullOrWhiteSpace($VmmDir)) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = [Windows.Forms.FolderBrowserDialog]::new()
        try {
            $dialog.Description = 'Choisis le dossier MemProcFS x64 contenant vmm.dll et leechcore.dll.'
            $dialog.ShowNewFolderButton = $false
            if ($dialog.ShowDialog() -ne 'OK') { exit 2 }
            $VmmDir = $dialog.SelectedPath
        } finally { $dialog.Dispose() }
    }
    $sourceFiles = @('DmaMemory.cs', 'MonoInspector.cs', 'MonoGameVersion.cs', 'RemoteVersionInfo.cs') | ForEach-Object { Join-Path $PSScriptRoot $_ }
    foreach ($file in $sourceFiles) {
        if (-not [IO.File]::Exists($file)) { throw ('Source absente : ' + [IO.Path]::GetFileName($file)) }
    }
    Write-State 'COMPILATION' 'Preparation du lecteur, de l''inspecteur Mono et de la detection de version.'
    Add-Type -Path $sourceFiles -ErrorAction Stop
    Write-State 'CONNEXION' 'Ouverture MemProcFS et recherche de 7DaysToDie.exe.'
    $session = [SevenDaysEsp.DmaMemory]::new($VmmDir, $Device)
    $report.ProcessId = $session.ProcessId
    $report.MemProcFsVersion = $session.VmmVersion
    $report.TargetWindowsBuild = $session.TargetWindowsBuild
    Write-State 'JEU_TROUVE' ('PID {0} - MemProcFS {1}' -f $session.ProcessId, $session.VmmVersion)
    foreach ($name in @('7DaysToDie.exe', 'UnityPlayer.dll', 'mono-2.0-bdwgc.dll', 'GameAssembly.dll')) {
        $identity = $session.IdentifyModule($name)
        $report.Modules += $identity
        if ($identity.Present) {
            Write-State 'MODULE' ('{0} - en-tete lisible : {1}' -f $name, $identity.HeaderReadable)
        }
    }
    Write-State 'ANALYSE_MONO' 'Lecture des metadonnees ciblees. Budget indicatif de 20 s entre les appels natifs ; un appel materiel peut durer davantage.'
    $inspector = [SevenDaysEsp.MonoInspector]::new($session)
    $report.Mono = $inspector.Inspect()
    $report.Status = $report.Mono.Status
    Write-State $report.Mono.Status $report.Mono.Message
    Write-State 'CLASSES' ('{0} classes ciblees dans le rapport.' -f $report.Mono.Classes.Count)
    Write-State 'RECHERCHE_VERSION' 'Lecture de Constants.cVersionInformation dans la memoire du jeu.'
    $versionReader = [SevenDaysEsp.MonoGameVersionReader]::new($session)
    $report.GameVersion = $versionReader.Inspect($report.Mono)
    if ($report.GameVersion.Status -eq 'VERSION_JEU_LUE') {
        Write-State 'VERSION_JEU' $report.GameVersion.DisplayVersion
        Write-State 'SOURCE_VERSION' $report.GameVersion.Source
        if (-not $report.GameVersion.FormatRecognized) {
            Write-State 'FORMAT_VERSION' 'Texte exact du jeu conserve ; format non interprete automatiquement.'
        }
    } else {
        Write-State 'VERSION_JEU_INDETERMINEE' $report.GameVersion.Message
        foreach ($warning in @($report.GameVersion.Warnings | Select-Object -First 2)) {
            Write-State 'DETAIL_VERSION' $warning
        }
    }
    $moduleVersionReader = [SevenDaysEsp.RemoteVersionInspector]::new($session)
    foreach ($moduleName in @('7DaysToDie.exe', 'UnityPlayer.dll', 'mono-2.0-bdwgc.dll')) {
        $moduleVersion = $moduleVersionReader.Inspect($moduleName)
        $report.ModuleVersions += $moduleVersion
        $fileVersion = $moduleVersion.DeclaredFileVersion
        if ([string]::IsNullOrWhiteSpace($fileVersion)) { $fileVersion = $moduleVersion.FixedFileVersion }
        $productVersion = $moduleVersion.DeclaredProductVersion
        if ([string]::IsNullOrWhiteSpace($productVersion)) { $productVersion = $moduleVersion.FixedProductVersion }
        if (-not [string]::IsNullOrWhiteSpace($fileVersion) -or -not [string]::IsNullOrWhiteSpace($productVersion)) {
            Write-State 'VERSION_MODULE' ('{0} : fichier={1} ; produit={2}' -f $moduleName, $fileVersion, $productVersion)
        } else {
            Write-State 'VERSION_MODULE_INDISPONIBLE' ('{0} : {1}' -f $moduleName, $moduleVersion.Status)
        }
    }
    if ($report.Mono.Status -eq 'METADONNEES_COLLECTEES') { $resultCode = 0 }
    else { $resultCode = 7 }
} catch {
    $message = $_.Exception.GetBaseException().Message
    $report.Status = 'ERREUR_INSPECTION'
    $report.Error = $message
    Write-State 'ERREUR_INSPECTION' $message
    if ($message -like '*JEU_NON_TROUVE*') { $resultCode = 5 }
    else { $resultCode = 6 }
} finally {
    if ($null -ne $session) {
        $report.ReadCalls = $session.ReadCalls
        $report.ReadBytes = $session.ReadBytes
        try { $session.Dispose(); Write-State 'FERMETURE' 'Session DMA fermee.' }
        catch {
            Write-State 'ERREUR_FERMETURE' $_.Exception.GetBaseException().Message
            $resultCode = 6
        }
    }
}

try {
    $outputDirectory = Join-Path $PSScriptRoot 'rapports'
    [IO.Directory]::CreateDirectory($outputDirectory) | Out-Null
    $reportPath = Join-Path $outputDirectory ('rapport-dma-' + [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0, 6) + '.json')
    $json = $report | ConvertTo-Json -Depth 20
    [IO.File]::WriteAllText($reportPath, $json, [Text.UTF8Encoding]::new($false))
    Write-State 'RAPPORT' $reportPath
    Write-State 'SUITE' 'Pour la version seule, copie la ligne VERSION_JEU. Pour poursuivre l''ESP, joins ce rapport-dma. Aucun fichier n''est envoye automatiquement.'
    Write-State 'ESP_INCOMPLET' 'Ce rapport ne valide pas encore les positions, la camera ou un ESP en jeu.'
} catch {
    Write-State 'ERREUR_RAPPORT' $_.Exception.GetBaseException().Message
    $resultCode = 8
}
exit $resultCode
