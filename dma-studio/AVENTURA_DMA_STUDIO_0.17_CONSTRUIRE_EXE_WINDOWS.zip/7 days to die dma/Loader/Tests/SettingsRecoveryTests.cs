using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class SettingsRecoveryTests
{
    public static Task ValidReplacementKeepsThePreviousSettings()
    {
        using var fixture = new SettingsFixture();
        var first = ExampleSettings(1);
        fixture.Store.Save(first);
        byte[] firstBytes = File.ReadAllBytes(fixture.Store.FilePath);
        Check(!File.Exists(fixture.Store.BackupPath), "The first save invented an earlier settings version.");

        var second = ExampleSettings(2);
        fixture.Store.Save(second);
        byte[] secondBytes = File.ReadAllBytes(fixture.Store.FilePath);
        Check(File.ReadAllBytes(fixture.Store.BackupPath).SequenceEqual(firstBytes),
            "Replacing valid settings did not preserve the previous file byte for byte.");
        Check(ReadState(fixture.Store.FilePath) == State(second) && ReadState(fixture.Store.BackupPath) == State(first),
            "The primary and backup do not contain the latest and previous complete settings respectively.");

        var third = ExampleSettings(3);
        fixture.Store.Save(third);
        Check(File.ReadAllBytes(fixture.Store.BackupPath).SequenceEqual(secondBytes) &&
            ReadState(fixture.Store.FilePath) == State(third), "The backup did not advance to the immediately preceding valid save.");
        Check(!File.Exists(fixture.Store.RejectedPath), "A valid settings replacement was incorrectly classified as corruption.");
        CheckNoTemporaryFiles(fixture.Store);
        return Task.CompletedTask;
    }

    public static Task CorruptPrimaryRecoversIndependentProfilesAndPreservesEvidence()
    {
        using var fixture = new SettingsFixture();
        var previous = ExampleSettings(7);
        fixture.Store.Save(previous);
        byte[] goodBytes = File.ReadAllBytes(fixture.Store.FilePath);
        fixture.Store.Save(ExampleSettings(8));
        byte[] brokenBytes = Encoding.UTF8.GetBytes("  {\"EspProfilesVersion\": 1, \"PlayerEsp\":\r\n<broken>\0");
        File.WriteAllBytes(fixture.Store.FilePath, brokenBytes);

        var recovered = fixture.Store.Load();
        Check(State(recovered) == State(previous), "Recovery discarded or combined the independent profiles in the good backup.");
        Check(!ReferenceEquals(recovered.PlayerEsp, recovered.ZombieEsp) &&
            recovered.PlayerEsp.Color != recovered.ZombieEsp.Color &&
            recovered.PlayerEsp.Enabled != recovered.ZombieEsp.Enabled,
            "Recovered player and zombie options lost their separate identities.");
        Check(!string.IsNullOrWhiteSpace(fixture.Store.LoadWarning) &&
            fixture.Store.LoadWarning.Contains("sauvegarde", StringComparison.OrdinalIgnoreCase),
            "Recovering from backup did not warn that the main settings file was unreadable.");
        Check(File.ReadAllBytes(fixture.Store.FilePath).SequenceEqual(brokenBytes) &&
            File.ReadAllBytes(fixture.Store.BackupPath).SequenceEqual(goodBytes) && !File.Exists(fixture.Store.RejectedPath),
            "Loading a recovery unexpectedly modified or removed the existing settings files.");

        string player = JsonSerializer.Serialize(recovered.PlayerEsp, Wire.Json);
        recovered.ZombieEsp.MaxDistance = 888;
        recovered.ZombieEsp.ShowNames = false;
        fixture.Store.Save(recovered);
        Check(JsonSerializer.Serialize(recovered.PlayerEsp, Wire.Json) == player,
            "Editing a recovered zombie profile modified the player profile.");
        Check(File.ReadAllBytes(fixture.Store.BackupPath).SequenceEqual(goodBytes),
            "Repairing the main file replaced the good backup with corrupt data.");
        Check(File.ReadAllBytes(fixture.Store.RejectedPath).SequenceEqual(brokenBytes),
            "Repairing the main file did not preserve the exact rejected bytes.");
        Check(ReadState(fixture.Store.FilePath) == State(recovered), "The repaired primary file lost the recovery edits.");
        var reloaded = fixture.Store.Load();
        Check(fixture.Store.LoadWarning == null && State(reloaded) == State(recovered),
            "The repaired file still needs backup recovery or did not persist the independent profiles.");
        CheckNoTemporaryFiles(fixture.Store);
        return Task.CompletedTask;
    }

    public static Task TwoUnreadableFilesReturnNormalizedDefaultsWithoutDeletingEither()
    {
        // Exercise parsing errors as well as ReadSettingsFile's null/size errors.
        foreach (var pair in new (string Primary, string Backup)[]
        {
            ("{broken primary", "{broken backup"),
            ("null", "null"),
            (new string('x', 65537), new string(' ', 65537))
        })
        {
            using var fixture = new SettingsFixture();
            byte[] primaryBytes = Encoding.UTF8.GetBytes(pair.Primary);
            byte[] backupBytes = Encoding.UTF8.GetBytes(pair.Backup);
            File.WriteAllBytes(fixture.Store.FilePath, primaryBytes);
            File.WriteAllBytes(fixture.Store.BackupPath, backupBytes);

            var defaults = fixture.Store.Load();
            Check(!string.IsNullOrWhiteSpace(fixture.Store.LoadWarning) &&
                fixture.Store.LoadWarning.Contains("sauvegarde", StringComparison.OrdinalIgnoreCase),
                "Two unreadable settings files failed without an explanation of the failed backup.");
            Check(defaults.SchemaVersion == 2 && defaults.ReadCadenceVersion == 1 && defaults.EspProfilesVersion == 1 &&
                defaults.IntervalMs == CaptureCadence.DefaultIntervalMs && defaults.OutputMode == "overlay" &&
                defaults.MenuKey == "Insert" && defaults.ToggleKey == "F6",
                "Fallback settings were not normalized into a usable current configuration.");
            Check(defaults.PlayerEsp != null && defaults.ZombieEsp != null &&
                !ReferenceEquals(defaults.PlayerEsp, defaults.ZombieEsp) &&
                defaults.PlayerEsp.Color == "#66DEF2" && defaults.ZombieEsp.Color == "#FF9A52" &&
                defaults.PlayerEsp.MaxDistance == 300 && defaults.ZombieEsp.MaxDistance == 300,
                "Fallback settings did not restore independent category defaults.");
            Check(File.ReadAllBytes(fixture.Store.FilePath).SequenceEqual(primaryBytes) &&
                File.ReadAllBytes(fixture.Store.BackupPath).SequenceEqual(backupBytes),
                "Loading fallback defaults removed or rewrote one of the unreadable originals.");
            Check(!File.Exists(fixture.Store.RejectedPath), "Loading alone moved an original into the rejected file.");
            CheckNoTemporaryFiles(fixture.Store);
        }
        return Task.CompletedTask;
    }

    public static async Task ConcurrentSavesOnOneStoreStayCompleteAndLastExplicitSaveWins()
    {
        using var fixture = new SettingsFixture();
        var initial = ExampleSettings(0);
        fixture.Store.Save(initial);
        var versions = Enumerable.Range(1, 16).Select(ExampleSettings).ToArray();
        var knownStates = new HashSet<string>(versions.Select(State), StringComparer.Ordinal) { State(initial) };
        var start = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        // Each caller owns its settings object. This tests concurrent operations
        // on one store instance, not unsynchronized edits or multiple processes.
        var operations = versions.Select(version => Task.Run(async () =>
        {
            await start.Task;
            fixture.Store.Save(version);
            var observed = fixture.Store.Load();
            Check(knownStates.Contains(State(observed)), "A concurrent load returned a partial or mixed save.");
            Check(fixture.Store.LoadWarning == null, "Concurrent writes forced a fallback recovery.");
        })).ToArray();
        start.SetResult(true);
        await Task.WhenAll(operations);

        Check(knownStates.Contains(ReadState(fixture.Store.FilePath)) &&
            knownStates.Contains(ReadState(fixture.Store.BackupPath)),
            "Concurrent saves left an invalid primary or backup, or a mixture of two versions.");
        CheckNoTemporaryFiles(fixture.Store);
        byte[] previousBytes = File.ReadAllBytes(fixture.Store.FilePath);
        var final = ExampleSettings(999);
        fixture.Store.Save(final);
        Check(ReadState(fixture.Store.FilePath) == State(final) && State(fixture.Store.Load()) == State(final),
            "A completed concurrent operation overwrote the subsequent explicit final save.");
        Check(File.ReadAllBytes(fixture.Store.BackupPath).SequenceEqual(previousBytes),
            "The final save did not retain the previously completed version as backup.");
        Check(!File.Exists(fixture.Store.RejectedPath), "Normal concurrent saving produced a rejected-settings file.");
        CheckNoTemporaryFiles(fixture.Store);
    }

    private static LoaderSettings ExampleSettings(int identity) => new()
    {
        EspProfilesVersion = 1, ReadCadenceVersion = 1, SdkDirectory = "test-sdk-" + identity,
        EspEnabled = identity % 2 == 0, OutputMode = "fuser", FuserDeviceName = @"\\.\DISPLAY2",
        FuserKeyColor = "#00FF00", MenuKey = "Home", ToggleKey = "F8",
        // The concurrency fixture must already be normalized; shortcut
        // migration/collision behavior is covered by ReadPolicyHotkeyTests.
        PlayersKey = "F7", ZombiesKey = "F9", RadarKey = "F10", CreativeMenuKey = "F11",
        PlayerEsp = new EntityEspSettings
        {
            Enabled = identity % 2 == 0, Color = "#123456", BoxStyle = "corners", MaxDistance = 100 + identity,
            ShowNames = false, ShowHealth = true, ShowDistances = false, ShowBoxes = true, ShowTracers = true,
            FontSize = 13, LineThickness = 2
        },
        ZombieEsp = new EntityEspSettings
        {
            Enabled = identity % 2 != 0, Color = "#ABCDEF", BoxStyle = "full", MaxDistance = 500 + identity,
            ShowNames = true, ShowHealth = false, ShowDistances = true, ShowBoxes = false, ShowTracers = false,
            FontSize = 18, LineThickness = 3
        }
    };

    private static string State(LoaderSettings settings) => JsonSerializer.Serialize(settings, Wire.Json);

    private static string ReadState(string path)
    {
        using var json = JsonDocument.Parse(File.ReadAllBytes(path));
        Check(json.RootElement.ValueKind == JsonValueKind.Object, "A settings file is not a JSON object.");
        var settings = json.RootElement.Deserialize<LoaderSettings>(Wire.Json);
        Check(settings != null, "A settings file contains no configuration.");
        return State(settings!);
    }

    private static void CheckNoTemporaryFiles(SettingsStore store) =>
        Check(!Directory.EnumerateFiles(store.DirectoryPath, "*.tmp").Any(), "A completed settings operation left a temporary file behind.");

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }

    private sealed class SettingsFixture : IDisposable
    {
        private readonly string directory = Path.Combine(Path.GetTempPath(), "7dtd-settings-recovery-" + Guid.NewGuid().ToString("N"));
        internal SettingsStore Store { get; }
        internal SettingsFixture()
        {
            Directory.CreateDirectory(directory);
            Store = new SettingsStore(directory);
        }
        public void Dispose() => Directory.Delete(directory, true);
    }
}
