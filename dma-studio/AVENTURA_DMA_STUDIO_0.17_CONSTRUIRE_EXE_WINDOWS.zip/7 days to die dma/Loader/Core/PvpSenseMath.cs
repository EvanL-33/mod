using System;
namespace SevenDaysEsp;

public static class PvpSenseMath
{
    // Unity yaw: 0 degrees points toward +Z and +90 toward +X.
    // This is body orientation, NOT evidence of aiming or line of sight.
    public static double? AngleToLocal(float? yawDegrees, LivePosition? remote, LivePosition? local)
    {
        if (yawDegrees is not float yaw || !float.IsFinite(yaw) ||
            Math.Abs(yaw) > 100000 || !Valid(remote) || !Valid(local)) return null;
        double dx = (double)local!.X - remote!.X;
        double dz = (double)local.Z - remote.Z;
        double length = Math.Sqrt(dx * dx + dz * dz);
        if (!double.IsFinite(length) || length < 0.1) return null;
        double rad = yaw * Math.PI / 180.0;
        double facing = Math.Sin(rad) * dx / length + Math.Cos(rad) * dz / length;
        return Math.Acos(Math.Clamp(facing, -1d, 1d)) * 180d / Math.PI;
    }

    private static bool Valid(LivePosition? v) => v != null &&
        float.IsFinite(v.X) && float.IsFinite(v.Y) && float.IsFinite(v.Z) &&
        Math.Abs(v.X) < 1000000 && Math.Abs(v.Y) < 1000000 && Math.Abs(v.Z) < 1000000;
}
