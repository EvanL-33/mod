using System;
using System.Collections.Generic;
using System.Linq;
using SevenDaysEsp;

namespace SevenDaysLoader.Services;

public readonly record struct LabelPlacementCandidate(int EntityId, double Left, double Top,
    double Width, double Height, int Priority = 0);

// This moves text blocks only; entity boxes and camera positions are never
// smoothed, shifted or retained. Fixed ordering avoids distance-sort swapping.
public static class LabelPlacement
{
    public static IReadOnlyDictionary<int, ProjectionBox> Place(IEnumerable<LabelPlacementCandidate> candidates,
        ProjectionViewport viewport, IEnumerable<ProjectionBox>? reserved = null,
        int maximumLabels = 64, double maximumDisplacement = 96)
    {
        var placed = new Dictionary<int, ProjectionBox>();
        if (!ValidViewport(viewport) || !double.IsFinite(maximumDisplacement) || maximumDisplacement < 0)
            return placed;
        maximumDisplacement = Math.Min(maximumDisplacement, 192);
        int limit = Math.Clamp(maximumLabels, 0, 128);
        var occupied = (reserved ?? Array.Empty<ProjectionBox>()).Where(ValidBox).Take(128).ToList();
        // At most 128 candidates can enter the placement algorithm. Callers
        // choose the category-balanced text budget before measuring WPF text.
        foreach (var candidate in candidates.Take(128).Where(c => ValidCandidate(c, viewport))
            .OrderByDescending(c => c.Priority).ThenBy(c => c.EntityId))
        {
            if (placed.Count >= limit) break;
            if (placed.ContainsKey(candidate.EntityId)) continue;
            double x = Math.Clamp(candidate.Left, viewport.X, viewport.Right - candidate.Width);
            double y = Math.Clamp(candidate.Top, viewport.Y, viewport.Bottom - candidate.Height);
            double verticalStep = Math.Min(48, candidate.Height + 5);
            var offsets = new List<ProjectionPoint> { new(0, 0) };
            for (int step = 1; step <= 4; step++)
            {
                double distance = verticalStep * step;
                if (distance > maximumDisplacement) break;
                offsets.Add(new(0, -distance)); offsets.Add(new(0, distance));
            }
            double side = Math.Min(48, maximumDisplacement);
            if (side > 0)
            {
                offsets.Add(new(-side, 0)); offsets.Add(new(side, 0));
            }
            foreach (var offset in offsets)
            {
                double px = x + offset.X, py = y + offset.Y;
                var box = new ProjectionBox(px, py, px + candidate.Width, py + candidate.Height);
                if (box.Left < viewport.X || box.Right > viewport.Right ||
                    box.Top < viewport.Y || box.Bottom > viewport.Bottom ||
                    occupied.Any(other => Intersects(box, other, 3))) continue;
                placed.Add(candidate.EntityId, box);
                occupied.Add(box);
                break;
            }
        }
        return placed;
    }

    public static bool Intersects(ProjectionBox first, ProjectionBox second, double gap = 0) =>
        first.Left < second.Right + gap && first.Right + gap > second.Left &&
        first.Top < second.Bottom + gap && first.Bottom + gap > second.Top;

    private static bool ValidViewport(ProjectionViewport r) => double.IsFinite(r.X) && double.IsFinite(r.Y) &&
        double.IsFinite(r.Width) && double.IsFinite(r.Height) && r.Width > 0 && r.Height > 0 &&
        double.IsFinite(r.Right) && double.IsFinite(r.Bottom);

    private static bool ValidBox(ProjectionBox box) => double.IsFinite(box.Left) && double.IsFinite(box.Top) &&
        double.IsFinite(box.Right) && double.IsFinite(box.Bottom) && box.Width > 0 && box.Height > 0;

    private static bool ValidCandidate(LabelPlacementCandidate c, ProjectionViewport viewport) =>
        c.EntityId >= 0 && double.IsFinite(c.Left) && double.IsFinite(c.Top) && double.IsFinite(c.Width) &&
        double.IsFinite(c.Height) && c.Width > 0 && c.Height > 0 && c.Width <= viewport.Width && c.Height <= viewport.Height;
}
