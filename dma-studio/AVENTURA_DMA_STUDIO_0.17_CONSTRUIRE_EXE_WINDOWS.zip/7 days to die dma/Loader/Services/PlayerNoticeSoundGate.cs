namespace SevenDaysLoader.Services;

// Called only on the UI thread. Consume notices even when sound or the overlay
// is disabled, so reopening the menu cannot replay a pending notification.
public sealed class PlayerNoticeSoundGate
{
    private long lastSequence;

    public bool TryConsume(PlayerProximityNotice? notice, bool allowed)
    {
        if (notice == null || notice.Sequence <= 0 || notice.Sequence <= lastSequence) return false;
        lastSequence = notice.Sequence;
        return allowed && notice.PlaySound;
    }
}
