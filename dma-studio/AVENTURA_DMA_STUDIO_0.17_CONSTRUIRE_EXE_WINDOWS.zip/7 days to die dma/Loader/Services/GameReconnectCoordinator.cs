using System;
using System.Threading;
using System.Threading.Tasks;

namespace SevenDaysLoader.Services;

// One delayed recovery per ended reader generation. The controller still owns
// the lifecycle gate and validates its stop-version ticket before changing it.
// No command or desired creative-menu state is stored by this coordinator.
internal sealed class GameReconnectCoordinator
{
    internal const string ProcessLostStage = "JEU_ARRETE";
    private readonly object gate = new();
    private readonly Func<CancellationToken, Task> delay;
    private CancellationTokenSource? pending;
    private Task completion = Task.CompletedTask;
    private int lastGeneration = int.MinValue;

    internal GameReconnectCoordinator(Func<CancellationToken, Task>? delay = null) =>
        this.delay = delay ?? (token => Task.Delay(TimeSpan.FromSeconds(2), token));

    internal Task Completion { get { lock (gate) return completion; } }

    internal static bool CanRecover(LoaderStatus status, LoaderSettings settings) =>
        status.Stage == ProcessLostStage && status.IsReader && settings.Mode == "reader" && settings.AutoReconnectGame;

    internal bool TrySchedule(int generation, Func<CancellationToken, Task> reconnect, Action<Exception> failed)
    {
        ArgumentNullException.ThrowIfNull(reconnect);
        ArgumentNullException.ThrowIfNull(failed);
        lock (gate)
        {
            if (pending != null || generation <= lastGeneration) return false;
            lastGeneration = generation;
            var cancellation = new CancellationTokenSource();
            pending = cancellation;
            completion = Task.Run(() => RunAsync(cancellation, reconnect, failed));
            return true;
        }
    }

    internal void Cancel()
    {
        lock (gate)
        {
            var cancellation = pending;
            pending = null;
            cancellation?.Cancel();
        }
    }

    private async Task RunAsync(CancellationTokenSource cancellation,
        Func<CancellationToken, Task> reconnect, Action<Exception> failed)
    {
        try
        {
            await delay(cancellation.Token).ConfigureAwait(false);
            cancellation.Token.ThrowIfCancellationRequested();
            await reconnect(cancellation.Token).ConfigureAwait(false);
        }
        catch (OperationCanceledException) when (cancellation.IsCancellationRequested) { }
        catch (Exception error)
        {
            // A startup/native failure is reported once and never retried here.
            if (!cancellation.IsCancellationRequested) failed(error);
        }
        finally
        {
            lock (gate)
            {
                if (ReferenceEquals(pending, cancellation)) pending = null;
                cancellation.Dispose();
            }
        }
    }
}
