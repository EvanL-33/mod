using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using SevenDaysDmaControl;

namespace SevenDaysLoader.UI;

// Live observation and editable intent are separate. Refresh never changes a
// slider/text input, sends a command or moves focus while the user is editing.
internal sealed class PlayerControlPanel : StackPanel
{
    private readonly ILoaderController controller;
    private readonly TextBlock status = FixedText(22, 16);
    private readonly TextBlock detail = FixedText(42, 11, wrap: true);
    private readonly TextBlock position = FixedText(20, 11);
    private readonly TextBlock bookmarkText = FixedText(20, 11);
    private readonly List<Action<PlayerControlState>> updates = new();
    private readonly List<(ControlOperation Operation, Button Button)> commands = new();
    private readonly TextBox x = CoordinateBox(), y = CoordinateBox(), z = CoordinateBox();
    private readonly Button currentPosition = new() { Content = "Position actuelle" };
    private readonly Button remember = new() { Content = "Mémoriser ici" };
    private readonly Button returnToPoint = new() { Content = "Revenir au point" };
    private readonly Button teleport = new() { Content = "Téléporter mon personnage", BorderBrush = Theme.Cyan };
    private (Guid Session, Guid Context, float X, float Y, float Z)? bookmark;
    private string? inputError;

    internal PlayerControlPanel(ILoaderController controller)
    {
        this.controller = controller;
        x.TextChanged += (_, _) => inputError = null;
        y.TextChanged += (_, _) => inputError = null;
        z.TextChanged += (_, _) => inputError = null;
        Children.Add(Theme.Text("Commandes du personnage", 20, null, true));
        Children.Add(Theme.Text("Module client 0.13 • commandes par DMA • profil V 3.4.0 (b10)", 11, Theme.Muted));
        Children.Add(Theme.Inset(Theme.Stack(status, detail, position), new Thickness(13, 10, 13, 8)));
        var installation = Theme.Button("Installer le module sur ce PC…", () => new ModuleInstallerWindow().Show());
        installation.Margin = new Thickness(0, 10, 0, 10);
        installation.HorizontalAlignment = HorizontalAlignment.Left;
        Children.Add(installation);
        Children.Add(Theme.Text("Installe le module une fois sur le PC du jeu. Une session qui charge les mods est nécessaire. Les états ci-dessous sont observés côté client ; l’effet en multijoueur dépend aussi du serveur.", 11, Theme.Muted));

        Children.Add(Heading("DÉPLACEMENT"));
        AddToggle("Vol", "Déplacement aérien du personnage.", ControlOperation.SetFly, ControlFlags.Fly);
        AddToggle("Noclip", "Active aussi le vol. Sors des blocs avant de remettre les collisions.", ControlOperation.SetNoclip, ControlFlags.Noclip);
        AddSlider("Vitesse admin", "Le multiplicateur s’applique selon le mode God, le vol et la caméra du jeu.",
            ControlOperation.SetSpeed, 0.1, 15, 1, 0.1, "×", s => s.Snapshot!.Observation.Speed);
        AddToggle("Mode God natif", "Bascule native du jeu avec son buff, le vol et le noclip.", ControlOperation.SetGod, ControlFlags.God);

        Children.Add(Heading("CAMÉRA ET VISIBILITÉ"));
        AddToggle("Caméra libre", "Ferme le menu Inser, puis utilise les commandes de déplacement du jeu.",
            ControlOperation.SetFreeCamera, ControlFlags.FreeCamera);
        AddToggle("Spectateur", "Transition native du modèle et de l’état spectateur du personnage.",
            ControlOperation.SetSpectator, ControlFlags.Spectator);
        AddSlider("Éclaircissement nocturne", "Luminosité locale ; ce réglage n’ajoute pas le filtre vert.",
            ControlOperation.SetNightBrightness, 0, 100, 100, 5, "%", s => s.Snapshot!.Observation.Brightness * 100f);

        Children.Add(Heading("TÉLÉPORTATION PERSONNELLE"));
        Children.Add(Theme.Text("X et Z : à l’intérieur du monde • Y : altitude de 1 à 254. La confirmation attend la fin de la transition du joueur.", 11, Theme.Muted));
        var coordinates = new Grid { Margin = new Thickness(0, 3, 0, 9) };
        TextBox[] inputs = { x, y, z }; string[] labels = { "X", "Y — altitude", "Z" };
        for (int i = 0; i < inputs.Length; ++i)
        {
            coordinates.ColumnDefinitions.Add(new ColumnDefinition());
            var column = Theme.Stack(Theme.Label(labels[i]), inputs[i]);
            column.Margin = new Thickness(0, 0, i == 2 ? 0 : 8, 0);
            Grid.SetColumn(column, i); coordinates.Children.Add(column);
        }
        Children.Add(coordinates);
        currentPosition.Click += (_, _) =>
        {
            var s = controller.PlayerControls;
            if (s.Available && s.Snapshot != null) SetCoordinates(s.Snapshot.Observation);
        };
        remember.Click += (_, _) =>
        {
            var s = controller.PlayerControls;
            if (!s.Available || s.Snapshot == null) return;
            var o = s.Snapshot.Observation;
            bookmark = (s.Snapshot.SessionId, o.ContextId, o.PositionX, o.PositionY, o.PositionZ);
            Refresh();
        };
        returnToPoint.Click += async (_, _) =>
        {
            var s = controller.PlayerControls;
            if (!HasCurrentBookmark(s) || bookmark is not { } point) return;
            await RequestAsync(ControlOperation.Teleport, x: point.X, y: point.Y, z: point.Z);
        };
        teleport.Click += async (_, _) =>
        {
            if (!TryCoordinate(x.Text, out float px) || !TryCoordinate(y.Text, out float py) || !TryCoordinate(z.Text, out float pz))
            {
                inputError = "Renseigne trois coordonnées finies, avec une virgule ou un point décimal.";
                Refresh(); return;
            }
            await RequestAsync(ControlOperation.Teleport, x: px, y: py, z: pz);
        };
        Children.Add(ButtonRow(currentPosition, remember));
        Children.Add(bookmarkText);
        Children.Add(ButtonRow(teleport, returnToPoint));
        commands.Add((ControlOperation.Teleport, teleport));
        Children.Add(Theme.Text("Le point mémorisé appartient à cette partie. Il n’est pas repris après un changement de personnage ou de session.", 10.5, Theme.Muted));

        Children.Add(Heading("RETOUR À L’ÉTAT INITIAL"));
        var restore = new Button { Content = "Restaurer les options modifiées", BorderBrush = Theme.Orange };
        restore.Click += async (_, _) => await RequestAsync(ControlOperation.RestoreOwned);
        commands.Add((ControlOperation.RestoreOwned, restore));
        Children.Add(restore);
        Children.Add(Theme.Text("Restaure les valeurs initiales encore contrôlées par le module. Une valeur changée entre-temps par le jeu est conservée. La téléportation ne s’annule pas avec ce bouton.", 11, Theme.Muted));
        Children.Add(Theme.Text("Fermer le loader arrête la liaison, sans désactiver automatiquement les modes déjà appliqués. Aucune commande n’est rejouée après reconnexion.", 11, Theme.Muted));
        Refresh();
    }

    private static TextBox CoordinateBox() => new() { Text = "0", MaxLength = 24, MinWidth = 55 };
    private static TextBlock FixedText(double height, double size, bool wrap = false) => new()
    {
        Height = height, FontSize = size, Foreground = Theme.Muted, Margin = new Thickness(0, 0, 0, 3),
        TextWrapping = wrap ? TextWrapping.Wrap : TextWrapping.NoWrap, TextTrimming = TextTrimming.CharacterEllipsis
    };
    private static TextBlock Heading(string text)
    { var label = Theme.Eyebrow(text); label.Margin = new Thickness(0, 18, 0, 8); return label; }
    private static Grid ButtonRow(params Button[] buttons)
    {
        var grid = new Grid { Margin = new Thickness(0, 0, 0, 10) };
        for (int i = 0; i < buttons.Length; ++i)
        {
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            buttons[i].Padding = new Thickness(6, 9, 6, 9);
            buttons[i].Margin = new Thickness(0, 0, i == buttons.Length - 1 ? 0 : 7, 0);
            Grid.SetColumn(buttons[i], i); grid.Children.Add(buttons[i]);
        }
        return grid;
    }

    private void AddToggle(string title, string description, ControlOperation operation, ControlFlags flag)
    {
        var current = FixedText(19, 11);
        var action = new Button { Content = "Activer", MinWidth = 104, VerticalAlignment = VerticalAlignment.Top };
        var grid = new Grid { Margin = new Thickness(0, 0, 0, 8) };
        grid.ColumnDefinitions.Add(new ColumnDefinition()); grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        var text = Theme.Stack(Theme.Text(title, 13, null, true), Theme.Text(description, 10.5, Theme.Muted), current);
        text.Margin = new Thickness(0, 0, 12, 0);
        grid.Children.Add(text); Grid.SetColumn(action, 1); grid.Children.Add(action);
        Children.Add(Theme.Inset(grid, new Thickness(12, 11, 12, 4)));
        action.Click += async (_, _) =>
        {
            var s = controller.PlayerControls;
            if (!s.Supports(operation) || s.Snapshot == null) return;
            await RequestAsync(operation, (s.Snapshot.Observation.Flags & flag) == 0);
        };
        commands.Add((operation, action));
        updates.Add(s =>
        {
            bool known = s.Available && s.Snapshot != null;
            bool enabled = known && (s.Snapshot!.Observation.Flags & flag) != 0;
            current.Text = known ? enabled ? "État observé : actif" : "État observé : inactif" : "État non confirmé";
            current.Foreground = enabled ? Theme.Cyan : Theme.Muted;
            action.Content = enabled ? "Désactiver" : "Activer";
        });
    }

    private void AddSlider(string title, string description, ControlOperation operation, double min, double max,
        double initial, double step, string unit, Func<PlayerControlState, float> observed)
    {
        var slider = new Slider { Minimum = min, Maximum = max, Value = initial, TickFrequency = step, IsSnapToTickEnabled = true };
        var selected = FixedText(20, 11);
        var current = FixedText(20, 11);
        void Selected() => selected.Text = "Valeur choisie : " + slider.Value.ToString("0.#", CultureInfo.CurrentCulture) + " " + unit;
        Selected(); slider.ValueChanged += (_, _) => Selected();
        var apply = new Button { Content = "Appliquer", HorizontalAlignment = HorizontalAlignment.Right, MinWidth = 104 };
        apply.Click += async (_, _) => await RequestAsync(operation, value: (float)(operation == ControlOperation.SetNightBrightness ? slider.Value / 100 : slider.Value));
        var panel = Theme.Stack(Theme.Text(title, 13, null, true), Theme.Text(description, 10.5, Theme.Muted), current, slider, selected, apply);
        var box = Theme.Inset(panel); box.Margin = new Thickness(0, 8, 0, 8); Children.Add(box);
        commands.Add((operation, apply));
        updates.Add(s => current.Text = s.Available && s.Snapshot != null
            ? "Valeur observée : " + observed(s).ToString("0.##", CultureInfo.CurrentCulture) + " " + unit : "Valeur non confirmée");
    }

    private async Task RequestAsync(ControlOperation operation, bool enabled = false, float value = 0, float x = 0, float y = 0, float z = 0)
    {
        inputError = null;
        try { await controller.SendPlayerControlAsync(operation, enabled, value, x, y, z); }
        catch (Exception error)
        {
            string message = error.GetBaseException().Message;
            controller.Log("Personnage : " + message); inputError = message;
        }
        Refresh();
    }

    private static bool TryCoordinate(string text, out float value) =>
        (float.TryParse(text.Trim(), NumberStyles.Float, CultureInfo.GetCultureInfo("fr-FR"), out value) ||
         float.TryParse(text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out value)) && PlayerControlPolicy.ValidCoordinate(value);
    private void SetCoordinates(GameObservation value)
    {
        x.Text = value.PositionX.ToString("0.###", CultureInfo.CurrentCulture);
        y.Text = value.PositionY.ToString("0.###", CultureInfo.CurrentCulture);
        z.Text = value.PositionZ.ToString("0.###", CultureInfo.CurrentCulture);
    }
    private bool HasCurrentBookmark(PlayerControlState s) => bookmark is { } point && s.Snapshot != null &&
        point.Session == s.Snapshot.SessionId && point.Context == s.Snapshot.Observation.ContextId;

    internal void Refresh()
    {
        var s = controller.PlayerControls;
        status.Text = s.IsBusy ? "Transition en cours…" : s.Available ? "Module connecté • personnage prêt" : "Commandes indisponibles";
        status.Foreground = s.Available ? Theme.Cyan : Theme.Muted;
        status.FontWeight = FontWeights.SemiBold;
        detail.Text = inputError ?? s.Message; detail.ToolTip = detail.Text;
        position.Text = s.Available && s.Snapshot != null ? string.Format(CultureInfo.CurrentCulture,
            "Position observée : X {0:0.0}  •  Y {1:0.0}  •  Z {2:0.0}", s.Snapshot.Observation.PositionX,
            s.Snapshot.Observation.PositionY, s.Snapshot.Observation.PositionZ) : "Position en attente de lecture.";
        foreach (var update in updates) update(s);
        foreach (var command in commands) command.Button.IsEnabled = s.Supports(command.Operation);
        currentPosition.IsEnabled = remember.IsEnabled = s.Available && !s.IsBusy;
        returnToPoint.IsEnabled = s.Supports(ControlOperation.Teleport) && HasCurrentBookmark(s);
        if (bookmark != null && s.Snapshot != null && !HasCurrentBookmark(s)) bookmark = null;
        bookmarkText.Text = bookmark is { } point
            ? string.Format(CultureInfo.CurrentCulture, "Point mémorisé : {0:0.0} / {1:0.0} / {2:0.0}", point.X, point.Y, point.Z)
            : "Aucun point mémorisé dans cette partie.";
    }
}
