using System;
using System.Text;

namespace SevenDaysDmaControl
{
    public enum ControlOperation : uint
    {
        None = 0, SetFly = 1, SetNoclip = 2, SetSpeed = 3, SetFreeCamera = 4,
        SetNightBrightness = 5, SetGod = 6, Teleport = 7, SetSpectator = 8, RestoreOwned = 9
    }

    public enum ControlStatus : uint { None = 0, Pending = 1, AppliedLocal = 2, Refused = 3, Failed = 4 }
    public enum BridgeAvailability : uint { Initializing = 0, Ready = 1, NoWorld = 2, Incompatible = 3, Faulted = 4 }

    [Flags]
    public enum ControlFlags : uint
    {
        None = 0, Fly = 1, Noclip = 2, FreeCamera = 4, God = 8, Spectator = 16,
        FirstPerson = 32, Dead = 64, Teleporting = 128, RemoteWorld = 256
    }

    public sealed class ControlRequest
    {
        public Guid SessionId;
        public Guid ContextId;
        public ulong RequestId;
        public int PlayerId;
        public ControlOperation Operation;
        // These values originate in a game StateBuffer snapshot, never in the loader's clock.
        public long IssuedGameTimeMs;
        public long ExpiresGameTimeMs;
        public bool Enabled;
        public float Value;
        public float PositionX, PositionY, PositionZ;
        public int TargetEntityId;
    }

    public sealed class GameObservation
    {
        public Guid ContextId;
        public int PlayerId;
        public BridgeAvailability Availability;
        public bool IsReady { get { return Availability == BridgeAvailability.Ready; } }
        // ControlBridge supplies its own monotonic clock before Execute/Poll.
        public long GameTimestampMs;
        public float PositionX, PositionY, PositionZ;
        public float Speed = 1f;
        public float Brightness;
        public ControlFlags Flags;
        public uint SupportedOperations = ControlProtocol.AllOperationsMask;
        public uint OwnedOperations;
        public string Message = "";
    }

    public sealed class GameActionResult
    {
        public ControlStatus Status;
        public string Message;
        public GameActionResult(ControlStatus status, string message) { Status = status; Message = message ?? ""; }
        public static GameActionResult Pending(string message) { return new GameActionResult(ControlStatus.Pending, message); }
        public static GameActionResult Applied(string message) { return new GameActionResult(ControlStatus.AppliedLocal, message); }
        public static GameActionResult Refused(string message) { return new GameActionResult(ControlStatus.Refused, message); }
        public static GameActionResult Failed(string message) { return new GameActionResult(ControlStatus.Failed, message); }
    }

    // All four calls are made only on the game update thread. Implementations must not start
    // background Unity work. Release must restore only state still owned in the same context.
    public interface IGameActions
    {
        GameObservation Observe();
        GameActionResult Execute(ControlRequest request, GameObservation current);
        GameActionResult Poll(ulong requestId, GameObservation current);
        void Release(GameObservation current);
    }

    public sealed class ControlSnapshot
    {
        public Guid SessionId;
        public GameObservation Observation = new GameObservation();
        public ulong LastRequestId;
        public Guid LastRequestContextId;
        public ControlOperation LastOperation;
        public ControlStatus LastStatus;
        public string LastMessage = "";
        // Highest consumed request in this module session; never decreases across worlds.
        public ulong RequestHighWatermark;
        public ulong PendingRequestId;
        public uint Sequence;
    }

    public static class ControlProtocol
    {
        public const uint Version = 1;
        public const uint RequestMagic = 0x51523744; // D7RQ, little endian
        public const uint StateMagic = 0x54533744;   // D7ST, little endian
        public const int RequestSize = 256;
        public const int StateSize = 512;
        public const int CommitOffset = 12;
        public const int RequestCrcOffset = RequestSize - 4;
        public const int StateCrcOffset = StateSize - 4;
        public const long MaxRequestLifetimeMs = 5000;
        public const long DefaultRequestLifetimeMs = 3000;
        public const long MaxPendingDurationMs = 35000;
        public const uint AllOperationsMask = 0x3FE;
        public const int StateMessageOffset = 144;
        public const int StateMessageCapacity = 360;
        public static uint OperationMask(ControlOperation operation) { return IsKnownOperation(operation) ? 1u << (int)operation : 0; }
        public static bool IsKnownOperation(ControlOperation operation) { return operation >= ControlOperation.SetFly && operation <= ControlOperation.RestoreOwned; }
        public static bool IsFinite(float value) { return !float.IsNaN(value) && !float.IsInfinity(value); }

        // Commit is nonzero/even for complete records. To publish: write an odd sequence to
        // offset 12, write bytes [0,12) and [16,size), then commit the even sequence last.
        // DMA readers copy the full record twice and require the SAME even sequence and CRC.
        // CRC covers the final even sequence; an odd/incomplete record never decodes.
        public static byte[] EncodeRequest(ControlRequest request, uint sequence)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));
            ValidateSequence(sequence);
            var bytes = Header(RequestMagic, RequestSize, sequence);
            PutGuid(bytes, 16, request.SessionId); PutGuid(bytes, 32, request.ContextId);
            PutUInt64(bytes, 48, request.RequestId); PutInt32(bytes, 56, request.PlayerId);
            PutUInt32(bytes, 60, (uint)request.Operation);
            PutInt64(bytes, 64, request.IssuedGameTimeMs); PutInt64(bytes, 72, request.ExpiresGameTimeMs);
            PutUInt32(bytes, 80, request.Enabled ? 1u : 0u); PutSingle(bytes, 84, request.Value);
            PutSingle(bytes, 88, request.PositionX); PutSingle(bytes, 92, request.PositionY); PutSingle(bytes, 96, request.PositionZ);
            PutInt32(bytes, 100, request.TargetEntityId); Seal(bytes);
            return bytes;
        }

        public static bool TryDecodeRequest(byte[] bytes, out ControlRequest request, out string error)
        {
            request = null;
            if (!ValidateRecord(bytes, RequestMagic, RequestSize, out error)) return false;
            if (GetUInt32(bytes, 80) > 1) { error = "INVALID_BOOLEAN"; return false; }
            request = new ControlRequest { SessionId = GetGuid(bytes, 16), ContextId = GetGuid(bytes, 32),
                RequestId = GetUInt64(bytes, 48), PlayerId = GetInt32(bytes, 56), Operation = (ControlOperation)GetUInt32(bytes, 60),
                IssuedGameTimeMs = GetInt64(bytes, 64), ExpiresGameTimeMs = GetInt64(bytes, 72), Enabled = GetUInt32(bytes, 80) != 0,
                Value = GetSingle(bytes, 84), PositionX = GetSingle(bytes, 88), PositionY = GetSingle(bytes, 92),
                PositionZ = GetSingle(bytes, 96), TargetEntityId = GetInt32(bytes, 100) };
            return true;
        }

        public static byte[] EncodeSnapshot(ControlSnapshot snapshot, uint sequence)
        {
            if (snapshot == null || snapshot.Observation == null) throw new ArgumentNullException(nameof(snapshot));
            ValidateSequence(sequence); var bytes = Header(StateMagic, StateSize, sequence); var o = snapshot.Observation;
            PutGuid(bytes, 16, snapshot.SessionId); PutGuid(bytes, 32, o.ContextId); PutInt64(bytes, 48, o.GameTimestampMs);
            PutInt32(bytes, 56, o.PlayerId); PutUInt32(bytes, 60, (uint)o.Availability); PutUInt32(bytes, 64, (uint)o.Flags);
            PutUInt32(bytes, 68, o.SupportedOperations); PutSingle(bytes, 72, o.PositionX); PutSingle(bytes, 76, o.PositionY);
            PutSingle(bytes, 80, o.PositionZ); PutSingle(bytes, 84, o.Speed); PutSingle(bytes, 88, o.Brightness);
            PutUInt32(bytes, 92, o.OwnedOperations); PutUInt64(bytes, 96, snapshot.LastRequestId);
            PutUInt32(bytes, 104, (uint)snapshot.LastStatus); PutUInt32(bytes, 108, (uint)snapshot.LastOperation);
            PutUInt64(bytes, 112, snapshot.RequestHighWatermark); PutUInt64(bytes, 120, snapshot.PendingRequestId);
            PutGuid(bytes, 128, snapshot.LastRequestContextId);
            PutUtf8(bytes, StateMessageOffset, StateMessageCapacity, snapshot.LastMessage);
            Seal(bytes); return bytes;
        }

        public static bool TryDecodeSnapshot(byte[] bytes, out ControlSnapshot snapshot, out string error)
        {
            snapshot = null;
            if (!ValidateRecord(bytes, StateMagic, StateSize, out error)) return false;
            uint availability = GetUInt32(bytes, 60), status = GetUInt32(bytes, 104);
            if (availability > (uint)BridgeAvailability.Faulted || status > (uint)ControlStatus.Failed) { error = "INVALID_STATE"; return false; }
            if (GetUInt32(bytes, StateMessageOffset) > StateMessageCapacity - 4) { error = "INVALID_MESSAGE_LENGTH"; return false; }
            var o = new GameObservation { ContextId = GetGuid(bytes, 32), GameTimestampMs = GetInt64(bytes, 48), PlayerId = GetInt32(bytes, 56),
                Availability = (BridgeAvailability)availability, Flags = (ControlFlags)GetUInt32(bytes, 64), SupportedOperations = GetUInt32(bytes, 68),
                PositionX = GetSingle(bytes, 72), PositionY = GetSingle(bytes, 76), PositionZ = GetSingle(bytes, 80),
                Speed = GetSingle(bytes, 84), Brightness = GetSingle(bytes, 88), OwnedOperations = GetUInt32(bytes, 92) };
            snapshot = new ControlSnapshot { SessionId = GetGuid(bytes, 16), Observation = o, LastRequestId = GetUInt64(bytes, 96),
                LastRequestContextId = GetGuid(bytes, 128),
                LastStatus = (ControlStatus)status, LastOperation = (ControlOperation)GetUInt32(bytes, 108),
                RequestHighWatermark = GetUInt64(bytes, 112), PendingRequestId = GetUInt64(bytes, 120),
                LastMessage = GetUtf8(bytes, StateMessageOffset, StateMessageCapacity), Sequence = GetUInt32(bytes, CommitOffset) };
            o.Message = snapshot.LastMessage; return true;
        }

        public static uint ReadSequence(byte[] bytes) { return bytes != null && bytes.Length >= 16 ? GetUInt32(bytes, CommitOffset) : 0; }
        public static uint NextSequence(uint previous) { uint next = unchecked((previous & ~1u) + 2u); return next == 0 ? 2u : next; }
        public static bool SameCommittedRecord(byte[] first, byte[] second)
        {
            if (first == null || second == null || first.Length != second.Length) return false;
            uint seq = ReadSequence(first); if (seq == 0 || (seq & 1) != 0 || seq != ReadSequence(second)) return false;
            for (int i = 0; i < first.Length; ++i) if (first[i] != second[i]) return false;
            return true;
        }
        public static void PutUInt32(byte[] bytes, int offset, uint value) { for (int i = 0; i < 4; ++i) bytes[offset + i] = (byte)(value >> (8 * i)); }
        public static uint GetUInt32(byte[] bytes, int offset) { return (uint)(bytes[offset] | bytes[offset + 1] << 8 | bytes[offset + 2] << 16 | bytes[offset + 3] << 24); }
        private static void PutUInt64(byte[] bytes, int offset, ulong value) { for (int i = 0; i < 8; ++i) bytes[offset + i] = (byte)(value >> (8 * i)); }
        private static ulong GetUInt64(byte[] bytes, int offset) { return GetUInt32(bytes, offset) | ((ulong)GetUInt32(bytes, offset + 4) << 32); }
        private static void PutInt32(byte[] b, int o, int v) { PutUInt32(b, o, unchecked((uint)v)); }
        private static int GetInt32(byte[] b, int o) { return unchecked((int)GetUInt32(b, o)); }
        private static void PutInt64(byte[] b, int o, long v) { PutUInt64(b, o, unchecked((ulong)v)); }
        private static long GetInt64(byte[] b, int o) { return unchecked((long)GetUInt64(b, o)); }
        private static void PutSingle(byte[] b, int o, float v) { var a = BitConverter.GetBytes(v); if (!BitConverter.IsLittleEndian) Array.Reverse(a); Buffer.BlockCopy(a, 0, b, o, 4); }
        private static float GetSingle(byte[] b, int o) { if (BitConverter.IsLittleEndian) return BitConverter.ToSingle(b, o); var a = new byte[4]; Buffer.BlockCopy(b, o, a, 0, 4); Array.Reverse(a); return BitConverter.ToSingle(a, 0); }
        private static void PutGuid(byte[] b, int o, Guid v) { Buffer.BlockCopy(v.ToByteArray(), 0, b, o, 16); }
        private static Guid GetGuid(byte[] b, int o) { var a = new byte[16]; Buffer.BlockCopy(b, o, a, 0, 16); return new Guid(a); }
        private static void PutUtf8(byte[] b, int o, int capacity, string text)
        {
            string value = text ?? ""; if (value.Length > 1024) value = value.Substring(0, 1024);
            var encoder = Encoding.UTF8.GetEncoder();
            int charsUsed, bytesUsed; bool completed; var chars = value.ToCharArray();
            encoder.Convert(chars, 0, chars.Length, b, o + 4, capacity - 4, true, out charsUsed, out bytesUsed, out completed);
            PutUInt32(b, o, (uint)bytesUsed);
        }
        private static string GetUtf8(byte[] b, int o, int capacity)
        {
            uint count = GetUInt32(b, o); return count <= capacity - 4 ? Encoding.UTF8.GetString(b, o + 4, (int)count) : "INVALID_MESSAGE_LENGTH";
        }
        private static byte[] Header(uint magic, int size, uint sequence)
        {
            var b = new byte[size]; PutUInt32(b, 0, magic); PutUInt32(b, 4, Version); PutUInt32(b, 8, (uint)size); PutUInt32(b, CommitOffset, sequence); return b;
        }
        private static void ValidateSequence(uint sequence) { if (sequence == 0 || (sequence & 1) != 0) throw new ArgumentOutOfRangeException(nameof(sequence)); }
        private static void Seal(byte[] bytes) { PutUInt32(bytes, bytes.Length - 4, ComputeCrc32(bytes, bytes.Length - 4)); }
        private static bool ValidateRecord(byte[] b, uint magic, int size, out string error)
        {
            error = "";
            if (b == null || b.Length != size) { error = "INVALID_LENGTH"; return false; }
            uint sequence = ReadSequence(b);
            if (sequence == 0 || (sequence & 1) != 0) { error = "UNCOMMITTED"; return false; }
            if (GetUInt32(b, 0) != magic) { error = "INVALID_MAGIC"; return false; }
            if (GetUInt32(b, 4) != Version) { error = "INCOMPATIBLE_PROTOCOL"; return false; }
            if (GetUInt32(b, 8) != size) { error = "INVALID_LENGTH"; return false; }
            if (GetUInt32(b, size - 4) != ComputeCrc32(b, size - 4)) { error = "CRC_MISMATCH"; return false; }
            return true;
        }
        public static uint ComputeCrc32(byte[] bytes, int length)
        {
            if (bytes == null || length < 0 || length > bytes.Length) throw new ArgumentOutOfRangeException(nameof(length));
            uint crc = 0xFFFFFFFF;
            for (int i = 0; i < length; ++i) { crc ^= bytes[i]; for (int j = 0; j < 8; ++j) crc = (crc >> 1) ^ ((crc & 1) != 0 ? 0xEDB88320u : 0u); }
            return ~crc;
        }
    }
}
