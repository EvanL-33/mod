using System;
using System.Diagnostics;
using SevenDaysEsp;

namespace SevenDaysLoader.Services;

// Runs on the capture thread only, after publication of the current capture.
// No command is retried here, including a native failure or uncertain readback.
internal static class CreativeMenuExecutor
{
    internal static CreativeMenuResult Execute(CreativeMenuRequest request,
        uint processId, LiveEntitySnapshot snapshot, double captureAgeMs,
        string gameVersion, Func<bool> validateProcess,
        Func<CreativeMenuAccessResult> apply)
    {
        var result = new CreativeMenuResult
        {
            Sequence = request.Sequence,
            RequestId = request.RequestId,
            ProcessId = request.ExpectedProcessId,
            PlayerContextId = request.ExpectedPlayerContextId,
            DesiredEnabled = request.DesiredEnabled,
            Toggle = request.Toggle
        };
        CreativeMenuResult Reject(string code, string message)
        {
            result.Code = code;
            result.Message = SafeMessage(message);
            return result;
        }

        if (CreativeMenuProtocol.IsExpired(request, Stopwatch.GetTimestamp()))
            return Reject("EXPIRE", "La demande a expiré avant son traitement. Aucune écriture effectuée.");
        if (processId == 0 || processId != request.ExpectedProcessId)
            return Reject("CONTEXTE_CHANGE", "Le processus de la demande ne correspond plus à la session DMA.");
        if (!string.Equals(gameVersion, "V 3.4.0 (b10)", StringComparison.Ordinal))
            return Reject("VERSION_NON_SUPPORTEE", "La commande créative est prévue pour V 3.4.0 (b10).");
        if (!FeedSample.IsValid(snapshot) || !double.IsFinite(captureAgeMs) ||
            captureAgeMs < 0 || captureAgeMs >= FeedSample.LifetimeMs ||
            !string.Equals(snapshot.PlayerContextId, request.ExpectedPlayerContextId, StringComparison.Ordinal))
            return Reject("CONTEXTE_CHANGE", "Le monde et le joueur de cette demande ne sont plus confirmés par une capture récente.");

        try
        {
            if (!validateProcess())
                return Reject("CONTEXTE_CHANGE", "Le jeu a quitté la vue DMA ou son processus a changé. Aucune écriture effectuée.");
        }
        catch (Exception ex)
        {
            return Reject("PROCESSUS_NON_CONFIRME", "Identification du processus impossible : " + ex.GetBaseException().Message);
        }
        if (CreativeMenuProtocol.IsExpired(request, Stopwatch.GetTimestamp()))
            return Reject("EXPIRE", "La demande a expiré pendant la vérification du processus. Aucune écriture effectuée.");

        // The core performs a fresh validation of roots, metadata, value types
        // and source references. Its result distinguishes a refusal before the
        // write from an unknown outcome after a native write was attempted.
        CreativeMenuAccessResult outcome = apply();
        result.Code = outcome.Code;
        result.Message = SafeMessage(outcome.Message);
        result.ObservedEnabled = outcome.Success ? outcome.ObservedEnabled : null;
        result.WriteAttempted = outcome.WriteAttempted;
        return result;
    }

    private static string SafeMessage(string? message)
    {
        string value = (message ?? "Résultat non renseigné.").Replace('\0', ' ');
        return value.Length <= CreativeMenuProtocol.MaxMessageLength ? value : value[..CreativeMenuProtocol.MaxMessageLength];
    }
}
