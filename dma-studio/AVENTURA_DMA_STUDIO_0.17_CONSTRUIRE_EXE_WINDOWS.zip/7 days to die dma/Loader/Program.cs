using System;
using System.Globalization;
using System.Threading;
using System.Windows;
using SevenDaysLoader.Services;
using SevenDaysLoader.UI;

namespace SevenDaysLoader;

public static class Program
{
    [STAThread]
    public static int Main(string[] args)
    {
        if (!OperatingSystem.IsWindows() || !Environment.Is64BitProcess) return 2;
        if (args.Length == 2 && args[0] == "--worker")
            return DmaWorker.RunAsync(args[1]).GetAwaiter().GetResult();
        if (args.Length == 1 && args[0] == "--install-module")
        {
            CultureInfo.DefaultThreadCurrentUICulture = CultureInfo.GetCultureInfo("fr-FR");
            var installer = new Application { ShutdownMode = ShutdownMode.OnMainWindowClose };
            return installer.Run(new ModuleInstallerWindow());
        }
        if (args.Length != 0 && !(args.Length == 1 && args[0] == "--display"))
        {
            MessageBox.Show("Démarre le lanceur sans argument, avec --display pour l’affichage distant, ou --install-module pour installer le module du jeu.", "7DTD Loader", MessageBoxButton.OK, MessageBoxImage.Information);
            return 2;
        }
        using var singleInstance = new Mutex(true, @"Local\SevenDaysDmaLoader-Desktop", out bool owner);
        if (!owner)
        {
            MessageBox.Show("Le lanceur est déjà ouvert dans cette session Windows. Retrouve-le dans la barre des tâches.", "7DTD Loader", MessageBoxButton.OK, MessageBoxImage.Information);
            return 0;
        }
        CultureInfo.DefaultThreadCurrentUICulture = CultureInfo.GetCultureInfo("fr-FR");
        var controller = new AppController();
        // Double-click always means the direct DMA reader, even when the old
        // configuration was last used as a remote display.
        controller.Settings.Mode = args.Length == 1 ? "display" : "reader";
        controller.SaveSettings();
        try
        {
            var app = new Application { ShutdownMode = ShutdownMode.OnMainWindowClose };
            app.DispatcherUnhandledException += (_, eventArgs) =>
            {
                controller.Log("Erreur d'interface : " + eventArgs.Exception.GetBaseException().Message);
                MessageBox.Show(eventArgs.Exception.GetBaseException().Message, "7DTD Loader — erreur", MessageBoxButton.OK, MessageBoxImage.Error);
                eventArgs.Handled = true;
            };
            return app.Run(new MainWindow(controller));
        }
        catch (Exception ex)
        {
            controller.Log("Erreur de démarrage : " + ex.GetBaseException().Message);
            MessageBox.Show(ex.GetBaseException().Message, "7DTD Loader", MessageBoxButton.OK, MessageBoxImage.Error);
            return 6;
        }
        finally
        {
            controller.DisposeAsync().AsTask().GetAwaiter().GetResult();
            singleInstance.ReleaseMutex();
        }
    }
}
