using System;
using System.Threading.Tasks;
using SevenDaysLoader.UI;

internal static class MenuStatusPresenterTests
{
    public static Task AlternatingCapturesKeepReadableSummary()
    {
        var state = new MenuStatusPresenter();
        Check(state.Update("acquiring", "Acquisition en cours.", "Premier diagnostic.", 0), "Initial summary was not published.");
        for (int i = 1; i <= 20; i++)
        {
            bool cameraReceived = (i & 1) == 1;
            string detail = "Diagnostic instantané " + i;
            Check(!state.Update(cameraReceived ? "received" : "acquiring",
                cameraReceived ? "Captures reçues récemment." : "Acquisition en cours.", detail, i * 100),
                "Alternating 100 ms results rewrote the readable summary.");
            Check(state.Summary == "Acquisition en cours." && state.Detail == detail,
                "Summary oscillated or the current diagnostic was hidden.");
        }
        return Task.CompletedTask;
    }

    public static Task SustainedStateUpdatesAfterSettling()
    {
        var state = new MenuStatusPresenter();
        state.Update("acquiring", "Acquisition en cours.", "Initial", 0);
        Check(!state.Update("received", "Captures reçues récemment.", "Fresh 1", 100), "A single capture changed the summary.");
        Check(!state.Update("received", "Captures reçues récemment.", "Fresh 2", 699), "Summary changed before its settling interval.");
        Check(state.Update("received", "Captures reçues récemment.", "Fresh 3", 700), "A sustained state never reached the summary.");
        Check(!state.Update("received", "Captures reçues récemment.", "Fresh 4", 800), "Same state requested unnecessary text replacement.");
        Check(!state.Update("acquiring", "Acquisition en cours.", "Camera currently unavailable", 900), "Transient loss caused summary flicker.");
        Check(state.Detail == "Camera currently unavailable", "Failure detail was delayed with the summary.");
        Check(state.Update("acquiring", "Acquisition en cours.", "Still unavailable", 1500), "Persistent loss was hidden.");
        return Task.CompletedTask;
    }

    public static Task ConfigurationChangesAppearImmediately()
    {
        var state = new MenuStatusPresenter();
        state.Update("acquiring", "Acquisition en cours.", "Reader waiting", 0);
        state.Update("received", "Captures reçues récemment.", "One valid capture", 100);
        Check(state.Update("esp-off", "ESP désactivé.", "User disabled ESP", 101, immediate: true), "Disable waited for the camera debounce.");
        Check(state.Summary == "ESP désactivé.", "Pending success overwrote a user setting.");
        Check(state.Update("acquiring", "Acquisition en cours.", "User enabled ESP", 102, immediate: true), "Re-enable retained the disabled summary.");
        Check(state.Update("resolution", "Résolutions différentes.", "Source 1920 × 1080, output 2560 × 1440", 103, immediate: true),
            "Output mismatch was hidden behind a transient camera summary.");
        Check(!state.Update("resolution", "Résolutions différentes.", "The same mismatch", 104, immediate: true),
            "Unchanged configuration rewrote the text.");
        return Task.CompletedTask;
    }

    public static Task FullCurrentDiagnosticIsPreserved()
    {
        var state = new MenuStatusPresenter();
        state.Update("received", "Captures reçues récemment.", "Previous success", 0);
        string detail = "CAMERA_CAPTURE_INSTABLE\nLa caméra a changé pendant la capture.\n" +
            "Image source : 1920 × 1080 px.\nViewport caméra : 1599 × 899 px à (0, 181).\n" + new string('x', 4096);
        state.Update("acquiring", "Acquisition en cours.", detail, 100);
        Check(state.Detail == detail, "Diagnostic was truncated, replaced by a summary or delayed.");
        Check(state.Summary == "Captures reçues récemment.", "The summary claims current ESP readiness instead of the last observation.");
        return Task.CompletedTask;
    }

    public static Task ClockRollbackRestartsPendingObservation()
    {
        var state = new MenuStatusPresenter();
        state.Update("acquiring", "Waiting", "First", 1000);
        state.Update("received", "Recently received", "Pending", 1050);
        Check(!state.Update("received", "Recently received", "After clock reset", 200), "Clock rollback committed an old pending state.");
        Check(!state.Update("received", "Recently received", "Not settled", 799), "Rollback discarded the required interval.");
        Check(state.Update("received", "Recently received", "Settled", 800), "A new stable interval did not recover after rollback.");
        return Task.CompletedTask;
    }

    private static void Check(bool value, string message)
    {
        if (!value) throw new InvalidOperationException(message);
    }
}
