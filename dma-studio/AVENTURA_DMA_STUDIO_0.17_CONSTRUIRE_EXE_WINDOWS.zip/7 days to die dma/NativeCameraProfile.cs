#nullable enable
// Generated from Loader/NativeProfileEvidence.json: exact user-supplied UnityPlayer.dll.
// Offsets require the PE identity and all core signatures. XR object offsets
// additionally require the exact conditional XR getter before their first use.
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace SevenDaysEsp
{
    public sealed class NativeCameraSignature
    {
        public string Name { get; }
        public uint Rva { get; }
        public string BytesHex { get; }
        public string Sha256 { get; }
        public bool RequiresXrManager { get; }
        internal NativeCameraSignature(string name, uint rva, string bytesHex, string sha256, bool requiresXrManager = false)
        { Name = name; Rva = rva; BytesHex = bytesHex; Sha256 = sha256; RequiresXrManager = requiresXrManager; }
    }

    public static class NativeCameraProfile
    {
        public const string ProfileId = "unity-2022.3.62f2-7670c08855a9-native-v1";
        public const string ModuleName = "UnityPlayer.dll";
        public const string FileSha256 = "a8dcc8f6f4cbee3da56552a4adbe56724228a0efcc2fcd737b516933f0418081";
        public const uint PeTimestamp = 0x68D67E4DU;
        public const uint ImageSize = 0x1E7C000U;
        public const ushort Machine = 0x8664;
        public const ushort OptionalHeaderMagic = 0x20B;
        public const uint TextRva = 0x1000U;
        public const uint TextSize = 0x187A793U;
        public const uint ReadOnlyDataRva = 0x187C000U;
        public const uint ReadOnlyDataSize = 0x39E2AEU;
        public const int ManagedNativePointerOffset = 0x10;
        public const int ActiveOffset = 0x39;
        public const int ViewOffset = 0x80;
        public const int ProjectionOffset = 0xC0;
        public const int NonJitteredExplicitOffset = 0x554;
        public const int NonJitteredProjectionOffset = 0x758;
        public const int TargetTextureIdOffset = 0x34C;
        public const int CustomBufferOffset = 0x350;
        public const int TargetDisplayOffset = 0x3E0;
        public const int RectOffset = 0x42C;
        public const int NearClipOffset = 0x464;
        public const int FarClipOffset = 0x468;
        public const int ProjectionDirtyOffset = 0x510;
        public const int ImplicitViewOffset = 0x512;
        public const int ProjectionModeOffset = 0x514;
        public const int OrthographicOffset = 0x523;
        public const int DynamicResolutionRequestOffset = 0x529;
        public const uint ScreenGlobalRva = 0x1D33BD0U;
        public const int ScreenWidthOffset = 0xFC;
        public const int ScreenHeightOffset = 0x108;
        public const int ScreenStereoOffset = 0x118;
        public const int ScreenWidthVirtualSlot = 0xB0;
        public const int ScreenHeightVirtualSlot = 0xB8;
        public const uint ScreenWidthMethodRva = 0x48D20U;
        public const uint ScreenHeightMethodRva = 0x48D30U;
        public const uint TimeGlobalRva = 0x1CCBA38U;
        public const int RenderedFrameCountOffset = 0xD0;
        public const uint XrGlobalRva = 0x1D33D20U;
        public const int XrEnabledVirtualSlot = 0x8;
        public const uint XrEnabledMethodRva = 0xF7FE30U;
        public const int XrEnabledOffset = 0x2A5;
        public const uint GraphicsGlobalRva = 0x1C43080U;
        public const int GraphicsDynamicResolutionOffset = 0x49B;

        private static readonly ReadOnlyCollection<NativeCameraSignature> signatures =
            Array.AsReadOnly(new NativeCameraSignature[]
            {
                new NativeCameraSignature("BindingRegistration", 0xFEFB50U, "48895c240848896c2410488974241848897c24204154415641574883ec204533ff4c8d25880401ff4533f60f1f4400004b8bb426e0ca8e0133ff48393d27d2c5004b8bac26a0378f01762733db0f1f00488b0501d2c500488bd6488bcdff1403ffc7488d5b084863c7483b05f8d1c50072de488bd6488bcdff150253d40041ffc74983c6084181ff970d000072a2", "656cba169cad8f94ea74b9ee6cd8fc51d1d90978b61849f5add7fec368645182"),
                new NativeCameraSignature("WorldToCameraReadAndRecompute", 0x6F3ACU, "80bb1205000000740f488d9380000000488bcbe82cc836000f1083800000000f11070f108b900000000f114f100f1083a00000000f1147200f108bb0000000488b9c24880000000f114f304883c4605f5e5dc3488bd6488d4d", "e759b1d04d82e345be3b52820fb6aea5bae41b6f80139ee560fb43aaaed9813b"),
                new NativeCameraSignature("WorldToCameraSetterImplicitFlag", 0x6F517U, "0f1003488bbc24880000000f1180800000000f104b100f1188900000000f1043200f1180a00000000f104b30488b5c2478c68012050000000f", "a9342f1df3e50ed293a5e082a7000662a132612b67474290c904c2a3834cbba5"),
                new NativeCameraSignature("WorldToCameraResetImplicitFlag", 0x6FFC2U, "488b9c2480000000c68012050000014883c4605dc3", "e9f84c7ee67b571732605a51a0c384cc8e6777ae2feef6d8f96bf0d69f3ed275"),
                new NativeCameraSignature("ProjectionGetterCallsCache", 0x6F675U, "481048894de8c645f001e88cc93600488bbc24880000000f10000f11030f1048100f114b100f1040200f1143200f1048300f114b30488b5c24784883c4605dc3488bd7488d", "3e9ad6bf27edb27738cd5dc9aaacc18534f586dd943cbc2742bb4b50d9b2b8ae"),
                new NativeCameraSignature("ProjectionCacheDirtyGate", 0x3DC010U, "488bc4534883ec7080b91005000000488bd90f8444010000", "69736020b313d4bf0311d359d9b5fa8d4bb91955e5cbe86d8f68b8eed6ab8e71"),
                new NativeCameraSignature("ProjectionCacheClearAndReturn", 0x3DC140U, "440f28442440488d83c00000000f287c24500f28742460488bbc2488000000c68310050000004883c4705bc3488d81c00000004883c4705bc3", "398a7977ad44ba1ec8ef8cf1fc176f6e789930968c8a9b2657564767a637ebb8"),
                new NativeCameraSignature("NormalizedRectGetter", 0x6D62FU, "0f10802c040000488b5c24780f1107488bbc24880000004883c4605dc3488bd3", "ba5d72abde75df928d46c665378c548e2599a570f109c322d1015b9b4908d35f"),
                new NativeCameraSignature("TargetTexturePPtrGetter", 0x6E364U, "4881c14c030000e8705a0e004885c07421", "40a21c39bafe76a4fffa1939d8170b0290e24a331f82f1ad2c4aae2b277ab24b"),
                new NativeCameraSignature("TargetTextureZeroResolver", 0x153DE0U, "40564883ec208b3185f6750833c04883c4205ec3", "4a5fe417a432279ba090e779a3bdc2379cbf607a5d0426a5766effdf11217064"),
                new NativeCameraSignature("TargetDisplayGetter", 0x6E821U, "8b80e0030000488b9c24800000004883c4605dc3", "c0eb61e0bfec54e276067d429ea59bd6adf53f18ae7a68d4f968852beeb18335"),
                new NativeCameraSignature("BehaviourActiveGetter", 0xF8B91U, "80783900488b9c24800000000f95c04883c4605dc3", "8f6a1e932f6ced1f1706038c343d901110a3c29f8f68f624360ecf0ffee9aff2"),
                new NativeCameraSignature("ScreenDimensionsGetters", 0x82230U, "488b059919cb018b80fc000000c3cccc488b058919cb018b8008010000c3", "57cf049a3a24d05f7010984fa4d0bdcc1145a9e99c3fbb55a43e0d4b775f5485"),
                new NativeCameraSignature("ScreenVirtualDimensions", 0x48D20U, "8b81fc000000c3cccccccccccccccccc8b8108010000c3", "3d842d8b668222b4a2e1c90d538a28bca0fc928aba47402baba140e6ca36774c"),
                new NativeCameraSignature("TimeFrameCountGetters", 0x1118F0U, "488b0541a1bb018b80c8000000c3cccc488b0531a1bb018b80d0000000c3", "16fd9026d772ff273f5cad35e3c0a53200f22e3ce3fb5e8567ff17e8cc151715"),
                new NativeCameraSignature("PixelRectCustomBufferBranch", 0x3D04CDU, "488b85500300004885c00f848e000000807833000f8584000000", "f21d8270a0563b333a8584ee5d2b3c7b5c6e483cbbe9a99c89f425daf2bb1e04"),
                new NativeCameraSignature("PixelRectDisplayAndScreenPath", 0x3D05BFU, "4c6385e003000033c9443b059d4996017d144b8d144048c1e205488d05904996014803d0eb03488bd14585c074244885d2741f660f6e4218660f6e4a1c0f5bc048890f0f5bc9f30f114708f30f114f0ceb52488b1db8359601488bcb488b03ff90b8000000488bcb48c744242000000000660f6ef0488b030f5bf6ff90b00000000f104c24200fc6c9d2660f6ec00f5bc0f30f10c80fc6c927f30f10ce0fc6c9390f110f", "6faa541dbed6f2111da554e0210a6d3d916015230067e4552f3ebe4fb8bbb96c"),
                new NativeCameraSignature("StereoXrNullGate", 0x3D38C5U, "488b0d540496014885c9742c488b01ff500884c0742283bbe4030000007419488b0d35049601488b01ff90f003000084c0740540b701eb034032ff", "466d0d3a238557c27ee0414fc05d0c4a244249d91d3fa5b86d707e617fe5c9d9"),
                new NativeCameraSignature("StereoScreenAndXrGate", 0x3D3941U, "488b0588029601488b5c243080b81801000000750a4084ff75054084ed74094084f6751684c9751232c0488b742438488b6c24404883c4205fc3488b742438b001488b6c24404883c4205f", "1b15027b2f7d2fa83949b37c16e169d43f8d250bcc061a1c83a510c242d9ddc5"),
                new NativeCameraSignature("ProjectionViewMultiply", 0x3DC9A0U, "48895c2408574883ec7080b91205000000488bf90f297424600f297c2450440f29442440440f294c2430440f29542420740c488d9180000000e812f2ffff488bcfe82af6ffff0f18080f188f800000000f109f80000000488b9c24800000000f10a7900000000f10", "556c8b6e0029e3afaa6a8cd9cf9aee5f06fd4685fc18c8fae922cfaf9c7386c7"),
                new NativeCameraSignature("XrEnabledGetter", 0xF7FE30U, "0fb681a5020000c3", "fa22bb7e6727c5b8bc6e011bd5665b8edc8e6902f447a193a976c52f4f36a035", true),
                new NativeCameraSignature("CameraRenderRefreshesView", 0x542540U, "80bf1205000000740f488d9780000000488bcfe89896e9ff488d9f80000000", "449fc1ec68bb98334b9c76ff9040466a9bfef5f0d0ef75ad44fb51ab9d6c4c73"),
                new NativeCameraSignature("EffectiveAllowDynamicResolutionGetter", 0x66537U, "80b829050000007420488b0539cbbd0180b89b040000007410b001488b9c24800000004883c4605dc3", "135976f18534f18012b741a638bddeeef51b9c1b097b32f6747a4801a0421126"),
                new NativeCameraSignature("NonJitteredProjectionGetter", 0x6F90FU, "80b954050000007409488d8158070000eb05e8eac636000f1000488bbc24880000000f11030f1048100f114b100f1040200f1143200f1048300f114b30", "0d9358f0e9a1fe771fe6a7367ce2ef72b6aa518bd9038e66a50c8aed72577510"),
                new NativeCameraSignature("NonJitteredProjectionSetter", 0x6FA6FU, "c68054050000010f10030f1180580700000f104b100f1188680700000f1043200f1180780700000f104b30488b5c24780f118888070000", "3fc97242ba4d862ea77180841e61ba247046b32bff3012c60559bb48769ecc49"),
            });
        public static IReadOnlyList<NativeCameraSignature> Signatures { get { return signatures; } }
    }
}
