using System;
using System.IO;
using System.Threading.Tasks;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class CaptureCadenceTests
{
    public static Task RequestedPeriodDoesNotAddDelayAfterOverrun()
    {
        foreach (var item in new (int Interval, double Elapsed, int Expected)[]
        {
            (50, 0, 50), (50, 20, 30), (150, 99, 51), (100, 99, 1),
            (50, 99, 0), (75, 99, 0), (100, 100, 0), (50, 10000, 0),
            (50, 49.1, 1), (150, 149.01, 1), (50, 0.1, 50),
            (-1, 0, 50), (5000, 0, 2000), (2000, 3000, 0),
            (50, -1, 50), (75, double.NaN, 75),
            (100, double.PositiveInfinity, 100), (150, double.NegativeInfinity, 150)
        })
        {
            int actual = CaptureCadence.RemainingDelayMs(item.Interval, item.Elapsed);
            Check(actual == item.Expected,
                $"Unexpected wait for interval {item.Interval}, elapsed {item.Elapsed}: {actual} instead of {item.Expected}.");
        }
        return Task.CompletedTask;
    }

    public static Task CadenceMigrationIsOneTimeAndPreservesOtherChoices()
    {
        Check(CaptureCadence.DefaultIntervalMs == 50 && new LoaderSettings().IntervalMs == 50 && new WorkerStart().IntervalMs == 50,
            "A fresh loader or worker still requests the former 150 ms default.");
        string directory = Path.Combine(Path.GetTempPath(), "7dtd-cadence-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(directory);
        try
        {
            var store = new SettingsStore(directory);
            var fresh = store.Load();
            Check(fresh.IntervalMs == 50 && fresh.ReadCadenceVersion == 1,
                "A new installation did not receive the current cadence policy.");
            File.WriteAllText(store.FilePath, "{\"IntervalMs\":150,\"EspEnabled\":false,\"AutoConnectDma\":false,\"SdkDirectory\":\"retained-sdk\"}");
            var migrated = new SettingsStore(directory).Load();
            Check(migrated.IntervalMs == 50 && migrated.ReadCadenceVersion == 1 &&
                !migrated.EspEnabled && !migrated.AutoConnectDma && migrated.SdkDirectory == "retained-sdk",
                "The old 150 ms policy was not migrated or unrelated choices changed.");
            store.Save(migrated);
            var saved = new SettingsStore(directory).Load();
            Check(saved.IntervalMs == 50 && saved.ReadCadenceVersion == 1,
                "The cadence migration marker did not survive saving and reloading.");
            saved.IntervalMs = 150;
            store.Save(saved);
            var explicitChoice = new SettingsStore(directory).Load();
            Check(explicitChoice.IntervalMs == 150 && explicitChoice.ReadCadenceVersion == 1,
                "Choosing 150 ms after migration was overwritten by a second migration.");
            store.Save(explicitChoice);
            Check(new SettingsStore(directory).Load().IntervalMs == 150,
                "Repeated persistence reset the user's current 150 ms choice.");
            foreach (int interval in new[] { 50, 75, 100, 250, 500, 1000, 2000 })
            {
                File.WriteAllText(store.FilePath, "{\"IntervalMs\":" + interval + ",\"ReadCadenceVersion\":0,\"ShowZombies\":false}");
                var preserved = new SettingsStore(directory).Load();
                Check(preserved.IntervalMs == interval && preserved.ReadCadenceVersion == 1 && !preserved.ShowZombies,
                    "A cadence other than the former default was changed during migration: " + interval);
                store.Save(preserved);
                Check(new SettingsStore(directory).Load().IntervalMs == interval,
                    "A preserved cadence changed on reload: " + interval);
            }
            File.WriteAllText(store.FilePath, "{\"ReadCadenceVersion\":1,\"IntervalMs\":150}");
            Check(new SettingsStore(directory).Load().IntervalMs == 150,
                "An already-migrated file was treated as a legacy cadence.");
        }
        finally { Directory.Delete(directory, true); }
        return Task.CompletedTask;
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
