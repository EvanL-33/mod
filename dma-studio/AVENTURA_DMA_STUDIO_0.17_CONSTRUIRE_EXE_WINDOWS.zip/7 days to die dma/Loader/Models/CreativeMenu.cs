using System;
using System.Diagnostics;
using System.IO;

namespace SevenDaysLoader;

// A one-shot intent. It is deliberately absent from LoaderSettings and from
// the remote display protocol; reconnecting must never replay a write.
public sealed class CreativeMenuRequest
{
    public long Sequence { get; set; }
    public string RequestId { get; set; } = "";
    public uint ExpectedProcessId { get; set; }
    public string ExpectedPlayerContextId { get; set; } = "";
    public bool? DesiredEnabled { get; set; }
    // Toggle is resolved from a fresh memory read by the core, never from the
    // last state displayed by the UI. It is mutually exclusive with a set.
    public bool Toggle { get; set; }
    public long RequestedTimestamp { get; set; }

    public CreativeMenuRequest Copy() => (CreativeMenuRequest)MemberwiseClone();
}

public sealed class CreativeMenuResult
{
    public long Sequence { get; set; }
    public string RequestId { get; set; } = "";
    public uint ProcessId { get; set; }
    public string PlayerContextId { get; set; } = "";
    public bool? DesiredEnabled { get; set; }
    public bool Toggle { get; set; }
    public bool? ObservedEnabled { get; set; }
    public bool WriteAttempted { get; set; }
    public string Code { get; set; } = "";
    public string Message { get; set; } = "";
}

public sealed record CreativeMenuState
{
    public bool Available { get; init; }
    public bool IsBusy { get; init; }
    public bool? ObservedEnabled { get; init; }
    public string Code { get; init; } = "INDISPONIBLE";
    public string Message { get; init; } = "En attente d’une partie lue par la DMA locale.";
    public DateTime? ConfirmedUtc { get; init; }
    public uint ProcessId { get; init; }
    public string PlayerContextId { get; init; } = "";
    public bool CanRequest => Available && !IsBusy;
}

public static class CreativeMenuProtocol
{
    public const int MaxRequestAgeMs = 10000;
    public const int MaxMessageLength = 1024;

    public static bool IsGuidN(string? value) => value != null && value.Length == 32 &&
        Guid.TryParseExact(value, "N", out Guid parsed) && parsed != Guid.Empty;

    public static void ValidateRequest(CreativeMenuRequest? request)
    {
        if (request == null || request.Sequence <= 0 || !IsGuidN(request.RequestId) ||
            request.ExpectedProcessId == 0 || !IsGuidN(request.ExpectedPlayerContextId) ||
            request.RequestedTimestamp <= 0 || (request.Toggle && request.DesiredEnabled.HasValue))
            throw new InvalidDataException("Demande de menu créatif incomplète ou invalide.");
    }

    // Both processes use the same Windows QueryPerformanceCounter. A future
    // timestamp is invalid too; wall-clock changes cannot extend an intent.
    public static bool IsExpired(CreativeMenuRequest request, long nowTimestamp)
    {
        if (request.RequestedTimestamp <= 0 || nowTimestamp < request.RequestedTimestamp) return true;
        return Stopwatch.GetElapsedTime(request.RequestedTimestamp, nowTimestamp).TotalMilliseconds >= MaxRequestAgeMs;
    }

    public static bool IsValidResult(CreativeMenuResult? result)
    {
        if (result == null || result.Sequence <= 0 || !IsGuidN(result.RequestId) ||
            result.ProcessId == 0 || !IsGuidN(result.PlayerContextId) ||
            string.IsNullOrWhiteSpace(result.Code) || result.Code.Length > 64 ||
            result.Message == null || result.Message.Length > MaxMessageLength ||
            result.Message.IndexOf('\0') >= 0 || (result.Toggle && result.DesiredEnabled.HasValue) ||
            (!result.Toggle && result.DesiredEnabled == null && result.WriteAttempted)) return false;
        foreach (char c in result.Code)
            if ((c < 'A' || c > 'Z') && (c < '0' || c > '9') && c != '_') return false;
        // A reported value is a confirmation, not a best-effort observation.
        // Failure paths must leave it unknown, including uncertain readback.
        return result.Code switch
        {
            "ETAT_LU" => !result.Toggle && result.DesiredEnabled == null && result.ObservedEnabled.HasValue && !result.WriteAttempted,
            "CONFIRME" => result.WriteAttempted && result.ObservedEnabled.HasValue &&
                (result.Toggle || (result.DesiredEnabled.HasValue && result.ObservedEnabled == result.DesiredEnabled)),
            "DEJA_APPLIQUE" => !result.Toggle && result.DesiredEnabled.HasValue &&
                result.ObservedEnabled == result.DesiredEnabled && !result.WriteAttempted,
            _ => result.ObservedEnabled == null
        };
    }
}
