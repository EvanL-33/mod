using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using SevenDaysEsp;

namespace SevenDaysLoader.Services;

public sealed record RadarTarget(LiveEntity Entity, double X, double Z, double DistanceMeters,
    double HeightMeters, EntityEspSettings Profile, PlayerVisualState Visual);

// The first band includes zero; later bands exclude their lower endpoint.
// A point exactly at 25/50/100 m belongs to one band, never two.
public sealed record RadarBand(int FromMeters, int ToMeters, int Players, int Zombies)
{
    public bool IsAvailable => ToMeters > FromMeters;
}

public sealed class RadarSummary
{
    public int RangeMeters { get; }
    public bool HasCurrentData { get; }
    public IReadOnlyList<RadarTarget> Targets { get; }
    public IReadOnlyList<RadarBand> Bands { get; }

    private RadarSummary(int range, bool hasCurrentData, List<RadarTarget> targets)
    {
        RangeMeters = range;
        HasCurrentData = hasCurrentData;
        Targets = new ReadOnlyCollection<RadarTarget>(targets);
        int[] edges = { 0, 25, 50, 100 };
        var bands = new List<RadarBand>(3);
        for (int i = 0; i < 3; i++)
        {
            int lower = edges[i], upper = Math.Min(range, edges[i + 1]);
            var inBand = targets.Where(t => t.DistanceMeters <= upper &&
                (i == 0 ? t.DistanceMeters >= 0 : t.DistanceMeters > lower)).ToArray();
            bands.Add(new(lower, upper, inBand.Count(t => t.Entity.Kind == "player"),
                inBand.Count(t => t.Entity.Kind == "zombie")));
        }
        Bands = new ReadOnlyCollection<RadarBand>(bands);
    }

    public static RadarSummary Create(LoaderSettings settings, FeedSample? sample, PlayerVisualLookup visuals)
    {
        ArgumentNullException.ThrowIfNull(settings);
        ArgumentNullException.ThrowIfNull(visuals);
        int range = EspDisplayPolicy.RadarRange(settings);
        var targets = new List<RadarTarget>();
        if (!settings.EspEnabled || !settings.ShowRadar || sample == null || !sample.IsFresh)
            return new(range, false, targets);
        var snapshot = sample.Snapshot;
        var local = snapshot.LocalPosition;
        var neutral = new PlayerVisualState();
        var ids = new HashSet<int>();
        foreach (var entity in snapshot.Entities)
        {
            if (!ids.Add(entity.EntityId)) continue;
            var visual = neutral;
            if (entity.Kind == "player" && !visuals.TryResolve(snapshot.PlayerContextId,
                entity.IdentityToken, entity.EntityId, out visual)) continue;
            double x = (double)entity.Position.X - local.X;
            double height = (double)entity.Position.Y - local.Y;
            double z = (double)entity.Position.Z - local.Z;
            double distance = Math.Sqrt(x * x + z * z);
            if (!EspDisplayPolicy.TryGetRadarProfile(settings, entity.Kind, distance, height, visual, out var profile)) continue;
            targets.Add(new(entity, x, z, distance, height, profile!, visual));
        }
        // Building a view must not revive a sample that expired during the work.
        if (!sample.IsFresh) return new(range, false, new());
        return new(range, true, targets);
    }
}
