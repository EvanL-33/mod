@echo off
setlocal
if not exist "%~dp07DTD-Loader.exe" (
  echo 7DTD-Loader.exe absent. Extrais le ZIP complet dans ce dossier.
  pause
  exit /b 1
)
start "" "%~dp07DTD-Loader.exe"
