using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace SevenDaysLoader.Services;

internal enum PlayerListSort { Distance, Name, Health }

// The order is a presentation choice only. It never grants an identity to an
// old packet, changes a session annotation, or retains an absent player.
internal static class PlayerListPolicy
{
    private static readonly CompareInfo French = CultureInfo.GetCultureInfo("fr-FR").CompareInfo;
    private const CompareOptions TextComparison = CompareOptions.IgnoreCase | CompareOptions.IgnoreNonSpace;

    internal static IReadOnlyList<PlayerRow> Arrange(IReadOnlyList<PlayerRow> source, string? search,
        PlayerListSort sort, IReadOnlyList<PlayerIdentity>? previousOrder = null, bool holdOrder = false)
    {
        string query = (search ?? string.Empty).Trim();
        if (query.Length > 128) query = query[..128];
        var rows = source.Take(4096).Select((row, index) => (Row: row, Index: index)).Where(item =>
            query.Length == 0 || French.IndexOf(item.Row.Name ?? string.Empty, query, TextComparison) >= 0 ||
            item.Row.Identity.EntityId.ToString(CultureInfo.InvariantCulture).Contains(query, StringComparison.OrdinalIgnoreCase)).ToList();
        var positions = new Dictionary<PlayerIdentity, int>();
        if (holdOrder && previousOrder != null)
            for (int i = 0; i < Math.Min(previousOrder.Count, 4096); i++) positions.TryAdd(previousOrder[i], i);
        rows.Sort((leftItem, rightItem) =>
        {
            var left = leftItem.Row;
            var right = rightItem.Row;
            if (holdOrder)
            {
                bool leftKnown = positions.TryGetValue(left.Identity, out int leftPosition);
                bool rightKnown = positions.TryGetValue(right.Identity, out int rightPosition);
                if (leftKnown != rightKnown) return leftKnown ? -1 : 1;
                if (leftKnown) return leftPosition != rightPosition ? leftPosition.CompareTo(rightPosition) : leftItem.Index.CompareTo(rightItem.Index);
            }
            int result = sort switch
            {
                PlayerListSort.Name => French.Compare(left.Name ?? string.Empty, right.Name ?? string.Empty, TextComparison),
                PlayerListSort.Health => CompareHealth(left.Health, right.Health),
                _ => FiniteDistance(left.DistanceMeters).CompareTo(FiniteDistance(right.DistanceMeters))
            };
            if (result != 0) return result;
            result = left.Identity.EntityId.CompareTo(right.Identity.EntityId);
            if (result != 0) return result;
            result = left.Identity.Token.CompareTo(right.Identity.Token);
            if (result != 0) return result;
            result = StringComparer.Ordinal.Compare(left.Identity.ContextId, right.Identity.ContextId);
            return result != 0 ? result : leftItem.Index.CompareTo(rightItem.Index);
        });
        return rows.Select(item => item.Row).ToArray();
    }

    private static int CompareHealth(int? left, int? right)
    {
        bool leftKnown = left is >= 0, rightKnown = right is >= 0;
        if (leftKnown != rightKnown) return leftKnown ? -1 : 1;
        return leftKnown ? left!.Value.CompareTo(right!.Value) : 0;
    }

    private static double FiniteDistance(double value) => double.IsFinite(value) && value >= 0 ? value : double.PositiveInfinity;
}
