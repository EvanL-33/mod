﻿// Read-only access to the game's declared version; no target code is invoked.
// Game API evidence (field identities, not fixed game offsets):
// https://github.com/IceCoffee1024/7DaysToDie-ServerKit/blob/ee4cd92564b337916e8088c165b3e559924042c1/src/SdtdServerKit/WebSockets/Telnet.cs
// https://github.com/closerex/Closer_ex-7D2D-mods/blob/be6199f7ba59404961fd6b0090dc7b7bc9aeb82f/0-KFCommonUtilityLib/Harmony/VersionPatcher/VersionPatchManager.cs
// Minor encoding can differ from display; do not infer a universal divisor:
// https://github.com/Kitsune-Den/KitsunePaintUnlocked/blob/main/tools/verify-game-version/watch-builds.ps1
// Candidate Windows x64 Unity Mono 2022 ABI:
// https://github.com/Unity-Technologies/mono/blob/unity-2022.3-mbe/mono/metadata/class-private-definition.h
// https://github.com/Unity-Technologies/mono/blob/unity-2022.3-mbe/mono/metadata/class-internals.h
// https://github.com/Unity-Technologies/mono/blob/unity-2022.3-mbe/mono/metadata/object-internals.h
// https://github.com/Unity-Technologies/mono/blob/unity-2022.3-mbe/mono/metadata/object.c
// mono_vtable_get_static_field_data returns vt->vtable[klass->vtable_size].
// All fields belonging to 7DTD are selected by observed metadata names/types.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace SevenDaysEsp
{
    public sealed class GameVersionReport
    {
        public string Status { get; set; }
        public bool VersionFound { get { return Status == "VERSION_JEU_LUE"; } }
        public string DisplayVersion { get; set; }
        public bool FormatRecognized { get; set; }
        public string Source { get; set; }
        public string Message { get; set; }
        public int CandidateCount { get; set; }
        public Dictionary<string, int> Components { get; set; }
        public List<string> Warnings { get; set; }

        public GameVersionReport()
        {
            Status = "VERSION_JEU_INDETERMINEE";
            Source = "Constants.cVersionInformation.LongString (memoire du jeu)";
            Components = new Dictionary<string, int>(StringComparer.Ordinal);
            Warnings = new List<string>();
        }
    }

    public sealed class MonoGameVersionReader
    {
        private sealed class Candidate
        {
            public string Text;
            public bool FormatRecognized;
            public ulong Domain;
            public Dictionary<string, int> Components = new Dictionary<string, int>(StringComparer.Ordinal);
            public List<string> Warnings = new List<string>();
        }

        private readonly IMemoryReader memory;
        private readonly UnicodeEncoding utf16 = new UnicodeEncoding(false, false, true);
        private readonly UTF8Encoding utf8 = new UTF8Encoding(false, true);
        private Stopwatch clock;
        private int readCalls;
        private int bytesRead;
        private const string SupportedLayout = "Unity Mono x64 2022 (candidate)";
        private const int MaximumDomains = 32;
        private const int MaximumStringChars = 128;
        private const int MaximumReadCalls = 1024;
        private const int MaximumReadBytes = 65536;
        private static readonly Regex VersionPattern = new Regex(@"\A(Alpha|V) ([0-9]{1,3})\.([0-9]{1,3}) \(b([0-9]{1,6})\)\z", RegexOptions.CultureInvariant);

        public MonoGameVersionReader(IMemoryReader reader)
        {
            if (reader == null) throw new ArgumentNullException("reader");
            memory = reader;
        }

        public GameVersionReport Inspect(MonoInspectionReport metadata)
        {
            GameVersionReport result = new GameVersionReport();
            clock = Stopwatch.StartNew();
            readCalls = 0;
            bytesRead = 0;
            try
            {
                if (metadata == null || metadata.SelectedLayout != SupportedLayout ||
                    (metadata.Status != "METADONNEES_COLLECTEES" && metadata.Status != "METADONNEES_PARTIELLES"))
                    throw new IOException("Le layout Mono 2022 n'a pas ete confirme par l'inspecteur de metadonnees.");

                MonoClassReport constants = FindClass(metadata, "Constants");
                MonoClassReport version = FindClass(metadata, "VersionInformation");
                ulong constantsClass = Address(constants.Address);
                ulong versionClass = Address(version.Address);
                ValidateClass(constantsClass, "Constants");
                ValidateClass(versionClass, "VersionInformation");
                ulong constantsImage = Pointer(constantsClass + 0x40);
                if (Pointer(versionClass + 0x40) != constantsImage)
                    throw new IOException("Les classes de version ne proviennent pas de la meme assembly.");

                MonoFieldReport versionReference = FindField(constants, "cVersionInformation", true);
                if (!versionReference.IsStatic || versionReference.IsLiteral || versionReference.TypeCode != "0x12" ||
                    versionReference.Type != "VersionInformation" || !String.IsNullOrEmpty(versionReference.Issue))
                    throw new IOException("cVersionInformation n'est pas une reference statique VersionInformation reconnue.");
                MonoFieldReport longString = FindField(version, "LongString", true);
                if (longString.IsStatic || longString.IsLiteral || longString.TypeCode != "0x0E" ||
                    longString.Type != "System.String" || !String.IsNullOrEmpty(longString.Issue))
                    throw new IOException("LongString n'est pas un champ d'instance System.String reconnu.");

                int instanceSize = I32(versionClass + 0x1C);
                if (instanceSize != version.InstanceSize || instanceSize < 24 || instanceSize > 1048576)
                    throw new IOException("La taille de l'objet VersionInformation est incoherente.");
                ValidateOffset(longString.Offset, instanceSize, 8, true);

                int vtableSlots = I32(constantsClass + 0x5C);
                int staticSize = I32(constantsClass + 0x90);
                if (vtableSlots < 0 || vtableSlots > 4096 || staticSize < 8 || staticSize > 1048576)
                    throw new IOException("Disposition du stockage statique Constants non reconnue.");
                ValidateOffset(versionReference.Offset, staticSize, 8, false);
                ulong runtime = Pointer(constantsClass + 0xD0);
                int maxDomain = U16(runtime);
                if (maxDomain >= MaximumDomains)
                    throw new IOException("Plus de 32 emplacements de domaines Mono ; lecture volontairement limitee.");

                List<Candidate> candidates = new List<Candidate>();
                HashSet<ulong> domains = new HashSet<ulong>();
                bool incompleteDomain = false;
                for (int index = 0; index <= maxDomain; index++)
                {
                    ulong vtable;
                    try { vtable = U64(runtime + 8UL + (ulong)index * 8UL); }
                    catch (IOException e) { result.Warnings.Add("Domaine " + index + " : " + e.Message); incompleteDomain = true; continue; }
                    if (vtable == 0) continue;
                    try
                    {
                        RequirePointer(vtable);
                        byte[] table = Read(vtable, 0x48);
                        if (BitConverter.ToUInt64(table, 0) != constantsClass)
                            throw new IOException("La vtable n'appartient pas a Constants.");
                        ulong domain = BitConverter.ToUInt64(table, 0x10);
                        RequirePointer(domain);
                        if (!domains.Add(domain)) throw new IOException("Domaine Mono duplique dans le stockage de classe.");
                        byte initialized = table[0x2D];
                        uint flags = BitConverter.ToUInt32(table, 0x30);
                        if (initialized == 0)
                        {
                            result.Warnings.Add("Domaine " + index + " : Constants n'est pas encore initialise ; aucune methode n'a ete appelee.");
                            continue;
                        }
                        if (initialized != 1 || (flags & 2U) != 0 || (flags & 4U) == 0)
                            throw new IOException("Initialisation ou indicateur de stockage statique incoherent.");
                        ulong staticPointerSlot = vtable + 0x48UL + (ulong)vtableSlots * 8UL;
                        ulong statics = Pointer(staticPointerSlot);
                        ulong fieldSlot = Add(statics, versionReference.Offset);
                        ulong versionObject = Pointer(fieldSlot);
                        Candidate candidate = ReadVersion(version, versionClass, instanceSize, longString,
                            versionObject, domain);
                        if (Pointer(fieldSlot) != versionObject || Pointer(staticPointerSlot) != statics ||
                            Pointer(constantsClass + 0xD0) != runtime || U64(runtime + 8UL + (ulong)index * 8UL) != vtable)
                            throw new IOException("La reference de version ou le domaine a change pendant la lecture.");
                        candidates.Add(candidate);
                    }
                    catch (IOException e)
                    {
                        result.Warnings.Add("Domaine " + index + " : " + e.Message);
                        incompleteDomain = true;
                    }
                }
                result.CandidateCount = candidates.Count;
                if (incompleteDomain)
                    throw new IOException("Un domaine initialise est illisible ou incoherent ; la version unique n'est pas confirmee.");
                if (candidates.Count == 0)
                    throw new IOException("Aucun objet de version initialise et lisible n'a ete trouve.");
                string display = candidates[0].Text;
                foreach (Candidate candidate in candidates)
                    if (!String.Equals(candidate.Text, display, StringComparison.Ordinal))
                        throw new IOException("Plusieurs domaines declarent des versions differentes ; resultat ambigu.");

                result.Status = "VERSION_JEU_LUE";
                result.DisplayVersion = display;
                result.FormatRecognized = candidates[0].FormatRecognized;
                result.Components = candidates[0].Components;
                foreach (Candidate candidate in candidates)
                    foreach (string warning in candidate.Warnings)
                        if (!result.Warnings.Contains(warning)) result.Warnings.Add(warning);
                result.Message = "Version declaree par le jeu lue dans l'objet VersionInformation. La compatibilite ESP reste a etablir.";
                if (!result.FormatRecognized)
                    result.Warnings.Add("Format d'affichage non interprete : LongString est conserve exactement apres verification de l'objet et de la stabilite de la lecture.");
                if (candidates.Count > 1)
                    result.Warnings.Add("La meme version a ete confirmee dans plusieurs domaines initialises.");
            }
            catch (Exception e)
            {
                result.Status = "VERSION_JEU_INDETERMINEE";
                result.DisplayVersion = null;
                result.FormatRecognized = false;
                result.Components.Clear();
                result.Message = e.Message;
            }
            return result;
        }

        private Candidate ReadVersion(MonoClassReport version, ulong versionClass, int instanceSize,
            MonoFieldReport longString, ulong instance, ulong domain)
        {
            ulong objectVtable = Pointer(instance);
            if (Pointer(objectVtable) != versionClass || Pointer(objectVtable + 0x10) != domain)
                throw new IOException("La reference statique ne designe pas une instance VersionInformation du meme domaine.");
            ulong stringSlot = Add(instance, longString.Offset);
            ulong textObject = Pointer(stringSlot);
            string text = ReadString(textObject);
            if (String.IsNullOrWhiteSpace(text)) throw new IOException("LongString est vide ou ne contient que des espaces.");
            // A known text format can enrich the report, but it must not gate a
            // validated read of the game's own LongString field. Preserve it verbatim.
            Match match = VersionPattern.Match(text);
            Candidate candidate = new Candidate { Text = text, Domain = domain, FormatRecognized = match.Success };
            if (match.Success)
            {
                int major = Int32.Parse(match.Groups[2].Value, CultureInfo.InvariantCulture);
                int minor = Int32.Parse(match.Groups[3].Value, CultureInfo.InvariantCulture);
                int build = Int32.Parse(match.Groups[4].Value, CultureInfo.InvariantCulture);
                if (major < 1) throw new IOException("Numero majeur invalide dans la version declaree.");
                candidate.Components.Add("Major", major);
                candidate.Components.Add("DisplayMinor", minor);
                candidate.Components.Add("Build", build);
                VerifyInteger(version, instance, instanceSize, "Major", major);
                VerifyInteger(version, instance, instanceSize, "Build", build);
            }
            // Some builds encode Minor differently from the formatted LongString.
            // Preserve the observed value without assuming a conversion rule.
            try
            {
                int? minorRaw = ReadOptionalInteger(version, instance, instanceSize, "Minor");
                if (minorRaw.HasValue)
                {
                    if (minorRaw.Value < 0 || minorRaw.Value > 999999)
                        throw new IOException("Composant Minor brut hors limites.");
                    candidate.Components.Add("MinorRaw", minorRaw.Value);
                }
            }
            catch (IOException ex) { candidate.Warnings.Add("Composant facultatif Minor non retenu : " + ex.Message); }
            MonoFieldReport valid = FindField(version, "IsValid", false);
            if (valid != null)
            {
                if (valid.IsStatic || valid.IsLiteral || valid.TypeCode != "0x02" || valid.Type != "System.Boolean" ||
                    !String.IsNullOrEmpty(valid.Issue)) throw new IOException("Champ IsValid non reconnu.");
                ValidateOffset(valid.Offset, instanceSize, 1, true);
                if (Read(Add(instance, valid.Offset), 1)[0] != 1) throw new IOException("L'objet de version n'est pas marque valide.");
            }
            // The selected object and immutable text must remain stable during the read.
            if (Pointer(instance) != objectVtable || Pointer(stringSlot) != textObject || ReadString(textObject) != text)
                throw new IOException("L'objet ou la chaine de version a change pendant la lecture.");
            return candidate;
        }

        private void VerifyInteger(MonoClassReport type, ulong instance, int size, string name, int expected)
        {
            int? value = ReadOptionalInteger(type, instance, size, name);
            if (value.HasValue && value.Value != expected)
                throw new IOException("La chaine de version contredit le champ " + name + ".");
        }

        private int? ReadOptionalInteger(MonoClassReport type, ulong instance, int size, string name)
        {
            MonoFieldReport field = FindField(type, name, false);
            if (field == null) return null;
            if (field.IsStatic || field.IsLiteral || field.TypeCode != "0x08" || field.Type != "System.Int32" ||
                !String.IsNullOrEmpty(field.Issue)) throw new IOException("Champ numerique " + name + " non reconnu.");
            ValidateOffset(field.Offset, size, 4, true);
            return I32(Add(instance, field.Offset));
        }

        private string ReadString(ulong instance)
        {
            ulong vtable = Pointer(instance);
            ulong klass = Pointer(vtable);
            ValidateClass(klass, "String", "System");
            int length = I32(instance + 0x10);
            if (length < 1 || length > MaximumStringChars) throw new IOException("Longueur de chaine de version hors limites.");
            byte[] bytes = Read(instance + 0x14, length * 2);
            string value;
            try { value = utf16.GetString(bytes); }
            catch (DecoderFallbackException) { throw new IOException("Chaine de version UTF-16 invalide."); }
            foreach (char c in value) if (Char.IsControl(c)) throw new IOException("Caractere de controle dans la chaine de version.");
            if (Pointer(instance) != vtable || I32(instance + 0x10) != length)
                throw new IOException("En-tete de chaine modifie pendant la lecture.");
            return value;
        }

        private void ValidateClass(ulong address, string name) { ValidateClass(address, name, String.Empty); }
        private void ValidateClass(ulong address, string name, string nameSpace)
        {
            byte[] header = Read(address, 0x60);
            if (header[0x1B] != 1 || CString(BitConverter.ToUInt64(header, 0x48)) != name ||
                CString(BitConverter.ToUInt64(header, 0x50)) != nameSpace)
                throw new IOException("Identite de classe Mono inattendue pour " + name + ".");
        }

        private static MonoClassReport FindClass(MonoInspectionReport report, string name)
        {
            MonoClassReport found = null;
            if (report.Classes != null)
                foreach (MonoClassReport item in report.Classes)
                    if (item != null && item.Name == name && String.IsNullOrEmpty(item.Namespace))
                    {
                        if (found != null) throw new IOException("Classe de version ambigue : " + name);
                        found = item;
                    }
            if (found == null) throw new IOException("Classe requise absente du rapport : " + name);
            return found;
        }

        private static MonoFieldReport FindField(MonoClassReport type, string name, bool required)
        {
            MonoFieldReport found = null;
            if (type.Fields != null)
                foreach (MonoFieldReport item in type.Fields)
                    if (item != null && item.Name == name)
                    {
                        if (found != null) throw new IOException("Champ de version ambigu : " + name);
                        found = item;
                    }
            if (required && found == null) throw new IOException("Champ de version absent : " + type.Name + "." + name);
            return found;
        }

        private static void ValidateOffset(int offset, int size, int width, bool instance)
        {
            if (offset < (instance ? 16 : 0) || width < 1 || size < width || offset > size - width ||
                (width > 1 && offset % width != 0)) throw new IOException("Offset de champ de version hors limites.");
        }

        private string CString(ulong address)
        {
            RequirePointer(address);
            List<byte> bytes = new List<byte>();
            for (int i = 0; i < 128; ++i)
            {
                byte value = Read(address + (uint)i, 1)[0];
                if (value == 0)
                {
                    try { return utf8.GetString(bytes.ToArray()); }
                    catch (DecoderFallbackException) { throw new IOException("Nom de classe UTF-8 invalide."); }
                }
                if (value < 0x20) throw new IOException("Nom de classe invalide.");
                bytes.Add(value);
            }
            throw new IOException("Nom de classe sans terminaison.");
        }

        private byte[] Read(ulong address, int count)
        {
            RequirePointer(address);
            if (count < 1 || count > 4096 || address > 0x00007FFFFFFFFFFFUL - (uint)(count - 1))
                throw new IOException("Plage de lecture de version invalide.");
            if (clock.ElapsedMilliseconds > 5000 || readCalls >= MaximumReadCalls || bytesRead > MaximumReadBytes - count)
                throw new IOException("Budget de lecture de version atteint.");
            ++readCalls;
            bytesRead += count;
            byte[] value = memory.Read(address, count);
            if (value == null || value.Length != count) throw new IOException("Lecture de version incomplete.");
            return value;
        }

        private static ulong Address(string value)
        {
            if (String.IsNullOrEmpty(value)) throw new IOException("Adresse de classe absente.");
            string hex = value.StartsWith("0x", StringComparison.OrdinalIgnoreCase) ? value.Substring(2) : value;
            ulong address;
            if (!UInt64.TryParse(hex, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out address))
                throw new IOException("Adresse de classe invalide.");
            RequirePointer(address);
            return address;
        }
        private static ulong Add(ulong address, int offset)
        {
            if (offset < 0 || address > 0x00007FFFFFFFFFFFUL - (uint)offset) throw new IOException("Depassement d'adresse de champ.");
            return address + (uint)offset;
        }
        private static void RequirePointer(ulong value)
        {
            if (value < 0x10000 || value > 0x00007FFFFFFFFFFFUL) throw new IOException("Pointeur utilisateur x64 invalide.");
        }
        private ulong U64(ulong address) { return BitConverter.ToUInt64(Read(address, 8), 0); }
        private ulong Pointer(ulong address) { ulong value = U64(address); RequirePointer(value); return value; }
        private ushort U16(ulong address) { return BitConverter.ToUInt16(Read(address, 2), 0); }
        private int I32(ulong address) { return BitConverter.ToInt32(Read(address, 4), 0); }
    }
}
