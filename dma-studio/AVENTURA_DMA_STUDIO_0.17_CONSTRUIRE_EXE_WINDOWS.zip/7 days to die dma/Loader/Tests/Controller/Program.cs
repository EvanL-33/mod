using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using SevenDaysLoader;
using SevenDaysLoader.Services;
using SevenDaysDmaControl;

internal static class Program
{
    private static async Task<int> Main()
    {
        var tests = new (string Name, Func<Task> Run)[]
        {
            (nameof(PlayerCommandsPreserveFramesAndWaitForExecution), PlayerCommandsPreserveFramesAndWaitForExecution),
            (nameof(CharacterContextCancelsOldIntentWithoutReplay), CharacterContextCancelsOldIntentWithoutReplay),
            (nameof(ModuleObservationCannotEraseReaderFailure), ModuleObservationCannotEraseReaderFailure),
            (nameof(AutomaticRecoveryDoesNotReplayCreativeIntent), AutomaticRecoveryDoesNotReplayCreativeIntent),
            (nameof(RapidSecondLossBeforeStartReturnsQueuesTheNextGeneration), RapidSecondLossBeforeStartReturnsQueuesTheNextGeneration),
            (nameof(StopDuringDelayCancelsRecovery), StopDuringDelayCancelsRecovery),
            (nameof(DisablingRecoveryDuringDelayClearsBusy), DisablingRecoveryDuringDelayClearsBusy),
            (nameof(NonrecoverableErrorsRemainStopped), NonrecoverableErrorsRemainStopped),
            (nameof(OldGenerationCallbacksCannotChangeTheNewSession), OldGenerationCallbacksCannotChangeTheNewSession),
            (nameof(StopCancelsARecoveryStartupInProgress), StopCancelsARecoveryStartupInProgress),
            (nameof(ManualConnectionSupersedesScheduledRecovery), ManualConnectionSupersedesScheduledRecovery),
            (nameof(ModeChangeCancelsPendingReaderRecovery), ModeChangeCancelsPendingReaderRecovery),
            (nameof(DisposeCancelsPendingRecovery), DisposeCancelsPendingRecovery)
        };
        int failures = 0;
        foreach (var test in tests)
        {
            var duration = Stopwatch.StartNew();
            try
            {
                await test.Run().WaitAsync(TimeSpan.FromSeconds(14));
                Console.WriteLine("PASS " + test.Name + " (" + duration.ElapsedMilliseconds + " ms)");
            }
            catch (Exception error)
            {
                failures++;
                Console.WriteLine("FAIL " + test.Name + " : " + error.GetBaseException());
                // Stop on timeout: a runaway test must not overlap the next
                // static fake-worker fixture and conceal a lifecycle failure.
                if (error is TimeoutException) break;
            }
        }
        Console.WriteLine("Failures: " + failures);
        return failures == 0 ? 0 : 1;
    }

    private static async Task AutomaticRecoveryDoesNotReplayCreativeIntent()
    {
        await using var f = new Fixture();
        await f.Controller.ConnectReaderAsync();
        var first = WorkerHost.Instances[0];
        Check(f.Controller.Status.IsConnected && f.Controller.CurrentFrame != null, "Initial reader was not connected.");
        await f.Controller.ToggleCreativeMenuAsync();
        first.EmitPlayerObservation();
        await f.Controller.SendPlayerControlAsync(ControlOperation.SetFly, true);
        Check(first.Requests.Length == 1 && f.Controller.CreativeMenu.IsBusy, "Creative request was not pending.");
        first.EmitLoss();
        Check(f.Controller.Status.Stage == "RECONNEXION_JEU" && f.Controller.Status.IsBusy &&
            !f.Controller.CreativeMenu.IsBusy && f.Controller.CurrentFrame == null,
            "Process loss did not clear the frame and creative intent before recovery.");
        await Until(() => WorkerHost.Instances.Length == 2 && f.Controller.Status.IsConnected);
        var second = WorkerHost.Instances[1];
        Check(first.Disposed && second.Requests.Length == 0 && second.PlayerRequests.Length == 0 && !f.Controller.PlayerControls.IsBusy && f.Controller.Status.ProcessId == second.Pid &&
            f.Controller.CreativeMenu.ObservedEnabled == null, "Recovery replayed a command or retained the previous host.");
    }

    private static async Task PlayerCommandsPreserveFramesAndWaitForExecution()
    {
        await using var f = new Fixture(); await f.Controller.ConnectReaderAsync();
        var host = WorkerHost.Instances[0]; var frame = f.Controller.CurrentFrame;
        Check(!f.Controller.PlayerControls.CanRequest, "Controls ready without a module.");
        host.EmitPlayerObservation();
        await f.Controller.SendPlayerControlAsync(ControlOperation.SetFly, true);
        Check(host.PlayerRequests.Length == 1 && f.Controller.PlayerControls.IsBusy && ReferenceEquals(frame, f.Controller.CurrentFrame), "Command affected ESP frame.");
        host.EmitPlayerSubmission(host.PlayerRequests[0]);
        Check(f.Controller.PlayerControls.IsBusy && f.Controller.PlayerControls.Snapshot!.Observation.Flags == ControlFlags.FirstPerson,
            "Transmission was presented as execution.");
        host.EmitPlayerObservation(7, ControlStatus.AppliedLocal, ControlOperation.SetFly, ControlFlags.Fly);
        Check(!f.Controller.PlayerControls.IsBusy && f.Controller.PlayerControls.Snapshot!.Observation.Flags == ControlFlags.Fly &&
            ReferenceEquals(frame, f.Controller.CurrentFrame), "Action result removed or changed current ESP capture.");
        await f.Controller.DisconnectAsync();
        host.EmitPlayerObservation(7, ControlStatus.AppliedLocal, ControlOperation.SetFly, ControlFlags.Fly);
        Check(!f.Controller.PlayerControls.Available && f.Controller.PlayerControls.Snapshot == null, "Stopped generation accepted an old module state.");
    }

    private static async Task CharacterContextCancelsOldIntentWithoutReplay()
    {
        await using var f = new Fixture(); await f.Controller.ConnectReaderAsync(); var host = WorkerHost.Instances[0];
        host.EmitPlayerObservation(); await f.Controller.SendPlayerControlAsync(ControlOperation.SetSpectator, true);
        var old = host.PlayerRequests[0]; host.ChangeCharacterContext(); host.EmitPlayerObservation(); host.EmitPlayerSubmission(old);
        Check(!f.Controller.PlayerControls.IsBusy && host.PlayerRequests.Length == 1, "Old intent survived character change.");
        await f.Controller.SendPlayerControlAsync(ControlOperation.SetFly, true);
        Check(host.PlayerRequests.Length == 2 && host.PlayerRequests[1].ExpectedModuleContextId == host.CharacterContext &&
            host.PlayerRequests[1].ExpectedModuleContextId != old.ExpectedModuleContextId, "New explicit action inherited old character identity.");
    }

    private static async Task ModuleObservationCannotEraseReaderFailure()
    {
        await using var f = new Fixture(); await f.Controller.ConnectReaderAsync(); var host = WorkerHost.Instances[0];
        host.EmitPlayerObservation(); host.EmitError("ERREUR_LECTURE"); host.EmitPlayerObservation();
        Check(f.Controller.Status.Stage == "ERREUR_LECTURE" && !f.Controller.PlayerControls.Available && f.Controller.CurrentFrame == null,
            "Module packet erased reader failure or revived commands.");
    }

    private static async Task RapidSecondLossBeforeStartReturnsQueuesTheNextGeneration()
    {
        await using var f = new Fixture(async (host, token) =>
        {
            if (host.Index == 2)
            {
                host.EmitLoss();
                await Task.Delay(75, token); // Ended occurs before this StartAsync returns.
            }
            else host.EmitFrame();
        });
        await f.Controller.ConnectReaderAsync();
        WorkerHost.Instances[0].EmitLoss();
        await Until(() => WorkerHost.Instances.Length == 3 && f.Controller.Status.IsConnected, 7000);
        var hosts = WorkerHost.Instances;
        Check(hosts[0].Disposed && hosts[1].Disposed && f.Controller.Status.ProcessId == hosts[2].Pid &&
            !f.Controller.Status.IsBusy, "Fast replacement loss left a busy status without the next recovery.");
    }

    private static async Task StopDuringDelayCancelsRecovery()
    {
        await using var f = new Fixture();
        await f.Controller.ConnectReaderAsync();
        WorkerHost.Instances[0].EmitLoss();
        await f.Controller.DisconnectAsync();
        Check(f.Controller.Status.Stage == "ARRETE" && !f.Controller.Status.IsBusy, "Stop left recovery active.");
        await Task.Delay(2250);
        Check(WorkerHost.Instances.Length == 1 && WorkerHost.Instances[0].Disposed, "A stopped reader restarted after the delay.");
    }

    private static async Task DisablingRecoveryDuringDelayClearsBusy()
    {
        await using var f = new Fixture();
        await f.Controller.ConnectReaderAsync();
        WorkerHost.Instances[0].EmitLoss();
        f.Controller.Settings.AutoReconnectGame = false;
        f.Controller.SaveSettings();
        Check(!f.Controller.Status.IsBusy && f.Controller.Status.Stage == GameReconnectCoordinator.ProcessLostStage,
            "Disabling recovery left the reconnect UI blocked.");
        await Task.Delay(2250);
        Check(WorkerHost.Instances.Length == 1, "Disabled recovery still started a new worker.");
        await f.Controller.ConnectReaderAsync();
        Check(WorkerHost.Instances.Length == 2 && f.Controller.Status.IsConnected, "Manual reconnect remained blocked.");
    }

    private static async Task NonrecoverableErrorsRemainStopped()
    {
        foreach (string stage in new[] { "ERREUR_LECTURE", "ERREUR_CONTROLE", "ERREUR_FERMETURE" })
        {
            await using var f = new Fixture();
            await f.Controller.ConnectReaderAsync();
            var host = WorkerHost.Instances[0];
            if (stage == "ERREUR_FERMETURE") host.EmitError(GameReconnectCoordinator.ProcessLostStage);
            host.EmitError(stage);
            host.EmitEnded();
            Check(f.Controller.Status.Stage == stage && !f.Controller.Status.IsBusy,
                "Ended replaced a nonrecoverable failure: " + stage);
            await Task.Delay(2250);
            Check(WorkerHost.Instances.Length == 1, "A nonrecoverable failure restarted DMA: " + stage);
        }
    }

    private static async Task OldGenerationCallbacksCannotChangeTheNewSession()
    {
        await using var f = new Fixture();
        await f.Controller.ConnectReaderAsync();
        var old = WorkerHost.Instances[0];
        await f.Controller.ToggleCreativeMenuAsync();
        var pending = old.Requests[0];
        await f.Controller.ConnectReaderAsync();
        var current = WorkerHost.Instances[1];
        var frame = f.Controller.CurrentFrame;
        old.EmitLoss(); old.EmitFrame(); old.EmitCreativeResult(pending); old.EmitControlError();
        Check(f.Controller.Status.ProcessId == current.Pid && f.Controller.Status.IsConnected &&
            ReferenceEquals(frame, f.Controller.CurrentFrame) && f.Controller.CreativeMenu.ObservedEnabled == null &&
            current.Requests.Length == 0, "An old callback replaced the current frame/status/creative state.");
        await Task.Delay(2250);
        Check(WorkerHost.Instances.Length == 2, "An old Ended callback scheduled an unrelated recovery.");
    }

    private static async Task StopCancelsARecoveryStartupInProgress()
    {
        var entered = Signal();
        await using var f = new Fixture(async (host, token) =>
        {
            if (host.Index == 2)
            {
                entered.TrySetResult();
                await Task.Delay(Timeout.Infinite, token);
            }
            else host.EmitFrame();
        });
        await f.Controller.ConnectReaderAsync();
        WorkerHost.Instances[0].EmitLoss();
        await entered.Task.WaitAsync(TimeSpan.FromSeconds(6));
        await f.Controller.DisconnectAsync().WaitAsync(TimeSpan.FromSeconds(2));
        Check(f.Controller.Status.Stage == "ARRETE" && !f.Controller.Status.IsBusy &&
            WorkerHost.Instances.Length == 2 && WorkerHost.Instances[1].Disposed,
            "Stop failed to cancel the startup token or dispose its new worker.");
    }

    private static async Task ManualConnectionSupersedesScheduledRecovery()
    {
        await using var f = new Fixture();
        await f.Controller.ConnectReaderAsync();
        WorkerHost.Instances[0].EmitLoss();
        await f.Controller.ConnectReaderAsync();
        uint current = WorkerHost.Instances[1].Pid;
        await Task.Delay(2250);
        Check(WorkerHost.Instances.Length == 2 && f.Controller.Status.ProcessId == current && f.Controller.Status.IsConnected,
            "The old delayed recovery overtook a newer manual connection.");
    }

    private static async Task ModeChangeCancelsPendingReaderRecovery()
    {
        await using var f = new Fixture();
        await f.Controller.ConnectReaderAsync();
        WorkerHost.Instances[0].EmitLoss();
        f.Controller.Settings.Mode = "display";
        f.Controller.SaveSettings();
        Check(!f.Controller.Status.IsBusy, "A mode change left delayed recovery marked busy.");
        await Task.Delay(2250);
        Check(WorkerHost.Instances.Length == 1 && f.Controller.Settings.Mode == "display",
            "A delayed reader recovery overrode display mode.");
    }

    private static async Task DisposeCancelsPendingRecovery()
    {
        await using var f = new Fixture();
        await f.Controller.ConnectReaderAsync();
        var old = WorkerHost.Instances[0]; old.EmitLoss();
        await f.Controller.DisposeAsync();
        old.EmitLoss(); old.EmitFrame();
        await Task.Delay(2250);
        Check(WorkerHost.Instances.Length == 1 && old.Disposed && !f.Controller.Status.IsConnected &&
            f.Controller.CurrentFrame == null, "A disposed controller restarted or accepted an old worker callback.");
    }

    private static async Task Until(Func<bool> condition, int milliseconds = 5500)
    {
        var clock = Stopwatch.StartNew();
        while (!condition())
        {
            if (clock.ElapsedMilliseconds >= milliseconds) throw new TimeoutException("Integration condition timed out.");
            await Task.Delay(10);
        }
    }

    private static void Check(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
    private static TaskCompletionSource Signal() => new(TaskCreationOptions.RunContinuationsAsynchronously);

    private sealed class Fixture : IAsyncDisposable
    {
        private readonly string directory;
        public AppController Controller { get; }
        internal Fixture(Func<WorkerHost, CancellationToken, Task>? start = null)
        {
            WorkerHost.Reset(start);
            directory = Path.Combine(AppContext.BaseDirectory, "temporary", Guid.NewGuid().ToString("N"));
            string sdk = Path.Combine(directory, "sdk"); Directory.CreateDirectory(sdk);
            File.WriteAllBytes(Path.Combine(sdk, "vmm.dll"), Array.Empty<byte>());
            File.WriteAllBytes(Path.Combine(sdk, "leechcore.dll"), Array.Empty<byte>());
            Controller = new AppController(new SettingsStore(Path.Combine(directory, "settings")));
            Controller.Settings.SdkDirectory = sdk;
            Controller.Settings.AutoReconnectGame = true;
            Controller.Settings.AutoConnectDma = false;
            Controller.Settings.Mode = "reader";
            Controller.SaveSettings();
        }
        public async ValueTask DisposeAsync()
        {
            await Controller.DisposeAsync();
            Directory.Delete(directory, true);
        }
    }
}
