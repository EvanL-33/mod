﻿#requires -Version 5.1
# Lanceur et outils ESP 0.4.1-dev : compatibilite du jeu encore a valider.
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()

if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    [Windows.Forms.MessageBox]::Show('Ouvre Lancer.cmd pour utiliser le mode STA requis.', 'Démarrage impossible') | Out-Null
    exit 1
}
try {
    $dataRoot = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'SevenDaysDmaLauncher'
    $logRoot = Join-Path $dataRoot 'logs'
    [IO.Directory]::CreateDirectory($logRoot) | Out-Null
    $configPath = Join-Path $dataRoot 'settings.json'
} catch {
    [Windows.Forms.MessageBox]::Show("Impossible de préparer le dossier des réglages :`r`n$($_.Exception.Message)", 'Erreur') | Out-Null
    exit 1
}

# Les événements asynchrones restent en C# : aucun callback PowerShell sans runspace.
Add-Type -TypeDefinition @'
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;

namespace SevenDaysDma {
    public sealed class Session : IDisposable {
        private Process process;
        private StreamWriter writer;
        private readonly object gate = new object();
        private readonly ConcurrentQueue<string> pending = new ConcurrentQueue<string>();
        private int pendingCount;
        private int omitted;
        private bool disposed;
        private bool logFailed;
        private bool outputClosed = true;
        private bool errorClosed = true;
        public string LogPath { get; private set; }
        public Session(string path) {
            LogPath = path;
            writer = new StreamWriter(new FileStream(path, FileMode.CreateNew, FileAccess.Write,
                FileShare.Read), new UTF8Encoding(false));
            writer.AutoFlush = true;
        }
        public bool IsRunning {
            get { try { return process != null && !process.HasExited; } catch { return false; } }
        }
        public int ProcessId { get { return process == null ? 0 : process.Id; } }
        public string ExitCode {
            get { try { return process != null && process.HasExited ? process.ExitCode.ToString() : "inconnu"; }
                catch { return "inconnu"; } }
        }
        private void Queue(string line) {
            if (Interlocked.Increment(ref pendingCount) <= 2000) {
                pending.Enqueue(line.Length > 8000 ? line.Substring(0, 8000) + " [affichage abrégé]" : line);
            } else { Interlocked.Decrement(ref pendingCount); Interlocked.Increment(ref omitted); }
        }
        public void Log(string source, string message) {
            string line = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + " [" + source + "] " + message;
            lock (gate) {
                if (disposed) return;
                try { if (!logFailed) writer.WriteLine(line); }
                catch (Exception ex) {
                    if (!logFailed) Queue("[Lanceur] Écriture du journal interrompue : " + ex.Message);
                    logFailed = true;
                }
                Queue(line);
            }
        }
        public string[] Drain(int maximum) {
            var lines = new List<string>();
            int skipped = Interlocked.Exchange(ref omitted, 0);
            if (skipped > 0) lines.Add("[Lanceur] " + skipped + " lignes masquées dans l'interface ; consulter le journal.");
            string line;
            while (lines.Count < maximum && pending.TryDequeue(out line)) {
                Interlocked.Decrement(ref pendingCount); lines.Add(line);
            }
            return lines.ToArray();
        }
        private void MarkStreamClosed(bool isError) {
            lock (gate) {
                if (isError) errorClosed = true; else outputClosed = true;
                Monitor.PulseAll(gate);
            }
        }
        public void Start(string executable, string arguments, string directory, bool utf8Output) {
            if (process != null) throw new InvalidOperationException("Session déjà utilisée.");
            process = new Process();
            process.StartInfo = new ProcessStartInfo {
                FileName = executable, Arguments = arguments, WorkingDirectory = directory,
                UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true,
                CreateNoWindow = false
            };
            if (utf8Output) {
                process.StartInfo.StandardOutputEncoding = new UTF8Encoding(false);
                process.StartInfo.StandardErrorEncoding = new UTF8Encoding(false);
            }
            process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e) {
                if (e.Data != null) Log("stdout", e.Data); else MarkStreamClosed(false);
            };
            process.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs e) {
                if (e.Data != null) Log("stderr", e.Data); else MarkStreamClosed(true);
            };
            Log("Lanceur", "Programme choisi : " + executable);
            Log("Lanceur", "Dossier de travail : " + directory);
            if (!process.Start()) throw new InvalidOperationException("Le programme n'a pas démarré.");
            Log("Lanceur", "Processus démarré, PID " + process.Id + ". Aucun état DMA n'est vérifié.");
            // Si la capture échoue, conserver le processus pour permettre son arrêt depuis l'interface.
            outputClosed = false; errorClosed = false;
            try { process.BeginOutputReadLine(); }
            catch (Exception ex) { MarkStreamClosed(false); Log("Lanceur", "Capture stdout impossible : " + ex.Message); }
            try { process.BeginErrorReadLine(); }
            catch (Exception ex) { MarkStreamClosed(true); Log("Lanceur", "Capture stderr impossible : " + ex.Message); }
        }
        public bool RequestClose() { return IsRunning && process.CloseMainWindow(); }
        public void ForceStop() { if (IsRunning) process.Kill(); }
        public void Dispose() {
            lock (gate) {
                if (disposed) return;
                if (!IsRunning) {
                    // Wait for EOF callbacks after exit, with a bound if a descendant retains a pipe.
                    var elapsed = Stopwatch.StartNew();
                    while (!outputClosed || !errorClosed) {
                        int remaining = 750 - (int)elapsed.ElapsedMilliseconds;
                        if (remaining <= 0) break;
                        Monitor.Wait(gate, remaining);
                    }
                    if (!outputClosed || !errorClosed)
                        Log("Lanceur", "Fin de capture incomplète après 750 ms ; un sous-processus peut conserver un flux ouvert.");
                }
                disposed = true;
                try { writer.Dispose(); } catch { }
            }
            if (process != null) process.Dispose();
        }
    }
}
'@

function Show-Error([string]$Message) {
    [Windows.Forms.MessageBox]::Show($form, $Message, 'Lanceur — erreur',
        [Windows.Forms.MessageBoxButtons]::OK, [Windows.Forms.MessageBoxIcon]::Error) | Out-Null
}
function New-Label([string]$Text) {
    $control = [Windows.Forms.Label]::new()
    $control.Text = $Text; $control.Dock = 'Fill'; $control.TextAlign = 'MiddleLeft'
    return $control
}
function New-Button([string]$Text, [int]$Width = 115) {
    $control = [Windows.Forms.Button]::new()
    $control.Text = $Text; $control.Size = [Drawing.Size]::new($Width, 32)
    $control.Margin = [Windows.Forms.Padding]::new(0, 4, 8, 4)
    return $control
}
function Get-CheckedSettings {
    $executable = [Environment]::ExpandEnvironmentVariables($exeBox.Text.Trim().Trim('"'))
    if ([string]::IsNullOrWhiteSpace($executable)) { throw 'Choisis le fichier .exe de ton moteur ESP/DMA. Aucun moteur n''est inclus.' }
    if (-not [IO.Path]::IsPathRooted($executable)) { throw 'Le programme doit être indiqué par son chemin complet.' }
    $executable = [IO.Path]::GetFullPath($executable)
    if (-not [IO.File]::Exists($executable) -or [IO.Path]::GetExtension($executable) -ine '.exe') {
        throw 'Le programme sélectionné doit être un fichier .exe existant.'
    }
    $directory = [Environment]::ExpandEnvironmentVariables($dirBox.Text.Trim().Trim('"'))
    if ([string]::IsNullOrWhiteSpace($directory)) { $directory = [IO.Path]::GetDirectoryName($executable) }
    if (-not [IO.Path]::IsPathRooted($directory)) { throw 'Le dossier de travail doit être un chemin complet, ou rester vide.' }
    $directory = [IO.Path]::GetFullPath($directory)
    if (-not [IO.Directory]::Exists($directory)) { throw 'Le dossier de travail indiqué n''existe pas.' }
    return @{ Executable = $executable; Arguments = $argsBox.Text; WorkingDirectory = $directory }
}
function Save-Settings {
    $settings = [ordered]@{
        Version = 2
        Executable = $exeBox.Text
        Arguments = $argsBox.Text
        WorkingDirectory = $dirBox.Text
        MemProcFsDirectory = $script:memProcFsDirectory
    }
    $temporary = $configPath + '.' + $PID + '.tmp'
    try {
        [IO.File]::WriteAllText($temporary, ($settings | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
        # NullString transmet un vrai null .NET ; $null devient une chaine vide sous Windows PowerShell.
        if ([IO.File]::Exists($configPath)) { [IO.File]::Replace($temporary, $configPath, [System.Management.Automation.Language.NullString]::Value) }
        else { [IO.File]::Move($temporary, $configPath) }
        $script:settingsSaveWarning = ''
    } finally { if ([IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) } }
}
function Save-SettingsIfPossible {
    try { Save-Settings }
    catch {
        $script:settingsSaveWarning = 'Le dossier MemProcFS reste utilisable pour cette session, mais les reglages n''ont pas pu etre enregistres. Detail : ' + $_.Exception.Message
    }
}
function Get-ValidMemProcFsDirectory([string]$Directory) {
    try {
        if ([string]::IsNullOrWhiteSpace($Directory)) { return $null }
        $expanded = [Environment]::ExpandEnvironmentVariables($Directory.Trim().Trim('"'))
        # Chemin complet de lecteur ou de partage Windows ; pas de chemin relatif.
        if ($expanded -notmatch '^(?:[A-Za-z]:[\\/]|\\\\[^\\]+\\[^\\]+(?:\\|$))') { return $null }
        $fullPath = [IO.Path]::GetFullPath($expanded)
        if (-not [IO.Directory]::Exists($fullPath)) { return $null }
        foreach ($dllName in @('vmm.dll', 'leechcore.dll')) {
            if (-not [IO.File]::Exists((Join-Path $fullPath $dllName))) { return $null }
        }
        return $fullPath
    } catch { return $null }
}
function Resolve-MemProcFsDirectory([switch]$Choose) {
    $selectedPath = Get-ValidMemProcFsDirectory $script:memProcFsDirectory
    if (-not $Choose -and $null -ne $selectedPath) {
        $script:memProcFsDirectory = $selectedPath
        return $selectedPath
    }
    $dialog = [Windows.Forms.FolderBrowserDialog]::new()
    try {
        $dialog.Description = 'Dossier MemProcFS x64 contenant vmm.dll et leechcore.dll. Ce choix sera memorise.'
        if (-not $Choose) {
            $dialog.Description = 'Dossier MemProcFS configure absent ou incomplet. Choisis celui contenant vmm.dll et leechcore.dll.'
        }
        $dialog.ShowNewFolderButton = $false
        if ([IO.Directory]::Exists($script:memProcFsDirectory)) { $dialog.SelectedPath = $script:memProcFsDirectory }
        elseif ([IO.Directory]::Exists($script:defaultMemProcFsDirectory)) { $dialog.SelectedPath = $script:defaultMemProcFsDirectory }
        if ($dialog.ShowDialog($form) -ne 'OK') { return $null }
        $selectedPath = Get-ValidMemProcFsDirectory $dialog.SelectedPath
        if ($null -eq $selectedPath) { throw 'Le dossier doit contenir vmm.dll et leechcore.dll directement. Choisis le dossier des binaires MemProcFS x64.' }
        $script:memProcFsDirectory = $selectedPath
        Save-SettingsIfPossible
        return $selectedPath
    } finally { $dialog.Dispose() }
}
function Append-Log([string]$Text) {
    if ($logBox.TextLength -gt 120000) {
        $logBox.Text = '[Lanceur] Début de l''affichage retiré ; consulter le journal complet.' + "`r`n" +
            $logBox.Text.Substring($logBox.TextLength - 60000)
    }
    $logBox.AppendText($Text + "`r`n")
}
function Update-Controls {
    $running = $null -ne $script:session -and $script:session.IsRunning
    foreach ($control in @($exeBox, $argsBox, $dirBox, $browseButton, $dirButton, $saveButton, $checkButton, $startButton, $demoButton, $dmaButton, $inspectButton, $previewButton, $sdkButton, $liveButton)) {
        $control.Enabled = -not $running
    }
    $stopButton.Enabled = $running
    $forceButton.Enabled = $running -and $script:stopRequested
}
function Start-ManagedProgram([string]$Executable, [string]$Arguments, [string]$Directory, [string]$Label, [bool]$Utf8Output = $false) {
    try {
        if ($null -ne $script:session -and $script:session.IsRunning) { throw 'Un programme est déjà actif dans ce lanceur.' }
        if ($null -ne $script:session) { $script:session.Dispose(); $script:session = $null }
        $path = Join-Path $logRoot ((Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '-' + [Guid]::NewGuid().ToString('N').Substring(0, 8) + '.log')
        $script:session = [SevenDaysDma.Session]::new($path)
        $script:sessionLabel = $Label; $script:exitReported = $false; $script:stopRequested = $false; $logBox.Clear()
        $script:session.Start($Executable, $Arguments, $Directory, $Utf8Output)
        $statusLabel.Text = $Label + ' en cours — PID ' + $script:session.ProcessId + '. Consulte le journal.'
    } catch {
        $script:exitReported = $true; $statusLabel.Text = 'Démarrage impossible.'
        if ($null -ne $script:session) { $script:session.Log('Lanceur', 'Erreur : ' + $_.Exception.Message) }
        throw
    } finally { Update-Controls }
}
function Quote-PathArgument([string]$Value) {
    if ($Value.Contains('"') -or $Value.Contains([string][char]0)) { throw 'Le chemin contient un caractère invalide.' }
    return '"' + [Text.RegularExpressions.Regex]::Replace($Value, '(\\+)$', '$1$1') + '"'
}
function Start-BundledTest([string]$FileName, [string]$ExtraArguments, [string]$Label) {
    $testPath = Join-Path $PSScriptRoot $FileName
    if (-not [IO.File]::Exists($testPath)) { throw ('Fichier de test absent : ' + $testPath) }
    if (-not [Environment]::Is64BitOperatingSystem) { throw 'Les tests nécessitent Windows 64 bits.' }
    $psPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    if ([IntPtr]::Size -ne 8) { $psPath = Join-Path $env:SystemRoot 'Sysnative\WindowsPowerShell\v1.0\powershell.exe' }
    if (-not [IO.File]::Exists($psPath)) { throw 'Windows PowerShell natif 64 bits est introuvable.' }
    $arguments = '-NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File ' + (Quote-PathArgument $testPath) + $ExtraArguments
    Start-ManagedProgram $psPath $arguments $PSScriptRoot $Label $true
}

$form = [Windows.Forms.Form]::new()
$form.Text = '7 Days to Die — Lanceur ESP/DMA local'
$form.Size = [Drawing.Size]::new(1000, 720); $form.MinimumSize = [Drawing.Size]::new(940, 640)
$form.StartPosition = 'CenterScreen'; $form.Font = [Drawing.Font]::new('Segoe UI', 10)
$form.AutoScaleMode = 'Dpi'
$layout = [Windows.Forms.TableLayoutPanel]::new()
$layout.Dock = 'Fill'; $layout.Padding = [Windows.Forms.Padding]::new(18); $layout.ColumnCount = 1; $layout.RowCount = 9
foreach ($height in @(38, 56, 144, 48, 88, 44, 28)) {
    $layout.RowStyles.Add([Windows.Forms.RowStyle]::new([Windows.Forms.SizeType]::Absolute, $height)) | Out-Null
}
$layout.RowStyles.Add([Windows.Forms.RowStyle]::new([Windows.Forms.SizeType]::Percent, 100)) | Out-Null
$layout.RowStyles.Add([Windows.Forms.RowStyle]::new([Windows.Forms.SizeType]::Absolute, 46)) | Out-Null
$form.Controls.Add($layout)
$title = New-Label '7 DAYS TO DIE  /  LANCEUR LOCAL'
$title.Font = [Drawing.Font]::new('Segoe UI', 15, [Drawing.FontStyle]::Bold)
$layout.Controls.Add($title, 0, 0)
$notice = New-Label '0.4.1-dev : radar DMA expérimental pour les joueurs et zombies de V 3.4.0 (b10). Lecture des positions sur le PC lecteur ; caméra et cadres superposés encore à valider. « Aperçu simulé » reste un test de rendu.'
$notice.ForeColor = [Drawing.Color]::FromArgb(130, 72, 8)
$layout.Controls.Add($notice, 0, 1)
$fields = [Windows.Forms.TableLayoutPanel]::new()
$fields.Dock = 'Fill'; $fields.ColumnCount = 3; $fields.RowCount = 3
$fields.ColumnStyles.Add([Windows.Forms.ColumnStyle]::new([Windows.Forms.SizeType]::Absolute, 175)) | Out-Null
$fields.ColumnStyles.Add([Windows.Forms.ColumnStyle]::new([Windows.Forms.SizeType]::Percent, 100)) | Out-Null
$fields.ColumnStyles.Add([Windows.Forms.ColumnStyle]::new([Windows.Forms.SizeType]::Absolute, 125)) | Out-Null
for ($row = 0; $row -lt 3; $row++) { $fields.RowStyles.Add([Windows.Forms.RowStyle]::new([Windows.Forms.SizeType]::Percent, 33.333)) | Out-Null }
$exeBox = [Windows.Forms.TextBox]::new(); $exeBox.Dock = 'Fill'; $exeBox.Margin = [Windows.Forms.Padding]::new(3, 11, 8, 3)
$argsBox = [Windows.Forms.TextBox]::new(); $argsBox.Dock = 'Fill'; $argsBox.Margin = $exeBox.Margin; $argsBox.MaxLength = 30000
$dirBox = [Windows.Forms.TextBox]::new(); $dirBox.Dock = 'Fill'; $dirBox.Margin = $exeBox.Margin
$browseButton = New-Button 'Parcourir…'; $browseButton.Margin = [Windows.Forms.Padding]::new(0, 8, 0, 0)
$dirButton = New-Button 'Dossier…'; $dirButton.Margin = $browseButton.Margin
$fields.Controls.Add((New-Label 'Programme ESP/DMA'), 0, 0); $fields.Controls.Add($exeBox, 1, 0); $fields.Controls.Add($browseButton, 2, 0)
$fields.Controls.Add((New-Label 'Arguments (facultatif)'), 0, 1); $fields.Controls.Add($argsBox, 1, 1); $fields.SetColumnSpan($argsBox, 2)
$fields.Controls.Add((New-Label "Dossier de travail`r`n(vide = celui du .exe)"), 0, 2); $fields.Controls.Add($dirBox, 1, 2); $fields.Controls.Add($dirButton, 2, 2)
$layout.Controls.Add($fields, 0, 2)
$actions = [Windows.Forms.FlowLayoutPanel]::new(); $actions.Dock = 'Fill'; $actions.WrapContents = $false
$saveButton = New-Button 'Enregistrer'; $checkButton = New-Button 'Vérifier'
$startButton = New-Button 'Démarrer'; $stopButton = New-Button 'Arrêter'
$forceButton = New-Button 'Forcer l''arrêt' 135; $logsButton = New-Button 'Journaux'
foreach ($button in @($saveButton, $checkButton, $startButton, $stopButton, $forceButton, $logsButton)) { $actions.Controls.Add($button) }
$layout.Controls.Add($actions, 0, 3)
$diagnostics = [Windows.Forms.FlowLayoutPanel]::new(); $diagnostics.Dock = 'Fill'; $diagnostics.WrapContents = $true
$liveButton = New-Button 'Radar joueurs/zombies' 205
$liveButton.BackColor = [Drawing.Color]::FromArgb(210, 231, 250)
$demoButton = New-Button 'Tester le lanceur' 165; $dmaButton = New-Button 'Tester DMA' 135
$inspectButton = New-Button 'Analyser ESP' 145; $previewButton = New-Button 'Aperçu simulé' 145
$reportsButton = New-Button 'Rapports' 100; $sdkButton = New-Button 'MemProcFS…' 125
foreach ($button in @($liveButton, $inspectButton, $dmaButton, $previewButton, $reportsButton, $sdkButton, $demoButton)) { $diagnostics.Controls.Add($button) }
$layout.Controls.Add($diagnostics, 0, 4)
$statusLabel = New-Label 'Charge ta partie V 3.4.0 (b10), puis clique sur Radar joueurs/zombies.'
$statusLabel.Font = [Drawing.Font]::new('Segoe UI', 10, [Drawing.FontStyle]::Bold)
$layout.Controls.Add($statusLabel, 0, 5)
$layout.Controls.Add((New-Label 'Journal de la session'), 0, 6)
$logBox = [Windows.Forms.TextBox]::new(); $logBox.Dock = 'Fill'; $logBox.Multiline = $true; $logBox.ReadOnly = $true
$logBox.ScrollBars = 'Both'; $logBox.WordWrap = $false; $logBox.Font = [Drawing.Font]::new('Consolas', 9)
$layout.Controls.Add($logBox, 0, 7)
$footer = New-Label ("Réglages et journaux : " + $dataRoot + "`r`n« Programme lancé » ne signifie pas « ESP actif » ni « DMA connecté ».")
$footer.Font = [Drawing.Font]::new('Segoe UI', 8); $footer.ForeColor = [Drawing.Color]::DimGray
$layout.Controls.Add($footer, 0, 8)
$script:session = $null; $script:exitReported = $false; $script:stopRequested = $false; $script:sessionLabel = 'Programme'
$script:defaultMemProcFsDirectory = 'C:\Users\Media\Desktop\MemProcFS_files_and_binaries-win_x64-latest'
$script:memProcFsDirectory = $script:defaultMemProcFsDirectory
$script:settingsSaveWarning = ''

$browseButton.Add_Click({
    $dialog = [Windows.Forms.OpenFileDialog]::new()
    try {
        $dialog.Title = 'Choisir ton moteur ESP/DMA existant'; $dialog.Filter = 'Programme Windows (*.exe)|*.exe'; $dialog.CheckFileExists = $true
        if ($dialog.ShowDialog($form) -eq 'OK') { $exeBox.Text = $dialog.FileName; $statusLabel.Text = 'Programme choisi — vérifie ses réglages avant de démarrer.' }
    } finally { $dialog.Dispose() }
})
$dirButton.Add_Click({
    $dialog = [Windows.Forms.FolderBrowserDialog]::new()
    try {
        $dialog.Description = 'Dossier de travail du moteur. Laisse le champ vide pour utiliser le dossier du .exe.'
        $dialog.ShowNewFolderButton = $false
        if ($dialog.ShowDialog($form) -eq 'OK') { $dirBox.Text = $dialog.SelectedPath }
    } finally { $dialog.Dispose() }
})
$saveButton.Add_Click({ try { Save-Settings; $statusLabel.Text = 'Réglages enregistrés.' } catch { Show-Error $_.Exception.Message } })
$checkButton.Add_Click({
    try { $checked = Get-CheckedSettings; $statusLabel.Text = 'Chemins valides. Compatibilité du moteur et connexion DMA non vérifiées.' }
    catch { Show-Error $_.Exception.Message }
})
$startButton.Add_Click({
    try {
        if ($null -ne $script:session -and $script:session.IsRunning) { return }
        $checked = Get-CheckedSettings; Save-Settings
        Start-ManagedProgram $checked.Executable $checked.Arguments $checked.WorkingDirectory 'Programme'
    } catch { Show-Error $_.Exception.Message }
})
$demoButton.Add_Click({
    try { Start-BundledTest 'Demo-Loader.ps1' '' 'Test local du lanceur' }
    catch { Show-Error $_.Exception.Message }
})
$dmaButton.Add_Click({
    try {
        $sdkPath = Resolve-MemProcFsDirectory
        if ($null -eq $sdkPath) { return }
        Start-BundledTest 'Probe-Dma.ps1' (' -VmmDir ' + (Quote-PathArgument $sdkPath) + ' -Device fpga') 'Diagnostic DMA'
        $script:session.Log('Lanceur', 'Dossier MemProcFS : ' + $sdkPath)
        if (-not [string]::IsNullOrEmpty($script:settingsSaveWarning)) {
            $script:session.Log('REGLAGES_NON_ENREGISTRES', $script:settingsSaveWarning)
        }
    } catch { Show-Error $_.Exception.Message }
})
$inspectButton.Add_Click({
    try {
        $sdkPath = Resolve-MemProcFsDirectory
        if ($null -eq $sdkPath) { return }
        Start-BundledTest 'Inspect-Dma.ps1' (' -VmmDir ' + (Quote-PathArgument $sdkPath) + ' -Device fpga') 'Analyse ESP (métadonnées)'
        $script:session.Log('Lanceur', 'Dossier MemProcFS : ' + $sdkPath)
        if (-not [string]::IsNullOrEmpty($script:settingsSaveWarning)) {
            $script:session.Log('REGLAGES_NON_ENREGISTRES', $script:settingsSaveWarning)
        }
    } catch { Show-Error $_.Exception.Message }
})
$liveButton.Add_Click({
    try {
        $sdkPath = Resolve-MemProcFsDirectory
        if ($null -eq $sdkPath) { return }
        Start-BundledTest 'Live-Dma.ps1' (' -VmmDir ' + (Quote-PathArgument $sdkPath) + ' -Device fpga') 'Radar DMA joueurs/zombies'
        $script:session.Log('Lanceur', 'Dossier MemProcFS : ' + $sdkPath)
        if (-not [string]::IsNullOrEmpty($script:settingsSaveWarning)) {
            $script:session.Log('REGLAGES_NON_ENREGISTRES', $script:settingsSaveWarning)
        }
    } catch { Show-Error $_.Exception.Message }
})
$sdkButton.Add_Click({
    try {
        $sdkPath = Resolve-MemProcFsDirectory -Choose
        if ($null -ne $sdkPath) {
            if ([string]::IsNullOrEmpty($script:settingsSaveWarning)) {
                $statusLabel.Text = 'MemProcFS : ' + $sdkPath
                Append-Log ('[MemProcFS] Dossier enregistre : ' + $sdkPath)
            } else {
                $statusLabel.Text = 'MemProcFS choisi pour cette session ; reglages non enregistres.'
                Append-Log ('[MemProcFS] Dossier utilise pour cette session : ' + $sdkPath)
                Append-Log ('[REGLAGES_NON_ENREGISTRES] ' + $script:settingsSaveWarning)
            }
        }
    } catch { Show-Error $_.Exception.Message }
})
$previewButton.Add_Click({
    try { Start-BundledTest 'Preview-Esp.ps1' '' 'Aperçu ESP SIMULÉ (sans DMA)' }
    catch { Show-Error $_.Exception.Message }
})
$reportsButton.Add_Click({
    try {
        $reportsPath = Join-Path $PSScriptRoot 'rapports'
        [IO.Directory]::CreateDirectory($reportsPath) | Out-Null
        Invoke-Item -LiteralPath $reportsPath
    } catch { Show-Error $_.Exception.Message }
})
$stopButton.Add_Click({
    try {
        if ($null -eq $script:session -or -not $script:session.IsRunning) { return }
        $script:stopRequested = $true
        if ($script:session.RequestClose()) { $statusLabel.Text = 'Fermeture normale demandée. Attends la fin du programme.' }
        else { $statusLabel.Text = 'Fermeture normale indisponible : ferme le moteur depuis son interface, ou utilise « Forcer l''arrêt ».' }
        $script:session.Log('Lanceur', $statusLabel.Text)
    } catch { Show-Error $_.Exception.Message } finally { Update-Controls }
})
$forceButton.Add_Click({
    try {
        if ($null -eq $script:session -or -not $script:session.IsRunning) { return }
        $answer = [Windows.Forms.MessageBox]::Show($form,
            ('Terminer immédiatement le processus lancé ici (PID ' + $script:session.ProcessId + ') ? Ses opérations en cours seront interrompues.'),
            'Forcer l''arrêt', [Windows.Forms.MessageBoxButtons]::YesNo, [Windows.Forms.MessageBoxIcon]::Warning,
            [Windows.Forms.MessageBoxDefaultButton]::Button2)
        if ($answer -eq 'Yes') { $script:session.Log('Lanceur', 'Arrêt forcé demandé par l''utilisateur.'); $script:session.ForceStop() }
    } catch { Show-Error $_.Exception.Message }
})
$logsButton.Add_Click({
    $dialog = [Windows.Forms.OpenFileDialog]::new()
    $viewer = $null
    try {
        $dialog.Title = 'Lire un journal'; $dialog.InitialDirectory = $logRoot; $dialog.Filter = 'Journal (*.log)|*.log'; $dialog.CheckFileExists = $true
        if ($dialog.ShowDialog($form) -ne 'OK') { return }
        $viewer = [Windows.Forms.Form]::new(); $viewer.Text = 'Journal — ' + [IO.Path]::GetFileName($dialog.FileName) + ' (500 dernières lignes)'
        $viewer.Size = [Drawing.Size]::new(950, 600); $viewer.StartPosition = 'CenterParent'
        $content = [Windows.Forms.TextBox]::new(); $content.Dock = 'Fill'; $content.Multiline = $true; $content.ReadOnly = $true
        $content.ScrollBars = 'Both'; $content.WordWrap = $false; $content.Font = [Drawing.Font]::new('Consolas', 9)
        $content.Text = (Get-Content -LiteralPath $dialog.FileName -Encoding UTF8 -Tail 500) -join "`r`n"
        $viewer.Controls.Add($content); $viewer.ShowDialog($form) | Out-Null
    } catch { Show-Error $_.Exception.Message }
    finally { if ($null -ne $viewer) { $viewer.Dispose() }; $dialog.Dispose() }
})

$timer = [Windows.Forms.Timer]::new(); $timer.Interval = 250
$timer.Add_Tick({
    if ($null -ne $script:session) {
        $lines = @($script:session.Drain(250))
        if ($lines.Count -gt 0) { Append-Log ($lines -join "`r`n") }
        if (-not $script:session.IsRunning -and -not $script:exitReported) {
            $script:exitReported = $true
            $statusLabel.Text = $script:sessionLabel + ' terminé — code de sortie ' + $script:session.ExitCode + '.'
            $script:session.Log('Lanceur', $statusLabel.Text); Update-Controls
        }
    }
})
$form.Add_FormClosing({
    param($sender, $eventArgs)
    if ($null -ne $script:session -and $script:session.IsRunning) {
        $eventArgs.Cancel = $true
        [Windows.Forms.MessageBox]::Show($form, 'Le programme est encore actif. Utilise Arrêter, puis Forcer l''arrêt si nécessaire, avant de fermer le lanceur.',
            'Programme actif', [Windows.Forms.MessageBoxButtons]::OK, [Windows.Forms.MessageBoxIcon]::Information) | Out-Null
    }
})

if ([IO.File]::Exists($configPath)) {
    try {
        $saved = [IO.File]::ReadAllText($configPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
        foreach ($entry in @(@('Executable', $exeBox), @('Arguments', $argsBox), @('WorkingDirectory', $dirBox))) {
            $property = $saved.PSObject.Properties[$entry[0]]
            if ($null -ne $property -and $property.Value -is [string]) { $entry[1].Text = $property.Value }
        }
        $sdkProperty = $saved.PSObject.Properties['MemProcFsDirectory']
        if ($null -ne $sdkProperty -and $sdkProperty.Value -is [string] -and -not [string]::IsNullOrWhiteSpace($sdkProperty.Value)) {
            $script:memProcFsDirectory = $sdkProperty.Value
        }
        if (-not [string]::IsNullOrWhiteSpace($exeBox.Text)) { $statusLabel.Text = 'Réglages chargés — vérifie-les ou démarre le programme.' }
    } catch { Append-Log ('Réglages illisibles ; saisis-les à nouveau. Détail : ' + $_.Exception.Message) }
}
Append-Log '0.4.1-dev : le radar tente la lecture reelle des positions. La projection camera reste a valider. Charge la partie avant de lancer le radar.'
Append-Log ('[MemProcFS] Dossier configure : ' + $script:memProcFsDirectory + ' (verifie au lancement du test).')
Update-Controls
try { $timer.Start(); [Windows.Forms.Application]::Run($form) }
finally {
    $timer.Stop(); $timer.Dispose()
    if ($null -ne $script:session) { $script:session.Dispose() }
    $form.Dispose()
}
