using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using SevenDaysEsp;
using SevenDaysLoader;
using SevenDaysDmaControl;

namespace System.Windows.Forms
{
    public sealed class Screen
    {
        public static Screen[] AllScreens { get; } = { new Screen() };
        public string DeviceName => "Harness display";
        public System.Drawing.Rectangle Bounds => new(0, 0, 1920, 1080);
    }
}

namespace SevenDaysLoader.Services
{
    // Only the process/pipe boundary is replaced. AppController, its lifecycle
    // gate, coordinator, settings, player/creative sessions and DTOs are real.
    public sealed class WorkerHost : IAsyncDisposable
    {
        private static readonly object AllGate = new();
        private static readonly List<WorkerHost> All = new();
        private static Func<WorkerHost, CancellationToken, Task>? startBehavior;
        private readonly object requestGate = new();
        private readonly List<CreativeMenuRequest> requests = new();
        private readonly List<PlayerControlRequest> playerRequests = new();
        public int Index { get; }
        public uint Pid => (uint)(7700 + Index);
        public string Context { get; } = Guid.NewGuid().ToString("N");
        public Guid ModuleSession { get; } = Guid.NewGuid();
        public Guid CharacterContext { get; private set; } = Guid.NewGuid();
        public volatile bool Disposed;
        public event Action<WorkerMessage>? Message;
        public event Action<string>? Ended;
        public event Action<string>? ControlError;
        public CreativeMenuRequest[] Requests { get { lock (requestGate) return requests.ToArray(); } }
        public PlayerControlRequest[] PlayerRequests { get { lock (requestGate) return playerRequests.ToArray(); } }

        public WorkerHost()
        {
            lock (AllGate) { Index = All.Count + 1; All.Add(this); }
        }

        public static void Reset(Func<WorkerHost, CancellationToken, Task>? behavior = null)
        { lock (AllGate) { All.Clear(); startBehavior = behavior; } }

        public static WorkerHost[] Instances { get { lock (AllGate) return All.ToArray(); } }

        public Task StartAsync(WorkerStart settings, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            Func<WorkerHost, CancellationToken, Task>? behavior;
            lock (AllGate) behavior = startBehavior;
            if (behavior != null) return behavior(this, cancellationToken);
            EmitFrame();
            return Task.CompletedTask;
        }

        public Task SendCreativeMenuAsync(CreativeMenuRequest request, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested();
            ObjectDisposedException.ThrowIf(Disposed, this);
            CreativeMenuProtocol.ValidateRequest(request);
            lock (requestGate) requests.Add(request.Copy());
            return Task.CompletedTask;
        }

        public void UpdateReadOptions(LiveReadOptions _) { }
        public Task SendPlayerControlAsync(PlayerControlRequest request, CancellationToken cancellationToken = default)
        {
            cancellationToken.ThrowIfCancellationRequested(); ObjectDisposedException.ThrowIf(Disposed, this);
            PlayerControlPolicy.ValidateRequest(request);
            lock (requestGate) playerRequests.Add(request.Copy());
            return Task.CompletedTask;
        }
        public ValueTask DisposeAsync() { Disposed = true; return ValueTask.CompletedTask; }

        // Event injection deliberately remains possible after Dispose to test
        // a callback already queued by the previous host generation.
        public void EmitFrame() => Message?.Invoke(new WorkerMessage
        {
            Kind = "frame", Stage = "ENTITES_LUES", Message = "Synthetic valid frame.",
            HasDmaSession = true, ProcessId = Pid, GameVersion = "V 3.4.0 (b10)",
            CapturedTimestamp = Stopwatch.GetTimestamp(),
            Frame = new LiveEntitySnapshot
            {
                Status = "ENTITES_LUES", PlayerContextId = Context, LocalId = 1,
                PlayerCaptureSequence = 1, LocalPosition = new LivePosition()
            }
        });

        public void EmitError(string stage) => Message?.Invoke(new WorkerMessage
        { Kind = "error", Stage = stage, Message = "Synthetic " + stage, ProcessId = Pid, HasDmaSession = false });
        public void EmitEnded() => Ended?.Invoke("Synthetic reader end.");
        public void EmitLoss() { EmitError(GameReconnectCoordinator.ProcessLostStage); EmitEnded(); }
        public void EmitControlError() => ControlError?.Invoke("Synthetic old control error.");
        public void ChangeCharacterContext() => CharacterContext = Guid.NewGuid();
        public void EmitPlayerObservation(ulong requestId = 0, ControlStatus status = ControlStatus.None, ControlOperation operation = ControlOperation.None,
            ControlFlags flags = ControlFlags.FirstPerson)
        {
            var snapshot = new ControlSnapshot
            {
                SessionId = ModuleSession, Sequence = 2, LastRequestId = requestId, RequestHighWatermark = requestId,
                LastRequestContextId = requestId == 0 ? Guid.Empty : CharacterContext,
                LastStatus = status, LastOperation = operation, LastMessage = "Synthetic module observation.",
                Observation = new GameObservation { ContextId = CharacterContext, PlayerId = 1, Availability = BridgeAvailability.Ready,
                    GameTimestampMs = 1000, PositionY = 65, Speed = 1, Flags = flags }
            };
            Message?.Invoke(new WorkerMessage { Kind = WorkerControl.PlayerControlStateKind,
                PlayerControlObservation = new PlayerControlObservation
                {
                    ProcessId = Pid, PlayerContextId = Context, CapturedTimestamp = Stopwatch.GetTimestamp(),
                    Available = true, Fresh = true, Code = "MODULE_PRET", Message = "Synthetic module observation.",
                    SnapshotRecord = ControlProtocol.EncodeSnapshot(snapshot, 2)
                } });
        }
        public void EmitPlayerSubmission(PlayerControlRequest request, ulong id = 7) => Message?.Invoke(new WorkerMessage
        {
            Kind = WorkerControl.PlayerControlSubmissionKind,
            PlayerControlSubmission = new PlayerControlSubmission
            {
                Sequence = request.Sequence, RequestId = request.RequestId, ProcessId = request.ExpectedProcessId,
                PlayerContextId = request.ExpectedPlayerContextId, Accepted = true, WriteAttempted = true, CommitAttempted = true,
                ModuleRequestId = id, Code = "TRANSMIS", Message = "Synthetic transmission."
            }
        });
        public void EmitCreativeResult(CreativeMenuRequest request) => Message?.Invoke(new WorkerMessage
        {
            Kind = WorkerControl.CreativeResultKind,
            CreativeResult = new CreativeMenuResult
            {
                Sequence = request.Sequence, RequestId = request.RequestId, ProcessId = request.ExpectedProcessId,
                PlayerContextId = request.ExpectedPlayerContextId, DesiredEnabled = request.DesiredEnabled, Toggle = request.Toggle,
                Code = "CONFIRME", Message = "Synthetic confirmation.", WriteAttempted = true, ObservedEnabled = true
            }
        });
    }
}
