using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;
using SevenDaysEsp;
using SevenDaysLoader.Services;

namespace SevenDaysLoader.UI;

internal sealed class OverlayManager : IDisposable
{
    private readonly ILoaderController controller;
    private readonly Window owner;
    private readonly RadarOverlay radar;
    private readonly ProjectedEspOverlay projectedEsp;
    private readonly OverlayMenu menu;
    private readonly FuserSurface fuser;
    private readonly PlayerNoticeSoundGate noticeSound = new();
    private readonly HashSet<int> watchedNearbyIds = new();
    private long watchedLastSoundAt;
    private uint watchedProcessId;
    private readonly HashSet<int> targetedZombieIds = new();
    private uint targetedZombieProcessId;
    private int targetedZombiePlayerId = -1;
    private string? targetedZombieContextId;
    private long lastZombieSoundAt;

    private readonly HwndSource source;
    private readonly IntPtr ownerHandle;
    private string registeredMenu = "", registeredToggle = "", registeredPlayers = "", registeredZombies = "", registeredRadar = "", registeredCreative = "";
    private bool menuRegistered, toggleRegistered, fuserExitRegistered, playersRegistered, zombiesRegistered, radarRegistered, creativeRegistered;
    private IntPtr previousForeground;
    private bool disposed;
    private bool enabled;
    private string layoutKey = "";
    private string menuLayoutKey = "";
    private string fuserDeviceName = "";
    private int fuserMonitorIndex = -1;
    private FeedSample? projectedSample;
    private FeedSample? publishedProjectionSample;
    private ProjectedFrame? projectedFrame;
    private string projectionFailure = "";
    private bool projectionNeedsRaise;
    private string projectionStatus = "ESP en attente de caméra.";
    internal bool Enabled => enabled;
    internal string HotkeyStatus { get; private set; } = "";
    internal string ProjectionStatus
    {
        get
        {
            var settings = controller.Settings;
            if (!enabled || disposed) return "Superposition arrêtée.";
            if (!settings.EspEnabled) return "Affichage désactivé · " + DisplayKey(settings.ToggleKey) + " pour réactiver.";
            if (!settings.ShowProjectedEsp) return "ESP projeté désactivé dans le menu.";
            if (!EspDisplayPolicy.HasProjectedProfile(settings))
                return "Aucun élément ESP activé dans les profils Joueurs et Zombies.";
            var sample = publishedProjectionSample;
            var geometry = projectedFrame;
            if (sample == null || geometry == null) return projectionStatus;
            // Publication and WPF rendering are separate dispatcher operations.
            // A receipt for a previous capture must never describe the current
            // capture as active, even before its queued refresh has executed.
            var current = controller.CurrentFrame;
            if (current == null) return "ESP en attente de positions récentes.";
            if (!ReferenceEquals(current, sample)) return "ESP en attente du rendu de la capture courante.";
            if (!sample.IsProjectionFresh)
                return "ESP suspendu : aucune caméra fraîche dans la capture courante.";
            var screens = System.Windows.Forms.Screen.AllScreens;
            if (settings.MonitorIndex < 0 || settings.MonitorIndex >= screens.Length)
                return "ESP suspendu : l’écran sélectionné est indisponible.";
            if (settings.OutputMode == "fuser" && !fuser.IsVisible)
                return "ESP suspendu : la sortie fuser est fermée.";
            if (!projectedEsp.TryGetRenderReceipt(geometry, sample.InitialAgeMs, sample.ReceivedTimestamp,
                screens[settings.MonitorIndex], out var renderedMapping, out int displayed, out string reason))
                return "ESP en attente de rendu : " + reason;
            var mapping = renderedMapping!;
            return "ESP actif · " + displayed + " repère(s) dessinés · " +
                mapping.SourceWidth + " × " + mapping.SourceHeight + " → " +
                mapping.OutputWidth + " × " + mapping.OutputHeight + " px · " + ScaleModeLabel(mapping.Mode) + " · viewport " +
                FormatPixels(mapping.ClipViewport.Width) + " × " + FormatPixels(mapping.ClipViewport.Height) +
                " px à (" + FormatPixels(mapping.ClipViewport.X) + ", " + FormatPixels(mapping.ClipViewport.Y) +
                ") · " + Math.Round(sample.AgeMs) + " ms.";
        }
    }

    internal OverlayManager(Window owner, ILoaderController controller)
    {
        this.owner = owner;
        this.controller = controller;
        ownerHandle = new WindowInteropHelper(owner).Handle;
        source = HwndSource.FromHwnd(ownerHandle) ?? throw new InvalidOperationException("Fenêtre du lanceur indisponible.");
        source.AddHook(WindowMessage);
        fuser = new FuserSurface(controller);
        projectedEsp = new ProjectedEspOverlay(controller);
        radar = new RadarOverlay(controller);
        menu = new OverlayMenu(controller, HideMenu, () => ReturnToOverlay(focusLoader: false));
        RegisterKeys();
    }

    internal void Enable()
    {
        if (disposed) return;
        enabled = true;
        Refresh();
    }
    internal void Disable()
    {
        if (disposed) return;
        enabled = false;
        ClearProjection("Superposition arrêtée.", resetCache: true, hideSurface: true);
        radar.Hide();
        fuser.Hide();
        HideMenu();
    }
    internal void ToggleMenu()
    {
        if (disposed) return;
        if (menu.IsVisible) { HideMenu(); return; }
        ShowMenu();
    }
    internal void ShowMenu()
    {
        if (disposed) return;
        Enable();
        if (menu.IsVisible) { menu.Refresh(); return; }
        previousForeground = Native.GetForegroundWindow();
        menu.Refresh();
        menu.Show();
        Position(menu, centered: true);
        menuLayoutKey = MonitorLayoutKey(menu);
        menu.Activate();
        Native.SetForegroundWindow(new WindowInteropHelper(menu).Handle);
    }
    internal void HideMenu()
    {
        if (!menu.IsVisible) return;
        bool wasForeground = Native.GetForegroundWindow() == new WindowInteropHelper(menu).Handle;
        menu.Hide();
        if (wasForeground && previousForeground != IntPtr.Zero && Native.IsWindow(previousForeground))
            Native.SetForegroundWindow(previousForeground);
        previousForeground = IntPtr.Zero;
    }

    internal void ReturnToOverlay(bool focusLoader = true)
    {
        if (disposed) return;
        controller.Settings.OutputMode = "overlay";
        controller.Settings.FuserTestPattern = false;
        ClearProjection("Retour à la superposition : ESP en attente d’une capture récente.", hideSurface: true);
        fuser.Hide();
        fuserDeviceName = "";
        fuserMonitorIndex = -1;
        layoutKey = "";
        try { controller.SaveSettings(); }
        catch (Exception e) { controller.Log("Réglages de sortie non enregistrés : " + e.Message); }
        if (focusLoader)
        {
            HideMenu();
            if (owner.WindowState == WindowState.Minimized) owner.WindowState = WindowState.Normal;
            owner.Activate();
        }
    }

    internal void Refresh()
    {
        if (disposed) return;
        RefreshPlayerNoticeSound();
        RefreshAdminWatch();
        RefreshZombieTargetSound();
        if (registeredMenu != controller.Settings.MenuKey || registeredToggle != controller.Settings.ToggleKey ||
            registeredPlayers != controller.Settings.PlayersKey || registeredZombies != controller.Settings.ZombiesKey ||
            registeredRadar != controller.Settings.RadarKey || registeredCreative != CreativeKey()) RegisterKeys();
        bool fuserMoved = false;
        if (enabled && controller.Settings.OutputMode == "fuser")
        {
            var screens = System.Windows.Forms.Screen.AllScreens;
            int index = controller.Settings.MonitorIndex;
            if (index < 0 || index >= screens.Length ||
                string.IsNullOrWhiteSpace(controller.Settings.FuserDeviceName) ||
                !string.Equals(screens[index].DeviceName, controller.Settings.FuserDeviceName, StringComparison.OrdinalIgnoreCase) ||
                (fuser.IsVisible && index == fuserMonitorIndex && screens[index].DeviceName != fuserDeviceName))
            {
                controller.Log("La sortie Windows mémorisée pour le fuser est absente ou ne correspond plus à l’écran sélectionné. Retour à la superposition ; sélectionne à nouveau la sortie reliée au fuser.");
                ReturnToOverlay(focusLoader: false);
            }
            else if (!fuserExitRegistered)
            {
                controller.Log("Sortie fuser non ouverte : Ctrl+Alt+F11 est déjà utilisé. Libère ce raccourci de secours puis redémarre le loader pour garder une commande de retour accessible.");
                ReturnToOverlay(focusLoader: false);
            }
            else
            {
                try
                {
                    fuserMoved = fuser.ShowOn(screens[index]);
                    fuserDeviceName = screens[index].DeviceName;
                    fuserMonitorIndex = index;
                }
                catch (Exception e)
                {
                    controller.Log("Sortie fuser indisponible : " + e.Message);
                    ReturnToOverlay(focusLoader: false);
                }
            }
        }
        else if (fuser.IsVisible)
        {
            fuser.Hide();
            fuserDeviceName = "";
            fuserMonitorIndex = -1;
        }
        // Keep the three nonactivating surfaces in this order. Only a show or
        // layout change raises them; normal frames never cover an open menu.
        if (fuserMoved) projectionNeedsRaise = true;
        bool projectionRaised = RefreshProjection();
        bool display = enabled && controller.Settings.EspEnabled && (controller.Settings.ShowRadar || controller.Settings.ShowHud);
        bool radarRaised = false;
        if (display)
        {
            if (!radar.IsVisible) { radar.Show(); layoutKey = ""; radarRaised = true; }
            radar.Refresh();
            string key = MonitorLayoutKey(radar) + "|" + controller.Settings.OverlayAnchor + "|" + controller.Settings.RadarSize + "|" + controller.Settings.ShowHud + "|" + controller.Settings.ShowRadar +
                "|" + controller.Settings.PlayerEsp.Enabled + "|" + controller.Settings.PlayerFeatures.ShowPinnedCard + "|" + controller.Settings.PlayerFeatures.ProximityAlerts +
                "|" + controller.Settings.PvpSense.ShowBloodMoon + "|" + controller.Settings.PvpSense.ShowZombieTarget;
            if (layoutKey != key) { Position(radar, false); layoutKey = key; radarRaised = true; }
            else if (fuserMoved || projectionRaised) { RaiseWithoutActivation(radar); radarRaised = true; }
        }
        else if (radar.IsVisible) radar.Hide();
        if (menu.IsVisible)
        {
            menu.Refresh();
            string menuKey = MonitorLayoutKey(menu);
            if (menuLayoutKey != menuKey) { Position(menu, true); menuLayoutKey = MonitorLayoutKey(menu); }
            else if (fuserMoved || projectionRaised || radarRaised) RaiseWithoutActivation(menu);
        }
    }

    private void RefreshPlayerNoticeSound()
    {
        var settings = controller.Settings;
        var players = controller.Players.ReadSnapshot();
        bool allowed = enabled && settings.EspEnabled && settings.PlayerEsp.Enabled && settings.ShowHud &&
            settings.PlayerFeatures.ProximityAlerts && settings.PlayerFeatures.AlertSound && players.HasCurrentData &&
            controller.CurrentFrame?.IsFresh == true;
        if (!noticeSound.TryConsume(players.Notice, allowed)) return;
        try { System.Media.SystemSounds.Exclamation.Play(); }
        catch (Exception ex) { controller.Log("Son de proximité indisponible : " + ex.GetBaseException().Message); }
    }

    private void RefreshAdminWatch()
    {
        var setting = controller.Settings.AdminWatch;
        var sample = controller.CurrentFrame;
        uint process = controller.Status.ProcessId;
        if (watchedProcessId != process || sample?.IsFresh != true || setting?.Enabled != true)
        {
            watchedNearbyIds.Clear(); watchedProcessId = process;
            return;
        }
        var matches = AdminWatchMatcher.Nearby(sample, setting);
        var current = matches.Select(e => e.EntityId).ToHashSet();
        bool arrival = current.Any(id => !watchedNearbyIds.Contains(id));
        watchedNearbyIds.Clear();
        watchedNearbyIds.UnionWith(current);
        long now = System.Diagnostics.Stopwatch.GetTimestamp();
        if (!arrival || !setting.Sound || !enabled || !controller.Settings.EspEnabled ||
            now - watchedLastSoundAt < System.Diagnostics.Stopwatch.Frequency * (long)Math.Clamp(setting.CooldownSeconds, 5, 120)) return;
        watchedLastSoundAt = now;
        try { System.Media.SystemSounds.Asterisk.Play(); }
        catch (Exception ex) { controller.Log("Son surveillance indisponible : " + ex.GetBaseException().Message); }
    }

    private void RefreshZombieTargetSound()
    {
        var setting = controller.Settings.PvpSense;
        var sample = controller.CurrentFrame;
        uint process = controller.Status.ProcessId;
        int local = sample?.IsFresh == true ? sample.Snapshot.LocalId : -1;
        string? context = sample?.IsFresh == true ? sample.Snapshot.PlayerContextId : null;
        if (!enabled || !controller.Settings.EspEnabled || !setting.ShowZombieTarget || sample?.IsFresh != true)
        {
            targetedZombieIds.Clear();
            targetedZombieContextId = null;
            return;
        }
        var current = sample.Snapshot.Entities.Where(e => e.Kind == "zombie" && e.ZombieTargetsLocal == true)
            .Select(e => e.EntityId).ToHashSet();
        if (targetedZombieProcessId != process || targetedZombiePlayerId != local ||
            !string.Equals(targetedZombieContextId, context, StringComparison.Ordinal))
        {
            targetedZombieIds.Clear();
            targetedZombieIds.UnionWith(current);
            targetedZombieProcessId = process;
            targetedZombiePlayerId = local;
            targetedZombieContextId = context;
            // First frame of a new context establishes the baseline; no stale beep.
            return;
        }
        bool newTarget = current.Any(id => !targetedZombieIds.Contains(id));
        targetedZombieIds.Clear();
        targetedZombieIds.UnionWith(current);
        long now = System.Diagnostics.Stopwatch.GetTimestamp();
        if (!newTarget || !setting.ZombieTargetSound ||
            now - lastZombieSoundAt < System.Diagnostics.Stopwatch.Frequency *
                (long)Math.Clamp(setting.SoundCooldownSeconds, 5, 120)) return;
        lastZombieSoundAt = now;
        try { System.Media.SystemSounds.Exclamation.Play(); }
        catch (Exception ex) { controller.Log("Alerte zombie indisponible : " + ex.GetBaseException().Message); }
    }

    private bool RefreshProjection()
    {
        var settings = controller.Settings;
        if (!enabled) return ClearProjection("Superposition arrêtée.", hideSurface: true);
        if (!settings.EspEnabled) return ClearProjection("Affichage désactivé · " + DisplayKey(settings.ToggleKey) + " pour réactiver.", hideSurface: true);
        if (!settings.ShowProjectedEsp) return ClearProjection("ESP projeté désactivé dans le menu.", hideSurface: true);
        if (!EspDisplayPolicy.HasProjectedProfile(settings))
            return ClearProjection("Aucun élément ESP activé dans les profils Joueurs et Zombies.", hideSurface: true);
        var sample = controller.CurrentFrame;
        if (sample == null || !sample.IsFresh)
            return ClearProjection("ESP en attente de positions récentes.", resetCache: true);
        if (!sample.IsProjectionFresh)
        {
            if (sample.AgeMs >= FeedSample.ProjectionLifetimeMs)
                return ClearProjection("ESP suspendu : capture de " + Math.Round(sample.AgeMs) + " ms, limite " +
                    FeedSample.ProjectionLifetimeMs + " ms.", resetCache: true);
            sample.TryGetProjectionView(out _, out var reason);
            return ClearProjection("ESP en attente : " + reason, resetCache: true);
        }
        var screens = System.Windows.Forms.Screen.AllScreens;
        int monitorIndex = settings.MonitorIndex;
        if (monitorIndex < 0 || monitorIndex >= screens.Length)
            return ClearProjection("ESP suspendu : l’écran sélectionné est indisponible.", hideSurface: true);
        if (settings.OutputMode == "fuser" && !fuser.IsVisible)
            return ClearProjection("ESP suspendu : la sortie fuser est fermée.", hideSurface: true);

        try
        {
            // FeedSample owns a received capture. Compute geometry once for that
            // object; rendering and filter changes reuse its immutable result.
            if (!ReferenceEquals(projectedSample, sample))
            {
                projectedSample = sample;
                projectedFrame = null;
                projectionFailure = "";
                if (sample.TryGetProjectionView(out var view, out var reason))
                {
                    var snapshot = sample.Snapshot;
                    var bounds = ValidatedBounds(snapshot);
                    if (!ProjectionMath.TryBuildFrame(view, snapshot.LocalPosition, snapshot.LocalId,
                        snapshot.Entities, bounds, out projectedFrame, out reason, snapshot.PlayerContextId)) projectionFailure = reason;
                }
                else projectionFailure = reason;
            }
            if (projectedFrame == null)
                return ClearProjection("ESP suspendu : " + projectionFailure);
            var screen = screens[monitorIndex];
            // Source projection remains cached for this capture. Output mapping
            // is recalculated on every refresh so mode/monitor changes never need
            // a new memory capture and never reset the sample's freshness clock.
            if (!ProjectionOutputMapping.TryCreate(projectedFrame.SourceWidth, projectedFrame.SourceHeight,
                screen.Bounds.Width, screen.Bounds.Height, projectedFrame.Viewport, settings.EspScaleMode,
                out var outputMapping, out var mappingReason))
                return ClearProjection("ESP suspendu : " + mappingReason, hideSurface: true);
            var mapping = outputMapping!;
            if (!mapping.HasVisibleViewport)
                return ClearProjection("ESP sans repère : le viewport caméra est entièrement recadré par le mode d’adaptation choisi.");
            // Geometry for a large capture may take time. Do not publish it if
            // it expired while being projected on the UI thread.
            if (!sample.IsProjectionFresh)
                return ClearProjection("ESP suspendu : capture expirée pendant la projection.", resetCache: true);

            bool raised = projectedEsp.ShowOn(screen);
            if (projectionNeedsRaise && !raised) { RaiseWithoutActivation(projectedEsp); raised = true; }
            projectionNeedsRaise = false;
            if (!ReferenceEquals(publishedProjectionSample, sample))
            {
                projectedEsp.Publish(projectedFrame, sample.InitialAgeMs, sample.ReceivedTimestamp, FeedSample.ProjectionLifetimeMs);
                publishedProjectionSample = sample;
            }
            projectedEsp.Refresh();
            projectionStatus = "ESP en attente du rendu de la capture courante.";
            return raised;
        }
        catch (Exception e)
        {
            return ClearProjection("ESP indisponible : " + e.Message, resetCache: true, hideSurface: true);
        }
    }

    private static Dictionary<int, ProjectionEntityBounds> ValidatedBounds(LiveEntitySnapshot snapshot)
    {
        var result = new Dictionary<int, ProjectionEntityBounds>();
        foreach (var entity in snapshot.Entities)
        {
            var bounds = entity.Bounds;
            if (bounds == null || !FeedSample.ValidPosition(bounds.Center) || !FeedSample.ValidPosition(bounds.Extents)) continue;
            var c = bounds.Center;
            var e = bounds.Extents;
            // Same deliberately broad entity-volume limits as the live reader;
            // validate again for a remote frame. No serialized trust flag exists.
            if (e.X <= 0 || e.Y <= 0 || e.Z <= 0 || e.X > 64 || e.Y > 64 || e.Z > 64) continue;
            var minimum = new LivePosition { X = c.X - e.X, Y = c.Y - e.Y, Z = c.Z - e.Z };
            var maximum = new LivePosition { X = c.X + e.X, Y = c.Y + e.Y, Z = c.Z + e.Z };
            if (!FeedSample.ValidPosition(minimum) || !FeedSample.ValidPosition(maximum) ||
                minimum.X >= maximum.X || minimum.Y >= maximum.Y || minimum.Z >= maximum.Z) continue;
            result[entity.EntityId] = new ProjectionEntityBounds(entity.EntityId, minimum, maximum, true);
        }
        return result;
    }

    private bool ClearProjection(string reason, bool resetCache = false, bool hideSurface = false)
    {
        projectedEsp.Clear();
        // Missing/stale camera data clears the drawing immediately, but keeps an
        // already-open transparent HWND in place. Repeated Hide/Show would raise
        // ESP, radar and menu again for every intermittent successful capture.
        if (hideSurface)
        {
            if (projectedEsp.IsVisible) projectedEsp.Hide();
            projectionNeedsRaise = false;
        }
        publishedProjectionSample = null;
        if (resetCache) { projectedSample = null; projectedFrame = null; projectionFailure = ""; }
        projectionStatus = reason;
        return false;
    }

    private static string FormatPixels(double value) => value.ToString("0.##", CultureInfo.GetCultureInfo("fr-FR"));

    private static string ScaleModeLabel(string mode) => mode switch
    {
        ProjectionOutputMapping.Fit => "ajuster, proportions conservées",
        ProjectionOutputMapping.Stretch => "étirer sur toute la sortie",
        ProjectionOutputMapping.Fill => "remplir et recadrer au centre",
        _ => "adaptation inconnue"
    };

    private string MonitorLayoutKey(Window window)
    {
        var screens = System.Windows.Forms.Screen.AllScreens;
        if (screens.Length == 0) return "none";
        int index = Math.Clamp(controller.Settings.MonitorIndex, 0, screens.Length - 1);
        var screen = screens[index];
        var h = new WindowInteropHelper(window).Handle;
        return index + "|" + screen.DeviceName + "|" + screen.Bounds + "|" + Native.GetDpiForWindow(h);
    }

    private void RegisterKeys()
    {
        UnregisterKeys();
        registeredMenu = controller.Settings.MenuKey;
        registeredToggle = controller.Settings.ToggleKey;
        registeredPlayers = controller.Settings.PlayersKey;
        registeredZombies = controller.Settings.ZombiesKey;
        registeredRadar = controller.Settings.RadarKey;
        registeredCreative = CreativeKey();
        menuRegistered = Register(registeredMenu, 101);
        toggleRegistered = Register(registeredToggle, 102);
        playersRegistered = Register(registeredPlayers, 104);
        zombiesRegistered = Register(registeredZombies, 105);
        radarRegistered = Register(registeredRadar, 106);
        creativeRegistered = Register(registeredCreative, 107);
        fuserExitRegistered = Native.RegisterHotKey(ownerHandle, 103, 0x4003, (uint)KeyInterop.VirtualKeyFromKey(Key.F11));
        HotkeyStatus = BindingStatus(registeredMenu, menuRegistered, "menu") + "     " +
            BindingStatus(registeredToggle, toggleRegistered, "afficher / masquer") + "     " +
            BindingStatus(registeredPlayers, playersRegistered, "joueurs") + "     " +
            BindingStatus(registeredZombies, zombiesRegistered, "zombies") + "     " +
            BindingStatus(registeredRadar, radarRegistered, "radar") + "     " +
            BindingStatus(registeredCreative, creativeRegistered, "créatif");
        HotkeyStatus += fuserExitRegistered ? "     Ctrl+Alt+F11 · quitter le fuser" : "     Ctrl+Alt+F11 occupé · sortie fuser indisponible";
        if (!menuRegistered || !toggleRegistered || !fuserExitRegistered ||
            (registeredPlayers.Length > 0 && !playersRegistered) || (registeredZombies.Length > 0 && !zombiesRegistered) ||
            (registeredRadar.Length > 0 && !radarRegistered) || (registeredCreative.Length > 0 && !creativeRegistered))
            controller.Log("Raccourcis : " + HotkeyStatus + ". Modifie une touche occupée dans Réglages ; les boutons restent utilisables.");
    }

    private static string BindingStatus(string key, bool registered, string action) => key.Length == 0
        ? action + " · sans raccourci"
        : DisplayKey(key) + " · " + action + (registered ? "" : " (touche occupée)");

    private string CreativeKey() => controller.Settings.Mode == "reader" ? controller.Settings.CreativeMenuKey : "";

    private void UnregisterKeys()
    {
        if (menuRegistered) Native.UnregisterHotKey(ownerHandle, 101);
        if (toggleRegistered) Native.UnregisterHotKey(ownerHandle, 102);
        if (fuserExitRegistered) Native.UnregisterHotKey(ownerHandle, 103);
        if (playersRegistered) Native.UnregisterHotKey(ownerHandle, 104);
        if (zombiesRegistered) Native.UnregisterHotKey(ownerHandle, 105);
        if (radarRegistered) Native.UnregisterHotKey(ownerHandle, 106);
        if (creativeRegistered) Native.UnregisterHotKey(ownerHandle, 107);
        menuRegistered = toggleRegistered = fuserExitRegistered = playersRegistered = zombiesRegistered = radarRegistered = creativeRegistered = false;
    }
    private bool Register(string name, int id)
    {
        if (!Enum.TryParse<Key>(name, out var key)) return false;
        return Native.RegisterHotKey(ownerHandle, id, 0x4000, (uint)KeyInterop.VirtualKeyFromKey(key));
    }
    private IntPtr WindowMessage(IntPtr h, int message, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (disposed) return IntPtr.Zero;
        if (message == 0x007E || message == 0x02E0)
        {
            layoutKey = ""; menuLayoutKey = "";
            ClearProjection("L’affichage a changé : repositionnement de l’ESP en cours.", hideSurface: true);
        }
        if (message != 0x0312) return IntPtr.Zero;
        int id = wParam.ToInt32();
        if (id == 101) { ToggleMenu(); handled = true; }
        else if (id == 102) { enabled = true; controller.ToggleEsp(); Refresh(); handled = true; }
        else if (id == 103) { ReturnToOverlay(); Refresh(); handled = true; }
        else if (id == 104) { enabled = true; controller.TogglePlayers(); Refresh(); handled = true; }
        else if (id == 105) { enabled = true; controller.ToggleZombies(); Refresh(); handled = true; }
        else if (id == 106) { enabled = true; controller.ToggleRadar(); Refresh(); handled = true; }
        else if (id == 107) { _ = ToggleCreativeAsync(); handled = true; }
        return IntPtr.Zero;
    }

    private async Task ToggleCreativeAsync()
    {
        try { await controller.ToggleCreativeMenuAsync(); }
        catch (Exception error) { controller.Log("[MENU_CREATIF] Raccourci non exécuté : " + error.GetBaseException().Message); }
    }
    private static void RaiseWithoutActivation(Window window) =>
        Native.SetWindowPos(new WindowInteropHelper(window).Handle, new IntPtr(-1), 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010);

    private void Position(Window window, bool centered)
    {
        var screens = System.Windows.Forms.Screen.AllScreens;
        if (screens.Length == 0) return;
        var bounds = screens[Math.Clamp(controller.Settings.MonitorIndex, 0, screens.Length - 1)].Bounds;
        var hwnd = new WindowInteropHelper(window).Handle;
        // Screen coordinates are physical pixels. Move first so Windows/WPF apply
        // the destination monitor's DPI, then size using that HWND's effective DPI.
        Native.SetWindowPos(hwnd, new IntPtr(-1), bounds.Left + 20, bounds.Top + 20, 0, 0, 0x0001 | 0x0010);
        double scale = Native.GetDpiForWindow(hwnd) / 96.0;
        if (scale <= 0) scale = 1;
        int width = (int)Math.Ceiling((centered ? OverlayMenu.PreferredWidth : window.Width) * scale);
        int height = (int)Math.Ceiling((centered ? OverlayMenu.PreferredHeight : window.Height) * scale);
        width = Math.Min(width, Math.Max(200, bounds.Width - 24));
        height = Math.Min(height, Math.Max(200, bounds.Height - 24));
        int x, y;
        if (centered) { x = bounds.Left + (bounds.Width - width) / 2; y = bounds.Top + (bounds.Height - height) / 2; }
        else
        {
            bool left = controller.Settings.OverlayAnchor.EndsWith("Left", StringComparison.Ordinal);
            bool bottom = controller.Settings.OverlayAnchor.StartsWith("Bottom", StringComparison.Ordinal);
            x = left ? bounds.Left + 18 : bounds.Right - width - 18;
            y = bottom ? bounds.Bottom - height - 18 : bounds.Top + 18;
        }
        Native.SetWindowPos(hwnd, new IntPtr(-1), x, y, width, height, 0x0010);
    }
    internal static string DisplayKey(string name) => name == "Insert" ? "INSER" : name == "Home" ? "DÉBUT" : name;
    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        UnregisterKeys();
        source.RemoveHook(WindowMessage);
        ClearProjection("ESP arrêté.", resetCache: true, hideSurface: true);
        menu.PermitClose = true;
        menu.Close();
        radar.Close();
        projectedEsp.Close();
        fuser.Close();
    }
}

internal sealed class RadarOverlay : Window
{
    private readonly ILoaderController controller;
    private readonly RadarControl radar;
    private readonly TextBlock header;
    private readonly TextBlock status;
    private readonly TextBlock keys;
    private readonly Border card;
    private readonly PlayerHudContent players;

    internal RadarOverlay(ILoaderController controller)
    {
        this.controller = controller;
        WindowStyle = WindowStyle.None; ResizeMode = ResizeMode.NoResize;
        AllowsTransparency = true; Background = Brushes.Transparent;
        ShowInTaskbar = false; ShowActivated = false; Topmost = true;
        IsHitTestVisible = false;
        FontFamily = new FontFamily("Segoe UI");
        header = Theme.Text("AVENTURA  /  RADAR EN DIRECT", 12, Theme.Cyan, true);
        radar = new RadarControl(controller);
        status = Theme.Text("En attente de données", 11, Theme.Muted);
        keys = Theme.Text("", 10, Theme.Muted);
        players = new PlayerHudContent(controller);
        var stack = Theme.Stack(header, radar, status, keys, players);
        card = new Border { Background = Theme.Surface, BorderBrush = Theme.Line, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(16), Padding = new Thickness(15), Child = stack };
        Content = new Viewbox { Stretch = Stretch.Uniform, StretchDirection = StretchDirection.DownOnly, Child = card };
        SourceInitialized += (_, _) =>
        {
            var h = new WindowInteropHelper(this).Handle;
            long styles = Native.GetWindowLongPtr(h, -20).ToInt64();
            Native.SetWindowLongPtr(h, -20, new IntPtr(styles | 0x20L | 0x08000000L | 0x80L));
            HwndSource.FromHwnd(h)?.AddHook(PassThrough);
        };
        Refresh();
    }
    private static IntPtr PassThrough(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (msg == 0x0084) { handled = true; return new IntPtr(-1); } // HTTRANSPARENT
        if (msg == 0x0021) { handled = true; return new IntPtr(3); } // MA_NOACTIVATE
        return IntPtr.Zero;
    }
    internal void Refresh()
    {
        var s = controller.Settings;
        double naturalWidth = s.RadarSize + 26;
        // Keep enough room for wrapped status/key text at the smallest radar size.
        double naturalHeight = (s.ShowRadar ? s.RadarSize : 0) + (s.ShowHud ? 142 : 26) + players.ReservedHeight;
        double fit = 1;
        var screens = System.Windows.Forms.Screen.AllScreens;
        if (screens.Length > 0)
        {
            var bounds = screens[Math.Clamp(s.MonitorIndex, 0, screens.Length - 1)].Bounds;
            double scale = Native.GetDpiForWindow(new WindowInteropHelper(this).Handle) / 96.0;
            if (scale <= 0) scale = 1;
            fit = Math.Min(1, Math.Min(Math.Max(1, bounds.Width - 36) / scale / naturalWidth,
                Math.Max(1, bounds.Height - 36) / scale / naturalHeight));
        }
        // Scale the entire card when necessary, including labels and HUD. Merely
        // clipping the HWND would leave fixed-size child content cut off at 200%.
        card.Width = naturalWidth;
        card.Height = naturalHeight;
        Width = naturalWidth * fit;
        Height = naturalHeight * fit;
        card.Opacity = s.RadarOpacity;
        radar.Width = s.RadarSize; radar.Height = s.RadarSize;
        radar.Visibility = s.ShowRadar ? Visibility.Visible : Visibility.Collapsed;
        header.Visibility = status.Visibility = keys.Visibility = s.ShowHud ? Visibility.Visible : Visibility.Collapsed;
        header.Text = s.ShowRadar ? "7DTD  /  RADAR" : "7DTD  /  HUD";
        players.Refresh();
        var frame = controller.CurrentFrame;
        status.Text = frame?.IsFresh == true
            ? frame.Snapshot.PlayersCount + " joueur(s)   ·   " + frame.Snapshot.ZombiesCount + " zombie(s)   ·   " + Math.Round(frame.AgeMs) + " ms"
            : "Données absentes ou expirées · aucun repère";
        keys.Text = OverlayManager.DisplayKey(s.MenuKey) + " menu  ·  " + OverlayManager.DisplayKey(s.ToggleKey) + " afficher / masquer";
        radar.InvalidateVisual();
    }
}

internal sealed class OverlayMenu : Window
{
    internal const double PreferredWidth = 620;
    internal const double PreferredHeight = 780;
    private readonly SettingsPanel settings;
    private readonly TextBlock state;
    private readonly Button stopFuser;
    private readonly ILoaderController controller;
    internal bool PermitClose { get; set; }
    internal OverlayMenu(ILoaderController controller, Action hide, Action returnToOverlay)
    {
        this.controller = controller;
        Width = PreferredWidth; Height = PreferredHeight; MinWidth = 360;
        SizeToContent = SizeToContent.Manual;
        WindowStartupLocation = WindowStartupLocation.Manual;
        WindowStyle = WindowStyle.None; ResizeMode = ResizeMode.NoResize;
        ShowInTaskbar = false; Topmost = true;
        AllowsTransparency = true;
        Theme.Apply(this); Background = Brushes.Transparent;
        var root = new Grid();
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(4) });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1) });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        var stripe = new Border { Background = Theme.Gradient("#72E6FA", "#FFAD72"),
            CornerRadius = new CornerRadius(10, 10, 0, 0) };
        root.Children.Add(stripe);

        var header = new Grid { Margin = new Thickness(23, 20, 23, 19) };
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        var emblem = new Border
        {
            Width = 44, Height = 44, CornerRadius = new CornerRadius(12),
            Background = Theme.Gradient("#FFB981", "#E97C45"), Margin = new Thickness(0, 0, 13, 0),
            Child = new TextBlock { Text = "7", FontSize = 25, FontWeight = FontWeights.Bold,
                Foreground = Theme.Background, HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center }
        };
        header.Children.Add(emblem);
        var title = Theme.Text("AVENTURA  /  DMA STUDIO", 17, Theme.Foreground, true);
        title.Margin = new Thickness(0, 0, 0, 4);
        var subtitle = Theme.Text("CENTRE DE CONTRÔLE  ·  MENU INSER", 10.5, Theme.Cyan, true);
        subtitle.Margin = new Thickness(0);
        var heading = Theme.Stack(title, subtitle);
        heading.VerticalAlignment = VerticalAlignment.Center;
        heading.MouseLeftButtonDown += (_, e) => { if (e.LeftButton == MouseButtonState.Pressed) DragMove(); };
        Grid.SetColumn(heading, 1); header.Children.Add(heading);
        var close = Theme.Button("✕", hide);
        close.Margin = new Thickness(10, 0, 0, 0);
        close.Width = 39; close.Height = 39; close.MinHeight = 39;
        close.Padding = new Thickness(0); close.FontSize = 16;
        close.ToolTip = "Fermer le menu (Échap)";
        Grid.SetColumn(close, 2); header.Children.Add(close);
        Grid.SetRow(header, 1); root.Children.Add(header);
        var rule = new Border { Background = Theme.Line };
        Grid.SetRow(rule, 2); root.Children.Add(rule);

        settings = new SettingsPanel(controller);
        var scroll = new ScrollViewer
        {
            Content = settings, VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            Padding = new Thickness(0, 0, 9, 0), Margin = new Thickness(22, 18, 15, 0)
        };
        Grid.SetRow(scroll, 3); root.Children.Add(scroll);

        state = Theme.Text("", 11.5, Theme.Muted);
        state.Margin = new Thickness(0, 0, 0, 12);
        state.Height = 39;
        state.LineHeight = 18;
        state.LineStackingStrategy = LineStackingStrategy.BlockLineHeight;
        state.TextWrapping = TextWrapping.NoWrap;
        state.TextTrimming = TextTrimming.CharacterEllipsis;
        state.ClipToBounds = true;
        stopFuser = Theme.Button("Quitter la sortie fuser  ·  retour à l’overlay", returnToOverlay);
        stopFuser.Margin = new Thickness(0); stopFuser.MinHeight = 39;
        var footer = Theme.Stack(state, stopFuser);
        var footerBorder = new Border
        {
            Background = Theme.Gradient("#172638", "#132030"),
            BorderBrush = Theme.Line, BorderThickness = new Thickness(0, 1, 0, 0),
            Padding = new Thickness(23, 14, 23, 14), Child = footer
        };
        Grid.SetRow(footerBorder, 4); root.Children.Add(footerBorder);
        var shell = new Border { Child = root, Background = Theme.Surface, BorderBrush = Theme.Line,
            BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(16), ClipToBounds = true,
            Margin = new Thickness(7) };
        Content = shell;
        KeyDown += (_, e) => { if (e.Key == Key.Escape) { hide(); e.Handled = true; } };
        Closing += (_, e) => { if (!PermitClose) { e.Cancel = true; hide(); } };
    }

    internal void Refresh()
    {
        settings.Refresh();
        string text = (controller.Settings.EspEnabled ? "●  ESP ACTIF" : "●  ESP INACTIF") +
            "    ·    Menu  " + OverlayManager.DisplayKey(controller.Settings.MenuKey) +
            "    ·    Échap pour fermer" + (controller.Settings.OutputMode == "fuser"
                ? "\nSortie fuser : Ctrl+Alt+F11 pour revenir à l’overlay." :
                  "\nRaccourcis et sons déclenchés sur le PC lecteur.");
        if (state.Text != text) state.Text = text;
        // Reserve the footer's space even outside fuser mode. A changing live
        // diagnostic must not resize the scroll viewport or move its controls.
        stopFuser.Visibility = controller.Settings.OutputMode == "fuser" ? Visibility.Visible : Visibility.Hidden;
    }
}

internal static class Native
{
    [StructLayout(LayoutKind.Sequential)] internal struct WindowRectangle
    {
        internal int Left;
        internal int Top;
        internal int Right;
        internal int Bottom;
    }
    [DllImport("user32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool RegisterHotKey(IntPtr hWnd, int id, uint modifiers, uint virtualKey);
    [DllImport("user32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool UnregisterHotKey(IntPtr hWnd, int id);
    [DllImport("user32.dll")] internal static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool IsWindow(IntPtr hWnd);
    [DllImport("user32.dll", EntryPoint = "GetWindowLongPtrW", SetLastError = true)] internal static extern IntPtr GetWindowLongPtr(IntPtr hWnd, int index);
    [DllImport("user32.dll", EntryPoint = "SetWindowLongPtrW", SetLastError = true)] internal static extern IntPtr SetWindowLongPtr(IntPtr hWnd, int index, IntPtr value);
    [DllImport("user32.dll", SetLastError = true)] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int x, int y, int width, int height, uint flags);
    [DllImport("user32.dll")] internal static extern uint GetDpiForWindow(IntPtr hWnd);
    [DllImport("user32.dll")] [return: MarshalAs(UnmanagedType.Bool)] internal static extern bool GetWindowRect(IntPtr hWnd, out WindowRectangle rectangle);
}
