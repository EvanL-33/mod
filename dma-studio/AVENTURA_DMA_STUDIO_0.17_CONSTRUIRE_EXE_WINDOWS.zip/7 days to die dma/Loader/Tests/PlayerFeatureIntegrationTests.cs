using System;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class PlayerFeatureIntegrationTests
{
    public static Task OldSettingsUseQuietDefaults()
    {
        var settings = JsonSerializer.Deserialize<LoaderSettings>("{\"EspProfilesVersion\":1,\"PlayerEsp\":{\"Enabled\":false}}")!;
        SettingsStore.Normalize(settings);
        Check(!settings.PlayerEsp.Enabled && settings.ZombieEsp.Enabled,
            "The player feature migration changed existing category visibility.");
        Check(!settings.PlayerFeatures.ProximityAlerts && !settings.PlayerFeatures.AlertSound &&
            !settings.PlayerFeatures.OffscreenIndicators && settings.PlayerFeatures.AvoidLabelOverlap,
            "Old settings enabled new notifications or lost the default label guard.");
        settings.PlayerFeatures = null!;
        SettingsStore.Normalize(settings);
        Check(settings.PlayerFeatures != null && !settings.PlayerFeatures.ProximityAlerts,
            "An explicit null player feature section did not recover safely.");
        return Task.CompletedTask;
    }

    public static Task FeatureOptionsAreBoundedWithoutResettingPreferences()
    {
        var settings = new LoaderSettings
        {
            PlayerFeatures = new PlayerFeaturesSettings
            {
                MaximumOffscreenIndicators = int.MaxValue, AlertDistance = -1,
                AlertRearmMargin = int.MaxValue, AlertCooldownSeconds = 0,
                OffscreenIndicators = true, ProximityAlerts = true, AlertSound = true,
                AvoidLabelOverlap = false, ShowPinnedCard = false
            }
        };
        SettingsStore.Normalize(settings);
        var p = settings.PlayerFeatures;
        Check(p.MaximumOffscreenIndicators == 32 && p.AlertDistance == 10 &&
            p.AlertRearmMargin == 100 && p.AlertCooldownSeconds == 3,
            "Invalid feature values were not bounded before storage.");
        Check(p.OffscreenIndicators && p.ProximityAlerts && p.AlertSound && !p.AvoidLabelOverlap && !p.ShowPinnedCard,
            "Normalization changed explicit user choices.");
        string before = JsonSerializer.Serialize(settings);
        SettingsStore.Normalize(settings);
        Check(before == JsonSerializer.Serialize(settings), "Feature normalization is not idempotent.");
        p.MaximumOffscreenIndicators = 0; p.AlertDistance = int.MaxValue;
        p.AlertRearmMargin = -2; p.AlertCooldownSeconds = int.MaxValue;
        SettingsStore.Normalize(settings);
        Check(p.MaximumOffscreenIndicators == 1 && p.AlertDistance == 1000 &&
            p.AlertRearmMargin == 5 && p.AlertCooldownSeconds == 120, "Opposite boundaries were not enforced.");
        return Task.CompletedTask;
    }

    public static Task FeaturePreferencesRoundtripWithIndependentProfiles()
    {
        string directory = Path.Combine(Path.GetTempPath(), "7dtd-player-options-" + Guid.NewGuid().ToString("N"));
        try
        {
            var store = new SettingsStore(directory);
            var settings = new LoaderSettings { EspProfilesVersion = 1, SdkDirectory = @"D:\Custom DMA\sdk" };
            settings.PlayerEsp.Color = "#ABCDEF";
            settings.ZombieEsp.Color = "#123456";
            settings.PlayerFeatures.ProximityAlerts = true;
            settings.PlayerFeatures.AlertsMarkedOnly = true;
            settings.PlayerFeatures.OffscreenIndicators = true;
            settings.PlayerFeatures.AlertDistance = 137;
            settings.PlayerFeatures.AlertRearmMargin = 23;
            settings.PlayerFeatures.AlertCooldownSeconds = 42;
            store.Save(settings);
            var read = store.Load();
            Check(read.PlayerFeatures.ProximityAlerts && read.PlayerFeatures.AlertsMarkedOnly &&
                read.PlayerFeatures.OffscreenIndicators && read.PlayerFeatures.AlertDistance == 137 &&
                read.PlayerFeatures.AlertRearmMargin == 23 && read.PlayerFeatures.AlertCooldownSeconds == 42,
                "Saved player feature choices did not survive a restart.");
            Check(read.SdkDirectory == settings.SdkDirectory && read.PlayerEsp.Color == "#ABCDEF" &&
                read.ZombieEsp.Color == "#123456", "Feature settings changed the SDK or independent profiles.");
            Check(!File.ReadAllText(store.FilePath).Contains("IdentityToken", StringComparison.Ordinal),
                "Transient player identity leaked into permanent settings.");
        }
        finally { if (Directory.Exists(directory)) Directory.Delete(directory, true); }
        return Task.CompletedTask;
    }

    public static Task DetailsConsumerRequiresOnlyPlayerDetails()
    {
        var settings = new LoaderSettings { EspProfilesVersion = 1, EspEnabled = false, ShowRadar = false, ShowProjectedEsp = false };
        settings.PlayerEsp.Enabled = settings.ZombieEsp.Enabled = false;
        var list = LiveReadPolicy.FromSettings(settings, false, playerDetails: true);
        Check(list.PlayerNames && list.PlayerHealth && !list.ZombieNames && !list.ZombieHealth,
            "A visible player list did not request its details independently of ESP, or requested zombie details.");
        var closed = LiveReadPolicy.FromSettings(settings, false, playerDetails: false);
        Check(!closed.PlayerNames && !closed.PlayerHealth && !closed.ZombieNames && !closed.ZombieHealth,
            "Closing the last detail view did not release the optional reads.");
        var shared = LiveReadPolicy.FromSettings(settings, true, playerDetails: false);
        Check(shared.PlayerNames && shared.PlayerHealth && shared.ZombieNames && shared.ZombieHealth,
            "Closing a local list dropped detail required by a remote display.");
        Check(!settings.EspEnabled && !settings.PlayerEsp.Enabled, "A detail consumer enabled ESP or its player profile.");
        return Task.CompletedTask;
    }

    public static Task NoticeSoundsAreConsumedOnceIncludingMutedPeriods()
    {
        var gate = new PlayerNoticeSoundGate();
        var first = new PlayerProximityNotice { Sequence = 1, PlaySound = true };
        Check(!gate.TryConsume(first, false), "A disabled overlay played an alert.");
        Check(!gate.TryConsume(first, true), "Re-enabling the overlay replayed a consumed alert.");
        var next = first with { Sequence = 2 };
        Check(gate.TryConsume(next, true) && !gate.TryConsume(next, true), "A current notice did not sound exactly once.");
        Check(!gate.TryConsume(first, true), "A late notice replayed an older sound.");
        Check(!gate.TryConsume(next with { Sequence = 3, PlaySound = false }, true), "A silent notice beeped.");
        Check(!gate.TryConsume(next with { Sequence = 3 }, true), "Enabling sound replayed a previously silent notice.");
        Check(!gate.TryConsume(null, true) && !gate.TryConsume(next with { Sequence = 0 }, true), "An empty notice was consumed as a sound.");
        return Task.CompletedTask;
    }

    private static void Check(bool condition, string message)
    {
        if (!condition) throw new InvalidOperationException(message);
    }
}
