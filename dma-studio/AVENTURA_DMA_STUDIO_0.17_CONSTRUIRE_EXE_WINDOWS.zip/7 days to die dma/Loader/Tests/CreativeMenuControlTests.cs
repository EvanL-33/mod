using System;
using System.Buffers.Binary;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using SevenDaysEsp;
using SevenDaysLoader;
using SevenDaysLoader.Services;

internal static class CreativeMenuControlTests
{
    private const string Context = "26aca9d4f5b94a048d4b1b17f654f3d9";

    public static Task MailboxCopiesConsumesAndRejectsReplay()
    {
        var state = new WorkerReadOptionsState(new());
        var request = Request(1, true);
        string originalId = request.RequestId;
        Check(state.TryQueueCreativeRequest(request), "First intent was not accepted.");
        request.RequestId = Guid.NewGuid().ToString("N"); request.DesiredEnabled = false;
        Check(!state.TryQueueCreativeRequest(Request(2, false)), "A second intent replaced an occupied mailbox.");
        var taken = state.TakeCreativeRequest()!;
        Check(taken.RequestId == originalId && taken.DesiredEnabled == true && !state.HasCreativeRequest,
            "The mailbox retained the mutable caller or did not consume the intent.");
        Check(state.TakeCreativeRequest() == null && !state.TryQueueCreativeRequest(taken), "An intent could be consumed/replayed twice.");
        var duplicateId = taken.Copy(); duplicateId.Sequence = 2;
        Check(!state.TryQueueCreativeRequest(duplicateId), "An immediate reused request ID bypassed replay rejection.");
        Check(state.TryQueueCreativeRequest(Request(2, null)), "A fresh read-only request was rejected.");
        state.ClearCreativeRequest();
        Check(state.TakeCreativeRequest() == null && !state.TryQueueCreativeRequest(Request(1, true)),
            "Clearing pending state erased the sequence history.");
        var expired = Request(3, true); expired.RequestedTimestamp -= Stopwatch.Frequency * 11;
        Check(state.TryQueueCreativeRequest(expired) && state.TryQueueCreativeRequest(Request(4, null)) &&
            state.TakeCreativeRequest()?.Sequence == 4,
            "An expired queued action stopped a new explicit refresh after capture resumed.");
        return Task.CompletedTask;
    }

    public static Task RequestValidationAndMonotonicExpiry()
    {
        var good = Request(1, null);
        CreativeMenuProtocol.ValidateRequest(good);
        Action<CreativeMenuRequest>[] corruptions =
        {
            r => r.Sequence = 0, r => r.RequestId = Guid.Empty.ToString("N"),
            r => r.RequestId = Guid.NewGuid().ToString("D"), r => r.ExpectedProcessId = 0,
            r => r.ExpectedPlayerContextId = "not a context", r => r.RequestedTimestamp = 0
        };
        foreach (var corrupt in corruptions)
        {
            var bad = good.Copy(); corrupt(bad);
            Expect<InvalidDataException>(() => CreativeMenuProtocol.ValidateRequest(bad));
        }
        long before = good.RequestedTimestamp - 1;
        long expiry = good.RequestedTimestamp + Stopwatch.Frequency * 10;
        Check(CreativeMenuProtocol.IsExpired(good, before), "A future command timestamp was accepted.");
        Check(!CreativeMenuProtocol.IsExpired(good, expiry - 1) && CreativeMenuProtocol.IsExpired(good, expiry),
            "The ten-second intent deadline was extended or shortened at its boundary.");
        return Task.CompletedTask;
    }

    public static async Task DuplexCommandsRemainSeparateFromReadOptions()
    {
        var pair = Duplex.CreatePair();
        using var server = pair.First; using var client = pair.Second;
        using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(5));
        using var stopped = new CancellationTokenSource();
        var state = new WorkerReadOptionsState(new());
        Task monitor = WorkerControlLoop.MonitorAsync(server, state, stopped);
        try
        {
            await Wire.WriteAsync(client, new WorkerControl { Kind = WorkerControl.CreativeMenuKind, CreativeMenu = Request(1, true) }, deadline.Token);
            await Until(() => state.HasCreativeRequest, deadline.Token);
            await Wire.WriteAsync(client, new WorkerControl { Kind = WorkerControl.ReadOptionsKind,
                ReadOptions = new LiveReadOptions { PlayerNames = false, ZombieNames = false } }, deadline.Token);
            await Until(() => state.Snapshot().Revision == 2, deadline.Token);
            var intent = state.TakeCreativeRequest();
            Check(intent?.DesiredEnabled == true && !monitor.IsCompleted && !stopped.IsCancellationRequested,
                "A read-options update lost the explicit intent or stopped the monitor.");
            await Wire.WriteAsync(client, new WorkerControl { Kind = WorkerControl.CreativeMenuKind, CreativeMenu = Request(2, null) }, deadline.Token);
            await Until(() => state.HasCreativeRequest, deadline.Token);
            Check(state.TakeCreativeRequest()?.DesiredEnabled == null, "Refresh did not remain read-only.");
            await Wire.WriteAsync(client, new WorkerControl { Kind = WorkerControl.StopKind }, deadline.Token);
            await monitor.WaitAsync(deadline.Token);
            Check(stopped.IsCancellationRequested && state.ControlFailure == null, "An ordinary stop was a protocol failure.");
        }
        finally { stopped.Cancel(); await monitor.WaitAsync(TimeSpan.FromSeconds(2)); }
    }

    public static async Task InvalidAndMixedCommandsCloseWithoutQueuedIntent()
    {
        string valid = System.Text.Json.JsonSerializer.Serialize(Request(1, true), Wire.Json);
        foreach (string payload in new[]
        {
            "{\"Kind\":\"creative-menu\"}",
            "{\"Kind\":\"creative-menu\",\"CreativeMenu\":{}}",
            "{\"Kind\":\"creative-menu\",\"CreativeMenu\":" + valid + ",\"ReadOptions\":{}}",
            "{\"Kind\":\"stop\",\"CreativeMenu\":" + valid + "}",
            "{\"Kind\":\"read-options\",\"ReadOptions\":{},\"CreativeMenu\":" + valid + "}"
        })
        {
            using var stream = Framed(payload);
            using var stopped = new CancellationTokenSource();
            var state = new WorkerReadOptionsState(new());
            await WorkerControlLoop.MonitorAsync(stream, state, stopped);
            Check(stopped.IsCancellationRequested && state.ControlFailure != null && !state.HasCreativeRequest,
                "A malformed/mixed control retained a runnable intent.");
        }
    }

    public static async Task StopDiscardsPendingWithoutExecution()
    {
        var pair = Duplex.CreatePair();
        using var server = pair.First; using var client = pair.Second;
        using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(5));
        using var stopped = new CancellationTokenSource();
        var state = new WorkerReadOptionsState(new());
        Task monitor = WorkerControlLoop.MonitorAsync(server, state, stopped);
        try
        {
            await Wire.WriteAsync(client, new WorkerControl { Kind = WorkerControl.CreativeMenuKind, CreativeMenu = Request(1, false) }, deadline.Token);
            await Until(() => state.HasCreativeRequest, deadline.Token);
            await Wire.WriteAsync(client, new WorkerControl { Kind = WorkerControl.StopKind }, deadline.Token);
            await monitor.WaitAsync(deadline.Token);
            Check(state.TakeCreativeRequest() == null && state.ControlFailure == null, "Shutdown retained a command for a later session.");
        }
        finally { stopped.Cancel(); await monitor.WaitAsync(TimeSpan.FromSeconds(2)); }
    }

    public static Task SessionUsesFreshLocalContextAndDoesNotMutateFeed()
    {
        var session = new CreativeMenuSession(); session.Reset(3);
        var sample = Sample();
        Expect<InvalidOperationException>(() => session.Begin(3, true));
        session.ObserveContext(3, 123, sample, false);
        Check(!session.State.CanRequest, "The remote display could submit a command.");
        session.ObserveContext(3, 123, sample, true);
        var request = session.Begin(3, null);
        Check(request.DesiredEnabled == null && session.State.IsBusy && !session.State.CanRequest,
            "A refresh became a write or a busy session accepted another action.");
        Expect<InvalidOperationException>(() => session.Begin(3, true));
        var result = Result(request, false);
        Check(session.Accept(3, result) && session.State.ObservedEnabled == false && session.State.ConfirmedUtc.HasValue,
            "A matching read result was not confirmed.");
        Check(sample.IsFresh && sample.Snapshot.Status == "ENTITES_LUES" && sample.Snapshot.PlayerContextId == Context &&
            sample.Snapshot.LocalId == 1, "Command handling mutated the ESP frame.");
        session.ObserveContext(3, 123, Sample(FeedSample.LifetimeMs), true);
        Check(!session.State.CanRequest && session.State.ObservedEnabled == null, "A stale frame kept a writable context.");
        return Task.CompletedTask;
    }

    public static Task SessionRejectsMismatchedAndPriorGenerationResults()
    {
        var session = new CreativeMenuSession(); session.Reset(4); session.ObserveContext(4, 123, Sample(), true);
        var request = session.Begin(4, true);
        var result = Result(request, true);
        Check(!session.Accept(3, result) && session.State.IsBusy, "An older generation completed the current request.");
        result.RequestId = Guid.NewGuid().ToString("N");
        Check(!session.Accept(4, result) && session.State.IsBusy, "An unrelated request ID was accepted.");
        result = Result(request, true); result.ProcessId = 999;
        Check(!session.Accept(4, result), "An unrelated process result was accepted.");
        result = Result(request, true); result.DesiredEnabled = false;
        Check(!session.Accept(4, result), "The result changed the requested operation.");
        Check(session.Accept(4, Result(request, true)), "The actual matching result was lost.");
        session.Reset(5);
        Check(!session.Accept(4, Result(request, true)) && session.State.ObservedEnabled == null,
            "Reset restored a previous operation or observed value.");
        return Task.CompletedTask;
    }

    public static Task ContextLossPreservesPendingButCannotConfirmOldParties()
    {
        var session = new CreativeMenuSession(); session.Reset(2); session.ObserveContext(2, 123, Sample(), true);
        var request = session.Begin(2, true);
        session.ObserveContext(2, 123, null, true);
        Check(session.State.IsBusy && !session.State.CanRequest, "A failed capture silently dropped an in-flight intent.");
        session.ObserveContext(2, 123, Sample(0, Guid.NewGuid().ToString("N")), true);
        Check(session.State.IsBusy, "A new world allowed concurrent submission before the prior outcome.");
        Check(session.Accept(2, Result(request, true)) && !session.State.IsBusy &&
            session.State.ObservedEnabled == null && session.State.Code == "CONTEXTE_CHANGE",
            "A previous world's enabled flag was presented as current.");
        return Task.CompletedTask;
    }

    public static Task TimeoutIsUnknownAndNeverReplays()
    {
        long now = Stopwatch.GetTimestamp();
        var session = new CreativeMenuSession(() => now, () => new DateTime(2026, 11, 16, 0, 0, 0, DateTimeKind.Utc));
        session.Reset(1); session.ObserveContext(1, 123, Sample(), true);
        var request = session.Begin(1, true);
        now += Stopwatch.Frequency * 10;
        Check(!session.State.IsBusy && session.State.ObservedEnabled == null && session.State.Code == "DELAI_DEPASSE",
            "Timeout was reported as success or retained an implicit retry.");
        Check(!session.Accept(1, Result(request, true)), "A timed-out intent was unexpectedly resurrected.");
        var next = session.Begin(1, null);
        Check(next.Sequence > request.Sequence && next.RequestId != request.RequestId && next.DesiredEnabled == null,
            "A fresh read recycled the timed-out write.");
        return Task.CompletedTask;
    }

    public static Task FailedSendDoesNotAssertRollbackOrAcceptOtherRequests()
    {
        var session = new CreativeMenuSession(); session.Reset(1); session.ObserveContext(1, 123, Sample(), true);
        var request = session.Begin(1, false);
        var other = request.Copy(); other.RequestId = Guid.NewGuid().ToString("N");
        Check(!session.FailSend(1, other, "wrong") && session.State.IsBusy, "An unrelated failure cleared the current request.");
        Check(session.FailSend(1, request, new string('x', 2048)) && !session.State.IsBusy &&
            session.State.ObservedEnabled == null && session.State.Message.Length == CreativeMenuProtocol.MaxMessageLength,
            "Failed send asserted a known flag or retained an unbounded message.");
        Check(!session.Accept(1, Result(request, false)), "A failed-send operation was silently completed later.");
        return Task.CompletedTask;
    }

    public static Task InvalidResultsCannotPublishConfirmedFlags()
    {
        var session = new CreativeMenuSession(); session.Reset(1); session.ObserveContext(1, 123, Sample(), true);
        var request = session.Begin(1, null);
        var bad = Result(request, true); bad.WriteAttempted = true;
        Check(!session.Accept(1, bad), "A refresh result reported a hardware write.");
        bad = Result(request, true); bad.Code = "INVALID CODE";
        Check(!session.Accept(1, bad), "An invalid status was accepted.");
        bad = Result(request, true); bad.Message = new string('x', 1025);
        Check(!session.Accept(1, bad) && session.State.ObservedEnabled == null && session.State.IsBusy,
            "Invalid result published its enabled value.");
        Check(session.Accept(1, Result(request, true)), "A later valid result was not accepted.");
        return Task.CompletedTask;
    }

    public static async Task HostDoesNotQueueIntentsWithoutLocalWorker()
    {
        var host = new WorkerHost();
        int failures = 0; host.ControlError += _ => failures++;
        try { await host.SendCreativeMenuAsync(Request(1, true)); throw new Exception("An idle host accepted an intent."); }
        catch (InvalidOperationException) { }
        await host.StopAsync();
        await host.DisposeAsync();
        try { await host.SendCreativeMenuAsync(Request(2, true)); throw new Exception("A disposed host accepted an intent."); }
        catch (ObjectDisposedException) { }
        Check(failures == 0, "A not-started/disposed host emitted a partial-send failure.");
    }

    public static Task ContradictoryResultsNeverConfirmStates()
    {
        var session = new CreativeMenuSession(); session.Reset(1); session.ObserveContext(1, 123, Sample(), true);
        var request = session.Begin(1, true);
        var wrongValue = Result(request, false);
        var missingWrite = Result(request, true); missingWrite.WriteAttempted = false;
        var idempotentWithWrite = Result(request, true); idempotentWithWrite.Code = "DEJA_APPLIQUE";
        var failedWithValue = Result(request, true); failedWithValue.Code = "ECHEC_ECRITURE";
        var queryForWrite = Result(request, true); queryForWrite.Code = "ETAT_LU"; queryForWrite.WriteAttempted = false;
        foreach (var invalid in new[] { wrongValue, missingWrite, idempotentWithWrite, failedWithValue, queryForWrite })
            Check(!session.Accept(1, invalid) && session.State.IsBusy && session.State.ObservedEnabled == null,
                "A contradictory result confirmed a game flag.");
        var already = Result(request, true); already.Code = "DEJA_APPLIQUE"; already.WriteAttempted = false;
        Check(session.Accept(1, already) && session.State.ObservedEnabled == true,
            "A genuinely idempotent result was not accepted.");
        var next = session.Begin(1, false);
        var uncertain = Result(next, null); uncertain.Code = "RESULTAT_INDETERMINE";
        Check(session.Accept(1, uncertain) && session.State.ObservedEnabled == null && !session.State.ConfirmedUtc.HasValue,
            "An uncertain outcome kept a previously confirmed flag.");
        var query = session.Begin(1, null);
        var wrongQueryCode = Result(query, false); wrongQueryCode.Code = "CONFIRME";
        Check(!session.Accept(1, wrongQueryCode) && session.Accept(1, Result(query, false)),
            "A refresh was classified as a confirmed write.");
        return Task.CompletedTask;
    }

    private static CreativeMenuRequest Request(long sequence, bool? desired) => new()
    {
        Sequence = sequence, RequestId = Guid.NewGuid().ToString("N"), ExpectedProcessId = 123,
        ExpectedPlayerContextId = Context, DesiredEnabled = desired, RequestedTimestamp = Stopwatch.GetTimestamp()
    };

    private static CreativeMenuResult Result(CreativeMenuRequest request, bool? observed) => new()
    {
        Sequence = request.Sequence, RequestId = request.RequestId, ProcessId = request.ExpectedProcessId,
        PlayerContextId = request.ExpectedPlayerContextId, DesiredEnabled = request.DesiredEnabled,
        ObservedEnabled = observed, WriteAttempted = request.DesiredEnabled.HasValue,
        Code = request.DesiredEnabled.HasValue ? "CONFIRME" : "ETAT_LU", Message = "État relu."
    };

    private static FeedSample Sample(double age = 0, string context = Context) => new(new LiveEntitySnapshot
    {
        Status = "ENTITES_LUES", LocalId = 1, LocalPosition = new LivePosition(),
        PlayerContextId = context, PlayerCaptureSequence = 1
    }, age);

    private static async Task Until(Func<bool> condition, CancellationToken token)
    {
        while (!condition()) await Task.Delay(1, token);
    }

    private static MemoryStream Framed(string json)
    {
        var bytes = Encoding.UTF8.GetBytes(json); var result = new MemoryStream();
        byte[] header = new byte[4]; BinaryPrimitives.WriteInt32LittleEndian(header, bytes.Length);
        result.Write(header); result.Write(bytes); result.Position = 0; return result;
    }

    private static void Check(bool condition, string message) { if (!condition) throw new Exception(message); }
    private static void Expect<T>(Action action) where T : Exception
    {
        try { action(); } catch (T) { return; }
        throw new Exception("Expected " + typeof(T).Name + ".");
    }

    // Bounded, fragmented, duplex transport for the actual Wire/control loop.
    // No Windows IPC socket or native DMA call is emulated by this stream.
    private sealed class Duplex : Stream
    {
        private readonly Channel<byte[]> incoming, outgoing;
        private readonly CancellationTokenSource lifetime = new();
        private byte[]? pending;
        private int offset;
        private bool disposed;
        private Duplex(Channel<byte[]> incoming, Channel<byte[]> outgoing) { this.incoming = incoming; this.outgoing = outgoing; }
        internal static (Duplex First, Duplex Second) CreatePair()
        {
            static Channel<byte[]> Channel() => System.Threading.Channels.Channel.CreateBounded<byte[]>(new BoundedChannelOptions(4)
                { SingleReader = true, SingleWriter = true, AllowSynchronousContinuations = false, FullMode = BoundedChannelFullMode.Wait });
            var first = Channel(); var second = Channel(); return (new(first, second), new(second, first));
        }
        public override bool CanRead => !disposed;
        public override bool CanWrite => !disposed;
        public override bool CanSeek => false;
        public override long Length => throw new NotSupportedException();
        public override long Position { get => throw new NotSupportedException(); set => throw new NotSupportedException(); }
        public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
        public override void SetLength(long value) => throw new NotSupportedException();
        public override async ValueTask<int> ReadAsync(Memory<byte> buffer, CancellationToken cancellationToken = default)
        {
            ObjectDisposedException.ThrowIf(disposed, this);
            if (buffer.Length == 0) return 0;
            using var linked = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, lifetime.Token);
            linked.Token.ThrowIfCancellationRequested();
            while (pending == null || offset == pending.Length)
            {
                try { pending = await incoming.Reader.ReadAsync(linked.Token).ConfigureAwait(false); }
                catch (ChannelClosedException) { return 0; }
                offset = 0;
            }
            int count = Math.Min(7, Math.Min(buffer.Length, pending.Length - offset));
            pending.AsMemory(offset, count).CopyTo(buffer); offset += count; return count;
        }
        public override async ValueTask WriteAsync(ReadOnlyMemory<byte> buffer, CancellationToken cancellationToken = default)
        {
            ObjectDisposedException.ThrowIf(disposed, this);
            if (buffer.Length == 0) return;
            using var linked = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, lifetime.Token);
            try { await outgoing.Writer.WriteAsync(buffer.ToArray(), linked.Token).ConfigureAwait(false); }
            catch (ChannelClosedException error) { throw new IOException("In-memory peer closed.", error); }
        }
        public override int Read(byte[] buffer, int offset, int count) => ReadAsync(buffer.AsMemory(offset, count)).AsTask().GetAwaiter().GetResult();
        public override void Write(byte[] buffer, int offset, int count) => WriteAsync(buffer.AsMemory(offset, count)).AsTask().GetAwaiter().GetResult();
        public override void Flush() => ObjectDisposedException.ThrowIf(disposed, this);
        public override Task FlushAsync(CancellationToken cancellationToken)
        { ObjectDisposedException.ThrowIf(disposed, this); cancellationToken.ThrowIfCancellationRequested(); return Task.CompletedTask; }
        protected override void Dispose(bool disposing)
        {
            if (disposing && !disposed)
            {
                disposed = true; incoming.Writer.TryComplete(); outgoing.Writer.TryComplete(); lifetime.Cancel(); lifetime.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
