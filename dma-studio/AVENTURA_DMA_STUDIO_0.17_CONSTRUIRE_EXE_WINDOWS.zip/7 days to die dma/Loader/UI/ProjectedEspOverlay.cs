using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;
using SevenDaysEsp;
using SevenDaysLoader.Services;

namespace SevenDaysLoader.UI;

// Full-screen, click-through surface above the fuser background. The manager owns
// visibility and z-order; this class never enables CanProject or discovers a camera.
internal sealed class ProjectedEspOverlay : Window
{
    private readonly ProjectedEspControl drawing;
    private readonly DispatcherTimer expiry;
    private string deviceName = "";
    private bool closed;
    internal string UnavailableReason => drawing.UnavailableReason;

    internal ProjectedEspOverlay(ILoaderController controller)
    {
        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        WindowStartupLocation = WindowStartupLocation.Manual;
        AllowsTransparency = true;
        Background = Brushes.Transparent;
        ShowInTaskbar = false;
        ShowActivated = false;
        Topmost = true;
        IsHitTestVisible = false;
        Width = 640;
        Height = 480;
        drawing = new ProjectedEspControl(controller);
        Content = drawing;
        expiry = new DispatcherTimer(DispatcherPriority.Render, Dispatcher);
        expiry.Tick += (_, _) =>
        {
            expiry.Stop();
            drawing.ExpireIfNeeded();
            ScheduleExpiry();
        };
        SourceInitialized += (_, _) =>
        {
            var handle = new WindowInteropHelper(this).Handle;
            long styles = Native.GetWindowLongPtr(handle, -20).ToInt64();
            Native.SetWindowLongPtr(handle, -20, new IntPtr(styles | 0x20L | 0x08000000L | 0x80L));
            HwndSource.FromHwnd(handle)?.AddHook(PassThrough);
        };
        IsVisibleChanged += (_, _) =>
        {
            if (!IsVisible) Clear();
            else ScheduleExpiry();
        };
        Closed += (_, _) => { closed = true; expiry.Stop(); drawing.Clear(); };
    }

    // The HWND covers the selected physical output. Geometry is mapped from the
    // source picture separately; window sizing never stretches WPF text or pens.
    // Returns true only when a show/move raised this surface: the manager can then
    // raise radar/menu once, after it. Refresh/Publish never change the z-order.
    internal bool ShowOn(System.Windows.Forms.Screen screen)
    {
        VerifyAccess();
        if (closed) throw new InvalidOperationException("La fenêtre ESP est fermée.");
        bool newlyVisible = !IsVisible;
        if (newlyVisible) Show();
        var handle = new WindowInteropHelper(this).Handle;
        var bounds = screen.Bounds;
        bool matches = Native.GetWindowRect(handle, out var actual) &&
            actual.Left == bounds.Left && actual.Top == bounds.Top &&
            actual.Right == bounds.Right && actual.Bottom == bounds.Bottom;
        bool moved = newlyVisible || deviceName != screen.DeviceName || !matches;
        if (moved)
        {
            if (!Native.SetWindowPos(handle, new IntPtr(-1), bounds.Left, bounds.Top, bounds.Width, bounds.Height, 0x0010))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "La surface ESP n’a pas pu être positionnée.");
            deviceName = screen.DeviceName;
        }
        drawing.SetOutput(bounds.Width, bounds.Height, moved);
        return moved;
    }

    internal bool TryGetRenderReceipt(ProjectedFrame expected, double sourceAgeMs, long sourceTimestamp,
        System.Windows.Forms.Screen screen, out ProjectionOutputMapping? mapping, out int markerCount, out string reason)
    {
        VerifyAccess();
        mapping = null;
        markerCount = 0;
        if (closed || !IsVisible) { reason = "La surface ESP est fermée."; return false; }
        var bounds = screen.Bounds;
        if (deviceName != screen.DeviceName || !Native.GetWindowRect(new WindowInteropHelper(this).Handle, out var actual) ||
            actual.Left != bounds.Left || actual.Top != bounds.Top || actual.Right != bounds.Right || actual.Bottom != bounds.Bottom)
        {
            reason = "Positionnement de la surface ESP en cours.";
            return false;
        }
        return drawing.TryGetRenderReceipt(expected, sourceAgeMs, sourceTimestamp, out mapping, out markerCount, out reason);
    }

    // Pass FeedSample.InitialAgeMs and FeedSample.ReceivedTimestamp, never a new
    // timestamp on each UI refresh. Re-publishing cannot rejuvenate the sample.
    internal void Publish(ProjectedFrame? frame, double initialAgeMs, long receivedTimestamp, int lifetimeMs = 250)
    {
        VerifyAccess();
        if (closed) return;
        drawing.Publish(frame, initialAgeMs, receivedTimestamp, lifetimeMs);
        ScheduleExpiry();
    }

    internal void Refresh()
    {
        VerifyAccess();
        if (closed) return;
        drawing.ExpireIfNeeded();
        drawing.InvalidateVisual();
        ScheduleExpiry();
    }

    internal void Clear()
    {
        VerifyAccess();
        expiry.Stop();
        drawing.Clear();
    }

    private void ScheduleExpiry()
    {
        expiry.Stop();
        if (closed || !IsVisible) return;
        double remaining = drawing.RemainingMs;
        if (remaining <= 0) { drawing.ExpireIfNeeded(); return; }
        expiry.Interval = TimeSpan.FromMilliseconds(Math.Max(1, remaining));
        expiry.Start();
    }

    private static IntPtr PassThrough(IntPtr hwnd, int message, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (message == 0x0084) { handled = true; return new IntPtr(-1); } // HTTRANSPARENT
        if (message == 0x0021) { handled = true; return new IntPtr(3); }  // MA_NOACTIVATE
        return IntPtr.Zero;
    }
}

internal sealed class ProjectedEspControl : FrameworkElement
{
    private readonly ILoaderController controller;
    private readonly MarkerPaint playerPaint = new();
    private readonly MarkerPaint zombiePaint = new();
    private readonly Dictionary<(string Color, double Width), MarkerPaint> customPaints = new();
    private static readonly Typeface MarkerTypeface = new("Segoe UI");
    private ProjectedFrame? frame;
    private double initialAgeMs;
    private long receivedTimestamp;
    private int lifetimeMs;
    private int outputWidth, outputHeight;
    private long presentationVersion;
    private RenderReceipt? renderReceipt;
    private RenderPerformanceToken? performanceToken;
    internal string UnavailableReason { get; private set; } = "Caméra non disponible.";
    internal double RemainingMs
    {
        get
        {
            if (frame == null || receivedTimestamp <= 0 || receivedTimestamp > Stopwatch.GetTimestamp()) return 0;
            double age = initialAgeMs + Stopwatch.GetElapsedTime(receivedTimestamp).TotalMilliseconds;
            return double.IsFinite(age) && age >= 0 ? Math.Max(0, lifetimeMs - age) : 0;
        }
    }

    internal ProjectedEspControl(ILoaderController controller) { this.controller = controller; IsHitTestVisible = false; }

    internal void SetOutput(int width, int height, bool moved = false)
    {
        if (outputWidth == width && outputHeight == height && !moved) return;
        outputWidth = width; outputHeight = height;
        ResetRenderReceipt("Positionnement de la surface ESP en cours.");
        InvalidateVisual();
    }

    internal void Publish(ProjectedFrame? value, double sourceAgeMs, long sourceTimestamp, int ttlMs)
    {
        Clear();
        long now = Stopwatch.GetTimestamp();
        if (value == null) return;
        if (!double.IsFinite(sourceAgeMs) || sourceAgeMs < 0 || sourceTimestamp <= 0 || sourceTimestamp > now ||
            ttlMs < 1 || ttlMs > FeedSample.ProjectionLifetimeMs)
        {
            UnavailableReason = "Horodatage de projection invalide.";
            return;
        }
        frame = value;
        initialAgeMs = sourceAgeMs;
        receivedTimestamp = sourceTimestamp;
        lifetimeMs = ttlMs;
        if (RemainingMs <= 0) { Clear("Projection expirée."); return; }
        // AppController registered this original receipt stamp before notifying
        // the UI. Telemetry identity is optional and never enables projection.
        if (controller.Performance.TryGetDrawToken(sourceTimestamp, sourceAgeMs, out var token))
            performanceToken = token;
        UnavailableReason = "Capture reçue ; rendu en attente.";
        InvalidateVisual();
    }

    internal void Clear(string reason = "Caméra non disponible.")
    {
        frame = null;
        initialAgeMs = 0;
        receivedTimestamp = 0;
        lifetimeMs = 0;
        performanceToken = null;
        ResetRenderReceipt(reason);
        InvalidateVisual();
    }

    internal void ExpireIfNeeded()
    {
        if (frame != null && RemainingMs <= 0) Clear("Projection expirée.");
    }

    private void ResetRenderReceipt(string reason)
    {
        ++presentationVersion;
        renderReceipt = null;
        UnavailableReason = reason;
    }

    internal bool TryGetRenderReceipt(ProjectedFrame expected, double sourceAgeMs, long sourceTimestamp,
        out ProjectionOutputMapping? mapping, out int markerCount, out string reason)
    {
        ExpireIfNeeded();
        mapping = null;
        markerCount = 0;
        reason = UnavailableReason;
        if (frame == null) return false;
        if (!ReferenceEquals(frame, expected) || receivedTimestamp != sourceTimestamp || initialAgeMs != sourceAgeMs)
        {
            reason = "La capture courante attend son rendu.";
            return false;
        }
        var receipt = renderReceipt;
        if (receipt == null || receipt.Version != presentationVersion || !ReferenceEquals(receipt.Frame, expected) ||
            receipt.SourceTimestamp != sourceTimestamp || receipt.SourceAgeMs != sourceAgeMs)
        {
            if (string.IsNullOrEmpty(reason)) reason = "Capture reçue ; rendu en attente.";
            return false;
        }
        if (receipt.Options != RenderOptions.Capture(controller.Settings) ||
            receipt.PlayerRevision != controller.Players.ReadSnapshot().Revision)
        {
            ResetRenderReceipt("Réglages modifiés ; nouveau rendu en attente.");
            reason = UnavailableReason;
            return false;
        }
        var dpi = VisualTreeHelper.GetDpi(this);
        if (dpi.DpiScaleX != receipt.DpiScaleX || dpi.DpiScaleY != receipt.DpiScaleY ||
            Math.Abs(ActualWidth * dpi.DpiScaleX - outputWidth) > 1 ||
            Math.Abs(ActualHeight * dpi.DpiScaleY - outputHeight) > 1)
        {
            ResetRenderReceipt("Positionnement de la surface ESP en cours.");
            reason = UnavailableReason;
            return false;
        }
        if (RemainingMs <= 0)
        {
            ExpireIfNeeded();
            reason = "Projection expirée.";
            return false;
        }
        mapping = receipt.Mapping;
        markerCount = receipt.MarkerCount;
        reason = "";
        return true;
    }

    protected override void OnRender(DrawingContext dc)
    {
        // A successful Publish is not a successful draw. Only the completed
        // render below can acknowledge this publication and these preferences.
        renderReceipt = null;
        UnavailableReason = "Rendu en attente.";
        base.OnRender(dc);
        var current = frame;
        var observedToken = performanceToken;
        var settings = controller.Settings;
        var options = RenderOptions.Capture(settings);
        long version = presentationVersion;
        if (!settings.EspEnabled || !settings.ShowProjectedEsp)
        { UnavailableReason = "Affichage ESP désactivé."; return; }
        if (!EspDisplayPolicy.HasProjectedProfile(settings))
        { UnavailableReason = "Aucun élément ESP activé dans les profils."; return; }
        if (current == null) { UnavailableReason = "Caméra non disponible."; return; }
        if (RemainingMs <= 0) { ExpireIfNeeded(); return; }
        if (!ProjectionOutputMapping.TryCreate(current.SourceWidth, current.SourceHeight,
            outputWidth, outputHeight, current.Viewport, settings.EspScaleMode,
            out var outputMapping, out var mappingReason))
        {
            UnavailableReason = mappingReason;
            return;
        }
        var mapping = outputMapping!;
        if (!mapping.HasVisibleViewport)
        {
            UnavailableReason = "Le viewport caméra est entièrement recadré par le mode d’adaptation choisi.";
            return;
        }
        var dpi = VisualTreeHelper.GetDpi(this);
        if (!double.IsFinite(dpi.DpiScaleX) || !double.IsFinite(dpi.DpiScaleY) || dpi.DpiScaleX <= 0 || dpi.DpiScaleY <= 0 ||
            Math.Abs(ActualWidth * dpi.DpiScaleX - outputWidth) > 1 ||
            Math.Abs(ActualHeight * dpi.DpiScaleY - outputHeight) > 1)
        {
            UnavailableReason = "Positionnement de la surface ESP en cours.";
            return;
        }
        // Map source geometry to physical output pixels first. Apply WPF's DPI
        // exactly once; the affine image transform never scales text or strokes.
        dc.PushTransform(new ScaleTransform(1 / dpi.DpiScaleX, 1 / dpi.DpiScaleY));
        var viewport = mapping.ClipViewport;
        dc.PushClip(new RectangleGeometry(new Rect(viewport.X, viewport.Y, viewport.Width, viewport.Height)));
        playerPaint.Update(settings.PlayerEsp, Theme.Cyan);
        zombiePaint.Update(settings.ZombieEsp, Theme.Orange);
        var players = new PlayerVisualLookup(controller.Players.ReadSnapshot());
        var visualById = new Dictionary<int, PlayerVisualState>();
        var visible = current.Markers.Where(m =>
        {
            PlayerVisualState? visual = null;
            if (m.Kind == "player" && !players.TryResolve(current.PlayerContextId, m.IdentityToken, m.EntityId, out visual)) return false;
            if (!EspDisplayPolicy.TryGetVisibleProfile(settings, m.Kind, m.DistanceMeters, true, out _, m.HeightMeters, visual) ||
                !mapping.IsMarkerVisible(m)) return false;
            if (visual != null) visualById[m.EntityId] = visual;
            return true;
        }).OrderByDescending(m => m.DistanceMeters).ToArray();
        PlayerVisualState? Visual(ProjectedMarker marker) => marker.Kind == "player" && visualById.TryGetValue(marker.EntityId, out var visual)
            ? visual : null;
        int Priority(ProjectedMarker marker) => marker.Kind == "player" && visualById.TryGetValue(marker.EntityId, out var visual)
            ? 1 + PlayerVisualLookup.Priority(visual) : 0;
        var labels = EspDisplayPolicy.SelectProjectedLabels(settings, visible, 64, Priority, Visual);
        var drawnIds = new HashSet<int>();
        var labelBlocks = new List<LabelBlock>();
        foreach (var marker in visible)
        {
            visualById.TryGetValue(marker.EntityId, out var visual);
            if (!EspDisplayPolicy.TryGetVisibleProfile(settings, marker.Kind, marker.DistanceMeters, true, out var selected,
                marker.HeightMeters, visual)) continue;
            var profile = selected!;
            if (marker.Kind == "player" && settings.AdminWatch?.PurpleEsp == true &&
                AdminWatchMatcher.IsListed(settings.AdminWatch, marker.Name) &&
                (visual == null || string.IsNullOrEmpty(visual.Color)))
                visual = (visual ?? new PlayerVisualState()) with { Color = settings.AdminWatch.Color };
            var paint = PaintForEntity(profile, marker.Kind, marker.DistanceMeters, marker.Health, marker.MaxHealth, visual);
            Brush color = paint.Color;
            var pen = paint.Line;
            var shadow = paint.Shadow;
            bool markerDrawn = false;
            ProjectionBox? outputBox = null;
            ProjectionPoint? outputAnchor = null;
            if (marker.Bounds is { } box && mapping.TryMapBox(box, out var mappedBox))
            {
                // Keep the true box when Fill crops it. Only drawing is clipped.
                outputBox = mappedBox;
                var rectangle = new Rect(mappedBox.Left, mappedBox.Top, mappedBox.Width, mappedBox.Height);
                if (profile.ShowBoxes)
                {
                    markerDrawn = true;
                    if (profile.BoxStyle == "corners") DrawCorners(dc, rectangle, shadow, pen);
                    else
                    {
                        dc.DrawRectangle(null, shadow, rectangle);
                        dc.DrawRectangle(null, pen, rectangle);
                    }
                }
            }
            if (marker.Anchor is { } anchor && mapping.TryMapPoint(anchor, out var mappedAnchor))
            {
                outputAnchor = mappedAnchor;
                var point = new Point(mappedAnchor.X, mappedAnchor.Y);
                if (profile.ShowBoxes)
                {
                    markerDrawn = true;
                    dc.DrawEllipse(null, shadow, point, 3.5, 3.5);
                    dc.DrawEllipse(null, pen, point, 3.5, 3.5);
                }
            }
            if (profile.ShowTracers && (outputBox != null || outputAnchor != null))
            {
                var start = new Point(viewport.X + viewport.Width / 2, viewport.Bottom - 1);
                var target = outputBox is { } bounds ? new Point((bounds.Left + bounds.Right) / 2, bounds.Bottom) :
                    new Point(outputAnchor!.Value.X, outputAnchor.Value.Y);
                dc.DrawLine(shadow, start, target);
                dc.DrawLine(pen, start, target);
                markerDrawn = true;
            }
            if (visual != null && PlayerVisualLookup.Priority(visual) > 0 && (outputBox != null || outputAnchor != null))
            {
                double accentX = outputBox?.Right ?? outputAnchor!.Value.X;
                double accentY = outputBox?.Top ?? outputAnchor!.Value.Y;
                if (accentX >= viewport.X && accentX <= viewport.Right && accentY >= viewport.Y && accentY <= viewport.Bottom)
                {
                    DrawDiamond(dc, new Point(accentX, accentY), paint, visual.Pinned);
                    markerDrawn = true;
                }
            }
            if (markerDrawn) drawnIds.Add(marker.EntityId);
            if (!labels.Contains(marker.EntityId) || (outputBox == null && outputAnchor == null)) continue;
            string label = profile.ShowNames ?
                (string.IsNullOrWhiteSpace(marker.Name) ? marker.Kind == "player" ? "Joueur" : "Zombie" : marker.Name) : "";
            if (profile.ShowDistances) label += (label.Length > 0 ? " · " : "") +
                marker.DistanceMeters.ToString("0", CultureInfo.GetCultureInfo("fr-FR")) + " m";
            if (profile.Rules?.ShowHeightIndicator == true)
            {
                string height = EntityDisplayRules.HeightIndicator(marker.HeightMeters);
                if (height.Length > 0) label += (label.Length > 0 ? " · " : "") + height;
            }
            if (marker.Kind == "player")
                label = PvpSenseLabels.Append(label, PvpSenseLabels.ForPlayer(settings.PvpSense,
                    marker.IsRunning, marker.IsCrouching, marker.IsJumping,
                    marker.HeldItemTypeId, marker.FacingLocalDegrees));
            else if (marker.Kind == "zombie")
                label = PvpSenseLabels.Append(label,
                    PvpSenseLabels.ForZombie(settings.PvpSense, marker.ZombieTargetsLocal));
            int? health = marker.Health is int value && value >= 0 ? value : null;
            int? maximum = marker.MaxHealth is int limit && limit > 0 ? limit : null;
            string healthLabel = !profile.ShowHealth ? "" : !health.HasValue ? "PV —" :
                health.Value.ToString("0", CultureInfo.GetCultureInfo("fr-FR")) +
                (maximum.HasValue ? " / " + maximum.Value.ToString("0", CultureInfo.GetCultureInfo("fr-FR")) : "") + " PV";
            bool showBar = profile.ShowHealth && health.HasValue && maximum.HasValue;
            if (label.Length == 0 && healthLabel.Length == 0) continue;
            double labelX = outputBox is { } b ? (b.Left + b.Right) / 2 : outputAnchor!.Value.X;
            double labelY = outputBox?.Top ?? outputAnchor!.Value.Y;
            var nameText = label.Length == 0 ? null : MarkerText(label, profile.FontSize, color, viewport.Width, dpi.PixelsPerDip);
            Brush healthColor = health.HasValue ? Brushes.White : Theme.Muted;
            var healthText = healthLabel.Length == 0 ? null : MarkerText(healthLabel, profile.FontSize, healthColor, viewport.Width, dpi.PixelsPerDip);
            double barWidth = showBar ? Math.Min(80, viewport.Width) : 0;
            double blockWidth = Math.Max(Math.Max(nameText?.Width ?? 0, healthText?.Width ?? 0), barWidth);
            double lineGap = nameText != null && healthText != null ? 2 : 0;
            // Keep space for the optional HP bar even when a read is unknown.
            double blockHeight = (nameText?.Height ?? 0) + lineGap + (healthText?.Height ?? 0) + (profile.ShowHealth ? 7 : 0);
            if (blockWidth > viewport.Width || blockHeight > viewport.Height) continue;
            double x = Math.Clamp(labelX - blockWidth / 2, viewport.X, viewport.Right - blockWidth);
            double y = Math.Clamp(labelY - blockHeight - 5, viewport.Y, viewport.Bottom - blockHeight);
            labelBlocks.Add(new(marker.EntityId, new(marker.EntityId, x, y, blockWidth, blockHeight, Priority(marker)),
                nameText, healthText, color, healthColor, lineGap, barWidth, health, maximum, showBar,
                new(labelX, labelY), paint));
        }
        var reserved = DrawOffscreenPlayers(dc, current, mapping, players, settings, dpi.PixelsPerDip, drawnIds);
        IReadOnlyDictionary<int, ProjectionBox>? placements = settings.PlayerFeatures.AvoidLabelOverlap
            ? LabelPlacement.Place(labelBlocks.Select(block => block.Candidate), viewport, reserved) : null;
        foreach (var block in labelBlocks)
        {
            ProjectionBox placement;
            if (placements != null)
            {
                if (!placements.TryGetValue(block.EntityId, out placement)) continue;
            }
            else placement = new(block.Candidate.Left, block.Candidate.Top,
                block.Candidate.Left + block.Candidate.Width, block.Candidate.Top + block.Candidate.Height);
            double x = placement.Left, y = placement.Top, blockWidth = placement.Width;
            // A short connector keeps shifted text associated with its entity.
            if (Math.Abs(x - block.Candidate.Left) > 1 || Math.Abs(y - block.Candidate.Top) > 1)
            {
                var start = new Point(Math.Clamp(block.Attachment.X, placement.Left, placement.Right),
                    Math.Clamp(block.Attachment.Y, placement.Top, placement.Bottom));
                var end = new Point(block.Attachment.X, block.Attachment.Y);
                dc.DrawLine(block.Paint.Shadow, start, end);
                dc.DrawLine(block.Paint.Line, start, end);
            }
            if (block.Name != null)
            {
                DrawMarkerText(dc, block.Name, block.Color, x + (blockWidth - block.Name.Width) / 2, y);
                y += block.Name.Height + block.LineGap;
            }
            if (block.HealthText != null)
            {
                DrawMarkerText(dc, block.HealthText, block.HealthColor, x + (blockWidth - block.HealthText.Width) / 2, y);
                y += block.HealthText.Height;
            }
            if (block.ShowBar)
            {
                double fraction = Math.Clamp((double)block.Health!.Value / block.Maximum!.Value, 0, 1);
                Brush fill = fraction <= .25 ? Brushes.OrangeRed : fraction <= .5 ? Brushes.Gold : Brushes.LimeGreen;
                var track = new Rect(x + (blockWidth - block.BarWidth) / 2, y + 3, block.BarWidth, 4);
                dc.DrawRectangle(Brushes.DimGray, new Pen(Brushes.Black, 2), track);
                if (fraction > 0) dc.DrawRectangle(fill, null, new Rect(track.X, track.Y, track.Width * fraction, track.Height));
            }
            drawnIds.Add(block.EntityId);
        }
        dc.Pop();
        dc.Pop();
        if (!ReferenceEquals(current, frame) || version != presentationVersion)
        {
            ResetRenderReceipt("La capture ou la sortie a changé pendant le rendu.");
            return;
        }
        if (RemainingMs <= 0) { ExpireIfNeeded(); return; }
        if (options != RenderOptions.Capture(settings) || players.Revision != controller.Players.ReadSnapshot().Revision)
        {
            ResetRenderReceipt("Réglages modifiés ; nouveau rendu en attente.");
            return;
        }
        // This acknowledges WPF drawing only, including a valid empty view.
        // It does not establish that a physical fuser has displayed the image.
        renderReceipt = new(current, initialAgeMs, receivedTimestamp, version, mapping, drawnIds.Count, options, players.Revision,
            dpi.DpiScaleX, dpi.DpiScaleY);
        UnavailableReason = "";
        // Count only completed drawing commands for a distinct capture. A valid
        // empty view also counts; redraws and old generations do not. This is
        // neither a GPU frame acknowledgement nor physical display latency.
        if (observedToken is { } completed) controller.Performance.ObserveDraw(completed);
    }

    private sealed record RenderReceipt(ProjectedFrame Frame, double SourceAgeMs, long SourceTimestamp,
        long Version, ProjectionOutputMapping Mapping, int MarkerCount, RenderOptions Options, long PlayerRevision,
        double DpiScaleX, double DpiScaleY);

    private sealed record LabelBlock(int EntityId, LabelPlacementCandidate Candidate,
        FormattedText? Name, FormattedText? HealthText, Brush Color, Brush HealthColor,
        double LineGap, double BarWidth, int? Health, int? Maximum, bool ShowBar,
        ProjectionPoint Attachment, MarkerPaint Paint);

    private MarkerPaint PaintForEntity(EntityEspSettings profile, string kind, double distanceMeters,
        int? health, int? maximumHealth, PlayerVisualState? visual)
    {
        var baseline = kind == "player" ? playerPaint : zombiePaint;
        string color = EntityDisplayRules.ResolveColor(profile, distanceMeters, health, maximumHealth, visual?.Color);
        if (color == profile.Color) return baseline;
        var key = (color, profile.LineThickness);
        if (customPaints.TryGetValue(key, out var cached)) return cached;
        // Bound frozen resource caching independently from the entity stream.
        if (customPaints.Count >= 64) customPaints.Clear();
        var paint = new MarkerPaint();
        paint.Update(color, profile.LineThickness, baseline.Color);
        customPaints.Add(key, paint);
        return paint;
    }

    private List<ProjectionBox> DrawOffscreenPlayers(DrawingContext dc, ProjectedFrame current,
        ProjectionOutputMapping mapping, PlayerVisualLookup players, LoaderSettings settings,
        double pixelsPerDip, HashSet<int> drawnIds)
    {
        var reserved = new List<ProjectionBox>();
        if (!settings.PlayerFeatures.OffscreenIndicators || !settings.PlayerEsp.Enabled) return reserved;
        // A partly visible validated box already explains the player's position.
        // This set ignores element toggles, so arrows never label an on-screen
        // player merely because the user disabled boxes/names.
        var onScreenIds = current.Markers.Where(marker => marker.Kind == "player" && mapping.IsMarkerVisible(marker))
            .Select(marker => marker.EntityId).ToHashSet();
        var candidates = new List<(ProjectedPlayerDirection Player, PlayerVisualState Visual)>();
        foreach (var player in current.PlayerDirections)
        {
            if (onScreenIds.Contains(player.EntityId) ||
                !players.TryResolve(current.PlayerContextId, player.IdentityToken, player.EntityId, out var visual) ||
                !EspDisplayPolicy.TryGetVisibleProfile(settings, "player", player.DistanceMeters, false, out _,
                    player.HeightMeters, visual)) continue;
            candidates.Add((player, visual));
        }
        var viewport = mapping.ClipViewport;
        int maximum = Math.Clamp(settings.PlayerFeatures.MaximumOffscreenIndicators, 1, 32);
        int arrows = 0;
        foreach (var candidate in candidates.OrderByDescending(c => PlayerVisualLookup.Priority(c.Visual))
            .ThenBy(c => c.Player.DistanceMeters).ThenBy(c => c.Player.EntityId))
        {
            if (arrows >= maximum) break;
            if (!OffscreenProjection.TryPlace(candidate.Player.Direction, mapping, current.Viewport, 22, out var arrow)) continue;
            var paint = PaintForEntity(settings.PlayerEsp, "player", candidate.Player.DistanceMeters,
                candidate.Player.Health, candidate.Player.MaxHealth, candidate.Visual);
            var point = new Point(arrow.Position.X, arrow.Position.Y);
            double dx = arrow.Direction.X, dy = arrow.Direction.Y;
            string captionText = settings.PlayerFeatures.OffscreenDistances
                ? candidate.Player.DistanceMeters.ToString("0", CultureInfo.GetCultureInfo("fr-FR")) + " m" : "";
            if (settings.PlayerEsp.Rules?.ShowHeightIndicator == true)
            {
                string height = EntityDisplayRules.HeightIndicator(candidate.Player.HeightMeters);
                if (height.Length > 0) captionText += (captionText.Length > 0 ? " · " : "") + height;
            }
            FormattedText? distance = captionText.Length > 0
                ? MarkerText((arrow.Behind ? "↶ " : "") + captionText,
                    11, paint.Color, Math.Min(160, viewport.Width), pixelsPerDip) : null;
            double textX = 0, textY = 0;
            var reservedBox = new ProjectionBox(point.X - 10, point.Y - 10, point.X + 10, point.Y + 10);
            if (distance != null)
            {
                if (OffscreenProjection.TryPlaceCaption(arrow, distance.Width, distance.Height, viewport, 10, out var caption))
                {
                    textX = caption.Left; textY = caption.Top;
                    reservedBox = new(Math.Min(reservedBox.Left, caption.Left), Math.Min(reservedBox.Top, caption.Top),
                        Math.Max(reservedBox.Right, caption.Right), Math.Max(reservedBox.Bottom, caption.Bottom));
                }
                else distance = null;
            }
            if (reserved.Any(other => LabelPlacement.Intersects(reservedBox, other, 4))) continue;
            var triangle = new StreamGeometry();
            using (var context = triangle.Open())
            {
                context.BeginFigure(new Point(point.X + dx * 8, point.Y + dy * 8), true, true);
                context.LineTo(new Point(point.X - dx * 6 - dy * 5, point.Y - dy * 6 + dx * 5), true, false);
                context.LineTo(new Point(point.X - dx * 6 + dy * 5, point.Y - dy * 6 - dx * 5), true, false);
            }
            triangle.Freeze();
            dc.DrawGeometry(null, paint.Shadow, triangle);
            dc.DrawGeometry(arrow.Behind ? Brushes.Transparent : paint.Color, paint.Line, triangle);
            if (distance != null) DrawMarkerText(dc, distance, paint.Color, textX, textY);
            reserved.Add(reservedBox);
            drawnIds.Add(candidate.Player.EntityId);
            ++arrows;
        }
        return reserved;
    }

    private static void DrawDiamond(DrawingContext dc, Point center, MarkerPaint paint, bool filled)
    {
        var geometry = new StreamGeometry();
        using (var context = geometry.Open())
        {
            context.BeginFigure(new Point(center.X, center.Y - 5), true, true);
            context.LineTo(new Point(center.X + 5, center.Y), true, false);
            context.LineTo(new Point(center.X, center.Y + 5), true, false);
            context.LineTo(new Point(center.X - 5, center.Y), true, false);
        }
        geometry.Freeze();
        dc.DrawGeometry(null, paint.Shadow, geometry);
        dc.DrawGeometry(filled ? paint.Color : Brushes.Transparent, paint.Line, geometry);
    }

    private readonly record struct RuleOptions(bool HeightFilter, int HeightMeters, bool ExemptPinned, bool HeightIndicator,
        string ColorMode, int LowHealth, int HighHealth, int NearDistance, int FarDistance,
        string LowColor, string MiddleColor, string HighColor)
    {
        internal static RuleOptions? Capture(EntityDisplayRulesSettings? value) => value == null ? null :
            new(value.HeightFilterEnabled, value.MaxHeightDifferenceMeters, value.ExemptPinnedFromHeightFilter,
                value.ShowHeightIndicator, value.ColorMode, value.HealthLowPercent, value.HealthHighPercent,
                value.DistanceNearMeters, value.DistanceFarMeters, value.LowColor, value.MiddleColor, value.HighColor);
    }

    private readonly record struct ProfileOptions(bool Enabled, bool Boxes, bool Names, bool Health,
        bool Distances, bool Tracers, string Color, string BoxStyle, int Distance, double FontSize, double LineThickness,
        RuleOptions? Rules)
    {
        internal static ProfileOptions? Capture(EntityEspSettings? value) => value == null ? null :
            new(value.Enabled, value.ShowBoxes, value.ShowNames, value.ShowHealth, value.ShowDistances,
                value.ShowTracers, value.Color, value.BoxStyle, value.MaxDistance, value.FontSize, value.LineThickness,
                RuleOptions.Capture(value.Rules));
    }

    private readonly record struct RenderOptions(bool Enabled, bool Projected, string ScaleMode,
        int Monitor, string OutputMode, string FuserDevice, ProfileOptions? Players, ProfileOptions? Zombies,
        bool Offscreen, bool OffscreenDistances, bool AvoidLabelOverlap, int MaximumArrows,
        bool PvpHeldItem, bool PvpMovement, bool PvpFacing, int PvpFacingCone, bool PvpZombieTarget)
    {
        internal static RenderOptions Capture(LoaderSettings settings) => new(settings.EspEnabled,
            settings.ShowProjectedEsp, settings.EspScaleMode, settings.MonitorIndex, settings.OutputMode,
            settings.FuserDeviceName, ProfileOptions.Capture(settings.PlayerEsp), ProfileOptions.Capture(settings.ZombieEsp),
            settings.PlayerFeatures.OffscreenIndicators, settings.PlayerFeatures.OffscreenDistances,
            settings.PlayerFeatures.AvoidLabelOverlap, settings.PlayerFeatures.MaximumOffscreenIndicators,
            settings.PvpSense.ShowHeldItemId, settings.PvpSense.ShowMovement,
            settings.PvpSense.ShowFacing, settings.PvpSense.FacingConeDegrees, settings.PvpSense.ShowZombieTarget);
    }

    private static void DrawCorners(DrawingContext dc, Rect box, Pen shadow, Pen line)
    {
        double dx = Math.Min(28, box.Width * .25), dy = Math.Min(28, box.Height * .2);
        foreach (Pen pen in new[] { shadow, line })
        {
            dc.DrawLine(pen, box.TopLeft, new Point(box.Left + dx, box.Top));
            dc.DrawLine(pen, box.TopLeft, new Point(box.Left, box.Top + dy));
            dc.DrawLine(pen, box.TopRight, new Point(box.Right - dx, box.Top));
            dc.DrawLine(pen, box.TopRight, new Point(box.Right, box.Top + dy));
            dc.DrawLine(pen, box.BottomLeft, new Point(box.Left + dx, box.Bottom));
            dc.DrawLine(pen, box.BottomLeft, new Point(box.Left, box.Bottom - dy));
            dc.DrawLine(pen, box.BottomRight, new Point(box.Right - dx, box.Bottom));
            dc.DrawLine(pen, box.BottomRight, new Point(box.Right, box.Bottom - dy));
        }
    }

    // Cache only frozen drawing resources, never positions or camera data.
    // The two profiles have independent resource keys and are applied at redraw.
    private sealed class MarkerPaint
    {
        private string key = "";
        private double thickness;
        internal Brush Color { get; private set; } = Brushes.White;
        internal Pen Line { get; private set; } = new(Brushes.White, 1.5);
        internal Pen Shadow { get; private set; } = new(Brushes.Black, 3.5);

        internal void Update(EntityEspSettings profile, Brush fallback)
            => Update(profile.Color, profile.LineThickness, fallback);

        internal void Update(string color, double lineThickness, Brush fallback)
        {
            if (key == color && thickness == lineThickness) return;
            key = color; thickness = lineThickness;
            Color = SafeBrush(key, fallback);
            Line = new Pen(Color, thickness); Line.Freeze();
            Shadow = new Pen(Brushes.Black, thickness + 2); Shadow.Freeze();
        }
    }

    private static FormattedText MarkerText(string value, double size, Brush color, double viewportWidth, double pixelsPerDip) =>
        new(value, CultureInfo.GetCultureInfo("fr-FR"), FlowDirection.LeftToRight,
            MarkerTypeface, size, color, pixelsPerDip)
        {
            MaxTextWidth = Math.Max(1, Math.Min(360, viewportWidth)),
            MaxLineCount = 1,
            Trimming = TextTrimming.CharacterEllipsis
        };

    private static void DrawMarkerText(DrawingContext dc, FormattedText text, Brush color, double x, double y)
    {
        var geometry = text.BuildGeometry(new Point(x, y));
        // Paint the glyph fill last so the centered outline cannot cover its
        // thin strokes, especially when the fuser removes the black key color.
        dc.DrawGeometry(null, new Pen(Brushes.Black, 2), geometry);
        dc.DrawGeometry(color, null, geometry);
    }

    private static Brush SafeBrush(string value, Brush fallback)
    {
        try { return Theme.Brush(value); }
        catch (FormatException) { return fallback; }
        catch (ArgumentException) { return fallback; }
        catch (NotSupportedException) { return fallback; }
    }
}
