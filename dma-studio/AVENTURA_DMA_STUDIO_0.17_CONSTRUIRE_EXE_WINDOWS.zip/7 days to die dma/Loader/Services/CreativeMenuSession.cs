using System;
using System.Diagnostics;

namespace SevenDaysLoader.Services;

// Independent from the ESP feed: command outcomes never publish or invalidate
// entity captures. This class owns only the UI's short-lived command context.
public sealed class CreativeMenuSession
{
    private readonly object gate = new();
    private readonly Func<long> timestamp;
    private readonly Func<DateTime> utcNow;
    private int generation;
    private long nextSequence;
    private uint processId;
    private string contextId = "";
    private bool readerConnected;
    private FeedSample? sample;
    private CreativeMenuRequest? pending;
    private CreativeMenuState state = new();

    public CreativeMenuSession() : this(Stopwatch.GetTimestamp, () => DateTime.UtcNow) { }

    internal CreativeMenuSession(Func<long> timestamp, Func<DateTime> utcNow)
    {
        this.timestamp = timestamp ?? throw new ArgumentNullException(nameof(timestamp));
        this.utcNow = utcNow ?? throw new ArgumentNullException(nameof(utcNow));
    }

    public CreativeMenuState State
    {
        get { lock (gate) { RefreshAvailability(); return state; } }
    }

    public void Reset(int currentGeneration)
    {
        lock (gate)
        {
            generation = currentGeneration;
            processId = 0;
            contextId = "";
            readerConnected = false;
            sample = null;
            pending = null;
            state = new();
        }
    }

    public bool ObserveContext(int expectedGeneration, uint currentProcessId, FeedSample? currentSample, bool isReaderConnected)
    {
        lock (gate)
        {
            if (expectedGeneration != generation) return false;
            string incomingContext = currentSample?.Snapshot.PlayerContextId ?? "";
            bool changed = processId != currentProcessId || !string.Equals(contextId, incomingContext, StringComparison.Ordinal);
            processId = currentProcessId;
            contextId = incomingContext;
            readerConnected = isReaderConnected;
            sample = currentSample;
            if (changed)
                state = state with
                {
                    ObservedEnabled = null, ConfirmedUtc = null,
                    Code = pending == null ? "A_ACTUALISER" : "EN_ATTENTE",
                    Message = pending == null ? "Actualise l’état du menu créatif de cette partie." :
                        "La partie a changé ; attente du résultat de la demande précédente."
                };
            RefreshAvailability();
            return true;
        }
    }

    public CreativeMenuRequest Begin(int expectedGeneration, bool? desiredEnabled)
        => BeginCore(expectedGeneration, desiredEnabled, false);

    public CreativeMenuRequest BeginToggle(int expectedGeneration)
        => BeginCore(expectedGeneration, null, true);

    private CreativeMenuRequest BeginCore(int expectedGeneration, bool? desiredEnabled, bool toggle)
    {
        lock (gate)
        {
            RefreshAvailability();
            if (expectedGeneration != generation || !state.CanRequest)
                throw new InvalidOperationException(state.IsBusy ? "Une demande de menu créatif est déjà en cours." :
                    "Une partie récente lue par la DMA locale est nécessaire.");
            if (nextSequence == long.MaxValue)
                throw new InvalidOperationException("Séquence de commandes épuisée. Redémarre le loader.");
            pending = new CreativeMenuRequest
            {
                Sequence = ++nextSequence, RequestId = Guid.NewGuid().ToString("N"),
                ExpectedProcessId = processId, ExpectedPlayerContextId = contextId,
                DesiredEnabled = desiredEnabled, Toggle = toggle, RequestedTimestamp = timestamp()
            };
            state = state with
            {
                IsBusy = true, Code = "EN_ATTENTE",
                Message = toggle ? "Inversion de l’état actuel demandée ; lecture et confirmation en attente." :
                    desiredEnabled.HasValue ? "Demande envoyée au lecteur ; confirmation en attente." :
                    "Lecture de l’état du menu créatif en cours."
            };
            return pending.Copy();
        }
    }

    public bool Accept(int expectedGeneration, CreativeMenuResult result)
    {
        lock (gate)
        {
            RefreshAvailability();
            if (expectedGeneration != generation || pending == null || !CreativeMenuProtocol.IsValidResult(result) ||
                result.Sequence != pending.Sequence || !string.Equals(result.RequestId, pending.RequestId, StringComparison.Ordinal) ||
                result.ProcessId != pending.ExpectedProcessId ||
                !string.Equals(result.PlayerContextId, pending.ExpectedPlayerContextId, StringComparison.Ordinal) ||
                result.DesiredEnabled != pending.DesiredEnabled || result.Toggle != pending.Toggle) return false;
            bool sameContext = state.Available && processId == result.ProcessId &&
                string.Equals(contextId, result.PlayerContextId, StringComparison.Ordinal);
            pending = null;
            state = sameContext ? state with
            {
                IsBusy = false, ObservedEnabled = result.ObservedEnabled,
                ConfirmedUtc = result.ObservedEnabled.HasValue ? utcNow() : null,
                Code = result.Code, Message = result.Message
            } : state with
            {
                IsBusy = false, ObservedEnabled = null, ConfirmedUtc = null,
                Code = "CONTEXTE_CHANGE", Message = "Le résultat concerne une partie précédente ; actualise la partie courante."
            };
            return true;
        }
    }

    public bool FailSend(int expectedGeneration, CreativeMenuRequest request, string message)
    {
        lock (gate)
        {
            RefreshAvailability();
            if (expectedGeneration != generation || pending == null || request.Sequence != pending.Sequence ||
                !string.Equals(request.RequestId, pending.RequestId, StringComparison.Ordinal)) return false;
            pending = null;
            string detail = string.IsNullOrWhiteSpace(message) ? "L’envoi n’a pas été confirmé." : message;
            if (detail.Length > CreativeMenuProtocol.MaxMessageLength) detail = detail[..CreativeMenuProtocol.MaxMessageLength];
            state = state with
            {
                IsBusy = false, ObservedEnabled = null, ConfirmedUtc = null, Code = "ENVOI_NON_CONFIRME",
                Message = detail
            };
            return true;
        }
    }

    private void RefreshAvailability()
    {
        bool available = readerConnected && processId > 0 && CreativeMenuProtocol.IsGuidN(contextId) && sample?.IsFresh == true;
        if (pending != null && CreativeMenuProtocol.IsExpired(pending, timestamp()))
        {
            pending = null;
            state = state with
            {
                IsBusy = false, ObservedEnabled = null, ConfirmedUtc = null,
                Code = "DELAI_DEPASSE", Message = "Résultat non reçu dans les 10 secondes. État indéterminé ; aucune relance automatique."
            };
        }
        if (!available)
            state = state with { ObservedEnabled = null, ConfirmedUtc = null };
        state = state with
        {
            Available = available, IsBusy = pending != null,
            ProcessId = available ? processId : 0, PlayerContextId = available ? contextId : ""
        };
    }
}
